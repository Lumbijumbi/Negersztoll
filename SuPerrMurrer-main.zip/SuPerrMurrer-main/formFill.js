/**
 * Form filling utilities with character-by-character priority
 */
const config = require('./config');

/**
 * Returns true when an error message indicates a fatal browser/context closed condition.
 * @param {string} errMsg - Error message string
 * @returns {boolean}
 */
function isBrowserClosedError(errMsg) {
  if (!errMsg) return false;
  return errMsg.includes('Target page') ||
    errMsg.includes('context or browser has been closed') ||
    errMsg.includes('browser has been closed') ||
    errMsg.includes('context was destroyed') ||
    errMsg.includes('session closed') ||
    errMsg.includes('page crashed');
}

/**
 * Fill form field with realistic typing (character-by-character FIRST)
 * Uses page.type(selector, char, { delay }) for trusted keystroke delivery.
 * No page.fill() or page.evaluate() — both create synthetic events that
 * DataDome detects (isTrusted:false, missing keyboard event chain).
 * Field clearing uses keyboard actions (Control+A + Backspace) to keep
 * the full event sequence natural and trusted.
 * 
 * @param {Page} page - Playwright page object
 * @param {string} selector - CSS selector for input field
 * @param {string} text - Text to fill
 * @param {Object} options - Additional options
 * @returns {Promise<boolean>} - True if successful
 */
async function fastFill(page, selector, text, options = {}) {
  const {
    typeDelayMin = config.form.typeDelayMin,
    typeDelayMax = config.form.typeDelayMax,
    clearFirst = true,
    logPrefix = '[fastFill]'
  } = options;

  // Guard against a closed/crashed browser before attempting any interaction
  try {
    if (page.isClosed && page.isClosed()) {
      console.warn(`${logPrefix} Page is closed, aborting form fill for ${selector}`);
      return false;
    }
  } catch (_) {
    console.warn(`${logPrefix} Page state check failed, aborting form fill for ${selector}`);
    return false;
  }

  try {
    // Step 1: Focus on the element
    try {
      await page.focus(selector).catch(() => {});
    } catch (e) {
      console.warn(`${logPrefix} Failed to focus on ${selector}`);
    }

    // Step 2: Clear the field if requested using keyboard actions.
    // Control+A selects all existing text; Backspace deletes it; Delete covers
    // any edge case where Backspace alone doesn't clear. This produces trusted
    // keyboard events that DataDome sees as natural user input.
    if (clearFirst) {
      try {
        await page.keyboard.press('Control+A').catch(() => {});
        await page.keyboard.press('Backspace').catch(() => {});
        await page.keyboard.press('Delete').catch(() => {});
      } catch (e) {
        console.warn(`${logPrefix} Failed to clear field ${selector}`);
      }
    }

    // Step 3: TYPE CHARACTER-BY-CHARACTER using page.type()
    // page.type(selector, char, { delay }) is Patchright's own native typing method.
    // It focuses the element, fires trusted keydown/keypress/input/keyup events,
    // and produces the correct isTrusted:true keyboard event chain that DataDome expects.
    // Unlike page.keyboard.type() which sends to the currently focused element
    // without per-character focus validation, page.type() ensures the element stays
    // focused and each character is properly dispatched.
    console.log(`${logPrefix} Typing character-by-character into ${selector}`);
    let successfulChars = 0;
    let browserClosed = false;

    for (const char of text) {
      try {
        const delay = Math.floor(Math.random() * (typeDelayMax - typeDelayMin + 1)) + typeDelayMin;
        await page.type(selector, char, { delay });
        if (browserClosed) break;
        successfulChars++;
      } catch (e) {
        const errMsg = (e && e.message) || '';
        if (isBrowserClosedError(errMsg)) {
          browserClosed = true;
          break;
        }
        console.warn(`${logPrefix} Failed to type char '${char}'`);
      }
    }

    if (browserClosed) {
      console.warn(`${logPrefix} Browser/context closed during character typing, aborting`);
      return false;
    }

    console.log(`${logPrefix} Typed ${successfulChars}/${text.length} characters successfully`);

    // Step 4: Verify the value was set
    const filledValue = await page.inputValue(selector).catch(() => '');
    if (filledValue === text) {
      console.log(`${logPrefix} ✓ Character-by-character fill successful for ${selector}`);
      return true;
    }

    // Do NOT fall back to page.fill() or page.evaluate() DOM manipulation.
    // Those create synthetic input events (missing keyboard chain, isTrusted:false)
    // that DataDome detects.
    console.warn(`${logPrefix} ✗ Fill verification failed for ${selector} (${filledValue.length}/${text.length} chars)`);
    return false;

  } catch (error) {
    console.error(`${logPrefix} Unexpected error: `, error?.message);
    return false;
  }
}

/**
 * Fill multiple form fields in sequence
 * @param {Page} page - Playwright page object
 * @param {Object} fieldMap - { selector: value, ...  }
 * @param {Object} options - Additional options
 * @returns {Promise<Object>} - { success: boolean, filled: number, total: number }
 */
async function fillForm(page, fieldMap, options = {}) {
  let filledCount = 0;
  const totalCount = Object.keys(fieldMap).length;

  for (const [selector, value] of Object.entries(fieldMap)) {
    const success = await fastFill(page, selector, value, options);
    if (success) filledCount++;
  }

  return {
    success: filledCount === totalCount,
    filled: filledCount,
    total: totalCount
  };
}

module.exports = {
  fastFill,
  fillForm,
  isBrowserClosedError
};