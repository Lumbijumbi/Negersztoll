/**
 * ============================================================================
 * COOKIE EXPORTER - Capture login-page session data for external tool reuse
 * ============================================================================
 *
 * When enabled, captures cookies + request headers + proxy information after
 * the login form page loads successfully, and writes export files in one of
 * four formats for external usage outside the app.
 *
 * EXPORT FORMATS:
 * ---------------
 *
 * 1. sessionComplete (default):
 *    Single JSON file containing only the raw cookie array — no metadata.
 *    Best for: Direct cookie injection into any HTTP client
 *    Output: {username}_{timestamp}.json
 *    [
 *      { name, value, domain, path, secure, httpOnly, sameSite },
 *      ...
 *    ]
 *
 * 2. sessionOnly:
 *    Same as sessionComplete — raw cookie array only, no metadata.
 *    Output: {username}_{timestamp}.json
 *    [
 *      { name, value, domain, path, secure, httpOnly, sameSite },
 *      ...
 *    ]
 *
 * 3. dataDomeOnly:
 *    Three separate JSON files for DataDome-specific workflows.
 *    Best for: External DataDome challenge handling
 *    Output:
 *      - {username}_{timestamp}_datadome.json: Just the datadome cookie
 *      - {username}_{timestamp}_headers.json:  Request headers
 *      - {username}_{timestamp}_proxy.json:    Proxy connection info with IP
 *
 * 4. DatadomePostRequestCookieonly:
 *    Single JSON file containing only the datadome cookie value read from the
 *    browser context cookie store after successful login.
 *    Reads context().cookies() after CAS authentication — zero event listeners,
 *    zero page.route() calls, zero timers during credential processing.
 *    Best for: Stealth-safe capture of the datadome token after login.
 *    Output: {username}_{timestamp}_datadome_post.json
 *    { "datadome": "<value>" }
 *
 * Configuration in config.js:
 *   cookieExport: {
 *     enabled: true/false,
 *     exportDir: "CookieExports",
 *     format: "sessionComplete" | "sessionOnly" | "dataDomeOnly" | "DatadomePostRequestCookieonly"
 *   }
 */

'use strict';

const fs   = require('fs');
const path = require('path');

class CookieExporter {
  /**
   * @param {object} options
   * @param {string} options.exportDir   - Directory to write export files into
   * @param {boolean} [options.enabled]  - Feature gate (default true)
   * @param {string} [options.format]    - Export format: 'sessionComplete', 'sessionOnly', 'dataDomeOnly', 'DatadomePostRequestCookieonly' (default 'sessionComplete')
   */
  constructor(options = {}) {
    this.exportDir = options.exportDir || path.join(process.cwd(), 'CookieExports');
    this.enabled   = options.enabled !== false;
    this.format    = options.format || 'sessionComplete';

    if (this.enabled) {
      this._ensureDir();
    }
  }

  // ── private ──────────────────────────────────────────────────────────────

  _ensureDir() {
    if (!fs.existsSync(this.exportDir)) {
      fs.mkdirSync(this.exportDir, { recursive: true });
    }
  }

  /**
   * Sanitize a string to be safe in a filename.
   * @param {string} str
   * @returns {string}
   */
  _sanitize(str) {
    if (!str || typeof str !== 'string') return 'unknown';
    return str.replace(/[/\\?%*|"<>:\s\n\r\t@]/g, '_').substring(0, 80);
  }

  _writeExportJson(filename, data) {
    this._ensureDir();
    const filePath = path.join(this.exportDir, filename);
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
    return filePath;
  }

  _findDatadomeCookie(cookies) {
    if (!Array.isArray(cookies)) return null;
    return cookies.find(c =>
      c && typeof c.name === 'string' &&
      this.datadomeCookieNames.includes(c.name.toLowerCase())
    ) || null;
  }

  /**
   * Write export files for dataDomeOnly format (3 separate files).
   * @param {string} basePath - Base file path without extension
   * @param {object} exportData - Export data object
   * @returns {string[]} Array of written file paths
   */
  _writeDataDomeOnlyFormat(basePath, exportData) {
    const written = [];

    // File 1: DataDome cookie only
    const dataDomeCookie = exportData.cookies.find(c => c.name.toLowerCase() === 'datadome');
    if (dataDomeCookie) {
      const dataDomePath = `${basePath}_datadome.json`;
      fs.writeFileSync(dataDomePath, JSON.stringify({
        capturedAt: exportData.capturedAt,
        username: exportData.username,
        cookie: dataDomeCookie
      }, null, 2), 'utf8');
      written.push(dataDomePath);
    }

    // File 2: Request headers
    const headersPath = `${basePath}_headers.json`;
    fs.writeFileSync(headersPath, JSON.stringify({
      capturedAt: exportData.capturedAt,
      username: exportData.username,
      headers: exportData.headers
    }, null, 2), 'utf8');
    written.push(headersPath);

    // File 3: Proxy connection information
    const proxyPath = `${basePath}_proxy.json`;
    fs.writeFileSync(proxyPath, JSON.stringify({
      capturedAt: exportData.capturedAt,
      username: exportData.username,
      proxy: exportData.proxy,
      proxyIP: exportData.proxy ? exportData.proxy.split(':')[0] : null
    }, null, 2), 'utf8');
    written.push(proxyPath);

    return written;
  }

  /**
   * Write export file containing only the raw cookie array (no metadata).
   * Used by sessionComplete and sessionOnly formats.
   * @param {string} filePath - Full file path
   * @param {object} exportData - Export data object
   */
  _writeCookiesOnlyFormat(filePath, exportData) {
    fs.writeFileSync(filePath, JSON.stringify(exportData.cookies, null, 2), 'utf8');
  }

  /**
   * Build a Python requests code snippet from the captured data.
   * @param {object} exportData
   * @returns {string}
   */
  _buildPythonSnippet(exportData) {
    const pyEscape = s => String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"');

    const cookieDict = exportData.cookies
      .map(c => `    "${pyEscape(c.name)}": "${pyEscape(c.value)}"`)
      .join(',\n');

    const headerDict = Object.entries(exportData.headers)
      .map(([k, v]) => `    "${pyEscape(k)}": "${pyEscape(v)}"`)
      .join(',\n');

    const proxySection = exportData.proxy
      ? `proxies = {\n    "http":  "${exportData.proxy}",\n    "https": "${exportData.proxy}"\n}\n\n`
      : '';

    return `import requests

# Session captured by SuPerrMurrer at ${exportData.capturedAt}
# Login URL: ${exportData.loginUrl}
# Username:  ${exportData.username || 'unknown'}

cookies = {
${cookieDict}
}

headers = {
${headerDict}
}

${proxySection}session = requests.Session()
session.cookies.update(cookies)
session.headers.update(headers)
${exportData.proxy ? '\n# Uncomment to use the original proxy:\n# session.proxies.update(proxies)\n' : ''}
# Example: load the login page with the captured session
response = session.get(
    "${exportData.loginUrl}",
    headers=headers,
    cookies=cookies,
${exportData.proxy ? '    # proxies=proxies,\n' : ''}    timeout=30
)
print(response.status_code, response.url)
`;
  }

  // ── public ───────────────────────────────────────────────────────────────

  /**
   * Capture the current page cookies + request headers and write an export
   * file.  Called after the login form page loads and popup is dismissed.
   *
   * @param {object} page       - Playwright page object
   * @param {string} username   - Credential being tested (may be empty)
   * @param {string} loginUrl   - Login page URL
   * @param {string} proxy      - Raw upstream proxy string
   * @returns {Promise<string|null>} Path of written file, or null on failure
   */
  async capture(page, username, loginUrl, proxy) {
    if (!this.enabled) return null;

    try {
      const ts       = new Date().toISOString().replace(/[:.]/g, '-').replace('T', '_').slice(0, 19);
      const safeName = this._sanitize(username || 'unknown');

      // DatadomePostRequestCookieonly: read the datadome cookie from the browser
      // context cookie store after login — zero listeners, zero timers.
      if (this.format === 'DatadomePostRequestCookieonly') {
        this._ensureDir();
        let rawCookies;
        try {
          rawCookies = await page.context().cookies();
        } catch (cookieErr) {
          const cookieErrMsg = cookieErr?.message || String(cookieErr);
          console.warn(`[COOKIE-EXPORT] DatadomePostRequestCookieonly: failed to read cookies for "${username || 'unknown'}": ${cookieErrMsg}. Export skipped.`);
          return null;
        }
        const ddCookie = rawCookies.find(c =>
          c && typeof c.name === 'string' && c.name.toLowerCase() === 'datadome'
        );
        if (!ddCookie) {
          console.warn(`[COOKIE-EXPORT] DatadomePostRequestCookieonly: no datadome cookie found for "${username || 'unknown'}". Export skipped.`);
          return null;
        }
        const filename = `${safeName}_${ts}_datadome_post.json`;
        const filePath = path.join(this.exportDir, filename);
        fs.writeFileSync(filePath, JSON.stringify({ datadome: ddCookie.value }, null, 2), 'utf8');
        return filePath;
      }

      // Gather cookies from browser context
      const rawCookies = await page.context().cookies().catch(() => []);
      const cookies = rawCookies.map(c => ({
        name:     c.name,
        value:    c.value,
        domain:   c.domain  || '',
        path:     c.path    || '/',
        secure:   !!c.secure,
        httpOnly: !!c.httpOnly,
        sameSite: c.sameSite || 'Lax'
      }));

      // Write file(s) based on format
      this._ensureDir();

      if (this.format === 'dataDomeOnly') {
        // Gather request headers sent by the browser via page.evaluate
        const headers = await page.evaluate(() => {
          // Build a minimal, useful header set from the browser
          const ua = navigator.userAgent;
          return {
            'User-Agent':      ua,
            'Accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': navigator.language || 'de-CH,de;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br'
          };
        }).catch(() => ({}));

        const exportData = {
          capturedAt: new Date().toISOString(),
          username:   username || 'unknown',
          loginUrl:   loginUrl || '',
          proxy:      proxy || null,
          userAgent:  headers['User-Agent'] || '',
          cookies,
          headers
        };

        // Write 3 separate files for dataDomeOnly format
        const basePath = path.join(this.exportDir, `${safeName}_${ts}`);
        const writtenPaths = this._writeDataDomeOnlyFormat(basePath, exportData);
        return writtenPaths[0]; // Return first path for consistency
      } else {
        // sessionComplete, sessionOnly, and any unrecognised format: raw cookie array only
        const exportData = { cookies };
        const filename = `${safeName}_${ts}.json`;
        const filePath = path.join(this.exportDir, filename);
        this._writeCookiesOnlyFormat(filePath, exportData);
        return filePath;
      }
    } catch (err) {
      const errorMessage = err?.message || String(err);
      console.warn(`[COOKIE-EXPORT] Export failed for "${username || 'unknown'}": ${errorMessage}`);
      return null;
    }
  }

  /**
   * List all export files in the export directory.
   * @returns {{ filename: string, capturedAt: string|null, username: string|null, size: number }[]}
   */
  listExports() {
    if (!fs.existsSync(this.exportDir)) return [];
    return fs.readdirSync(this.exportDir)
      .filter(f => f.endsWith('.json'))
      .map(f => {
        const fp   = path.join(this.exportDir, f);
        const stat = fs.statSync(fp);
        let capturedAt = null;
        let username   = null;
        try {
          const d = JSON.parse(fs.readFileSync(fp, 'utf8'));
          capturedAt = d.capturedAt || null;
          username   = d.username   || null;
        } catch (_) {}
        return { filename: f, capturedAt, username, size: stat.size };
      })
      .sort((a, b) => (b.capturedAt || '').localeCompare(a.capturedAt || ''));
  }

  /**
   * Read a single export file.
   * @param {string} filename - bare filename (no directory)
   * @returns {object|null}
   */
  readExport(filename) {
    // Prevent path traversal
    const safe = path.basename(filename);
    const fp   = path.join(this.exportDir, safe);
    if (!fs.existsSync(fp)) return null;
    try {
      return JSON.parse(fs.readFileSync(fp, 'utf8'));
    } catch (_) {
      return null;
    }
  }
}

module.exports = CookieExporter;