/**
 * ProxyHealthTracker — Structured proxy health monitoring service
 *
 * Replaces the fragile log-regex approach with an in-memory Map of
 * proxy → structured health records.  Every proxy event (success, failure,
 * block, TCP failure, blacklist) flows through this single class so the
 * GUI can read structured data instead of parsing log lines.
 *
 * MASSIVE IMPROVEMENTS (Layer 1 & 2):
 * - Error classification (ErrorClassifier)
 * - Latency percentiles & trend detection (LatencyAnalyzer)
 * - Circuit breaker state machine (CircuitBreaker)
 * - Anomaly detection (AnomalyDetector)
 * - Graduated recovery modes (RecoveryScheduler)
 *
 * Used by:
 *   - Worker  (records TCP/block/success/failure per credential attempt)
 *   - Controller (aggregates IPC health events from all workers)
 *   - GUI server (reads via getAll/getStats for /api/proxies/status)
 */

'use strict';

const EventEmitter = require('events');
const fs = require('fs');
const path = require('path');

// Integrate new utilities
const ErrorClassifier = require('./errorClassifier');
const LatencyAnalyzer = require('./latencyAnalyzer');
const CircuitBreaker = require('./circuitBreaker');
const AnomalyDetector = require('./anomalyDetector');
const RecoveryScheduler = require('./recoveryScheduler');

/** Maximum number of recent events to keep per proxy (ring buffer). */
const MAX_EVENTS_PER_PROXY = 50;

/** Maximum number of response-time samples for rolling average. */
const MAX_RESPONSE_SAMPLES = 50;  // Increased from 20 for better percentiles

/** Default persistence interval (60 s). */
const DEFAULT_PERSIST_INTERVAL_MS = 60000;

/**
 * Create a fresh proxy health record with MASSIVE IMPROVEMENTS
 * @param {string} address  Sanitised host:port string
 * @returns {object}
 */
function createRecord(address) {
  const now = Date.now();
  return {
    address,
    firstSeen: now,
    lastSeen: now,

    // --- Existing Counters ---
    successCount: 0,
    failCount: 0,
    blockCount: 0,
    tcpFailCount: 0,

    // --- MASSIVE NEW: Error Breakdown ---
    errorBreakdown: {
      tcp_timeout: 0,
      dns_failure: 0,
      tls_error: 0,
      connection_reset: 0,
      timeout: 0,
      http_4xx: 0,
      http_5xx: 0,
      blocked: 0,
      captcha: 0,
      unknown: 0
    },

    // --- MASSIVE NEW: Latency Tracking (Percentiles + Trend) ---
    responseTimes: [],        // Recent samples (ring buffer, 50 max)
    avgResponseTime: 0,
    lastResponseTime: 0,
    p50ResponseTime: 0,       // NEW: 50th percentile
    p95ResponseTime: 0,       // NEW: 95th percentile
    p99ResponseTime: 0,       // NEW: 99th percentile
    minResponseTime: 0,       // NEW
    maxResponseTime: 0,       // NEW
    latencyTrend: 'stable',   // NEW: 'stable' | 'degrading' | 'improving'

    // Last event timestamps
    lastSuccess: null,
    lastFailure: null,

    // Blacklist state
    currentlyBlacklisted: false,
    blacklistReason: null,
    blacklistExpiry: null,
    blacklistCount: 0,

    // Streak tracking
    consecutiveFailures: 0,
    lifetimeRotations: 0,

    // Health score (0–100), recomputed on every mutation
    healthScore: 100,

    // Currently in active use by a worker
    inUse: false,

    // Paused by operator (excluded from selection but not blacklisted)
    paused: false,

    // Recent events ring buffer [{ts, type, detail}]
    recentEvents: [],

    // --- MASSIVE NEW: Circuit Breaker State ---
    circuitState: 'CLOSED',   // NEW: 'CLOSED' | 'OPEN' | 'HALF_OPEN'
    circuitOpenedAt: null,    // NEW
    circuitFailureCount: 0,   // NEW

    // --- MASSIVE NEW: Anomaly Flags ---
    anomalyFlags: {           // NEW
      sudden_latency_spike: false,
      consistent_timeouts: false,
      cascading_failures: false,
      rate_limit_detection: false,
      captcha_loop: false,
      dns_problems: false
    },

    // --- MASSIVE NEW: Recovery Mode ---
    recoveryMode: 'normal',   // NEW: 'normal' | 'graduating' | 'cooldown'
    recoveryScheduledAt: null,// NEW
    recoveryAttempts: 0,      // NEW
    recoveryLastSuccessAt: null, // NEW

    // --- MASSIVE NEW: Degradation Level ---
    degradationLevel: 0       // NEW: 0-4 (0=healthy, 4=dying)
  };
}

class ProxyHealthTracker extends EventEmitter {
  /**
   * @param {object} [options]
   * @param {string} [options.persistFile]        Path for periodic JSON snapshots
   * @param {number} [options.persistIntervalMs]  Snapshot interval (ms)
   */
  constructor(options = {}) {
    super();
    /** @type {Map<string, object>} */
    this.proxies = new Map();

    this.persistFile = options.persistFile || null;
    this.persistIntervalMs = options.persistIntervalMs || DEFAULT_PERSIST_INTERVAL_MS;
    this._persistHandle = null;

    // Initialize new utility modules (Layers 1 & 2)
    this.errorClassifier = new ErrorClassifier();
    this.latencyAnalyzer = new LatencyAnalyzer({ maxSamples: MAX_RESPONSE_SAMPLES });
    this.circuitBreaker = new CircuitBreaker(options.circuitBreakerOptions || {});
    this.anomalyDetector = new AnomalyDetector(options.anomalyDetectorOptions || {});
    this.recoveryScheduler = new RecoveryScheduler(options.recoverySchedulerOptions || {});

    if (this.persistFile) {
      this._loadSnapshot();
      this._startPersistence();
    }
  }

  // ---------------------------------------------------------------------------
  //  Mutation methods (ENHANCED with new utilities)
  // ---------------------------------------------------------------------------

  /**
   * Record a successful credential attempt through this proxy.
   * ENHANCED: Updates latency metrics, circuit state, recovery progress
   * 
   * @param {string} proxy   Sanitised host:port
   * @param {number} [duration]  Response time in ms
   */
  recordSuccess(proxy, duration = 0) {
    const r = this._ensureRecord(proxy);
    r.successCount++;
    r.lastSuccess = Date.now();
    r.lastSeen = Date.now();
    r.consecutiveFailures = 0;

    if (duration > 0) {
      // ENHANCED: Use LatencyAnalyzer for percentiles + trend
      this.latencyAnalyzer.recordLatency(r, duration);
    }

    // ENHANCED: Update circuit breaker (success helps recovery)
    this.circuitBreaker.updateState(r, true);

    // ENHANCED: If in recovery mode, record progress
    if (r.recoveryMode !== 'normal') {
      this.recoveryScheduler.recordRecoverySuccess(r);
    }

    this._pushEvent(r, 'success', duration ? `${duration}ms` : null);
    this._recomputeHealth(r);
    
    // ENHANCED: Detect anomalies on every update
    this.anomalyDetector.detectAnomalies(r);
    
    this.emit('proxy_health_updated', { proxy, record: this._safeClone(r) });
  }

  /**
   * Record a failed credential attempt (not a block — just a login failure).
   * ENHANCED: Categorizes error, updates circuit state, schedules recovery if needed
   * 
   * @param {string} proxy
   * @param {string} [reason]
   * @param {Error} [error] - Error object for classification
   */
  recordFailure(proxy, reason = 'unknown', error = null) {
    const r = this._ensureRecord(proxy);
    r.failCount++;
    r.lastFailure = Date.now();
    r.lastSeen = Date.now();
    r.consecutiveFailures++;

    // ENHANCED: Classify error type
    const errorCategory = error 
      ? this.errorClassifier.classifyError(error, {})
      : reason;
    r.errorBreakdown[errorCategory] = (r.errorBreakdown[errorCategory] || 0) + 1;

    // ENHANCED: Update circuit breaker (failure counts)
    this.circuitBreaker.updateState(r, false);

    // ENHANCED: If too many consecutive failures, schedule recovery
    if (r.consecutiveFailures >= 5) {
      this.recoveryScheduler.scheduleRecovery(r, errorCategory);
    }

    this._pushEvent(r, 'failure', reason);
    this._recomputeHealth(r);
    this.anomalyDetector.detectAnomalies(r);
    this.emit('proxy_health_updated', { proxy, record: this._safeClone(r) });
  }

  /**
   * Record a proxy/IP block or CAPTCHA event.
   * ENHANCED: Immediate circuit open, recovery scheduling, anomaly detection
   * 
   * @param {string} proxy
   * @param {string} [reason]
   */
  recordBlock(proxy, reason = 'blocked') {
    const r = this._ensureRecord(proxy);
    r.blockCount++;
    r.lastFailure = Date.now();
    r.lastSeen = Date.now();
    r.consecutiveFailures++;

    // ENHANCED: Classify error
    const errorCategory = this.errorClassifier.classifyError(new Error(reason), {});
    r.errorBreakdown[errorCategory] = (r.errorBreakdown[errorCategory] || 0) + 1;

    // ENHANCED: Force circuit breaker open (harsh failure)
    this.circuitBreaker.open(r, reason);

    // ENHANCED: Schedule immediate recovery
    this.recoveryScheduler.scheduleRecovery(r, reason);

    this._pushEvent(r, 'block', reason);
    this._recomputeHealth(r);
    this.anomalyDetector.detectAnomalies(r);
    this.emit('proxy_health_updated', { proxy, record: this._safeClone(r) });
  }

  /**
   * Record a TCP connectivity failure.
   * ENHANCED: Error categorization, circuit breaker update
   * 
   * @param {string} proxy
   */
  recordTcpFail(proxy) {
    const r = this._ensureRecord(proxy);
    r.tcpFailCount++;
    r.lastFailure = Date.now();
    r.lastSeen = Date.now();
    r.consecutiveFailures++;

    // ENHANCED: Categorize as TCP timeout
    r.errorBreakdown['tcp_timeout'] = (r.errorBreakdown['tcp_timeout'] || 0) + 1;

    // ENHANCED: Update circuit breaker
    this.circuitBreaker.updateState(r, false);

    // ENHANCED: If many TCP failures, schedule recovery
    if (r.tcpFailCount >= 3) {
      this.recoveryScheduler.scheduleRecovery(r, 'tcp_timeout');
    }

    this._pushEvent(r, 'tcp_fail', null);
    this._recomputeHealth(r);
    this.anomalyDetector.detectAnomalies(r);
    this.emit('proxy_health_updated', { proxy, record: this._safeClone(r) });
  }

  /**
   * Mark a proxy as blacklisted.
   * ENHANCED: Uses ErrorClassifier to determine TTL
   * 
   * @param {string} proxy
   * @param {string} reason
   * @param {number} [ttlMs]      TTL in milliseconds (auto-computed if not provided)
   */
  recordBlacklist(proxy, reason, ttlMs) {
    const r = this._ensureRecord(proxy);
    r.currentlyBlacklisted = true;
    r.blacklistReason = reason;
    
    // ENHANCED: Auto-compute TTL from error classifier if not provided
    if (!ttlMs) {
      ttlMs = this.errorClassifier.recommendBlacklistTTL(reason);
    }
    
    r.blacklistExpiry = Date.now() + ttlMs;
    r.blacklistCount++;
    r.lastSeen = Date.now();

    // ENHANCED: Force circuit open
    this.circuitBreaker.open(r, reason);

    this._pushEvent(r, 'blacklisted', `${reason} (${Math.round(ttlMs / 60000)}min)`);
    this._recomputeHealth(r);
    this.anomalyDetector.detectAnomalies(r);
    this.emit('proxy_health_updated', { proxy, record: this._safeClone(r) });
  }

  /**
   * Remove blacklist flag from a proxy (manual un-blacklist or TTL expired).
   * ENHANCED: Also resets circuit breaker for recovery
   * 
   * @param {string} proxy
   */
  removeBlacklist(proxy) {
    const r = this.proxies.get(proxy);
    if (!r) return;
    r.currentlyBlacklisted = false;
    r.blacklistReason = null;
    r.blacklistExpiry = null;

    // ENHANCED: Reset circuit to allow recovery testing
    this.circuitBreaker.close(r);

    this._pushEvent(r, 'unblacklisted', null);
    this._recomputeHealth(r);
    this.anomalyDetector.detectAnomalies(r);
    this.emit('proxy_health_updated', { proxy, record: this._safeClone(r) });
  }

  /**
   * Record a proxy rotation event.
   * @param {string} proxy
   */
  recordRotation(proxy) {
    const r = this._ensureRecord(proxy);
    r.lifetimeRotations++;
    r.lastSeen = Date.now();
    this._pushEvent(r, 'rotation', null);
  }

  /**
   * Mark a proxy as currently in-use by a worker.
   * @param {string} proxy
   * @param {boolean} inUse
   */
  setInUse(proxy, inUse) {
    const r = this._ensureRecord(proxy);
    r.inUse = !!inUse;
  }

  /**
   * Pause / unpause a proxy.
   * @param {string} proxy
   * @param {boolean} paused
   */
  setPaused(proxy, paused) {
    const r = this.proxies.get(proxy);
    if (!r) return;
    r.paused = !!paused;
    this._pushEvent(r, paused ? 'paused' : 'unpaused', null);
    this._recomputeHealth(r);
    this.emit('proxy_health_updated', { proxy, record: this._safeClone(r) });
  }

  // ---------------------------------------------------------------------------
  //  Read methods
  // ---------------------------------------------------------------------------

  /**
   * Return all proxy records as a plain array.  Refreshes expired blacklist
   * flags before returning so the GUI always sees current state.
   * ENHANCED: Also checks recovery mode duration
   * 
   * @returns {object[]}
   */
  getAll() {
    const now = Date.now();
    const results = [];
    for (const r of this.proxies.values()) {
      // Auto-expire blacklist
      if (r.currentlyBlacklisted && r.blacklistExpiry && now >= r.blacklistExpiry) {
        r.currentlyBlacklisted = false;
        r.blacklistReason = null;
        r.blacklistExpiry = null;
        this.circuitBreaker.close(r);
        this._recomputeHealth(r);
      }

      // ENHANCED: Check recovery mode duration, auto-promote if ready
      this.recoveryScheduler.checkRecoveryDuration(r);

      results.push(this._safeClone(r));
    }
    return results;
  }

  /**
   * Get a single proxy record.
   * @param {string} proxy
   * @returns {object|null}
   */
  getByProxy(proxy) {
    const r = this.proxies.get(proxy);
    return r ? this._safeClone(r) : null;
  }

  /**
   * Compute aggregate pool statistics.
   * ENHANCED: Includes circuit breaker stats, anomaly counts, recovery modes
   * 
   * @returns {object}
   */
  getStats() {
    const all = this.getAll();
    const total = all.length;
    if (total === 0) {
      return {
        total: 0, healthy: 0, degraded: 0, blacklisted: 0, paused: 0,
        avgHealthScore: 0, avgResponseTime: 0, totalBlocks: 0,
        poolHealthPercent: 0, exhaustionEstimateMin: null,
        // ENHANCED NEW:
        circuitOpenCount: 0,
        anomaliesDetected: 0,
        recoveryModeCount: 0,
        p95PoolLatency: 0
      };
    }

    let healthy = 0;
    let degraded = 0;
    let blacklisted = 0;
    let paused = 0;
    let totalScore = 0;
    let totalRt = 0;
    let rtCount = 0;
    let totalBlocks = 0;
    let circuitOpenCount = 0;
    let anomaliesDetected = 0;
    let recoveryModeCount = 0;
    const p95Values = [];

    for (const p of all) {
      totalScore += p.healthScore;
      totalBlocks += p.blockCount;
      if (p.avgResponseTime > 0) { totalRt += p.avgResponseTime; rtCount++; }
      if (p.p95ResponseTime > 0) p95Values.push(p.p95ResponseTime);
      
      // ENHANCED: Count circuit open, anomalies, recovery modes
      if (p.circuitState === 'OPEN') circuitOpenCount++;
      if (this.anomalyDetector.getAnomalyCount(p) > 0) anomaliesDetected++;
      if (p.recoveryMode !== 'normal') recoveryModeCount++;
      
      if (p.paused) { paused++; continue; }
      if (p.currentlyBlacklisted) { blacklisted++; continue; }
      if (p.healthScore >= 60) { healthy++; } else { degraded++; }
    }

    const poolHealthPercent = Math.round(totalScore / total);
    const p95PoolLatency = p95Values.length > 0 
      ? Math.round(p95Values.reduce((a, b) => a + b, 0) / p95Values.length)
      : 0;

    // Exhaustion estimate: at current block rate, how long until all proxies blacklisted?
    let exhaustionEstimateMin = null;
    const usable = total - blacklisted - paused;
    if (totalBlocks > 0 && usable > 0) {
      const firstTs = Math.min(...all.map(p => p.firstSeen));
      const elapsedMin = (Date.now() - firstTs) / 60000;
      if (elapsedMin > 0) {
        const blocksPerMin = totalBlocks / elapsedMin;
        if (blocksPerMin > 0) {
          exhaustionEstimateMin = Math.round(usable / blocksPerMin);
        }
      }
    }

    return {
      total,
      healthy,
      degraded,
      blacklisted,
      paused,
      avgHealthScore: poolHealthPercent,
      avgResponseTime: rtCount > 0 ? Math.round(totalRt / rtCount) : 0,
      totalBlocks,
      poolHealthPercent,
      exhaustionEstimateMin,
      // ENHANCED NEW:
      circuitOpenCount,
      anomaliesDetected,
      recoveryModeCount,
      p95PoolLatency
    };
  }

  /**
   * Export data as JSON (for analytics export).
   * @returns {string}
   */
  exportJson() {
    return JSON.stringify(this.getAll(), null, 2);
  }

  /**
   * Export data as CSV with ENHANCED fields.
   * @returns {string}
   */
  exportCsv() {
    const headers = [
      'address', 'healthScore', 'successCount', 'failCount', 'blockCount',
      'tcpFailCount', 'avgResponseTime', 'p95ResponseTime', 'latencyTrend',
      'consecutiveFailures', 'circuitState', 'recoveryMode', 'anomalyCount',
      'currentlyBlacklisted', 'blacklistReason', 'blacklistCount',
      'lifetimeRotations', 'firstSeen', 'lastSeen'
    ];
    const rows = [headers.join(',')];
    for (const r of this.getAll()) {
      const anomalyCount = this.anomalyDetector.getAnomalyCount(r);
      rows.push(headers.map(h => {
        let v = r[h];
        if (h === 'anomalyCount') v = anomalyCount;
        if (v instanceof Date) return new Date(v).toISOString();
        if (typeof v === 'string') return `"${v.replace(/"/g, '""')}"`;
        return v ?? '';
      }).join(','));
    }
    return rows.join('\n');
  }

  // ---------------------------------------------------------------------------
  //  Seed / bulk operations
  // ---------------------------------------------------------------------------

  /**
   * Seed known proxies from a proxy list file so they appear in the GUI
   * even before any traffic flows through them.
   * @param {string[]} proxyLines  Raw proxy lines from file
   * @param {function} [sanitizeFn]  Optional sanitizer (addr → host:port)
   */
  seedFromList(proxyLines, sanitizeFn) {
    for (const line of proxyLines) {
      const addr = sanitizeFn ? sanitizeFn(line) : line;
      if (addr && addr.includes(':')) {
        this._ensureRecord(addr);
      }
    }
  }

  /**
   * Remove a proxy entirely from the tracker.
   * @param {string} proxy
   * @returns {boolean}
   */
  removeProxy(proxy) {
    return this.proxies.delete(proxy);
  }

  /**
   * Clear all records.
   */
  clear() {
    this.proxies.clear();
  }

  /**
   * Merge data from a persisted snapshot array into the in-memory tracker.
   * Takes the higher of local vs. persisted counters to avoid data loss.
   * ENHANCED: Also merges new fields (circuit state, recovery mode, etc.)
   * 
   * @param {object[]} entries  Array of snapshot records (from JSON persistence)
   */
  mergeFromSnapshot(entries) {
    if (!Array.isArray(entries)) return;
    for (const entry of entries) {
      if (!entry.address) continue;
      const r = this._ensureRecord(entry.address);
      // Merge counters (take higher value)
      if (entry.successCount > r.successCount) r.successCount = entry.successCount;
      if (entry.failCount > r.failCount) r.failCount = entry.failCount;
      if (entry.blockCount > r.blockCount) r.blockCount = entry.blockCount;
      if (entry.tcpFailCount > r.tcpFailCount) r.tcpFailCount = entry.tcpFailCount;
      if (entry.blacklistCount > r.blacklistCount) r.blacklistCount = entry.blacklistCount;
      // Merge blacklist state
      if (entry.currentlyBlacklisted) {
        r.currentlyBlacklisted = true;
        r.blacklistReason = entry.blacklistReason;
        r.blacklistExpiry = entry.blacklistExpiry;
      }
      if (entry.consecutiveFailures > r.consecutiveFailures) r.consecutiveFailures = entry.consecutiveFailures;
      // Merge timing data
      if (entry.avgResponseTime > 0) r.avgResponseTime = entry.avgResponseTime;
      if (entry.lastResponseTime > 0) r.lastResponseTime = entry.lastResponseTime;
      r.lifetimeRotations = Math.max(r.lifetimeRotations, entry.lifetimeRotations || 0);
      // Merge GUI-expected fields that were previously dropped
      if (entry.inUse !== undefined) r.inUse = entry.inUse;
      if (entry.paused !== undefined) r.paused = entry.paused;
      if (entry.lastSeen) r.lastSeen = entry.lastSeen;
      if (entry.lastSuccess) r.lastSuccess = entry.lastSuccess;
      if (entry.lastFailure) r.lastFailure = entry.lastFailure;
      if (entry.firstSeen) r.firstSeen = entry.firstSeen;
      // ENHANCED: Merge new fields
      if (entry.circuitState) r.circuitState = entry.circuitState;
      if (entry.recoveryMode) r.recoveryMode = entry.recoveryMode;
      if (entry.latencyTrend) r.latencyTrend = entry.latencyTrend;
      if (entry.p95ResponseTime) r.p95ResponseTime = entry.p95ResponseTime;
      // Merge recent events (if snapshot has more events, use those)
      if (Array.isArray(entry.recentEvents) && entry.recentEvents.length > r.recentEvents.length) {
        r.recentEvents = entry.recentEvents.slice(-MAX_EVENTS_PER_PROXY);
      }
      // Recompute health and emit update event so SSE clients see changes
      this._recomputeHealth(r);
      this.anomalyDetector.detectAnomalies(r);
      this.emit('proxy_health_updated', { proxy: entry.address, record: this._safeClone(r) });
    }
  }

  // ---------------------------------------------------------------------------
  //  Weighted proxy selection (ENHANCED with circuit breaker check)
  // ---------------------------------------------------------------------------

  /**
   * Select a proxy using weighted random selection.  Proxies with higher
   * health scores are more likely to be chosen.
   * ENHANCED: Respects circuit breaker state
   *
   * @param {string[]} candidates  Pool of candidate proxy addresses
   * @returns {string|null}  Selected proxy address or null if none available
   */
  weightedSelect(candidates) {
    if (!candidates || candidates.length === 0) return null;

    // Build weight list — filter out blacklisted, paused, and circuit open
    const weighted = [];
    let totalWeight = 0;

    for (const addr of candidates) {
      const r = this.proxies.get(addr);

      // ENHANCED: Skip if circuit OPEN (hard fail)
      if (r && r.circuitState === 'OPEN') continue;

      // Skip blacklisted/paused
      if (r && (r.currentlyBlacklisted || r.paused)) continue;

      // ENHANCED: Lower weight for HALF_OPEN proxies
      let scoreMultiplier = 1.0;
      if (r && r.circuitState === 'HALF_OPEN') {
        scoreMultiplier = 0.5;  // 50% weight reduction during testing
      }

      // Weight = healthScore (1–100) + small base so even unhealthy proxies
      // have a tiny chance.  Unknown proxies get a neutral score of 70.
      const baseScore = r ? r.healthScore : 70;
      const score = baseScore * scoreMultiplier;
      const weight = Math.max(score, 1);
      totalWeight += weight;
      weighted.push({ addr, weight });
    }

    if (weighted.length === 0) return null;

    // Weighted random pick
    let rand = Math.random() * totalWeight;
    for (const entry of weighted) {
      rand -= entry.weight;
      if (rand <= 0) return entry.addr;
    }
    return weighted[weighted.length - 1].addr;
  }

  // ---------------------------------------------------------------------------
  //  Persistence
  // ---------------------------------------------------------------------------

  /** Save snapshot to disk. */
  saveSnapshot() {
    if (!this.persistFile) return;
    try {
      const dir = path.dirname(this.persistFile);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      const data = JSON.stringify(this.getAll());
      fs.writeFileSync(this.persistFile, data, 'utf8');
    } catch (e) {
      // Non-fatal — snapshot is optional
    }
  }

  /** Stop periodic persistence. */
  destroy() {
    if (this._persistHandle) {
      clearInterval(this._persistHandle);
      this._persistHandle = null;
    }
    this.saveSnapshot();
    this.removeAllListeners();
  }

  // ---------------------------------------------------------------------------
  //  Internal helpers
  // ---------------------------------------------------------------------------

  /**
   * Normalise a raw proxy string to a safe host:port identifier.
   * Strips scheme, credentials, path/query/fragment, and host:port:user:pass
   * suffixes so records only retain a sanitised address.
   * @param {string} proxy
   * @returns {string}
   */
  _sanitizeProxyIdentifier(proxy) {
    let value = typeof proxy === 'string' ? proxy.trim() : String(proxy || '').trim();
    if (!value) return value;

    // Remove URL scheme if present (e.g. http://, https://, socks5://).
    value = value.replace(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//, '');

    // Strip query / fragment first, then any path.
    value = value.split('#', 1)[0].split('?', 1)[0].split('/', 1)[0];

    // Strip userinfo if present, using the last '@' to avoid truncating hosts.
    const atIndex = value.lastIndexOf('@');
    if (atIndex !== -1) {
      value = value.slice(atIndex + 1);
    }

    // Preserve bracketed IPv6 host with optional port.
    const ipv6Match = value.match(/^(\[[^\]]+\])(?::(\d+))?/);
    if (ipv6Match) {
      return ipv6Match[2] ? ipv6Match[1] + ':' + ipv6Match[2] : ipv6Match[1];
    }

    // Collapse host:port:user:pass and similar variants to host:port.
    const hostPortMatch = value.match(/^([^:/?#]+):(\d+)/);
    if (hostPortMatch) {
      return hostPortMatch[1] + ':' + hostPortMatch[2];
    }

    return value;
  }

  /**
   * Ensure a record exists for the given proxy.
   * The proxy identifier is sanitised to host:port before storing to prevent
   * credential leakage through persistence/API endpoints.
   * @param {string} proxy
   * @returns {object}
   */
  _ensureRecord(proxy) {
    const sanitized = this._sanitizeProxyIdentifier(proxy);
    if (!this.proxies.has(sanitized)) {
      this.proxies.set(sanitized, createRecord(sanitized));
    }
    return this.proxies.get(sanitized);
  }

  /**
   * Push an event to the proxy's recent-events ring buffer.
   * @param {object} record
   * @param {string} type
   * @param {string|null} detail
   */
  _pushEvent(record, type, detail) {
    record.recentEvents.push({ ts: Date.now(), type, detail });
    if (record.recentEvents.length > MAX_EVENTS_PER_PROXY) {
      record.recentEvents.shift();
    }
  }

  /**
   * Compute health score (0–100) from the record's current state.
   * ENHANCED: Includes circuit breaker penalty, anomaly penalties
   *
   * Factors:
   *   - Recent success rate (last N attempts)       40 %
   *   - Consecutive failure penalty                  15 %
   *   - Block penalty                                15 %
   *   - Blacklist / paused penalty                   15 %
   *   - Circuit breaker penalty                      10 %
   *   - Anomaly penalties                             5 %
   */
  _recomputeHealth(r) {
    let score = 100;

    // --- Success rate component (40 pts) ---
    const totalAttempts = r.successCount + r.failCount;
    if (totalAttempts > 0) {
      const rate = r.successCount / totalAttempts;
      score -= (1 - rate) * 40;
    }

    // --- Consecutive failures component (15 pts) ---
    // Each consecutive failure costs 3 pts, max 15
    score -= Math.min(r.consecutiveFailures * 3, 15);

    // --- Block component (15 pts) ---
    // Each block costs 3.75 pts, max 15
    score -= Math.min(r.blockCount * 3.75, 15);

    // --- Blacklist / paused component (15 pts) ---
    if (r.currentlyBlacklisted) score -= 15;
    else if (r.paused) score -= 7.5;

    // --- Circuit breaker component (10 pts) --- ENHANCED NEW
    if (r.circuitState === 'OPEN') {
      score -= 10;
    } else if (r.circuitState === 'HALF_OPEN') {
      score -= 5;  // Lighter penalty during testing
    }

    // --- Anomaly component (5 pts) --- ENHANCED NEW
    const anomalyCount = this.anomalyDetector.getAnomalyCount(r);
    if (anomalyCount > 0) {
      score -= Math.min(anomalyCount * 2, 5);
    }

    // --- Latency trend component (bonus/penalty) --- ENHANCED NEW
    if (r.latencyTrend === 'degrading') {
      score -= 5;  // Small penalty
    } else if (r.latencyTrend === 'improving') {
      score += 3;  // Small bonus
    }

    r.healthScore = Math.max(0, Math.min(100, Math.round(score)));
  }

  /**
   * Create a plain-object clone of a record suitable for JSON serialisation
   * ENHANCED: Includes all new fields (circuit, anomalies, recovery, latency)
   * 
   * @param {object} r
   * @returns {object}
   */
  _safeClone(r) {
    const anomalySummary = this.anomalyDetector.getAnomalySummary(r);
    const circuitState = this.circuitBreaker.getState(r);
    const recoveryStatus = this.recoveryScheduler.getRecoveryStatus(r);

    return {
      address: r.address,
      firstSeen: r.firstSeen,
      lastSeen: r.lastSeen,
      successCount: r.successCount,
      failCount: r.failCount,
      blockCount: r.blockCount,
      tcpFailCount: r.tcpFailCount,
      // ENHANCED NEW: Latency metrics
      avgResponseTime: r.avgResponseTime,
      lastResponseTime: r.lastResponseTime,
      p50ResponseTime: r.p50ResponseTime,
      p95ResponseTime: r.p95ResponseTime,
      p99ResponseTime: r.p99ResponseTime,
      minResponseTime: r.minResponseTime,
      maxResponseTime: r.maxResponseTime,
      latencyTrend: r.latencyTrend,
      // Existing fields
      consecutiveFailures: r.consecutiveFailures,
      currentlyBlacklisted: r.currentlyBlacklisted,
      blacklistReason: r.blacklistReason,
      blacklistExpiry: r.blacklistExpiry,
      blacklistCount: r.blacklistCount,
      lifetimeRotations: r.lifetimeRotations,
      healthScore: r.healthScore,
      inUse: r.inUse,
      paused: r.paused,
      recentEvents: r.recentEvents.slice(),
      // ENHANCED NEW: Circuit breaker state
      circuitState: circuitState.state,
      circuitOpenedAt: circuitState.openedAt,
      circuitTimeOpen: circuitState.timeOpen,
      // ENHANCED NEW: Anomalies
      anomalyCount: anomalySummary.count,
      anomalySeverity: anomalySummary.severity,
      anomalies: anomalySummary.anomalies,
      // ENHANCED NEW: Recovery mode
      recoveryMode: recoveryStatus.mode,
      recoveryTestRate: recoveryStatus.testRate,
      recoveryAttempts: recoveryStatus.attempts,
      // Legacy compatibility fields for existing GUI
      healthy: r.healthScore >= 40 && !r.currentlyBlacklisted && r.circuitState !== 'OPEN',
      // Error breakdown
      errorBreakdown: r.errorBreakdown
    };
  }

  /** Compute numeric average of an array. */
  _avg(arr) {
    if (arr.length === 0) return 0;
    return Math.round(arr.reduce((a, b) => a + b, 0) / arr.length);
  }

  /** Load persisted snapshot from disk. */
  _loadSnapshot() {
    if (!this.persistFile) return;
    try {
      if (!fs.existsSync(this.persistFile)) return;
      const raw = JSON.parse(fs.readFileSync(this.persistFile, 'utf8'));
      if (!Array.isArray(raw)) return;
      for (const entry of raw) {
        if (!entry.address) continue;
        const r = createRecord(entry.address);
        // Restore scalar fields
        for (const key of Object.keys(r)) {
          if (key === 'recentEvents' || key === 'responseTimes') continue;
          if (entry[key] !== undefined) r[key] = entry[key];
        }
        if (Array.isArray(entry.recentEvents)) {
          r.recentEvents = entry.recentEvents.slice(-MAX_EVENTS_PER_PROXY);
        }
        this.proxies.set(r.address, r);
      }
    } catch (_) {
      // Corrupt/missing file — start fresh
    }
  }

  /** Start periodic snapshot saves. */
  _startPersistence() {
    this._persistHandle = setInterval(() => {
      this.saveSnapshot();
    }, this.persistIntervalMs);
    // Allow process to exit even with the interval running
    if (this._persistHandle.unref) this._persistHandle.unref();
  }
}

module.exports = ProxyHealthTracker;
