/**
 * Enhanced Form Submission with Multiple Fallbacks and Random Method Selection
 */

const config = require('../config');

class Logger {
  constructor(prefix = '[form]', level = 'info') {
    this.prefix = prefix;
    this.levels = { debug: 0, info: 1, warn: 2, error: 3 };
    this.currentLevel = this.levels[level] || 1;
  }

  debug(msg) { if (this.currentLevel <= 0) console.log(`${this.prefix} [DEBUG] ${msg}`); }
  info(msg) { if (this.currentLevel <= 1) console.log(`${this.prefix} [INFO] ${msg}`); }
  warn(msg) { if (this.currentLevel <= 2) console.warn(`${this.prefix} [WARN] ${msg}`); }
  error(msg) { if (this.currentLevel <= 3) console.error(`${this.prefix} [ERROR] ${msg}`); }
}

const logger = new Logger('[form]', config.logging.logLevel);

/**
 * Try to submit form using CSS selectors
 */
async function submitViaCssSelectors(page, logPrefix) {
  for (const selector of config.login.submitSelectors) {
    try {
      logger.debug(`${logPrefix} Trying CSS selector: ${selector}`);
      
      const button = await page.$(selector);
      if (!button) {
        logger.debug(`${logPrefix} Selector not found: ${selector}`);
        continue;
      }

      // Check visibility and enabled state using native Playwright methods
      // (no page.evaluate — avoids injecting JS that DataDome can detect)
      const isVisible = await button.isVisible().catch(() => false);
      if (!isVisible) {
        logger.debug(`${logPrefix} Button not visible: ${selector}`);
        continue;
      }

      const isEnabled = await button.isEnabled().catch(() => true);
      if (!isEnabled) {
        logger.warn(`${logPrefix} Button disabled: ${selector}`);
        continue;
      }

      // Click button using native Patchright click (produces trusted events).
      // No page.evaluate fallback — synthetic el.click() creates isTrusted:false events.
      logger.info(`${logPrefix} Found submit button via CSS: ${selector}`);
      await button.click();

      return {
        success: true,
        method: 'css_selector',
        selector: selector,
        details: `Clicked via CSS selector: ${selector}`
      };

    } catch (error) {
      logger.debug(`${logPrefix} CSS selector error (${selector}): ${error?.message}`);
      continue;
    }
  }
  
  return { success: false };
}

/**
 * Try to submit form using XPath
 */
async function submitViaXPath(page, logPrefix) {
  if (!config.login.submitXPath) {
    return { success: false };
  }

  try {
    logger.debug(`${logPrefix} Trying XPath: ${config.login.submitXPath}`);

    const buttons = await page.$$(config.login.submitXPath).catch(() => []);
    if (!buttons || buttons.length === 0) {
      logger.debug(`${logPrefix} XPath not found`);
      return { success: false };
    }

    logger.info(`${logPrefix} Found submit button via XPath`);

    // Click using native Patchright click (trusted events).
    // No page.evaluate fallback — synthetic click creates isTrusted:false events.
    await buttons[0].click();

    return {
      success: true,
      method: 'xpath',
      xpath: config.login.submitXPath,
      details: 'Clicked via XPath'
    };
  } catch (error) {
    logger.debug(`${logPrefix} XPath error: ${error?.message}`);
    return { success: false };
  }
}

/**
 * Try to submit form using Enter key
 */
async function submitViaEnterKey(page, logPrefix) {
  try {
    logger.info(`${logPrefix} Trying keyboard submission (Enter key)...`);

    await page.press(config.login.passwordSelector, 'Enter').catch(() => {});

    logger.info(`${logPrefix} Pressed Enter on password field`);
    
    return {
      success: true,
      method: 'keyboard_enter',
      selector: config.login.passwordSelector,
      details: 'Pressed Enter on password field'
    };

  } catch (error) {
    logger.debug(`${logPrefix} Keyboard Enter failed: ${error?.message}`);
    return { success: false };
  }
}

/**
 * Find and click submit button with comprehensive fallback chain
 * Supports random method selection or specific method preference
 */
async function findAndClickSubmitButton(page, logPrefix = '[submit]') {
  logger.info(`${logPrefix} Attempting to submit form... `);

  const submitMethod = config.login.submitMethod || 'random';
  
  // If random, shuffle the methods
  if (submitMethod === 'random') {
    const methods = ['css', 'xpath', 'enter'];
    // Fisher-Yates shuffle
    for (let i = methods.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [methods[i], methods[j]] = [methods[j], methods[i]];
    }
    
    logger.debug(`${logPrefix} Random method order: ${methods.join(' -> ')}`);
    
    // Try methods in random order
    for (const method of methods) {
      let result;
      
      if (method === 'css') {
        result = await submitViaCssSelectors(page, logPrefix);
      } else if (method === 'xpath') {
        result = await submitViaXPath(page, logPrefix);
      } else if (method === 'enter') {
        result = await submitViaEnterKey(page, logPrefix);
      }
      
      if (result.success) {
        return result;
      }
    }
  } else if (submitMethod === 'css') {
    // Try CSS first, then fallback to others
    let result = await submitViaCssSelectors(page, logPrefix);
    if (result.success) return result;
    
    result = await submitViaXPath(page, logPrefix);
    if (result.success) return result;
    
    result = await submitViaEnterKey(page, logPrefix);
    if (result.success) return result;
  } else if (submitMethod === 'xpath') {
    // Try XPath first, then fallback to others
    let result = await submitViaXPath(page, logPrefix);
    if (result.success) return result;
    
    result = await submitViaCssSelectors(page, logPrefix);
    if (result.success) return result;
    
    result = await submitViaEnterKey(page, logPrefix);
    if (result.success) return result;
  } else if (submitMethod === 'enter') {
    // Try Enter key first, then fallback to others
    let result = await submitViaEnterKey(page, logPrefix);
    if (result.success) return result;
    
    result = await submitViaCssSelectors(page, logPrefix);
    if (result.success) return result;
    
    result = await submitViaXPath(page, logPrefix);
    if (result.success) return result;
  }

  // JS-based fallbacks (form.submit(), synthetic el.click()) are intentionally
  // omitted.  They fire events with isTrusted:false which DataDome detects.
  // If all three primary methods fail, report failure so the caller can retry.

  logger.error(`${logPrefix} Failed to submit form using any method`);

  return {
    success: false,
    method: 'none',
    details: 'All submission methods failed'
  };
}

/**
 * Check if reCAPTCHA is present on page
 */
async function detectRecaptcha(page) {
  try {
    logger.debug('[reCAPTCHA] Checking for reCAPTCHA...');

    for (const selector of config.login.recaptcha.selectors) {
      const element = await page.$(selector).catch(() => null);
      
      if (element) {
        logger.warn(`[reCAPTCHA] reCAPTCHA detected (${selector})`);

        const version = await page.evaluate((sel) => {
          const el = document.querySelector(sel);
          if (!el) return 'unknown';

          const html = el.outerHTML.toLowerCase();
          if (html.includes('recaptcha/api.js')) return 'v2';
          if (html.includes('recaptcha__enterprise')) return 'enterprise';
          if (html.includes('v3')) return 'v3';
          
          return 'v2';
        }, selector).catch(() => 'v2');

        return {
          detected: true,
          version: version,
          selector: selector,
          details: `reCAPTCHA ${version} detected`,
          callback: config.login.recaptcha.callbackFunction
        };
      }
    }

    logger.debug('[reCAPTCHA] No reCAPTCHA detected');
    return {
      detected: false,
      version: null,
      details: 'No reCAPTCHA found'
    };

  } catch (error) {
    logger.error(`[reCAPTCHA] Detection error: ${error?.message}`);
    return {
      detected: false,
      error: error?.message
    };
  }
}

/**
 * Wait for reCAPTCHA completion
 */
async function waitForRecaptchaCompletion(page, timeoutMs = 30000) {
  try {
    logger.debug('[reCAPTCHA] Waiting for reCAPTCHA completion...');

    const recaptchaCheck = await detectRecaptcha(page);
    if (!recaptchaCheck.detected) {
      logger.debug('[reCAPTCHA] No reCAPTCHA to wait for');
      return true;
    }

    const completed = await Promise.race([
      // isolatedContext: false — must access the main page window to intercept
      // the reCAPTCHA callback set by the site's own scripts.
      page.evaluate(([callbackName, timeoutMsArg]) => {
        return new Promise((resolve) => {
          const originalCallback = window[callbackName];
          let resolved = false;

          // Restore the original callback and clean up so the patched function
          // does not outlive this detection window.
          function cleanup(result) {
            if (resolved) return;
            resolved = true;
            clearInterval(interval);
            clearTimeout(timer);
            window[callbackName] = originalCallback;
            resolve(result);
          }

          window[callbackName] = function(...args) {
            if (originalCallback) originalCallback.apply(this, args);
            cleanup(true);
          };

          const interval = setInterval(() => {
            const token = document.querySelector('[name="g-recaptcha-response"]');
            if (token && token.value) {
              cleanup(true);
            }
          }, 500);

          const timer = setTimeout(() => cleanup(false), timeoutMsArg);
        });
      }, [config.login.recaptcha.callbackFunction, timeoutMs], false),

      new Promise(r => setTimeout(() => r(false), timeoutMs))
    ]);

    if (completed) {
      logger.info('[reCAPTCHA] reCAPTCHA completed');
      return true;
    } else {
      logger.warn('[reCAPTCHA] reCAPTCHA timeout');
      return false;
    }

  } catch (error) {
    logger.warn(`[reCAPTCHA] Completion check error: ${error?.message}`);
    return false;
  }
}

/**
 * Find and click logout button with retry logic
 */
async function findAndClickLogoutButton(page, logPrefix = '[logout]') {
  const maxAttempts = config.account.logoutRetryAttempts || 3;
  const retryDelay = config.account.logoutRetryDelay || 1000;
  
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      logger.info(`${logPrefix} Attempting logout (attempt ${attempt}/${maxAttempts})...`);

      // METHOD 1: TRY CSS SELECTORS
      for (const selector of config.account.logoutSelectors) {
        try {
          logger.debug(`${logPrefix} Trying CSS selector: ${selector}`);
          
          const button = await page.$(selector);
          if (!button) {
            logger.debug(`${logPrefix} Selector not found: ${selector}`);
            continue;
          }

          // Use native Playwright visibility check (no page.evaluate)
          const isVisible = await button.isVisible().catch(() => false);
          if (!isVisible) {
            logger.debug(`${logPrefix} Button not visible: ${selector}`);
            continue;
          }

          // Native Patchright click (trusted events, no JS fallback)
          logger.info(`${logPrefix} Found logout button via CSS: ${selector}`);
          await button.click();

          // Wait for logout to complete
          await new Promise(r => setTimeout(r, config.account.logoutPostDelay || 2000));

          return {
            success: true,
            method: 'css_selector',
            selector: selector,
            attempt: attempt,
            details: `Clicked logout via CSS selector: ${selector}`
          };

        } catch (error) {
          logger.debug(`${logPrefix} CSS selector error (${selector}): ${error?.message}`);
          continue;
        }
      }

      // METHOD 2: TRY TEXT CONTENT MATCHING via Playwright role locators (no page.evaluate).
      // Scope to links and buttons to avoid clicking non-interactive elements (e.g. <span>).
      try {
        logger.debug(`${logPrefix} Trying text content search...`);

        for (const phrase of config.account.logoutPhrases) {
          try {
            // Try links first, then buttons — logout is most often an <a> tag
            const linkLocator = page.getByRole('link', { name: phrase });
            if (await linkLocator.isVisible({ timeout: 1000 }).catch(() => false)) {
              await linkLocator.click();
              logger.info(`${logPrefix} Logout link clicked via text: "${phrase}"`);

              await new Promise(r => setTimeout(r, config.account.logoutPostDelay || 2000));

              return {
                success: true,
                method: 'text_search',
                attempt: attempt,
                details: `Found and clicked logout link via text: "${phrase}"`
              };
            }

            const buttonLocator = page.getByRole('button', { name: phrase });
            if (await buttonLocator.isVisible({ timeout: 1000 }).catch(() => false)) {
              await buttonLocator.click();
              logger.info(`${logPrefix} Logout button clicked via text: "${phrase}"`);

              await new Promise(r => setTimeout(r, config.account.logoutPostDelay || 2000));

              return {
                success: true,
                method: 'text_search',
                attempt: attempt,
                details: `Found and clicked logout button via text: "${phrase}"`
              };
            }
          } catch (_) {
            // continue to next phrase
          }
        }

      } catch (error) {
        logger.debug(`${logPrefix} Text search error: ${error?.message}`);
      }

      // If this wasn't the last attempt, wait before retrying
      if (attempt < maxAttempts) {
        logger.debug(`${logPrefix} Retry ${attempt} failed, waiting ${retryDelay}ms before next attempt...`);
        await new Promise(r => setTimeout(r, retryDelay));
      }

    } catch (error) {
      logger.debug(`${logPrefix} Attempt ${attempt} error: ${error?.message}`);
      
      if (attempt < maxAttempts) {
        await new Promise(r => setTimeout(r, retryDelay));
      }
    }
  }

  // ALL ATTEMPTS FAILED
  logger.warn(`${logPrefix} Failed to logout after ${maxAttempts} attempts`);

  return {
    success: false,
    method: 'none',
    attempts: maxAttempts,
    details: 'All logout attempts failed'
  };
}

module.exports = {
  findAndClickSubmitButton,
  detectRecaptcha,
  waitForRecaptchaCompletion,
  findAndClickLogoutButton
};