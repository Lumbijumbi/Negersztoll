'use strict';

/**
 * Maps UI exportMode values to CookieExporter internal format values.
 * Shared between gui/server.js and the worker to avoid format mismatch.
 */
const exportModeMap = {
  'sessionComplete': 'sessionComplete',
  'session': 'sessionOnly',
  'datadome': 'dataDomeOnly',
  'DatadomePostRequestCookieonly': 'DatadomePostRequestCookieonly'
};

/**
 * Resolve a UI exportMode value to its CookieExporter format.
 * @param {string} uiExportMode - The exportMode value from config/UI
 * @param {string} [fallbackFormat] - Fallback format if mode is not mapped
 * @returns {string} Resolved CookieExporter format
 */
function resolveCookieExportFormat(uiExportMode, fallbackFormat) {
  return exportModeMap[uiExportMode] || fallbackFormat || 'sessionComplete';
}

module.exports = { exportModeMap, resolveCookieExportFormat };
