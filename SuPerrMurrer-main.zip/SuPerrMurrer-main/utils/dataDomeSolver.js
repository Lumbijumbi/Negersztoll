/**
 * DataDome CAPTCHA Solver using DeathByCaptcha
 * Includes both reCAPTCHA token injection (solveDataDome) and
 * slider drag simulation (solveDataDomeSlider).
 */
const axios = require('axios');
const config = require('../config');

// DataDome slider captcha — selector sets tried in order
const SLIDER_BUTTON_SELECTORS = [
  '#captcha__button',
  '.captcha__button',
  '[id$="__button"]',
  '.DD_captcha_button',
  '[data-cy="captcha-button"]',
  '.slider__handler',
  '.slide-button'
];

const SLIDER_TRACK_SELECTORS = [
  '#captcha__bar',
  '.captcha__bar',
  '.slider__bar',
  '.DD_captcha_bar',
  '[id$="__bar"]'
];

/**
 * Small random integer between min and max (inclusive).
 * @param {number} min
 * @param {number} max
 * @returns {number}
 */
function _rnd(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Solve a DataDome slider CAPTCHA by simulating a realistic human-like drag.
 *
 * DataDome presents a horizontal slider inside an iframe from captcha-delivery.com.
 * The user must drag the slider button from the left end to the right end of the
 * track.  We replicate this with:
 *   1. Hovering near the button to trigger any hover state.
 *   2. Mouse-down on the centre of the button.
 *   3. A smooth, slightly jittered ease-in-out drag to the far right of the track.
 *   4. Mouse-up, then a brief wait to allow the server-side verification to resolve.
 *   5. Checking whether the iframe is still present to determine success.
 *
 * Coordinates: Playwright returns element bounding boxes in the coordinate space of
 * the document that owns the element.  For a cross-origin iframe the coordinates
 * returned by frame.locator().boundingBox() are relative to the iframe's own
 * viewport.  We therefore get the iframe's page-level offset separately and add the
 * two together to get absolute page coordinates for page.mouse operations.
 *
 * @param {import('playwright').Page} page - Playwright / Patchright page object
 * @returns {Promise<boolean>} true if the captcha appears to have been solved
 */
async function solveDataDomeSlider(page) {
  try {
    // 1. Locate the DataDome iframe element (page-level handle)
    const iframeEl = await page.$('iframe[src*="captcha-delivery.com"]').catch(() => null);
    if (!iframeEl) {
      console.warn('[DATADOME-SLIDER] iframe[src*="captcha-delivery.com"] not found');
      return false;
    }

    const frame = await iframeEl.contentFrame().catch(() => null);
    if (!frame) {
      console.warn('[DATADOME-SLIDER] Could not obtain content frame');
      return false;
    }

    // 2. Obtain the iframe's own offset in page coordinates
    const iframeBox = await iframeEl.boundingBox().catch(() => null);
    if (!iframeBox) {
      console.warn('[DATADOME-SLIDER] Could not get iframe bounding box');
      return false;
    }

    // 3. Find the slider button inside the iframe
    let sliderEl = null;
    for (const sel of SLIDER_BUTTON_SELECTORS) {
      try {
        sliderEl = await frame.waitForSelector(sel, { timeout: 2000 });
        if (sliderEl) {
          console.log(`[DATADOME-SLIDER] Slider button found via: ${sel}`);
          break;
        }
      } catch (_) {
        // try next selector
      }
    }
    if (!sliderEl) {
      console.warn('[DATADOME-SLIDER] Slider button not found inside iframe');
      return false;
    }

    // 4. Get slider button bounding box (relative to iframe viewport)
    const sliderBox = await sliderEl.boundingBox().catch(() => null);
    if (!sliderBox || sliderBox.width === 0) {
      console.warn('[DATADOME-SLIDER] Slider bounding box invalid');
      return false;
    }

    // 5. Determine drag distance from the track width (falls back to a sensible default)
    let trackWidth = 0;
    for (const sel of SLIDER_TRACK_SELECTORS) {
      try {
        const trackEl = await frame.$(sel).catch(() => null);
        if (trackEl) {
          const tb = await trackEl.boundingBox().catch(() => null);
          if (tb && tb.width > 0) {
            trackWidth = tb.width;
            break;
          }
        }
      } catch (_) {
        // try next selector
      }
    }
    // Fallback: use iframe width minus a small margin if we couldn't read the track
    if (!trackWidth) {
      trackWidth = iframeBox.width > 0 ? iframeBox.width - 20 : 300;
    }

    // 6. Convert element-relative coordinates to absolute page coordinates
    const startX = iframeBox.x + sliderBox.x + sliderBox.width / 2;
    const startY = iframeBox.y + sliderBox.y + sliderBox.height / 2;
    const dragDistance = Math.max(0, trackWidth - sliderBox.width);
    const endX = startX + dragDistance;

    console.log(`[DATADOME-SLIDER] Dragging from (${startX.toFixed(0)},${startY.toFixed(0)}) → (${endX.toFixed(0)},${startY.toFixed(0)}) (dist: ${dragDistance.toFixed(0)}px)`);

    // 7. Realistic human-like drag
    // Hover near the button before pressing (simulates pointer approach)
    await page.mouse.move(startX - _rnd(5, 15), startY + _rnd(-3, 3), { steps: _rnd(3, 6) });
    await new Promise(r => setTimeout(r, _rnd(60, 150)));
    await page.mouse.move(startX, startY, { steps: _rnd(2, 4) });
    await new Promise(r => setTimeout(r, _rnd(40, 100)));

    await page.mouse.down();
    await new Promise(r => setTimeout(r, _rnd(80, 180)));

    // Smooth ease-in-out drag in small increments with subtle jitter
    const totalSteps = _rnd(28, 40);
    for (let i = 1; i <= totalSteps; i++) {
      const t = i / totalSteps;
      // Ease-in-out: cubic Hermite
      const eased = t * t * (3 - 2 * t);
      // Clamp x so horizontal jitter never overshoots the end position
      const rawX = startX + (endX - startX) * eased + (Math.random() - 0.5) * 2;
      const x = Math.min(rawX, endX);
      const y = startY + (Math.random() - 0.5) * 3;
      await page.mouse.move(x, y);
      await new Promise(r => setTimeout(r, _rnd(6, 18)));
    }

    // Settle exactly at the end position with consistent minor vertical jitter
    await page.mouse.move(endX, startY + (Math.random() - 0.5) * 2);
    await new Promise(r => setTimeout(r, _rnd(50, 120)));
    await page.mouse.up();

    // 8. Wait for the server-side verification to complete
    await new Promise(r => setTimeout(r, _rnd(1800, 2500)));

    // 9. Check whether the slider iframe is still visible (gone = success)
    const stillPresent = await page.$('iframe[src*="captcha-delivery.com"]').catch(() => null);
    if (!stillPresent) {
      console.log('[DATADOME-SLIDER] ✅ Slider captcha solved (iframe gone)');
      return true;
    }

    console.warn('[DATADOME-SLIDER] ⚠️ Slider captcha iframe still present after drag');
    return false;

  } catch (error) {
    console.error(`[DATADOME-SLIDER] Solve error: ${error.message}`);
    return false;
  }
}

async function solveDataDome(page) {
  try {
    // 1. Detect the DataDome iframe
    const frameElement = await page.waitForSelector('iframe[src*="captcha-delivery.com"]', { timeout: 10000 });
    const frame = await frameElement.contentFrame();
    const frameUrl = await frameElement.getAttribute('src');

    // 2. Extract the SiteKey
    const siteKey = await frame.evaluate(() => {
      const el = document.querySelector('.g-recaptcha');
      return el ? el.getAttribute('data-sitekey') : null;
    });

    if (!siteKey) throw new Error('Could not find DataDome sitekey');

    console.log(`[DATADOME] Solving CAPTCHA (SiteKey: ${siteKey})...`);

    // 3. Request solve from DeathByCaptcha
    const submitRes = await axios.post('http://api.dbcapi.me/api/captcha', {
      username: config.captcha.username,
      password: config.captcha.password,
      type: 4,
      token_params: JSON.stringify({ 
        googlekey: siteKey, 
        pageurl: frameUrl 
      })
    });

    const captchaId = submitRes.data.captcha;
    let token = null;

    // 4. Poll for solution
    for (let i = 0; i < 24; i++) {
      await new Promise(r => setTimeout(r, 5000));
      const statusRes = await axios.get(`http://api.dbcapi.me/api/captcha/${captchaId}`);
      if (statusRes.data.text) {
        token = statusRes.data.text;
        break;
      }
    }

    if (!token) throw new Error('DBC Solving Timeout');

    // 5. Inject the token into the main execution context so that the page's
    // own onSuccess callback (set on the main window) is accessible.
    // Start waitForNavigation BEFORE inject so we never miss the navigation
    // event that the form submit inside evaluate may trigger immediately.
    console.log('[DATADOME] Injecting token and waiting for redirect...');
    await Promise.all([
      page.waitForNavigation({ waitUntil: 'load', timeout: 30000 }),
      frame.evaluate((t) => {
        const responseField = document.querySelector('#g-recaptcha-response') || 
                              document.querySelector('[name="g-recaptcha-response"]');
        if (responseField) {
          responseField.value = t;
          if (typeof window.onSuccess === 'function') {
            window.onSuccess(t);
          } else {
            const form = responseField.closest('form');
            if (form) form.submit();
          }
        }
      }, token, false)
    ]);
    return true;

  } catch (error) {
    console.error(`[DATADOME] Solve Error: ${error.message}`);
    return false;
  }
}

module.exports = { solveDataDome, solveDataDomeSlider };