/**
 * Recovery Scheduler - Manage proxy recovery modes and graduated restart
 * 
 * Modes:
 * - normal: Full operation (100% requests tested)
 * - graduating: Moderate recovery (33% of requests test proxy)
 * - cooldown: Gentle recovery (10% of requests test proxy)
 */

'use strict';

class RecoveryScheduler {
  constructor(options = {}) {
    this.modes = {
      normal: {
        testRate: 1.0,
        duration: Infinity,
        description: 'Full operation'
      },
      graduating: {
        testRate: 0.33,
        duration: options.graduatingDuration || 10 * 60 * 1000,  // 10 min
        description: 'Moderate recovery (test 33%)'
      },
      cooldown: {
        testRate: 0.1,
        duration: options.cooldownDuration || 5 * 60 * 1000,  // 5 min
        description: 'Gentle recovery (test 10%)'
      }
    };
  }

  /**
   * Initialize recovery state on a proxy record
   */
  initializeRecoveryState(record) {
    record.recoveryMode = record.recoveryMode || 'normal';
    record.recoveryScheduledAt = record.recoveryScheduledAt || null;
    record.recoveryAttempts = record.recoveryAttempts || 0;
    record.recoveryLastSuccessAt = record.recoveryLastSuccessAt || null;
  }

  /**
   * Schedule a proxy into recovery mode after failures
   * 
   * @param {object} record - Proxy health record
   * @param {string} failureType - Category of failure (e.g., 'captcha', 'blocked')
   */
  scheduleRecovery(record, failureType) {
    this.initializeRecoveryState(record);

    const now = Date.now();
    
    // Determine recovery mode based on failure severity
    let mode = 'graduating';  // Default: moderate recovery
    
    if (failureType === 'blocked' || failureType === 'captcha' || failureType === 'tls_error') {
      mode = 'cooldown';  // Harsh failures = gentle recovery
    }
    
    record.recoveryMode = mode;
    record.recoveryScheduledAt = now;
    record.recoveryAttempts = 0;
  }

  /**
   * Check if this request should test the proxy during recovery
   * 
   * @param {object} record - Proxy health record
   * @returns {boolean} - True if request should go through proxy
   */
  shouldTestDuringRecovery(record) {
    this.initializeRecoveryState(record);

    const mode = this.modes[record.recoveryMode];
    if (!mode) {
      record.recoveryMode = 'normal';
      return true;
    }

    // Always test in normal mode
    if (record.recoveryMode === 'normal') {
      return true;
    }

    // Random testing in graduated/cooldown modes
    return Math.random() < mode.testRate;
  }

  /**
   * Record a successful test during recovery
   * Increments recovery success count toward promotion
   * 
   * @param {object} record - Proxy health record
   */
  recordRecoverySuccess(record) {
    this.initializeRecoveryState(record);
    
    record.recoveryAttempts++;
    record.recoveryLastSuccessAt = Date.now();
    
    // Auto-promote if enough successes (3+ per mode)
    if (record.recoveryAttempts >= 3) {
      this.promoteRecoveryStage(record);
    }
  }

  /**
   * Promote proxy to next recovery stage
   * cooldown → graduating → normal
   * 
   * @param {object} record - Proxy health record
   */
  promoteRecoveryStage(record) {
    this.initializeRecoveryState(record);

    if (record.recoveryMode === 'cooldown') {
      record.recoveryMode = 'graduating';
      record.recoveryAttempts = 0;
    } else if (record.recoveryMode === 'graduating') {
      record.recoveryMode = 'normal';
      record.recoveryAttempts = 0;
    }
  }

  /**
   * Check if recovery mode duration has expired, auto-promote
   * 
   * @param {object} record - Proxy health record
   * @returns {boolean} - True if recovery mode changed
   */
  checkRecoveryDuration(record) {
    this.initializeRecoveryState(record);

    if (record.recoveryMode === 'normal') {
      return false;
    }

    const mode = this.modes[record.recoveryMode];
    if (!mode || mode.duration === Infinity) {
      return false;
    }

    const elapsed = Date.now() - (record.recoveryScheduledAt || Date.now());
    if (elapsed >= mode.duration) {
      this.promoteRecoveryStage(record);
      return true;
    }

    return false;
  }

  /**
   * Demote proxy back to cooldown (manual intervention for re-failures)
   * 
   * @param {object} record - Proxy health record
   */
  demoteRecoveryStage(record) {
    this.initializeRecoveryState(record);

    if (record.recoveryMode !== 'cooldown') {
      record.recoveryMode = 'cooldown';
      record.recoveryScheduledAt = Date.now();
      record.recoveryAttempts = 0;
    }
  }

  /**
   * Get recovery status
   */
  getRecoveryStatus(record) {
    this.initializeRecoveryState(record);

    const mode = this.modes[record.recoveryMode];
    const elapsed = record.recoveryScheduledAt 
      ? Date.now() - record.recoveryScheduledAt
      : 0;
    
    return {
      mode: record.recoveryMode,
      testRate: mode.testRate,
      duration: mode.duration,
      elapsed,
      attempts: record.recoveryAttempts,
      lastSuccess: record.recoveryLastSuccessAt,
      description: mode.description
    };
  }

  /**
   * Reset recovery to normal
   */
  resetRecovery(record) {
    record.recoveryMode = 'normal';
    record.recoveryScheduledAt = null;
    record.recoveryAttempts = 0;
    record.recoveryLastSuccessAt = null;
  }
}

module.exports = RecoveryScheduler;
