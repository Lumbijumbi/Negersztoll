/**
 * Account Unlock Module
 * 
 * Attempts to unlock a locked account by triggering a password reset flow.
 * Used when an account is detected as locked due to too many login attempts.
 */

'use strict';

const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');
const { fastFill } = require('../formFill');

/**
 * Attempt to unlock a locked account via password reset
 *
 * @param {import('playwright').Page} page - Playwright page object
 * @param {string} email - Email address (username) used for password reset
 * @param {Object} config - Configuration object
 * @param {Object} logger - Logger instance
 * @returns {Promise<{success: boolean, method: string, details: string}>}
 */
async function unlockAccountViaPasswordReset(page, email, config, logger) {
  const prConfig = config.passwordReset || {};
  const navTimeout = prConfig.navigationTimeout || 10000;
  const confirmTimeout = prConfig.confirmationTimeout || 5000;

  logger.info('[UNLOCK]', `Attempting password reset for locked account: ${email}`);

  try {
    // ── Step 1: Find and click the password-reset link ────────────────────────
    const resetClicked = await _clickPasswordResetLink(page, config, logger, navTimeout);
    if (!resetClicked) {
      logger.warn('[UNLOCK]', `❌ Password reset link not found for ${email}`);
      await _writeUnlockRequestedEntry(email, config, logger, 'failed:link_not_found');
      return { success: false, method: 'none', details: 'password_reset_link_not_found' };
    }

    // ── Step 2: Wait for the reset form to appear (up to navTimeout) ──────────
    const emailFilled = await _waitForEmailFieldAndFill(page, email, config, logger, navTimeout);
    if (!emailFilled) {
      logger.warn('[UNLOCK]', `❌ Could not fill email field for ${email}`);
      await _writeUnlockRequestedEntry(email, config, logger, 'failed:email_field_not_found');
      return { success: false, method: 'reset_link_clicked', details: 'email_field_not_found' };
    }

    // ── Step 2.5: Dismiss consent overlay, then detect and handle CAPTCHA ─────
    const captchaConfig = (config.passwordReset || {}).captchaHandling || {};
    if (captchaConfig.enabled) {
      await _dismissConsentOverlay(page, config, logger);
      const captchaResult = await _detectAndHandleCaptcha(page, config, logger);
      if (captchaResult.detected) {
        const captchaHandled = await _handleCaptchaStrategy(page, email, config, logger, captchaResult);
        if (!captchaHandled.continueFlow) {
          await _writeUnlockRequestedEntry(email, config, logger, captchaHandled.status);
          return {
            success: false,
            method: 'email_filled',
            details: captchaHandled.details
          };
        }
      }
    }

    // ── Step 3: Click the submit button ───────────────────────────────────────
    const submitted = await _clickResetSubmitButton(page, config, logger);
    if (!submitted) {
      logger.warn('[UNLOCK]', `❌ Could not click reset submit button for ${email}`);
      await _writeUnlockRequestedEntry(email, config, logger, 'failed:submit_button_not_found');
      return { success: false, method: 'email_filled', details: 'submit_button_not_found' };
    }

    // ── Step 4: Wait for confirmation ─────────────────────────────────────────
    const confirmed = await _waitForConfirmation(page, config, logger, confirmTimeout);

    if (confirmed) {
      logger.success('[UNLOCK]', `✅ Password reset requested for ${email}`);
      await _writeUnlockRequestedEntry(email, config, logger, 'reset_email_sent');
      return { success: true, method: 'password_reset', details: 'reset_email_sent' };
    } else {
      // Form was submitted but no confirmation phrase was detected — treat as uncertain
      logger.warn('[UNLOCK]', `⚠️ Reset form submitted for ${email} but confirmation not detected`);
      await _writeUnlockRequestedEntry(email, config, logger, 'reset_submitted_unconfirmed');
      return { success: true, method: 'password_reset', details: 'reset_submitted_unconfirmed' };
    }
  } catch (err) {
    const errorMessage = err?.message || String(err);
    logger.warn('[UNLOCK]', `❌ Password reset failed for ${email}: ${errorMessage}`);
    return { success: false, method: 'error', details: errorMessage };
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Internal helpers
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Find and click the "forgot password" / password-reset link on the current page.
 */
async function _clickPasswordResetLink(page, config, logger, timeout) {
  const prConfig = config.passwordReset || {};

  // 1) Config selector (login.forgotPasswordLink)
  const configSelector = config.login && config.login.forgotPasswordLink;
  if (configSelector) {
    if (await _tryClick(page, configSelector, timeout, logger)) {
      logger.info('[UNLOCK]', `Reset link clicked via configSelector: ${configSelector}`);
      return true;
    }
  }

  // 2) Configured link selectors from passwordReset section
  const resetLinkSelectors = prConfig.resetLinkSelectors || [
    "a[href*='forgot']",
    "a[href*='reset']",
    "a[href*='password']",
    "a[href*='passwort']"
  ];
  for (const sel of resetLinkSelectors) {
    if (await _tryClick(page, sel, timeout, logger)) {
      logger.info('[UNLOCK]', `Reset link clicked via selector: ${sel}`);
      return true;
    }
  }

  // 3) Text-based search (configured phrases + defaults)
  const resetPhrases = prConfig.resetLinkPhrases || [
    'Passwort zurücksetzen',
    'Passwort vergessen',
    'Forgot password',
    'Reset password',
    'jetzt ihr Passwort zurück'
  ];
  for (const phrase of resetPhrases) {
    try {
      const locator = page.getByText(phrase, { exact: false });
      const count = await locator.count().catch(() => 0);
      if (count > 0) {
        await locator.first().click({ timeout });
        logger.info('[UNLOCK]', `Reset link clicked via text phrase: "${phrase}"`);
        return true;
      }
    } catch (_) {
      // continue to next phrase
    }
  }

  return false;
}

/**
 * Wait for an email/username field to appear (up to navTimeout) and fill it.
 * Replaces the fixed-delay sleep so slower reset pages don't cause false negatives.
 */
async function _waitForEmailFieldAndFill(page, email, config, logger, navTimeout) {
  const prConfig = config.passwordReset || {};
  const configuredSelector = prConfig.emailSelector ||
    "#email, #username, input[type='email'], input[name='email'], input[name='username']";

  const selectors = configuredSelector.split(',').map(s => s.trim()).filter(Boolean);
  const formLoadDelay = prConfig.formLoadDelay || 1500;

  // Poll for any of the selectors to become visible, up to navTimeout
  const deadline = Date.now() + navTimeout;
  // Give the page a minimum grace period before starting to poll.
  // Capped at navTimeout so a very small navTimeout doesn't cause an overshoot.
  await _sleep(Math.min(formLoadDelay, navTimeout));

  while (Date.now() < deadline) {
    for (const sel of selectors) {
      try {
        const visible = await page.isVisible(sel).catch(() => false);
        if (visible) {
          const filled = await fastFill(page, sel, email, { logPrefix: '[UNLOCK]' });
          if (filled) {
            logger.info('[UNLOCK]', `Email filled via selector: ${sel}`);
            return true;
          }
        }
      } catch (_) {
        // continue to next selector
      }
    }
    await _sleep(300);
  }

  return false;
}

/**
 * Find and click the submit button on the password-reset form.
 */
async function _clickResetSubmitButton(page, config, logger) {
  const prConfig = config.passwordReset || {};
  const timeout = prConfig.navigationTimeout || 10000;

  // 1) Configured CSS selectors
  const submitSelectors = prConfig.submitSelectors || [
    "button[type='submit']",
    "input[type='submit']",
    "button.btn-primary"
  ];
  for (const sel of submitSelectors) {
    if (await _tryClick(page, sel, timeout, logger)) {
      logger.info('[UNLOCK]', `Reset submit clicked via selector: ${sel}`);
      return true;
    }
  }

  // 2) Text-based search
  const submitPhrases = prConfig.submitPhrases || [
    'Absenden',
    'Senden',
    'Submit',
    'Zurücksetzen',
    'Reset'
  ];
  for (const phrase of submitPhrases) {
    try {
      const locator = page.getByRole('button', { name: phrase, exact: false });
      const count = await locator.count().catch(() => 0);
      if (count > 0) {
        await locator.first().click({ timeout });
        logger.info('[UNLOCK]', `Reset submit clicked via button text: "${phrase}"`);
        return true;
      }
    } catch (_) {
      // continue
    }
  }

  return false;
}

/**
 * Wait for a confirmation message that the reset email was sent.
 */
async function _waitForConfirmation(page, config, logger, timeout) {
  const prConfig = config.passwordReset || {};
  const phrases = prConfig.confirmationPhrases || [
    'E-Mail wurde gesendet',
    'Email has been sent',
    'Überprüfen Sie Ihr Postfach',
    'Check your inbox',
    'Passwort zurücksetzen Link',
    'erfolgreich'
  ];

  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    try {
      const bodyText = await page.evaluate(() => document.body.innerText || '').catch(() => '');
      const normalized = bodyText.toLowerCase();
      for (const phrase of phrases) {
        if (normalized.includes(phrase.toLowerCase())) {
          logger.info('[UNLOCK]', `Confirmation phrase found: "${phrase}"`);
          return true;
        }
      }
    } catch (_) {
      // ignore transient errors while polling
    }
    await _sleep(500);
  }
  return false;
}

/**
 * Append entry to the unlock_requested output file.
 * @param {string} email
 * @param {Object} config
 * @param {Object} logger
 * @param {string} status - short status tag (e.g. 'reset_email_sent', 'failed:link_not_found')
 */
async function _writeUnlockRequestedEntry(email, config, logger, status) {
  try {
    const outputConfig = config.output || {};
    const filename = outputConfig.unlockRequestedFile || 'unlock_requested.txt';
    const filePath = path.isAbsolute(filename) ? filename : path.join(process.cwd(), filename);

    const timestamp = new Date().toISOString();
    const line = `${timestamp} | ${email} | ${status || 'unknown'}\n`;

    fs.appendFileSync(filePath, line, 'utf8');
    logger.info('[UNLOCK]', `Logged to ${filename}: ${email} [${status}]`);
  } catch (err) {
    logger.warn('[UNLOCK]', `Could not write to unlock_requested file: ${err?.message || String(err)}`);
  }
}

/**
 * Try clicking a CSS selector, return true on success.
 */
async function _tryClick(page, selector, timeout, logger) {
  try {
    const visible = await page.isVisible(selector).catch(() => false);
    if (!visible) return false;
    await page.click(selector, { timeout });
    return true;
  } catch (_) {
    return false;
  }
}

/** Simple sleep helper */
function _sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Attempt to dismiss privacy/consent overlays before interacting with the form.
 * Tries common consent-accept button selectors silently.
 *
 * @param {import('playwright').Page} page
 * @param {Object} config
 * @param {Object} logger
 */
async function _dismissConsentOverlay(page, config, logger) {
  const captchaConfig = (config.passwordReset || {}).captchaHandling || {};
  const consentSelectors = captchaConfig.consentSelectors || [
    "button:has-text('Alle akzeptieren')",
    "button:has-text('Accept all')",
    '#onetrust-accept-btn-handler',
    '.consent-accept',
    "button[data-testid='consent-accept']"
  ];

  for (const sel of consentSelectors) {
    try {
      const visible = await page.isVisible(sel).catch(() => false);
      if (visible) {
        await page.click(sel, { timeout: 3000 });
        logger.info('[UNLOCK]', `Consent overlay dismissed via: ${sel}`);
        await _sleep(500);
        return true;
      }
    } catch (_) {
      // continue to next selector
    }
  }
  return false;
}

/**
 * Detect the presence of a CAPTCHA on the current page.
 *
 * @param {import('playwright').Page} page
 * @param {Object} config
 * @param {Object} logger
 * @returns {Promise<{detected: boolean, type: string, selector: string}>}
 */
async function _detectAndHandleCaptcha(page, config, logger) {
  const captchaConfig = (config.passwordReset || {}).captchaHandling || {};

  if (captchaConfig.enabled === false) {
    return { detected: false, type: 'none', selector: '' };
  }

  const captchaSelectors = captchaConfig.captchaSelectors || [
    "iframe[src*='recaptcha']",
    "iframe[src*='captcha-delivery.com']",
    '.g-recaptcha',
    'div[data-sitekey]',
    '#recaptcha',
    "iframe[src*='hcaptcha']",
    '.h-captcha'
  ];

  for (const sel of captchaSelectors) {
    try {
      const visible = await page.isVisible(sel).catch(() => false);
      if (visible) {
        const type = _classifyCaptchaType(sel);
        logger.warn('[UNLOCK]', `⚠️ CAPTCHA detected (type: ${type}, selector: ${sel})`);
        return { detected: true, type, selector: sel };
      }
    } catch (_) {
      // continue
    }
  }

  return { detected: false, type: 'none', selector: '' };
}

/**
 * Classify CAPTCHA type from selector string.
 * @param {string} selector
 * @returns {string}
 */
function _classifyCaptchaType(selector) {
  if (/captcha-delivery\.com(?:[/'"]|$)/.test(selector)) return 'datadome';
  if (selector.includes('hcaptcha') || selector.includes('h-captcha')) return 'hcaptcha';
  if (
    selector.includes('recaptcha') ||
    selector.includes('g-recaptcha') ||
    selector.includes('data-sitekey')
  ) return 'recaptcha';
  return 'unknown';
}

/**
 * Execute the configured CAPTCHA handling strategy.
 *
 * @param {import('playwright').Page} page
 * @param {string} email
 * @param {Object} config
 * @param {Object} logger
 * @param {{detected: boolean, type: string, selector: string}} captchaResult
 * @returns {Promise<{continueFlow: boolean, status: string, details: string}>}
 */
async function _handleCaptchaStrategy(page, email, config, logger, captchaResult) {
  const captchaConfig = (config.passwordReset || {}).captchaHandling || {};
  const strategy = captchaConfig.strategy || 'skip';

  logger.info('[UNLOCK]', `Applying CAPTCHA strategy "${strategy}" for type: ${captchaResult.type}`);

  if (strategy === 'screenshot') {
    await _takeCaptchaScreenshot(page, email, config, logger, captchaResult.type);
    return {
      continueFlow: false,
      status: `failed:captcha_detected:${captchaResult.type}`,
      details: `captcha_detected:${captchaResult.type}`
    };
  }

  if (strategy === 'solve') {
    const solveResult = await _attemptCaptchaSolve(page, config, logger, captchaResult);
    if (solveResult) {
      logger.success('[UNLOCK]', `✅ CAPTCHA solved for ${email}`);
      return { continueFlow: true, status: 'captcha_solved', details: 'captcha_solved' };
    }
    // Solve failed — fall through to screenshot + skip
    if (captchaConfig.screenshotOnCaptcha !== false) {
      await _takeCaptchaScreenshot(page, email, config, logger, captchaResult.type);
    }
    logger.warn('[UNLOCK]', `❌ CAPTCHA solve failed for ${email}`);
    return {
      continueFlow: false,
      status: `failed:captcha_solve_failed:${captchaResult.type}`,
      details: `captcha_solve_failed:${captchaResult.type}`
    };
  }

  if (strategy === 'pause') {
    const pauseTimeout = captchaConfig.pauseTimeout || 120000;
    logger.warn('[UNLOCK]', `⏸️ CAPTCHA detected for ${email} — pausing ${pauseTimeout}ms for manual resolution`);
    await _sleep(pauseTimeout);
    // After pause, check if CAPTCHA is gone
    const stillPresent = await page.isVisible(captchaResult.selector).catch(() => false);
    if (!stillPresent) {
      logger.info('[UNLOCK]', `CAPTCHA resolved after pause for ${email}`);
      return { continueFlow: true, status: 'captcha_resolved_after_pause', details: 'captcha_resolved_after_pause' };
    }
    logger.warn('[UNLOCK]', `⚠️ CAPTCHA still present after pause for ${email}`);
    return {
      continueFlow: false,
      status: `failed:captcha_not_resolved:${captchaResult.type}`,
      details: `captcha_not_resolved:${captchaResult.type}`
    };
  }

  // Default: skip
  if (captchaConfig.screenshotOnCaptcha !== false) {
    await _takeCaptchaScreenshot(page, email, config, logger, captchaResult.type);
  }
  logger.warn('[UNLOCK]', `⏭️ Skipping account ${email} due to CAPTCHA (type: ${captchaResult.type})`);
  return {
    continueFlow: false,
    status: `failed:captcha_detected:${captchaResult.type}`,
    details: `captcha_detected:${captchaResult.type}`
  };
}

/**
 * Take a screenshot and save it for manual review.
 * @param {import('playwright').Page} page
 * @param {string} email
 * @param {Object} config
 * @param {Object} logger
 * @param {string} captchaType
 */
async function _takeCaptchaScreenshot(page, email, config, logger, captchaType) {
  try {
    const captchaConfig = (config.passwordReset || {}).captchaHandling || {};
    const screenshotDir = captchaConfig.screenshotDir || 'screenshots/captcha';
    const absDir = path.isAbsolute(screenshotDir)
      ? screenshotDir
      : path.join(process.cwd(), screenshotDir);

    if (!fs.existsSync(absDir)) {
      fs.mkdirSync(absDir, { recursive: true });
    }

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const safeMail = email.replace(/[^a-zA-Z0-9@._-]/g, '_');
    const filename = `captcha_${captchaType}_${safeMail}_${timestamp}.png`;
    const screenshotPath = path.join(absDir, filename);

    await page.screenshot({ path: screenshotPath, fullPage: false });
    logger.info('[UNLOCK]', `📸 CAPTCHA screenshot saved: ${screenshotPath}`);
    return screenshotPath;
  } catch (err) {
    logger.warn('[UNLOCK]', `Could not save CAPTCHA screenshot: ${err?.message || String(err)}`);
    return null;
  }
}

/**
 * Attempt to solve a CAPTCHA using the configured solver service.
 * Follows the same pattern as dataDomeSolver.js.
 *
 * @param {import('playwright').Page} page
 * @param {Object} config
 * @param {Object} logger
 * @param {{detected: boolean, type: string, selector: string}} captchaResult
 * @returns {Promise<boolean>}
 */
async function _attemptCaptchaSolve(page, config, logger, captchaResult) {
  const captchaConfig = (config.passwordReset || {}).captchaHandling || {};
  const solverService = captchaConfig.solverService;
  const apiKey = captchaConfig.solverApiKey || '';
  const maxAttempts = captchaConfig.maxSolveAttempts || 2;
  const solveTimeout = captchaConfig.solveTimeout || 120000;

  if (!solverService || !apiKey) {
    logger.warn('[UNLOCK]', 'CAPTCHA solve strategy requires solverService and solverApiKey in config');
    return false;
  }

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    logger.info('[UNLOCK]', `CAPTCHA solve attempt ${attempt}/${maxAttempts} via ${solverService}`);
    try {
      let siteKey = null;
      let pageUrl = null;

      // Extract siteKey and page URL
      try {
        pageUrl = page.url();
        siteKey = await page.evaluate(() => {
          const el = document.querySelector('[data-sitekey]') ||
                     document.querySelector('.g-recaptcha') ||
                     document.querySelector('.h-captcha');
          return el ? el.getAttribute('data-sitekey') : null;
        }).catch(() => null);

        // Try inside iframe for DataDome / framed CAPTCHAs
        if (!siteKey && captchaResult.type === 'datadome') {
          const frameEl = await page.$(captchaResult.selector).catch(() => null);
          if (frameEl) {
            const frame = await frameEl.contentFrame().catch(() => null);
            if (frame) {
              pageUrl = await frameEl.getAttribute('src').catch(() => pageUrl);
              siteKey = await frame.evaluate(() => {
                const el = document.querySelector('.g-recaptcha') || document.querySelector('[data-sitekey]');
                return el ? el.getAttribute('data-sitekey') : null;
              }).catch(() => null);
            }
          }
        }
      } catch (_) {
        // Ignore extraction errors
      }

      if (!siteKey) {
        logger.warn('[UNLOCK]', `Could not extract siteKey for CAPTCHA solve (attempt ${attempt})`);
        continue;
      }

      let token = null;

      if (solverService === 'deathbycaptcha') {
        token = await _solveViaDeathByCaptcha(apiKey, siteKey, pageUrl, solveTimeout, logger, captchaResult.type);
      } else if (solverService === '2captcha') {
        token = await _solveVia2Captcha(apiKey, siteKey, pageUrl, solveTimeout, logger, captchaResult.type);
      } else if (solverService === 'anticaptcha') {
        token = await _solveViaAntiCaptcha(apiKey, siteKey, pageUrl, solveTimeout, logger, captchaResult.type);
      } else {
        logger.warn('[UNLOCK]', `Unknown solver service: ${solverService}`);
        return false;
      }

      if (token) {
        // Inject token into the main execution context so that the page's
        // own onSuccess callback (set on the main window) is accessible.
        await page.evaluate((t) => {
          const responseField = document.querySelector('#g-recaptcha-response') ||
                                document.querySelector('[name="g-recaptcha-response"]') ||
                                document.querySelector('#h-captcha-response') ||
                                document.querySelector('[name="h-captcha-response"]');
          if (responseField) {
            responseField.value = t;
            if (typeof window.onSuccess === 'function') {
              window.onSuccess(t);
            }
          }
        }, token, false);
        logger.info('[UNLOCK]', `CAPTCHA token injected (attempt ${attempt})`);
        return true;
      }
    } catch (err) {
      logger.warn('[UNLOCK]', `CAPTCHA solve attempt ${attempt} error: ${err?.message || String(err)}`);
    }
  }
  return false;
}

/**
 * Make an HTTP/HTTPS POST/GET request (simple wrapper without axios).
 * @param {string} url
 * @param {Object|null} postData - if set, performs POST with JSON body; otherwise GET
 * @param {number} timeoutMs
 * @returns {Promise<string>}
 */
function _httpRequest(url, postData, timeoutMs) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const lib = parsed.protocol === 'https:' ? https : http;
    const body = postData ? JSON.stringify(postData) : null;
    const options = {
      hostname: parsed.hostname,
      port: parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
      path: parsed.pathname + (parsed.search || ''),
      method: postData ? 'POST' : 'GET',
      headers: postData ? {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body)
      } : {}
    };

    let settled = false;
    let timer;
    let response = null;

    const req = lib.request(options, (res) => {
      response = res;
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(data);
      });
      res.on('error', (err) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        reject(err);
      });
    });

    req.on('error', (e) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      reject(e);
    });

    timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      const err = new Error(`HTTP request timed out: ${options.method} ${url}`);
      try { req.destroy(err); } catch (_) {}
      if (response && typeof response.destroy === 'function') {
        try { response.destroy(err); } catch (_) {}
      }
      reject(err);
    }, timeoutMs || 30000);

    if (body) req.write(body);
    req.end();
  });
}

/**
 * Solve CAPTCHA via DeathByCaptcha API.
 * @param {string} captchaType - 'recaptcha' | 'hcaptcha' | 'datadome' | 'unknown'
 */
async function _solveViaDeathByCaptcha(apiKey, siteKey, pageUrl, solveTimeout, logger, captchaType) {
  // apiKey format expected: "username:password"
  const [username, password] = apiKey.split(':');
  if (!username || !password) {
    logger.warn('[UNLOCK]', 'DeathByCaptcha apiKey must be in format "username:password"');
    return null;
  }

  // DBC type 4 = reCAPTCHA; type 7 = hCaptcha
  const isHCaptcha = captchaType === 'hcaptcha';
  const dbcType = isHCaptcha ? 7 : 4;
  const keyName = isHCaptcha ? 'sitekey' : 'googlekey';
  const tokenParams = JSON.stringify({ [keyName]: siteKey, pageurl: pageUrl });
  const submitBody = `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}&type=${dbcType}&token_params=${encodeURIComponent(tokenParams)}`;
  const submitOptions = {
    hostname: 'api.dbcapi.me',
    port: 80,
    path: '/api/captcha',
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Length': Buffer.byteLength(submitBody)
    }
  };

  let captchaId = null;
  try {
    captchaId = await new Promise((resolve, reject) => {
      let settled = false;
      let timer;

      const req = http.request(submitOptions, (res) => {
        let data = '';
        res.on('data', c => { data += c; });
        res.on('end', () => {
          if (settled) return;
          settled = true;
          clearTimeout(timer);
          try {
            const parsed = new URLSearchParams(data);
            resolve(parsed.get('captcha') || null);
          } catch (_) { resolve(null); }
        });
        res.on('error', (e) => {
          if (settled) return;
          settled = true;
          clearTimeout(timer);
          reject(e);
        });
      });

      req.on('error', (e) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        reject(e);
      });

      timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        const err = new Error('DeathByCaptcha submit timed out');
        try { req.destroy(err); } catch (_) {}
        reject(err);
      }, 15000);

      req.write(submitBody);
      req.end();
    });
  } catch (err) {
    logger.warn('[UNLOCK]', `DeathByCaptcha submit failed: ${err?.message || String(err)}`);
    return null;
  }

  if (!captchaId) return null;

  const pollDeadline = Date.now() + solveTimeout;
  while (Date.now() < pollDeadline) {
    await _sleep(5000);
    try {
      const statusRaw = await _httpRequest(`http://api.dbcapi.me/api/captcha/${captchaId}`, null, 10000);
      const parsed = new URLSearchParams(statusRaw);
      const text = parsed.get('text');
      if (text) return text;
    } catch (_) {}
  }
  return null;
}

/**
 * Solve CAPTCHA via 2Captcha API.
 * @param {string} captchaType - 'recaptcha' | 'hcaptcha' | 'datadome' | 'unknown'
 */
async function _solveVia2Captcha(apiKey, siteKey, pageUrl, solveTimeout, logger, captchaType) {
  // 2Captcha uses different method + key parameter name depending on CAPTCHA type
  const isHCaptcha = captchaType === 'hcaptcha';
  const method = isHCaptcha ? 'hcaptcha' : 'userrecaptcha';
  const keyParam = isHCaptcha ? 'sitekey' : 'googlekey';
  // Submit task
  const submitUrl = `https://2captcha.com/in.php?key=${encodeURIComponent(apiKey)}&method=${method}&${keyParam}=${encodeURIComponent(siteKey)}&pageurl=${encodeURIComponent(pageUrl)}&json=1`;
  let captchaId = null;
  try {
    const submitRaw = await _httpRequest(submitUrl, null, 15000);
    const submitRes = JSON.parse(submitRaw);
    if (submitRes.status !== 1) {
      logger.warn('[UNLOCK]', `2Captcha submit error: ${submitRes.error_text || submitRes.request}`);
      return null;
    }
    captchaId = submitRes.request;
  } catch (err) {
    logger.warn('[UNLOCK]', `2Captcha submit failed: ${err?.message || String(err)}`);
    return null;
  }

  // Poll for result
  const pollDeadline = Date.now() + solveTimeout;
  await _sleep(20000); // Initial wait
  while (Date.now() < pollDeadline) {
    try {
      const resultUrl = `https://2captcha.com/res.php?key=${encodeURIComponent(apiKey)}&action=get&id=${captchaId}&json=1`;
      const resultRaw = await _httpRequest(resultUrl, null, 10000);
      const resultRes = JSON.parse(resultRaw);
      if (resultRes.status === 1) return resultRes.request;
      if (resultRes.request !== 'CAPCHA_NOT_READY') {
        logger.warn('[UNLOCK]', `2Captcha poll error: ${resultRes.request}`);
        return null;
      }
    } catch (_) {}
    await _sleep(5000);
  }
  return null;
}

/**
 * Solve CAPTCHA via AntiCaptcha API.
 * @param {string} captchaType - 'recaptcha' | 'hcaptcha' | 'datadome' | 'unknown'
 */
async function _solveViaAntiCaptcha(apiKey, siteKey, pageUrl, solveTimeout, logger, captchaType) {
  // Create task
  const isHCaptcha = captchaType === 'hcaptcha';
  const taskType = isHCaptcha ? 'HCaptchaTaskProxyless' : 'NoCaptchaTaskProxyless';
  let taskId = null;
  try {
    const createBody = {
      clientKey: apiKey,
      task: {
        type: taskType,
        websiteURL: pageUrl,
        websiteKey: siteKey
      }
    };
    const createRaw = await _httpRequest('https://api.anti-captcha.com/createTask', createBody, 15000);
    const createRes = JSON.parse(createRaw);
    if (createRes.errorId !== 0) {
      logger.warn('[UNLOCK]', `AntiCaptcha create error: ${createRes.errorDescription}`);
      return null;
    }
    taskId = createRes.taskId;
  } catch (err) {
    logger.warn('[UNLOCK]', `AntiCaptcha create task failed: ${err?.message || String(err)}`);
    return null;
  }

  // Poll for result
  const pollDeadline = Date.now() + solveTimeout;
  await _sleep(10000); // Initial wait
  while (Date.now() < pollDeadline) {
    try {
      const resultBody = { clientKey: apiKey, taskId };
      const resultRaw = await _httpRequest('https://api.anti-captcha.com/getTaskResult', resultBody, 10000);
      const resultRes = JSON.parse(resultRaw);
      if (resultRes.errorId !== 0) {
        logger.warn('[UNLOCK]', `AntiCaptcha poll error: ${resultRes.errorDescription}`);
        return null;
      }
      if (resultRes.status === 'ready') return resultRes.solution.gRecaptchaResponse;
    } catch (_) {}
    await _sleep(5000);
  }
  return null;
}

module.exports = {
  unlockAccountViaPasswordReset,
  _writeUnlockRequestedEntry,
  _waitForConfirmation,
  _dismissConsentOverlay,
  _detectAndHandleCaptcha,
  _handleCaptchaStrategy,
  _classifyCaptchaType,
  _takeCaptchaScreenshot,
  _attemptCaptchaSolve,
  _httpRequest
};
