'use strict';

const mockFs = {
  existsSync: jest.fn().mockReturnValue(false),
  mkdirSync: jest.fn(),
  writeFileSync: jest.fn(),
  readdirSync: jest.fn().mockReturnValue([]),
  statSync: jest.fn().mockReturnValue({ size: 100 }),
  readFileSync: jest.fn().mockReturnValue('{}')
};

jest.mock('fs', () => mockFs);

const fs = require('fs');
const CookieExporter = require('../../utils/cookieExporter');

describe('CookieExporter', () => {
  beforeEach(() => {
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'warn').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});

    fs.existsSync.mockReturnValue(false);
    fs.mkdirSync.mockReset();
    fs.writeFileSync.mockReset();
    fs.readdirSync.mockReturnValue([]);
    fs.statSync.mockReturnValue({ size: 100 });
    fs.readFileSync.mockReturnValue('{}');
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('constructor', () => {
    it('should use default exportDir', () => {
      const exporter = new CookieExporter();
      expect(exporter.exportDir).toContain('CookieExports');
    });

    it('should use provided exportDir', () => {
      const exporter = new CookieExporter({ exportDir: '/custom/dir' });
      expect(exporter.exportDir).toBe('/custom/dir');
    });

    it('should be enabled by default', () => {
      const exporter = new CookieExporter();
      expect(exporter.enabled).toBe(true);
    });

    it('should respect enabled=false', () => {
      const exporter = new CookieExporter({ enabled: false });
      expect(exporter.enabled).toBe(false);
    });

    it('should create export directory when enabled', () => {
      fs.existsSync.mockReturnValue(false);
      new CookieExporter({ exportDir: '/fake/dir' });
      expect(fs.mkdirSync).toHaveBeenCalledWith('/fake/dir', { recursive: true });
    });

    it('should not create directory when disabled', () => {
      new CookieExporter({ exportDir: '/fake/dir', enabled: false });
      expect(fs.mkdirSync).not.toHaveBeenCalled();
    });

    it('should not create directory when it already exists', () => {
      fs.existsSync.mockReturnValue(true);
      new CookieExporter({ exportDir: '/existing/dir' });
      expect(fs.mkdirSync).not.toHaveBeenCalled();
    });
  });

  describe('_sanitize', () => {
    it('should sanitize strings with special characters', () => {
      const exporter = new CookieExporter({ enabled: false });
      const result = exporter._sanitize('user@test.com/path');
      expect(result).not.toContain('/');
      expect(result).not.toContain('@');
    });

    it('should return unknown for null/non-string input', () => {
      const exporter = new CookieExporter({ enabled: false });
      expect(exporter._sanitize(null)).toBe('unknown');
      expect(exporter._sanitize(123)).toBe('unknown');
    });

    it('should truncate to 80 characters', () => {
      const exporter = new CookieExporter({ enabled: false });
      const long = 'a'.repeat(200);
      expect(exporter._sanitize(long).length).toBe(80);
    });
  });

  describe('_buildPythonSnippet', () => {
    it('should generate a valid Python snippet', () => {
      const exporter = new CookieExporter({ enabled: false });
      const exportData = {
        capturedAt: new Date().toISOString(),
        username: 'testuser',
        loginUrl: 'https://example.com/login',
        proxy: 'http://proxy:8080',
        cookies: [{ name: 'session', value: 'abc123' }],
        headers: { 'User-Agent': 'Mozilla/5.0' }
      };
      const snippet = exporter._buildPythonSnippet(exportData);
      expect(snippet).toContain('import requests');
      expect(snippet).toContain('session = requests.Session()');
      expect(snippet).toContain('session');
      expect(snippet).toContain('abc123');
    });

    it('should handle missing proxy', () => {
      const exporter = new CookieExporter({ enabled: false });
      const exportData = {
        capturedAt: new Date().toISOString(),
        username: 'testuser',
        loginUrl: 'https://example.com/login',
        proxy: null,
        cookies: [{ name: 'session', value: 'abc123' }],
        headers: {}
      };
      const snippet = exporter._buildPythonSnippet(exportData);
      expect(snippet).toContain('import requests');
      expect(snippet).not.toContain('proxies');
    });

    it('should escape quotes in cookie values', () => {
      const exporter = new CookieExporter({ enabled: false });
      const exportData = {
        capturedAt: new Date().toISOString(),
        username: 'user',
        loginUrl: 'https://example.com',
        proxy: null,
        cookies: [{ name: 'sess', value: '"quoted"' }],
        headers: {}
      };
      const snippet = exporter._buildPythonSnippet(exportData);
      expect(snippet).toContain('\\"quoted\\"');
    });
  });

  describe('capture', () => {
    let exporter;

    beforeEach(() => {
      exporter = new CookieExporter({ exportDir: '/fake/exports' });
    });

    it('should return null when disabled', async () => {
      const disabledExporter = new CookieExporter({ enabled: false });
      const result = await disabledExporter.capture({}, 'user', 'https://example.com', null);
      expect(result).toBeNull();
    });

    it('should capture cookies and write export file', async () => {
      const page = {
        context: () => ({
          cookies: jest.fn().mockResolvedValue([{ name: 'sess', value: 'val', domain: 'example.com' }])
        }),
        evaluate: jest.fn().mockResolvedValue({ 'User-Agent': 'Mozilla/5.0', 'Accept': '*/*', 'Accept-Language': 'en', 'Accept-Encoding': 'gzip' })
      };
      fs.existsSync.mockReturnValue(true);
      const result = await exporter.capture(page, 'testuser', 'https://example.com/login', 'http://proxy:8080');
      expect(result).not.toBeNull();
      expect(fs.writeFileSync).toHaveBeenCalled();
    });

    it('should return null on unexpected error in capture', async () => {
      const page = {
        context: () => { throw new Error('context blown up'); }
      };
      const result = await exporter.capture(page, 'user', 'https://example.com', null);
      expect(result).toBeNull();
      expect(console.warn).toHaveBeenCalledWith(
        expect.stringContaining('Export failed for')
      );
    });

    it('should handle non-Error thrown values in capture', async () => {
      const page = {
        context: () => { throw 'string error'; }
      };
      const result = await exporter.capture(page, 'user', 'https://example.com', null);
      expect(result).toBeNull();
      expect(console.warn).toHaveBeenCalledWith(
        expect.stringContaining('string error')
      );
    });

    it('should use unknown username when not provided', async () => {
      const page = {
        context: () => ({
          cookies: jest.fn().mockResolvedValue([{ name: 'sess', value: 'val' }])
        }),
        evaluate: jest.fn().mockResolvedValue({})
      };
      fs.existsSync.mockReturnValue(true);
      await exporter.capture(page, '', 'https://example.com', null);
      const writePath = fs.writeFileSync.mock.calls[0][0];
      expect(writePath).toContain('unknown');
    });

    it('should export datadome cookie, headers, and proxy as separate files', async () => {
      const exporter = new CookieExporter({ exportDir: '/fake/exports', format: 'dataDomeOnly' });
      const page = {
        context: () => ({
          cookies: jest.fn().mockResolvedValue([
            { name: 'datadome', value: 'abc', domain: 'example.com' },
            { name: 'other', value: 'val' }
          ])
        }),
        evaluate: jest.fn().mockResolvedValue({ 'User-Agent': 'Mozilla/5.0', 'Accept': '*/*', 'Accept-Language': 'en', 'Accept-Encoding': 'gzip' })
      };
      fs.existsSync.mockReturnValue(true);

      const result = await exporter.capture(page, 'user1', 'https://example.com/login', 'http://proxy:8080');
      expect(result).not.toBeNull();
      expect(typeof result).toBe('string');
      expect(result).toContain('_datadome.json');
      expect(fs.writeFileSync).toHaveBeenCalledTimes(3);

      const payloads = fs.writeFileSync.mock.calls.map(call => JSON.parse(call[1]));
      const datadomeExport = payloads.find(p => p.cookie && p.cookie.name === 'datadome');
      const headersExport = payloads.find(p => p.headers);
      const proxyExport = payloads.find(p => 'proxy' in p && 'proxyIP' in p);

      expect(datadomeExport.cookie.name).toBe('datadome');
      expect(headersExport.headers).toBeDefined();
      expect(proxyExport.proxy).toBe('http://proxy:8080');
    });

    it('should omit python snippet in session-only mode', async () => {
      const exporter = new CookieExporter({ exportDir: '/fake/exports', format: 'sessionOnly' });
      const page = {
        context: () => ({
          cookies: jest.fn().mockResolvedValue([{ name: 'sess', value: 'val' }])
        }),
        evaluate: jest.fn().mockResolvedValue({})
      };
      fs.existsSync.mockReturnValue(true);

      await exporter.capture(page, 'user2', 'https://example.com', null);
      const payload = JSON.parse(fs.writeFileSync.mock.calls[0][1]);
      expect(Array.isArray(payload)).toBe(true);
      expect(payload[0].name).toBe('sess');
    });
  });

  describe('listExports', () => {
    it('should return empty array when dir does not exist', () => {
      const exporter = new CookieExporter({ exportDir: '/nonexistent', enabled: false });
      fs.existsSync.mockReturnValue(false);
      expect(exporter.listExports()).toEqual([]);
    });

    it('should return list of json files', () => {
      const exporter = new CookieExporter({ exportDir: '/fake/exports', enabled: false });
      fs.existsSync.mockReturnValue(true);
      fs.readdirSync.mockReturnValue(['user_2024-01-01.json', 'readme.txt']);
      fs.statSync.mockReturnValue({ size: 500 });
      fs.readFileSync.mockReturnValue(JSON.stringify({ capturedAt: '2024-01-01T00:00:00Z', username: 'user' }));
      const list = exporter.listExports();
      expect(list.length).toBe(1);
      expect(list[0].filename).toBe('user_2024-01-01.json');
      expect(list[0].username).toBe('user');
    });

    it('should handle unreadable json files', () => {
      const exporter = new CookieExporter({ exportDir: '/fake/exports', enabled: false });
      fs.existsSync.mockReturnValue(true);
      fs.readdirSync.mockReturnValue(['bad.json']);
      fs.statSync.mockReturnValue({ size: 10 });
      fs.readFileSync.mockReturnValue('invalid json');
      const list = exporter.listExports();
      expect(list.length).toBe(1);
      expect(list[0].capturedAt).toBeNull();
    });
  });

  describe('readExport', () => {
    it('should return null when file does not exist', () => {
      const exporter = new CookieExporter({ exportDir: '/fake/exports', enabled: false });
      fs.existsSync.mockReturnValue(false);
      expect(exporter.readExport('test.json')).toBeNull();
    });

    it('should read and parse export file', () => {
      const exporter = new CookieExporter({ exportDir: '/fake/exports', enabled: false });
      fs.existsSync.mockReturnValue(true);
      const exportData = { capturedAt: '2024-01-01T00:00:00Z', username: 'testuser', cookies: [] };
      fs.readFileSync.mockReturnValue(JSON.stringify(exportData));
      const result = exporter.readExport('test.json');
      expect(result).toEqual(exportData);
    });

    it('should prevent path traversal', () => {
      const exporter = new CookieExporter({ exportDir: '/fake/exports', enabled: false });
      fs.existsSync.mockReturnValue(false);
      exporter.readExport('../../../etc/passwd');
      // Should use basename, so path should be within exportDir
      expect(fs.existsSync).toHaveBeenCalledWith(expect.stringContaining('passwd'));
      expect(fs.existsSync).toHaveBeenCalledWith(expect.not.stringContaining('..'));
    });

    it('should return null on parse error', () => {
      const exporter = new CookieExporter({ exportDir: '/fake/exports', enabled: false });
      fs.existsSync.mockReturnValue(true);
      fs.readFileSync.mockReturnValue('not valid json');
      expect(exporter.readExport('bad.json')).toBeNull();
    });
  });

  describe('Export Formats', () => {
    let mockPage;

    beforeEach(() => {
      mockPage = {
        context: jest.fn().mockReturnValue({
          cookies: jest.fn().mockResolvedValue([
            { name: 'datadome', value: 'dd-value-123', domain: '.example.com', path: '/', secure: true, httpOnly: false, sameSite: 'Lax' },
            { name: 'session', value: 'sess-123', domain: '.example.com', path: '/', secure: true, httpOnly: true, sameSite: 'Lax' }
          ])
        }),
        evaluate: jest.fn().mockResolvedValue({
          'User-Agent': 'Mozilla/5.0',
          'Accept': 'text/html',
          'Accept-Language': 'en-US',
          'Accept-Encoding': 'gzip, deflate, br'
        })
      };
      fs.existsSync.mockReturnValue(false);
    });

    describe('sessionComplete format (default)', () => {
      it('should export raw cookie array only — no metadata', async () => {
        const exporter = new CookieExporter({ exportDir: '/fake/exports', format: 'sessionComplete' });
        await exporter.capture(mockPage, 'testuser', 'https://example.com/login', 'proxy.example.com:8080');

        expect(fs.writeFileSync).toHaveBeenCalledTimes(1);
        const writeCall = fs.writeFileSync.mock.calls[0];
        const exportData = JSON.parse(writeCall[1]);

        // Output must be a bare array — not a wrapper object
        expect(Array.isArray(exportData)).toBe(true);
        expect(exportData).toHaveLength(2);

        // Each element should be a cookie object with the expected fields
        expect(exportData[0]).toMatchObject({ name: expect.any(String), value: expect.any(String) });
        expect(Object.keys(exportData[0])).toEqual(
          expect.arrayContaining(['name', 'value', 'domain', 'path', 'secure', 'httpOnly', 'sameSite'])
        );

        // No metadata keys should appear anywhere in the top-level array elements
        exportData.forEach(cookie => {
          expect(cookie).not.toHaveProperty('capturedAt');
          expect(cookie).not.toHaveProperty('username');
          expect(cookie).not.toHaveProperty('pythonSnippet');
          expect(cookie).not.toHaveProperty('headers');
        });
      });
    });

    describe('sessionOnly format', () => {
      it('should export raw cookie array only — no metadata', async () => {
        const exporter = new CookieExporter({ exportDir: '/fake/exports', format: 'sessionOnly' });
        await exporter.capture(mockPage, 'testuser', 'https://example.com/login', 'proxy.example.com:8080');

        expect(fs.writeFileSync).toHaveBeenCalledTimes(1);
        const writeCall = fs.writeFileSync.mock.calls[0];
        const exportData = JSON.parse(writeCall[1]);

        // Output must be a bare array — not a wrapper object
        expect(Array.isArray(exportData)).toBe(true);
        expect(exportData).toHaveLength(2);

        // Each element should be a cookie object with the expected fields
        expect(exportData[0]).toMatchObject({ name: expect.any(String), value: expect.any(String) });
        expect(Object.keys(exportData[0])).toEqual(
          expect.arrayContaining(['name', 'value', 'domain', 'path', 'secure', 'httpOnly', 'sameSite'])
        );

        // No metadata keys should appear anywhere in the top-level array elements
        exportData.forEach(cookie => {
          expect(cookie).not.toHaveProperty('capturedAt');
          expect(cookie).not.toHaveProperty('username');
          expect(cookie).not.toHaveProperty('pythonSnippet');
          expect(cookie).not.toHaveProperty('headers');
        });
      });
    });

    describe('dataDomeOnly format', () => {
      it('should export 3 separate files', async () => {
        const exporter = new CookieExporter({ exportDir: '/fake/exports', format: 'dataDomeOnly' });
        await exporter.capture(mockPage, 'testuser', 'https://example.com/login', 'proxy.example.com:8080');

        // Should write 3 files
        expect(fs.writeFileSync).toHaveBeenCalledTimes(3);

        // Check datadome cookie file
        const dataDomeCall = fs.writeFileSync.mock.calls[0];
        expect(dataDomeCall[0]).toContain('_datadome.json');
        const dataDomeData = JSON.parse(dataDomeCall[1]);
        expect(dataDomeData.cookie).toBeDefined();
        expect(dataDomeData.cookie.name).toBe('datadome');
        expect(dataDomeData.cookie.value).toBe('dd-value-123');

        // Check headers file
        const headersCall = fs.writeFileSync.mock.calls[1];
        expect(headersCall[0]).toContain('_headers.json');
        const headersData = JSON.parse(headersCall[1]);
        expect(headersData.headers).toBeDefined();
        expect(headersData.headers['User-Agent']).toBe('Mozilla/5.0');

        // Check proxy file
        const proxyCall = fs.writeFileSync.mock.calls[2];
        expect(proxyCall[0]).toContain('_proxy.json');
        const proxyData = JSON.parse(proxyCall[1]);
        expect(proxyData.proxy).toBe('proxy.example.com:8080');
        expect(proxyData.proxyIP).toBe('proxy.example.com');
      });

      it('should handle missing datadome cookie', async () => {
        mockPage.context().cookies.mockResolvedValue([
          { name: 'session', value: 'sess-123', domain: '.example.com', path: '/', secure: true, httpOnly: true, sameSite: 'Lax' }
        ]);

        const exporter = new CookieExporter({ exportDir: '/fake/exports', format: 'dataDomeOnly' });
        await exporter.capture(mockPage, 'testuser', 'https://example.com/login', null);

        // Should write 2 files (headers + proxy, no datadome)
        expect(fs.writeFileSync).toHaveBeenCalledTimes(2);
      });

      it('should handle null proxy', async () => {
        const exporter = new CookieExporter({ exportDir: '/fake/exports', format: 'dataDomeOnly' });
        await exporter.capture(mockPage, 'testuser', 'https://example.com/login', null);

        const proxyCall = fs.writeFileSync.mock.calls[2];
        const proxyData = JSON.parse(proxyCall[1]);
        expect(proxyData.proxy).toBeNull();
        expect(proxyData.proxyIP).toBeNull();
      });
    });

    describe('DatadomePostRequestCookieonly format', () => {
      let mockPage;

      beforeEach(() => {
        mockPage = {
          context: jest.fn().mockReturnValue({
            cookies: jest.fn().mockResolvedValue([
              { name: 'datadome', value: 'jYj65Q3J_Fkf~DGawj~V7aA33', domain: '.example.com', path: '/', secure: true, httpOnly: false, sameSite: 'Lax' },
              { name: 'session', value: 'sess-abc', domain: '.example.com', path: '/', secure: true, httpOnly: true, sameSite: 'Lax' }
            ])
          })
        };
        fs.existsSync.mockReturnValue(false);
      });

      it('should NOT call page.on or page.route — zero listeners registered', async () => {
        const pageWithSpy = {
          ...mockPage,
          on:    jest.fn(),
          route: jest.fn()
        };
        const exporter = new CookieExporter({ exportDir: '/fake/exports', format: 'DatadomePostRequestCookieonly' });
        await exporter.capture(pageWithSpy, 'testuser', 'https://example.com', null);
        expect(pageWithSpy.on).not.toHaveBeenCalled();
        expect(pageWithSpy.route).not.toHaveBeenCalled();
      });

      it('should extract datadome value from context cookies and write only { datadome: value }', async () => {
        const exporter = new CookieExporter({ exportDir: '/fake/exports', format: 'DatadomePostRequestCookieonly' });
        const result = await exporter.capture(mockPage, 'testuser', 'https://example.com', null);

        expect(result).not.toBeNull();
        expect(result).toContain('_datadome_post.json');
        expect(fs.writeFileSync).toHaveBeenCalledTimes(1);

        const writtenContent = JSON.parse(fs.writeFileSync.mock.calls[0][1]);
        expect(writtenContent).toEqual({ datadome: 'jYj65Q3J_Fkf~DGawj~V7aA33' });
        expect(Object.keys(writtenContent)).toHaveLength(1);
      });

      it('should return null when no datadome cookie exists in context', async () => {
        mockPage.context.mockReturnValue({
          cookies: jest.fn().mockResolvedValue([
            { name: 'session', value: 'sess-123', domain: '.example.com', path: '/', secure: true, httpOnly: true, sameSite: 'Lax' }
          ])
        });
        const exporter = new CookieExporter({ exportDir: '/fake/exports', format: 'DatadomePostRequestCookieonly' });
        const result = await exporter.capture(mockPage, 'testuser', 'https://example.com', null);
        expect(result).toBeNull();
        expect(fs.writeFileSync).not.toHaveBeenCalled();
        expect(console.warn).toHaveBeenCalledWith(
          expect.stringContaining('no datadome cookie found')
        );
      });

      it('should match datadome cookie name case-insensitively', async () => {
        mockPage.context.mockReturnValue({
          cookies: jest.fn().mockResolvedValue([
            { name: 'DataDome', value: 'casetest-value', domain: '.example.com', path: '/', secure: false, httpOnly: false, sameSite: 'Lax' }
          ])
        });
        const exporter = new CookieExporter({ exportDir: '/fake/exports', format: 'DatadomePostRequestCookieonly' });
        const result = await exporter.capture(mockPage, 'testuser', 'https://example.com', null);
        expect(result).not.toBeNull();
        const content = JSON.parse(fs.writeFileSync.mock.calls[0][1]);
        expect(content).toEqual({ datadome: 'casetest-value' });
      });

      it('should return null and warn when context().cookies() throws', async () => {
        mockPage.context.mockReturnValue({
          cookies: jest.fn().mockRejectedValue(new Error('context gone'))
        });
        const exporter = new CookieExporter({ exportDir: '/fake/exports', format: 'DatadomePostRequestCookieonly' });
        const result = await exporter.capture(mockPage, 'testuser', 'https://example.com', null);
        expect(result).toBeNull();
        expect(console.warn).toHaveBeenCalledWith(
          expect.stringContaining('failed to read cookies')
        );
      });

      it('should write only the datadome value — no metadata fields', async () => {
        const exporter = new CookieExporter({ exportDir: '/fake/exports', format: 'DatadomePostRequestCookieonly' });
        await exporter.capture(mockPage, 'testuser', 'https://example.com', null);
        const content = JSON.parse(fs.writeFileSync.mock.calls[0][1]);
        expect(content).not.toHaveProperty('capturedAt');
        expect(content).not.toHaveProperty('username');
        expect(content).not.toHaveProperty('loginUrl');
        expect(content).not.toHaveProperty('proxy');
        expect(Object.keys(content)).toHaveLength(1);
      });
    });

    describe('format parameter', () => {
      it('should default to sessionComplete', () => {
        const exporter = new CookieExporter({ exportDir: '/fake/exports' });
        expect(exporter.format).toBe('sessionComplete');
      });

      it('should respect format parameter', () => {
        const exporter = new CookieExporter({ exportDir: '/fake/exports', format: 'sessionOnly' });
        expect(exporter.format).toBe('sessionOnly');
      });
    });
  });
});
