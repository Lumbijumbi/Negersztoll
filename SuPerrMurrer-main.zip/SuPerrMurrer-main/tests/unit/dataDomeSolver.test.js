'use strict';

jest.mock('../../config', () => ({
  captcha: { username: 'test_user', password: 'test_pass' }
}));

// Mock axios as a virtual module since it may not be installed
const mockAxios = {
  post: jest.fn(),
  get: jest.fn()
};
jest.mock('axios', () => mockAxios, { virtual: true });

const axios = mockAxios;
const { solveDataDome, solveDataDomeSlider } = require('../../utils/dataDomeSolver');

describe('dataDomeSolver', () => {
  let page;
  let frame;

  beforeEach(() => {
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
    jest.clearAllMocks();

    frame = {
      evaluate: jest.fn().mockResolvedValue('test-sitekey-123'),
    };

    page = {
      waitForSelector: jest.fn().mockResolvedValue({
        contentFrame: jest.fn().mockResolvedValue(frame),
        getAttribute: jest.fn().mockResolvedValue('https://captcha-delivery.com/captcha/?hash=abc')
      }),
      waitForNavigation: jest.fn().mockResolvedValue(undefined)
    };
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('should return false when no siteKey found', async () => {
    frame.evaluate.mockResolvedValueOnce(null);
    const result = await solveDataDome(page);
    expect(result).toBe(false);
    expect(console.error).toHaveBeenCalledWith(expect.stringContaining('Could not find DataDome sitekey'));
  });

  it('should return false when waitForSelector fails', async () => {
    page.waitForSelector.mockRejectedValue(new Error('selector timeout'));
    const result = await solveDataDome(page);
    expect(result).toBe(false);
    expect(console.error).toHaveBeenCalledWith(expect.stringContaining('selector timeout'));
  });

  it('should submit to DBC API and return true when token found on first poll', async () => {
    // Override the setTimeout to avoid 5-second delays
    const origSetTimeout = global.setTimeout;
    global.setTimeout = (fn, _ms) => origSetTimeout(fn, 0);

    axios.post.mockResolvedValue({ data: { captcha: '12345' } });
    // First poll immediately returns the solved token
    axios.get.mockResolvedValue({ data: { text: 'solved-token' } });

    const result = await solveDataDome(page);
    global.setTimeout = origSetTimeout;
    expect(result).toBe(true);
    expect(axios.post).toHaveBeenCalledWith(
      'http://api.dbcapi.me/api/captcha',
      expect.objectContaining({ username: 'test_user', type: 4 })
    );
  });

  it('should return false when axios.post fails', async () => {
    axios.post.mockRejectedValue(new Error('network error'));
    const result = await solveDataDome(page);
    expect(result).toBe(false);
  });

  it('should inject token and navigate when solved', async () => {
    const origSetTimeout = global.setTimeout;
    global.setTimeout = (fn, _ms) => origSetTimeout(fn, 0);

    axios.post.mockResolvedValue({ data: { captcha: '12345' } });
    axios.get.mockResolvedValue({ data: { text: 'my-token' } });

    const result = await solveDataDome(page);
    global.setTimeout = origSetTimeout;
    expect(result).toBe(true);
    expect(frame.evaluate).toHaveBeenCalledTimes(2);
    expect(page.waitForNavigation).toHaveBeenCalled();
  });

  it('should return false when waitForNavigation fails', async () => {
    const origSetTimeout = global.setTimeout;
    global.setTimeout = (fn, _ms) => origSetTimeout(fn, 0);

    axios.post.mockResolvedValue({ data: { captcha: '12345' } });
    axios.get.mockResolvedValue({ data: { text: 'my-token' } });
    page.waitForNavigation.mockRejectedValue(new Error('Navigation timeout'));

    const result = await solveDataDome(page);
    global.setTimeout = origSetTimeout;
    expect(result).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// solveDataDomeSlider
// ---------------------------------------------------------------------------

describe('solveDataDomeSlider', () => {
  // Suppress console output during tests
  beforeEach(() => {
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'warn').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  /**
   * Build a minimal page mock that has no captcha-delivery iframe.
   */
  function makePageNoIframe() {
    return {
      $: jest.fn().mockResolvedValue(null),
      mouse: { move: jest.fn(), down: jest.fn(), up: jest.fn() }
    };
  }

  /**
   * Build a page mock that simulates a visible DataDome slider iframe.
   * After the drag the iframe disappears (page.$ returns null on the second call).
   */
  function makePageWithSlider({ trackWidth = 280, iframeGoneAfterDrag = true } = {}) {
    const sliderEl = {
      boundingBox: jest.fn().mockResolvedValue({ x: 0, y: 10, width: 40, height: 40 })
    };
    const trackEl = {
      boundingBox: jest.fn().mockResolvedValue({ x: 0, y: 10, width: trackWidth, height: 40 })
    };
    const frame = {
      waitForSelector: jest.fn().mockResolvedValue(sliderEl),
      $: jest.fn().mockResolvedValue(trackEl)
    };
    const iframeEl = {
      contentFrame: jest.fn().mockResolvedValue(frame),
      boundingBox: jest.fn().mockResolvedValue({ x: 100, y: 200, width: 400, height: 100 })
    };

    let callCount = 0;
    const pageMock = {
      $: jest.fn().mockImplementation(async () => {
        // First call: iframe present; subsequent calls: gone (slide solved) or still present
        if (callCount === 0) {
          callCount++;
          return iframeEl;
        }
        return iframeGoneAfterDrag ? null : iframeEl;
      }),
      mouse: {
        move: jest.fn().mockResolvedValue(undefined),
        down: jest.fn().mockResolvedValue(undefined),
        up: jest.fn().mockResolvedValue(undefined)
      }
    };
    return { pageMock, iframeEl, frame, sliderEl, trackEl };
  }

  it('returns false when no captcha-delivery iframe is present', async () => {
    const page = makePageNoIframe();
    const result = await solveDataDomeSlider(page);
    expect(result).toBe(false);
    expect(console.warn).toHaveBeenCalledWith(expect.stringContaining('not found'));
  });

  it('returns false when contentFrame() returns null', async () => {
    const iframeEl = {
      contentFrame: jest.fn().mockResolvedValue(null),
      boundingBox: jest.fn().mockResolvedValue({ x: 0, y: 0, width: 400, height: 100 })
    };
    const page = {
      $: jest.fn().mockResolvedValue(iframeEl),
      mouse: { move: jest.fn(), down: jest.fn(), up: jest.fn() }
    };
    const result = await solveDataDomeSlider(page);
    expect(result).toBe(false);
    expect(console.warn).toHaveBeenCalledWith(expect.stringContaining('content frame'));
  });

  it('returns false when iframe bounding box is null', async () => {
    const frame = { waitForSelector: jest.fn(), $: jest.fn() };
    const iframeEl = {
      contentFrame: jest.fn().mockResolvedValue(frame),
      boundingBox: jest.fn().mockResolvedValue(null)
    };
    const page = {
      $: jest.fn().mockResolvedValue(iframeEl),
      mouse: { move: jest.fn(), down: jest.fn(), up: jest.fn() }
    };
    const result = await solveDataDomeSlider(page);
    expect(result).toBe(false);
    expect(console.warn).toHaveBeenCalledWith(expect.stringContaining('bounding box'));
  });

  it('returns false when slider button is not found inside iframe', async () => {
    const frame = {
      waitForSelector: jest.fn().mockRejectedValue(new Error('timeout')),
      $: jest.fn()
    };
    const iframeEl = {
      contentFrame: jest.fn().mockResolvedValue(frame),
      boundingBox: jest.fn().mockResolvedValue({ x: 100, y: 200, width: 400, height: 100 })
    };
    const page = {
      $: jest.fn().mockResolvedValue(iframeEl),
      mouse: { move: jest.fn(), down: jest.fn(), up: jest.fn() }
    };
    const result = await solveDataDomeSlider(page);
    expect(result).toBe(false);
    expect(console.warn).toHaveBeenCalledWith(expect.stringContaining('Slider button not found'));
  });

  it('returns true when drag succeeds and iframe disappears', async () => {
    const origSetTimeout = global.setTimeout;
    global.setTimeout = (fn, _ms) => origSetTimeout(fn, 0);

    const { pageMock } = makePageWithSlider({ iframeGoneAfterDrag: true });
    const result = await solveDataDomeSlider(pageMock);

    global.setTimeout = origSetTimeout;
    expect(result).toBe(true);
    expect(pageMock.mouse.down).toHaveBeenCalled();
    expect(pageMock.mouse.up).toHaveBeenCalled();
    expect(console.log).toHaveBeenCalledWith(expect.stringContaining('solved'));
  });

  it('returns false when drag completes but iframe is still present', async () => {
    const origSetTimeout = global.setTimeout;
    global.setTimeout = (fn, _ms) => origSetTimeout(fn, 0);

    const { pageMock } = makePageWithSlider({ iframeGoneAfterDrag: false });
    const result = await solveDataDomeSlider(pageMock);

    global.setTimeout = origSetTimeout;
    expect(result).toBe(false);
    expect(console.warn).toHaveBeenCalledWith(expect.stringContaining('still present'));
  });

  it('uses iframe width as fallback when track selector is not found', async () => {
    const origSetTimeout = global.setTimeout;
    global.setTimeout = (fn, _ms) => origSetTimeout(fn, 0);

    const sliderEl = {
      boundingBox: jest.fn().mockResolvedValue({ x: 0, y: 10, width: 40, height: 40 })
    };
    const frame = {
      waitForSelector: jest.fn().mockResolvedValue(sliderEl),
      // No track element found
      $: jest.fn().mockResolvedValue(null)
    };
    const iframeEl = {
      contentFrame: jest.fn().mockResolvedValue(frame),
      boundingBox: jest.fn().mockResolvedValue({ x: 50, y: 100, width: 350, height: 100 })
    };

    let callCount = 0;
    const page = {
      $: jest.fn().mockImplementation(async () => {
        if (callCount === 0) { callCount++; return iframeEl; }
        return null; // gone after drag
      }),
      mouse: {
        move: jest.fn().mockResolvedValue(undefined),
        down: jest.fn().mockResolvedValue(undefined),
        up: jest.fn().mockResolvedValue(undefined)
      }
    };

    const result = await solveDataDomeSlider(page);
    global.setTimeout = origSetTimeout;
    expect(result).toBe(true);
    // Drag calls should still have been made
    expect(page.mouse.down).toHaveBeenCalled();
    expect(page.mouse.up).toHaveBeenCalled();
  });
});
