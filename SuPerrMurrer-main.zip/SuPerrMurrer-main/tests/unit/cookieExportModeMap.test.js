'use strict';

const { exportModeMap, resolveCookieExportFormat } = require('../../utils/cookieExportModeMap');

describe('cookieExportModeMap', () => {
  describe('exportModeMap', () => {
    it('should map sessionComplete to sessionComplete', () => {
      expect(exportModeMap['sessionComplete']).toBe('sessionComplete');
    });

    it('should map session to sessionOnly', () => {
      expect(exportModeMap['session']).toBe('sessionOnly');
    });

    it('should map datadome to dataDomeOnly', () => {
      expect(exportModeMap['datadome']).toBe('dataDomeOnly');
    });

    it('should map DatadomePostRequestCookieonly to DatadomePostRequestCookieonly', () => {
      expect(exportModeMap['DatadomePostRequestCookieonly']).toBe('DatadomePostRequestCookieonly');
    });
  });

  describe('resolveCookieExportFormat', () => {
    it('should resolve known UI export modes', () => {
      expect(resolveCookieExportFormat('sessionComplete')).toBe('sessionComplete');
      expect(resolveCookieExportFormat('session')).toBe('sessionOnly');
      expect(resolveCookieExportFormat('datadome')).toBe('dataDomeOnly');
      expect(resolveCookieExportFormat('DatadomePostRequestCookieonly')).toBe('DatadomePostRequestCookieonly');
    });

    it('should use fallback format for unknown mode', () => {
      expect(resolveCookieExportFormat('unknownMode', 'dataDomeOnly')).toBe('dataDomeOnly');
    });

    it('should default to sessionComplete when no mode or fallback', () => {
      expect(resolveCookieExportFormat(undefined)).toBe('sessionComplete');
      expect(resolveCookieExportFormat(null)).toBe('sessionComplete');
      expect(resolveCookieExportFormat('')).toBe('sessionComplete');
    });
  });
});
