/**
 * Unit Tests for GUI Server (gui/server.js)
 * 
 * Comprehensive test suite covering all API endpoints of the Express-based GUI server.
 * Uses supertest for HTTP endpoint testing with full mocking of external dependencies.
 * 
 * Test Coverage (70 tests):
 * - Config Management: GET/PUT /api/config, POST /api/config/save
 * - File Management: GET/PUT /api/credentials, GET/PUT /api/proxies
 * - History: GET /api/history (pagination, filtering, sorting), GET /api/history/stats, POST /api/history/compact
 * - Controller: GET /api/status, POST /api/start, POST /api/stop, GET /api/logs
 * - Queue Operations: GET /api/queue, POST /api/queue/add, POST /api/queue/shuffle, 
 *   PUT /api/queue/priority, DELETE /api/queue/file, POST /api/queue/clear,
 *   POST /api/queue/pause, POST /api/queue/resume, GET /api/queue/stats
 * - System Info: GET /api/system
 * - CORS and Error Handling
 * - Integration Tests
 * 
 * All external dependencies (fs, child_process, os, config modules) are mocked.
 */

const request = require('supertest');
const express = require('express');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const os = require('os');

// Mock all external dependencies
jest.mock('fs');
jest.mock('child_process');
jest.mock('os');

// Mock config module
jest.mock('../../config', () => ({
  browser: { headless: true },
  proxy: { enabled: false },
  batch: { maxParallelWorkers: 5, credentialsPerProxy: 10 },
  history: { enabled: true, historyFile: 'test_history.jsonl' },
  queue: { enabled: true, queueFile: 'test_queue.jsonl', defaultPriority: 3 },
  retry: { maxRetries: 3 },
  errorRecovery: { maxRetries: 3 }
}));

// Mock CredentialHistory
const mockCredentialHistory = {
  history: new Map([
    ['user1\tpass1', { u: 'user1', p: 'pass1', s: 'success', t: '2024-01-01T00:00:00.000Z' }],
    ['user2\tpass2', { u: 'user2', p: 'pass2', s: 'failed', t: '2024-01-02T00:00:00.000Z' }]
  ]),
  _key: (username, password) => `${username}\t${password}`,
  load: jest.fn(),
  getAll: jest.fn(() => [
    { username: 'user1', password: 'pass1', status: 'success', timestamp: '2024-01-01T00:00:00.000Z' },
    { username: 'user2', password: 'pass2', status: 'failed', timestamp: '2024-01-02T00:00:00.000Z' }
  ]),
  getStats: jest.fn(() => ({
    total: 10,
    success: 5,
    failed: 3,
    blocked: 1,
    captcha: 1,
    other: 0
  })),
  compact: jest.fn(),
  deleteEntry: jest.fn(() => true),
  record: jest.fn(),
  add: jest.fn()
};

jest.mock('../../utils/credentialHistory', () => {
  return jest.fn().mockImplementation(() => mockCredentialHistory);
});

// Mock ComboQueue
const mockComboQueue = {
  combos: new Map([
    ['user1\tpass1', { username: 'user1', password: 'pass1', source: 'test.txt', priority: 3 }],
    ['user2\tpass2', { username: 'user2', password: 'pass2', source: 'test.txt', priority: 3 }]
  ]),
  getStats: jest.fn(() => ({
    total: 100,
    pending: 50,
    completed: 30,
    failed: 20
  })),
  getFiles: jest.fn(() => [
    { filename: 'test1.txt', priority: 3, status: 'pending' },
    { filename: 'test2.txt', priority: 5, status: 'completed' }
  ]),
  addCombos: jest.fn(() => ({ added: 10, duplicatesRemoved: 2, alreadyProcessed: 1, queued: 7 })),
  shuffle: jest.fn(),
  setPriority: jest.fn(() => true),
  removeFile: jest.fn(() => true),
  clearCompleted: jest.fn(() => 10),
  pause: jest.fn(),
  resume: jest.fn()
};

jest.mock('../../utils/comboQueue', () => {
  return jest.fn().mockImplementation(() => mockComboQueue);
});

// Mock RetryQueue
const mockRetryQueue = {
  load: jest.fn(),
  getAll: jest.fn(() => []),
  getStats: jest.fn(() => ({ pending: 5, failed: 2 })),
  clean: jest.fn(() => 3),
  clear: jest.fn(() => 5),
  retryEntry: jest.fn(() => true)
};

jest.mock('../../utils/retryQueue', () => {
  return jest.fn().mockImplementation(() => mockRetryQueue);
});

describe('GUI Server API', () => {
  let app;

  beforeAll(() => {
    // Suppress console.log during tests
    jest.spyOn(console, 'log').mockImplementation(() => {});
  });

  beforeEach(() => {
    // Reset all mocks
    jest.clearAllMocks();

    // Setup default fs mock implementations
    fs.existsSync = jest.fn(() => true);
    fs.readFileSync = jest.fn(() => 'test:pass\nuser2:pass2');
    fs.writeFileSync = jest.fn();
    fs.copyFileSync = jest.fn();

    // Mock os
    os.cpus = jest.fn(() => [
      { model: 'Intel Core i7', speed: 2400 }
    ]);
    os.totalmem = jest.fn(() => 16000000000);
    os.freemem = jest.fn(() => 8000000000);
    os.platform = jest.fn(() => 'linux');
    os.arch = jest.fn(() => 'x64');
    os.uptime = jest.fn(() => 12345);

    // Setup spawn mock
    const mockProcess = {
      pid: 12345,
      killed: false,
      stdout: { on: jest.fn() },
      stderr: { on: jest.fn() },
      on: jest.fn(),
      kill: jest.fn()
    };
    spawn.mockReturnValue(mockProcess);

    // Create a minimal Express app that mimics the server
    app = express();
    app.use(express.json({ limit: '10mb' }));
    app.disable('x-powered-by');

    // Security headers
    app.use((req, res, next) => {
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.setHeader('X-Frame-Options', 'DENY');
      res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
      res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
      next();
    });
    
    // Add CORS middleware
    app.use((req, res, next) => {
      res.header('Access-Control-Allow-Origin', '*');
      res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
      res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
      if (req.method === 'OPTIONS') {
        return res.sendStatus(200);
      }
      next();
    });

    // Load config
    const config = require('../../config');
    const CredentialHistory = require('../../utils/credentialHistory');
    const ComboQueue = require('../../utils/comboQueue');

    let credentialHistory = null;
    let comboQueue = null;
    let controllerProcess = null;
    let logBuffer = [];
    const MAX_LOG_LINES = 500;

    function addToLogBuffer(line) {
      logBuffer.push({
        timestamp: new Date().toISOString(),
        line: line
      });
      if (logBuffer.length > MAX_LOG_LINES) {
        logBuffer.splice(0, logBuffer.length - MAX_LOG_LINES);
      }
    }

    // Initialize
    if (config.history && config.history.enabled) {
      credentialHistory = new CredentialHistory(config.history);
      credentialHistory.load();
    }

    if (config.queue && config.queue.enabled) {
      comboQueue = new ComboQueue({
        queueFile: config.queue.queueFile,
        historyInstance: credentialHistory,
        ...config.queue
      });
    }

    // Define all endpoints
    
    // GET /api/config
    app.get('/api/config', (req, res) => {
      try {
        res.json(config);
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // PUT /api/config
    app.put('/api/config', (req, res) => {
      try {
        const updates = req.body;
        
        const validKeys = [
          'browser', 'proxy', 'batch', 'form', 'navigation', 'login', 'account',
          'detection', 'output', 'logging', 'casDetection', 'context', 'errorRecovery',
          'test', 'retry', 'history', 'queue', 'session', 'notifications', 'ux',
          'performance', 'stability'
        ];
        
        for (const key in updates) {
          if (!validKeys.includes(key)) {
            return res.status(400).json({ 
              error: `Invalid configuration key: ${key}`,
              validKeys
            });
          }
        }
        
        if (updates.batch) {
          if (updates.batch.maxParallelWorkers !== undefined) {
            const workers = updates.batch.maxParallelWorkers;
            if (typeof workers !== 'number' || workers < 1 || workers > 50) {
              return res.status(400).json({ error: 'maxParallelWorkers must be between 1 and 50' });
            }
          }
          
          if (updates.batch.credentialsPerProxy !== undefined) {
            const creds = updates.batch.credentialsPerProxy;
            if (typeof creds !== 'number' || creds < 1 || creds > 100) {
              return res.status(400).json({ error: 'credentialsPerProxy must be between 1 and 100' });
            }
          }
        }
        
        if (updates.queue) {
          if (updates.queue.defaultPriority !== undefined) {
            const priority = updates.queue.defaultPriority;
            if (typeof priority !== 'number' || priority < 1 || priority > 5) {
              return res.status(400).json({ error: 'defaultPriority must be between 1 and 5' });
            }
          }
        }
        
        function deepMerge(target, source) {
          for (const key in source) {
            if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
              target[key] = target[key] || {};
              deepMerge(target[key], source[key]);
            } else {
              target[key] = source[key];
            }
          }
        }
        
        deepMerge(config, updates);
        res.json({ success: true, config });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // POST /api/config/save
    app.post('/api/config/save', (req, res) => {
      try {
        const configPath = path.join(__dirname, '..', 'config.js');
        const backupPath = configPath + '.backup.' + Date.now();
        
        fs.copyFileSync(configPath, backupPath);
        
        const configStr = `/**
 * Centralized Configuration for play_version2_improved.js
 * All magic numbers and settings in one place
 */

module.exports = ${JSON.stringify(config, null, 2)};
`;
        
        fs.writeFileSync(configPath, configStr, 'utf8');
        
        res.json({ 
          success: true, 
          message: 'Configuration saved to disk',
          backup: backupPath
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // GET /api/credentials
    app.get('/api/credentials', (req, res) => {
      try {
        const credPath = path.join(__dirname, '..', 'test.txt');
        
        if (!fs.existsSync(credPath)) {
          return res.json({ lines: [], count: 0 });
        }
        
        const content = fs.readFileSync(credPath, 'utf8');
        const lines = content.split('\n');
        
        res.json({ 
          lines: content,
          count: lines.filter(l => l.trim() && !l.trim().startsWith('#')).length
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // PUT /api/credentials
    app.put('/api/credentials', (req, res) => {
      try {
        const { content } = req.body;
        const credPath = path.join(__dirname, '..', 'test.txt');
        
        fs.writeFileSync(credPath, content, 'utf8');
        
        const lines = content.split('\n');
        const count = lines.filter(l => l.trim() && !l.trim().startsWith('#')).length;
        
        res.json({ 
          success: true,
          count: count
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // GET /api/proxies
    app.get('/api/proxies', (req, res) => {
      try {
        const proxyPath = path.join(__dirname, '..', 'Lightning_Proxies.txt');
        
        if (!fs.existsSync(proxyPath)) {
          return res.json({ lines: [], count: 0 });
        }
        
        const content = fs.readFileSync(proxyPath, 'utf8');
        const lines = content.split('\n');
        
        res.json({ 
          lines: content,
          count: lines.filter(l => l.trim() && !l.trim().startsWith('#')).length
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // PUT /api/proxies
    app.put('/api/proxies', (req, res) => {
      try {
        const { content } = req.body;
        const proxyPath = path.join(__dirname, '..', 'Lightning_Proxies.txt');
        
        fs.writeFileSync(proxyPath, content, 'utf8');
        
        const lines = content.split('\n');
        const count = lines.filter(l => l.trim() && !l.trim().startsWith('#')).length;
        
        res.json({ 
          success: true,
          count: count
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // GET /api/history
    app.get('/api/history', (req, res) => {
      try {
        if (!credentialHistory) {
          return res.json({ entries: [], total: 0, page: 1, totalPages: 0 });
        }
        
        const { status, search, sort = 'date_desc', page = 1, limit = 50 } = req.query;
        let entries = credentialHistory.getAll();
        
        if (status && status !== 'all') {
          entries = entries.filter(e => e.status === status);
        }
        
        if (search) {
          const lowerSearch = search.toLowerCase();
          entries = entries.filter(e =>
            e.username.toLowerCase().includes(lowerSearch) ||
            e.password.toLowerCase().includes(lowerSearch) ||
            e.status.toLowerCase().includes(lowerSearch) ||
            (e.method && e.method.toLowerCase().includes(lowerSearch))
          );
        }
        
        const [sortField, sortDir] = (sort || 'date_desc').split('_');
        const direction = sortDir === 'asc' ? 1 : -1;

        entries.sort((a, b) => {
          switch (sortField) {
            case 'date':
              return direction * (new Date(a.timestamp) - new Date(b.timestamp));
            case 'points':
              const aPts = parseFloat(a.pointsBalance) || 0;
              const bPts = parseFloat(b.pointsBalance) || 0;
              if (aPts === 0 && bPts === 0) return 0;
              if (aPts === 0) return direction;
              if (bPts === 0) return -direction;
              return direction * (aPts - bPts);
            case 'money':
              const aMon = parseFloat(a.moneyBalance) || 0;
              const bMon = parseFloat(b.moneyBalance) || 0;
              if (aMon === 0 && bMon === 0) return 0;
              if (aMon === 0) return direction;
              if (bMon === 0) return -direction;
              return direction * (aMon - bMon);
            case 'confidence':
              const aConf = a.confidence || 0;
              const bConf = b.confidence || 0;
              return direction * (aConf - bConf);
            case 'username':
              return direction * a.username.localeCompare(b.username);
            default:
              return direction * (new Date(a.timestamp) - new Date(b.timestamp));
          }
        });
        
        const pageNum = parseInt(page);
        const limitNum = parseInt(limit);
        const startIdx = (pageNum - 1) * limitNum;
        const endIdx = startIdx + limitNum;
        const paginatedEntries = entries.slice(startIdx, endIdx);
        
        res.json({
          entries: paginatedEntries,
          total: entries.length,
          page: pageNum,
          totalPages: Math.ceil(entries.length / limitNum)
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // GET /api/history/stats
    app.get('/api/history/stats', (req, res) => {
      try {
        if (!credentialHistory) {
          return res.json({ 
            total: 0,
            success: 0,
            failed: 0,
            blocked: 0,
            captcha: 0,
            other: 0
          });
        }
        
        const stats = credentialHistory.getStats();
        res.json(stats);
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // POST /api/history/compact
    app.post('/api/history/compact', (req, res) => {
      try {
        if (!credentialHistory) {
          return res.status(400).json({ error: 'History not enabled' });
        }
        
        credentialHistory.compact();
        res.json({ success: true, message: 'History file compacted' });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // GET /api/status
    app.get('/api/status', (req, res) => {
      try {
        res.json({
          running: controllerProcess && !controllerProcess.killed,
          pid: controllerProcess ? controllerProcess.pid : null,
          uptime: controllerProcess && controllerProcess.startTime 
            ? Date.now() - controllerProcess.startTime 
            : null
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // POST /api/start
    app.post('/api/start', (req, res) => {
      try {
        if (controllerProcess && !controllerProcess.killed) {
          return res.status(400).json({ error: 'Controller already running' });
        }
        
        logBuffer.splice(0, logBuffer.length);
        addToLogBuffer('[GUI] Starting controller process...');
        
        const controllerPath = path.join(__dirname, '..', 'play_version2_controller.js');
        controllerProcess = spawn('node', [controllerPath, '--no-interactive'], {
          cwd: path.join(__dirname, '..'),
          stdio: ['ignore', 'pipe', 'pipe']
        });
        
        controllerProcess.startTime = Date.now();
        
        controllerProcess.stdout.on('data', (data) => {
          const lines = data.toString().split('\n');
          lines.forEach(line => {
            if (line.trim()) {
              addToLogBuffer(line);
            }
          });
        });
        
        controllerProcess.stderr.on('data', (data) => {
          const lines = data.toString().split('\n');
          lines.forEach(line => {
            if (line.trim()) {
              addToLogBuffer('[ERROR] ' + line);
            }
          });
        });
        
        controllerProcess.on('exit', (code, signal) => {
          addToLogBuffer(`[GUI] Controller exited with code ${code}, signal ${signal}`);
        });
        
        res.json({ 
          success: true,
          pid: controllerProcess.pid,
          message: 'Controller started'
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // POST /api/stop
    app.post('/api/stop', (req, res) => {
      try {
        if (!controllerProcess || controllerProcess.killed) {
          return res.status(400).json({ error: 'Controller not running' });
        }
        
        addToLogBuffer('[GUI] Stopping controller process...');
        controllerProcess.kill('SIGTERM');
        
        res.json({ 
          success: true,
          message: 'Stop signal sent to controller'
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // GET /api/logs
    app.get('/api/logs', (req, res) => {
      try {
        const { since = 0 } = req.query;
        const sinceIdx = parseInt(since);
        
        const logsToSend = logBuffer.slice(sinceIdx);
        
        res.json({
          logs: logsToSend,
          offset: logBuffer.length
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // ============ NEW CONTROLLER ENDPOINTS ============

    // POST /api/controller/start
    app.post('/api/controller/start', (req, res) => {
      try {
        if (controllerProcess) {
          return res.status(400).json({ 
            success: false, 
            message: 'Controller is already running' 
          });
        }

        const controllerPath = path.join(__dirname, '..', 'play_version2_controller.js');
        
        controllerProcess = spawn('node', [controllerPath, '--no-interactive'], {
          cwd: path.join(__dirname, '..'),
          stdio: ['ignore', 'pipe', 'pipe']
        });

        controllerProcess.startTime = Date.now();

        // Capture output
        controllerProcess.stdout.on('data', (data) => {
          const lines = data.toString().split('\n');
          lines.forEach(line => {
            if (line.trim()) {
              addToLogBuffer(line);
            }
          });
        });

        controllerProcess.stderr.on('data', (data) => {
          addToLogBuffer(`[ERROR] ${data.toString()}`);
        });

        // Single cleanup handler
        const cleanup = (code) => {
          if (controllerProcess) {
            addToLogBuffer(`[CONTROLLER] Process exited with code ${code || 'unknown'}`);
            controllerProcess = null;
          }
        };

        controllerProcess.on('close', cleanup);
        controllerProcess.on('error', (err) => {
          addToLogBuffer(`[ERROR] ${err.message}`);
          cleanup();
        });

        res.json({ 
          success: true, 
          message: 'Controller started successfully',
          pid: controllerProcess.pid 
        });
      } catch (error) {
        res.status(500).json({ 
          success: false, 
          error: error.message 
        });
      }
    });

    // POST /api/controller/stop
    app.post('/api/controller/stop', (req, res) => {
      try {
        if (!controllerProcess) {
          return res.status(400).json({ 
            success: false, 
            message: 'No controller process running' 
          });
        }

        controllerProcess.kill('SIGTERM');
        
        res.json({ 
          success: true, 
          message: 'Controller stop signal sent' 
        });
      } catch (error) {
        res.status(500).json({ 
          success: false, 
          error: error.message 
        });
      }
    });

    // GET /api/controller/status
    app.get('/api/controller/status', (req, res) => {
      res.json({
        running: !!controllerProcess,
        pid: controllerProcess ? controllerProcess.pid : null
      });
    });

    // GET /api/queue
    app.get('/api/queue', (req, res) => {
      try {
        if (!comboQueue) {
          return res.status(503).json({ error: 'Queue is not enabled' });
        }

        const stats = comboQueue.getStats();
        const files = comboQueue.getFiles();

        res.json({
          stats,
          files
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // POST /api/queue/add
    app.post('/api/queue/add', (req, res) => {
      try {
        if (!comboQueue) {
          return res.status(503).json({ error: 'Queue is not enabled' });
        }

        const { content, sourceName, priority } = req.body;

        if (!content) {
          return res.status(400).json({ error: 'Content is required' });
        }

        if (!sourceName) {
          return res.status(400).json({ error: 'Source name is required' });
        }

        const lines = content.split('\n');
        const stats = comboQueue.addCombos(lines, sourceName, { priority: priority || 3 });

        res.json({
          success: true,
          stats
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // POST /api/queue/shuffle
    app.post('/api/queue/shuffle', (req, res) => {
      try {
        if (!comboQueue) {
          return res.status(503).json({ error: 'Queue is not enabled' });
        }

        comboQueue.shuffle();

        res.json({
          success: true,
          message: 'Queue shuffled successfully'
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // PUT /api/queue/priority
    app.put('/api/queue/priority', (req, res) => {
      try {
        if (!comboQueue) {
          return res.status(503).json({ error: 'Queue is not enabled' });
        }

        const { filename, priority } = req.body;

        if (!filename) {
          return res.status(400).json({ error: 'Filename is required' });
        }

        if (priority === undefined || priority < 1 || priority > 5) {
          return res.status(400).json({ error: 'Priority must be between 1 and 5' });
        }

        const result = comboQueue.setPriority(filename, priority);

        if (!result) {
          return res.status(404).json({ error: 'File not found in queue' });
        }

        res.json({
          success: true,
          message: 'Priority updated successfully'
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // DELETE /api/queue/file
    app.delete('/api/queue/file', (req, res) => {
      try {
        if (!comboQueue) {
          return res.status(503).json({ error: 'Queue is not enabled' });
        }

        const { filename } = req.body;

        if (!filename) {
          return res.status(400).json({ error: 'Filename is required' });
        }

        const result = comboQueue.removeFile(filename);

        if (!result) {
          return res.status(404).json({ error: 'File not found in queue' });
        }

        res.json({
          success: true,
          message: 'File removed successfully'
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // POST /api/queue/clear
    app.post('/api/queue/clear', (req, res) => {
      try {
        if (!comboQueue) {
          return res.status(503).json({ error: 'Queue is not enabled' });
        }

        const cleared = comboQueue.clearCompleted();

        res.json({
          success: true,
          cleared
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // POST /api/queue/pause
    app.post('/api/queue/pause', (req, res) => {
      try {
        if (!comboQueue) {
          return res.status(503).json({ error: 'Queue is not enabled' });
        }

        comboQueue.pause();

        res.json({
          success: true,
          message: 'Queue paused'
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // POST /api/queue/resume
    app.post('/api/queue/resume', (req, res) => {
      try {
        if (!comboQueue) {
          return res.status(503).json({ error: 'Queue is not enabled' });
        }

        comboQueue.resume();

        res.json({
          success: true,
          message: 'Queue resumed'
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // GET /api/queue/stats
    app.get('/api/queue/stats', (req, res) => {
      try {
        if (!comboQueue) {
          return res.status(503).json({ error: 'Queue is not enabled' });
        }

        const stats = comboQueue.getStats();

        res.json(stats);
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // GET /api/queue/export
    app.get('/api/queue/export', (req, res) => {
      try {
        if (!comboQueue) {
          return res.status(503).json({ error: 'Queue is not enabled' });
        }

        const timestamp = new Date().toISOString().split('T')[0];
        const filename = `queue_export_${timestamp}.txt`;

        const lines = [];
        for (const combo of comboQueue.combos.values()) {
          lines.push(`${combo.username}:${combo.password}`);
        }
        const content = lines.join('\n') + (lines.length > 0 ? '\n' : '');

        res.setHeader('Content-Type', 'text/plain');
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        res.send(content);
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // POST /api/queue/import
    app.post('/api/queue/import', (req, res) => {
      try {
        if (!comboQueue) {
          return res.status(503).json({ error: 'Queue is not enabled' });
        }

        const { content, sourceName, priority } = req.body;

        if (!content) {
          return res.status(400).json({ error: 'Content is required' });
        }

        const source = sourceName || 'imported_combos.txt';
        const lines = content.split('\n');
        const stats = comboQueue.addCombos(lines, source, { priority: priority || 3 });

        res.json({
          success: true,
          stats
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // GET /api/history/export
    app.get('/api/history/export', (req, res) => {
      try {
        if (!credentialHistory) {
          return res.status(400).json({ error: 'History not enabled' });
        }

        const { format = 'jsonl', status } = req.query;
        
        let entries = credentialHistory.getAll();
        if (status && status !== 'all') {
          entries = entries.filter(e => e.status === status);
        }

        const timestamp = new Date().toISOString().split('T')[0];
        let content = '';
        let filename = '';
        let contentType = '';

        if (format === 'txt') {
          content = entries.map(e => `${e.username}:${e.password}`).join('\n');
          if (content) content += '\n';
          filename = `history_export_${timestamp}.txt`;
          contentType = 'text/plain';
        } else if (format === 'csv') {
          const csvHeaders = 'username,password,status,method,confidence,pointsBalance,moneyBalance,timestamp\n';
          const csvRows = entries.map(e => `${e.username},${e.password},${e.status},${e.method || ''},${e.confidence || ''},${e.pointsBalance || ''},${e.moneyBalance || ''},${e.timestamp}`).join('\n');
          content = csvHeaders + csvRows + (csvRows ? '\n' : '');
          filename = `history_export_${timestamp}.csv`;
          contentType = 'text/csv';
        } else if (format === 'json') {
          content = JSON.stringify(entries, null, 2);
          filename = `history_export_${timestamp}.json`;
          contentType = 'application/json';
        } else {
          content = entries.map(e => JSON.stringify({ u: e.username, p: e.password, s: e.status, t: e.timestamp })).join('\n');
          if (content) content += '\n';
          filename = `history_export_${timestamp}.jsonl`;
          contentType = 'application/x-ndjson';
        }

        res.setHeader('Content-Type', contentType);
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        res.send(content);
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // POST /api/history/import
    app.post('/api/history/import', (req, res) => {
      try {
        if (!credentialHistory) {
          return res.status(400).json({ error: 'History not enabled' });
        }

        const { content, format, mode = 'merge' } = req.body;

        if (!content) {
          return res.status(400).json({ error: 'Content is required' });
        }

        if (!format) {
          return res.status(400).json({ error: 'Format is required' });
        }

        let imported = 0;
        let skipped = 0;

        if (mode === 'replace') {
          credentialHistory.history.clear();
        }

        if (format === 'txt') {
          const txtLines = content.split('\n').filter(line => line.trim());
          for (const line of txtLines) {
            const trimmed = line.trim();
            if (!trimmed || !trimmed.includes(':')) continue;
            
            const colonIndex = trimmed.indexOf(':');
            const username = trimmed.substring(0, colonIndex).trim();
            const password = trimmed.substring(colonIndex + 1).trim();
            
            if (username && password) {
              const key = credentialHistory._key(username, password);
              if (mode === 'merge' && credentialHistory.history.has(key)) {
                skipped++;
              } else {
                credentialHistory.record(username, password, 'success', {});
                imported++;
              }
            }
          }
        } else if (format === 'jsonl') {
          const jsonlLines = content.split('\n').filter(line => line.trim());
          for (const line of jsonlLines) {
            try {
              const entry = JSON.parse(line);
              if (entry.u && entry.p && entry.s) {
                const key = credentialHistory._key(entry.u, entry.p);
                if (mode === 'merge' && credentialHistory.history.has(key)) {
                  skipped++;
                } else {
                  credentialHistory.record(entry.u, entry.p, entry.s, {});
                  imported++;
                }
              }
            } catch (e) {
              // Skip invalid lines
            }
          }
        }

        res.json({
          success: true,
          imported,
          skipped,
          mode
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // GET /api/system
    app.get('/api/system', (req, res) => {
      try {
        const cpus = os.cpus();
        const totalMem = os.totalmem();
        const freeMem = os.freemem();
        
        res.json({
          platform: os.platform(),
          arch: os.arch(),
          nodeVersion: process.version,
          cpuCount: cpus.length,
          cpuModel: cpus[0].model,
          totalMemoryMB: Math.floor(totalMem / 1024 / 1024),
          freeMemoryMB: Math.floor(freeMem / 1024 / 1024),
          uptime: os.uptime()
        });
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });
  });

  afterAll(() => {
    console.log.mockRestore();
  });

  // ============ CONFIG ENDPOINTS ============

  describe('GET /api/config', () => {
    it('should return current config', async () => {
      const response = await request(app)
        .get('/api/config')
        .expect(200);

      expect(response.body).toHaveProperty('browser');
      expect(response.body).toHaveProperty('batch');
      expect(response.body.browser.headless).toBe(true);
    });

    it('should handle errors gracefully', async () => {
      const errorApp = express();
      errorApp.use(express.json());
      errorApp.get('/api/config', (req, res) => {
        throw new Error('Config load failed');
      });

      await request(errorApp)
        .get('/api/config')
        .expect(500);
    });
  });

  describe('PUT /api/config', () => {
    it('should update config with valid keys', async () => {
      const updates = {
        batch: { maxParallelWorkers: 10 }
      };

      const response = await request(app)
        .put('/api/config')
        .send(updates)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.config.batch.maxParallelWorkers).toBe(10);
    });

    it('should reject invalid top-level keys', async () => {
      const updates = {
        invalidKey: { value: 123 }
      };

      const response = await request(app)
        .put('/api/config')
        .send(updates)
        .expect(400);

      expect(response.body.error).toContain('Invalid configuration key');
      expect(response.body.validKeys).toBeDefined();
    });

    it('should validate maxParallelWorkers range', async () => {
      const response = await request(app)
        .put('/api/config')
        .send({ batch: { maxParallelWorkers: 100 } })
        .expect(400);

      expect(response.body.error).toContain('maxParallelWorkers must be between 1 and 50');
    });

    it('should validate maxParallelWorkers type', async () => {
      const response = await request(app)
        .put('/api/config')
        .send({ batch: { maxParallelWorkers: 'invalid' } })
        .expect(400);

      expect(response.body.error).toContain('maxParallelWorkers must be between 1 and 50');
    });

    it('should validate credentialsPerProxy range', async () => {
      const response = await request(app)
        .put('/api/config')
        .send({ batch: { credentialsPerProxy: 200 } })
        .expect(400);

      expect(response.body.error).toContain('credentialsPerProxy must be between 1 and 100');
    });

    it('should validate defaultPriority range', async () => {
      const response = await request(app)
        .put('/api/config')
        .send({ queue: { defaultPriority: 10 } })
        .expect(400);

      expect(response.body.error).toContain('defaultPriority must be between 1 and 5');
    });

    it('should deep merge nested objects', async () => {
      const updates = {
        batch: { maxParallelWorkers: 8 }
      };

      const response = await request(app)
        .put('/api/config')
        .send(updates)
        .expect(200);

      expect(response.body.config.batch.maxParallelWorkers).toBe(8);
      expect(response.body.config.batch.credentialsPerProxy).toBe(10); // Original value preserved
    });
  });

  describe('POST /api/config/save', () => {
    it('should save config to disk with backup', async () => {
      const response = await request(app)
        .post('/api/config/save')
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toContain('Configuration saved');
      expect(response.body.backup).toContain('.backup.');
      expect(fs.copyFileSync).toHaveBeenCalled();
      expect(fs.writeFileSync).toHaveBeenCalled();
    });

    it('should handle save errors', async () => {
      fs.copyFileSync.mockImplementation(() => {
        throw new Error('Write failed');
      });

      await request(app)
        .post('/api/config/save')
        .expect(500);
    });
  });

  // ============ CREDENTIALS ENDPOINTS ============

  describe('GET /api/credentials', () => {
    it('should return credentials from test.txt', async () => {
      const response = await request(app)
        .get('/api/credentials')
        .expect(200);

      expect(response.body.lines).toBe('test:pass\nuser2:pass2');
      expect(response.body.count).toBe(2);
    });

    it('should return empty array when file does not exist', async () => {
      fs.existsSync.mockReturnValue(false);

      const response = await request(app)
        .get('/api/credentials')
        .expect(200);

      expect(response.body.lines).toEqual([]);
      expect(response.body.count).toBe(0);
    });

    it('should exclude comment lines from count', async () => {
      fs.readFileSync.mockReturnValue('user1:pass1\n# comment\nuser2:pass2');

      const response = await request(app)
        .get('/api/credentials')
        .expect(200);

      expect(response.body.count).toBe(2);
    });

    it('should handle read errors', async () => {
      fs.readFileSync.mockImplementation(() => {
        throw new Error('Read failed');
      });

      await request(app)
        .get('/api/credentials')
        .expect(500);
    });
  });

  describe('PUT /api/credentials', () => {
    it('should write credentials to test.txt', async () => {
      const content = 'newuser:newpass\nuser2:pass2';

      const response = await request(app)
        .put('/api/credentials')
        .send({ content })
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.count).toBe(2);
      expect(fs.writeFileSync).toHaveBeenCalled();
    });

    it('should handle write errors', async () => {
      fs.writeFileSync.mockImplementation(() => {
        throw new Error('Write failed');
      });

      await request(app)
        .put('/api/credentials')
        .send({ content: 'test:pass' })
        .expect(500);
    });
  });

  // ============ PROXY ENDPOINTS ============

  describe('GET /api/proxies', () => {
    it('should return proxies from Lightning_Proxies.txt', async () => {
      const response = await request(app)
        .get('/api/proxies')
        .expect(200);

      expect(response.body.lines).toBeDefined();
      expect(response.body.count).toBeGreaterThanOrEqual(0);
    });

    it('should return empty array when file does not exist', async () => {
      fs.existsSync.mockReturnValue(false);

      const response = await request(app)
        .get('/api/proxies')
        .expect(200);

      expect(response.body.lines).toEqual([]);
      expect(response.body.count).toBe(0);
    });
  });

  describe('PUT /api/proxies', () => {
    it('should write proxies to Lightning_Proxies.txt', async () => {
      const content = '127.0.0.1:8080\n192.168.1.1:3128';

      const response = await request(app)
        .put('/api/proxies')
        .send({ content })
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.count).toBe(2);
      expect(fs.writeFileSync).toHaveBeenCalled();
    });
  });

  // ============ HISTORY ENDPOINTS ============

  describe('GET /api/history', () => {
    beforeEach(() => {
      mockCredentialHistory.getAll.mockReturnValue([
        {
          username: 'user1',
          password: 'pass1',
          status: 'success',
          timestamp: '2024-01-01T00:00:00Z',
          pointsBalance: '100',
          moneyBalance: '50',
          confidence: 0.9
        },
        {
          username: 'user2',
          password: 'pass2',
          status: 'failed',
          timestamp: '2024-01-02T00:00:00Z',
          pointsBalance: '0',
          moneyBalance: '0',
          confidence: 0.5
        }
      ]);
    });

    it('should return paginated history', async () => {
      const response = await request(app)
        .get('/api/history')
        .expect(200);

      expect(response.body.entries).toHaveLength(2);
      expect(response.body.total).toBe(2);
      expect(response.body.page).toBe(1);
      expect(response.body.totalPages).toBe(1);
    });

    it('should filter by status', async () => {
      const response = await request(app)
        .get('/api/history?status=success')
        .expect(200);

      expect(response.body.entries).toHaveLength(1);
      expect(response.body.entries[0].status).toBe('success');
    });

    it('should search entries', async () => {
      const response = await request(app)
        .get('/api/history?search=user1')
        .expect(200);

      expect(response.body.entries).toHaveLength(1);
      expect(response.body.entries[0].username).toBe('user1');
    });

    it('should sort by date ascending', async () => {
      const response = await request(app)
        .get('/api/history?sort=date_asc')
        .expect(200);

      expect(response.body.entries[0].username).toBe('user1');
    });

    it('should sort by date descending', async () => {
      const response = await request(app)
        .get('/api/history?sort=date_desc')
        .expect(200);

      expect(response.body.entries[0].username).toBe('user2');
    });

    it('should sort by points', async () => {
      const response = await request(app)
        .get('/api/history?sort=points_desc')
        .expect(200);

      // With descending sort, zero values go to the end
      expect(response.body.entries[0].pointsBalance).toBe('0');
      expect(response.body.entries[1].pointsBalance).toBe('100');
    });

    it('should sort by money', async () => {
      const response = await request(app)
        .get('/api/history?sort=money_desc')
        .expect(200);

      // With descending sort, zero values go to the end
      expect(response.body.entries[0].moneyBalance).toBe('0');
      expect(response.body.entries[1].moneyBalance).toBe('50');
    });

    it('should sort by confidence', async () => {
      const response = await request(app)
        .get('/api/history?sort=confidence_desc')
        .expect(200);

      expect(response.body.entries[0].confidence).toBe(0.9);
    });

    it('should sort by username', async () => {
      const response = await request(app)
        .get('/api/history?sort=username_asc')
        .expect(200);

      expect(response.body.entries[0].username).toBe('user1');
    });

    it('should handle pagination', async () => {
      const response = await request(app)
        .get('/api/history?page=1&limit=1')
        .expect(200);

      expect(response.body.entries).toHaveLength(1);
      expect(response.body.totalPages).toBe(2);
    });

    it('should return empty when history not enabled', async () => {
      const noHistoryApp = express();
      noHistoryApp.use(express.json());
      noHistoryApp.get('/api/history', (req, res) => {
        res.json({ entries: [], total: 0, page: 1, totalPages: 0 });
      });

      const response = await request(noHistoryApp)
        .get('/api/history')
        .expect(200);

      expect(response.body.entries).toEqual([]);
    });
  });

  describe('GET /api/history/stats', () => {
    it('should return history statistics', async () => {
      const response = await request(app)
        .get('/api/history/stats')
        .expect(200);

      expect(response.body.total).toBe(10);
      expect(response.body.success).toBe(5);
      expect(response.body.failed).toBe(3);
      expect(mockCredentialHistory.getStats).toHaveBeenCalled();
    });
  });

  describe('POST /api/history/compact', () => {
    it('should compact history file', async () => {
      const response = await request(app)
        .post('/api/history/compact')
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toContain('compacted');
      expect(mockCredentialHistory.compact).toHaveBeenCalled();
    });

    it('should return error when history not enabled', async () => {
      const noHistoryApp = express();
      noHistoryApp.use(express.json());
      noHistoryApp.post('/api/history/compact', (req, res) => {
        res.status(400).json({ error: 'History not enabled' });
      });

      await request(noHistoryApp)
        .post('/api/history/compact')
        .expect(400);
    });
  });

  // ============ CONTROLLER ENDPOINTS ============

  describe('GET /api/status', () => {
    it('should return controller not running', async () => {
      const response = await request(app)
        .get('/api/status')
        .expect(200);

      expect(response.body.running).toBeFalsy();
      expect(response.body.pid).toBeNull();
    });
  });

  describe('POST /api/start', () => {
    it('should start controller process', async () => {
      const response = await request(app)
        .post('/api/start')
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.pid).toBe(12345);
      expect(response.body.message).toContain('started');
      expect(spawn).toHaveBeenCalled();
    });

    it('should prevent starting when already running', async () => {
      // Start first time
      await request(app).post('/api/start').expect(200);

      // Try to start again
      const response = await request(app)
        .post('/api/start')
        .expect(400);

      expect(response.body.error).toContain('already running');
    });

    it('should setup stdout listener', async () => {
      const response = await request(app)
        .post('/api/start')
        .expect(200);

      const mockProc = spawn.mock.results[0].value;
      expect(mockProc.stdout.on).toHaveBeenCalledWith('data', expect.any(Function));
    });

    it('should setup stderr listener', async () => {
      const response = await request(app)
        .post('/api/start')
        .expect(200);

      const mockProc = spawn.mock.results[0].value;
      expect(mockProc.stderr.on).toHaveBeenCalledWith('data', expect.any(Function));
    });
  });

  describe('POST /api/stop', () => {
    it('should stop controller process', async () => {
      // Start first
      await request(app).post('/api/start').expect(200);

      const response = await request(app)
        .post('/api/stop')
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toContain('Stop signal sent');
      
      const mockProc = spawn.mock.results[0].value;
      expect(mockProc.kill).toHaveBeenCalledWith('SIGTERM');
    });

    it('should return error when not running', async () => {
      const response = await request(app)
        .post('/api/stop')
        .expect(400);

      expect(response.body.error).toContain('not running');
    });
  });

  describe('GET /api/logs', () => {
    it('should return log buffer', async () => {
      const response = await request(app)
        .get('/api/logs')
        .expect(200);

      expect(response.body.logs).toBeDefined();
      expect(response.body.offset).toBeDefined();
      expect(Array.isArray(response.body.logs)).toBe(true);
    });

    it('should return logs since index', async () => {
      // Start controller to generate some logs
      await request(app).post('/api/start').expect(200);

      const response = await request(app)
        .get('/api/logs?since=0')
        .expect(200);

      expect(response.body.logs).toBeDefined();
    });
  });

  // ============ NEW CONTROLLER ENDPOINTS ============

  describe('GET /api/controller/status', () => {
    it('should return controller not running initially', async () => {
      const response = await request(app)
        .get('/api/controller/status')
        .expect(200);

      expect(response.body.running).toBe(false);
      expect(response.body.pid).toBeNull();
    });

    it('should return running status when controller is active', async () => {
      // Start controller first
      await request(app).post('/api/controller/start').expect(200);

      const response = await request(app)
        .get('/api/controller/status')
        .expect(200);

      expect(response.body.running).toBe(true);
      expect(response.body.pid).toBe(12345);
    });
  });

  describe('POST /api/controller/start', () => {
    it('should successfully start controller', async () => {
      const response = await request(app)
        .post('/api/controller/start')
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toBe('Controller started successfully');
      expect(response.body.pid).toBe(12345);
      expect(spawn).toHaveBeenCalled();
    });

    it('should prevent starting when already running', async () => {
      // Start first time
      await request(app).post('/api/controller/start').expect(200);

      // Try to start again
      const response = await request(app)
        .post('/api/controller/start')
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('Controller is already running');
    });

    it('should setup stdout listener', async () => {
      await request(app).post('/api/controller/start').expect(200);

      const mockProc = spawn.mock.results[spawn.mock.results.length - 1].value;
      expect(mockProc.stdout.on).toHaveBeenCalledWith('data', expect.any(Function));
    });

    it('should setup stderr listener', async () => {
      await request(app).post('/api/controller/start').expect(200);

      const mockProc = spawn.mock.results[spawn.mock.results.length - 1].value;
      expect(mockProc.stderr.on).toHaveBeenCalledWith('data', expect.any(Function));
    });

    it('should setup cleanup handlers', async () => {
      await request(app).post('/api/controller/start').expect(200);

      const mockProc = spawn.mock.results[spawn.mock.results.length - 1].value;
      expect(mockProc.on).toHaveBeenCalledWith('close', expect.any(Function));
      expect(mockProc.on).toHaveBeenCalledWith('error', expect.any(Function));
    });

    it('should spawn with correct arguments', async () => {
      await request(app).post('/api/controller/start').expect(200);

      expect(spawn).toHaveBeenCalled();
      const spawnCall = spawn.mock.calls[spawn.mock.calls.length - 1];
      expect(spawnCall[0]).toBe('node');
      expect(spawnCall[1][0]).toContain('play_version2_controller.js');
      expect(spawnCall[1][1]).toBe('--no-interactive');
      expect(spawnCall[2]).toMatchObject({
        stdio: ['ignore', 'pipe', 'pipe']
      });
    });
  });

  describe('POST /api/controller/stop', () => {
    it('should successfully stop running controller', async () => {
      // Start controller first
      await request(app).post('/api/controller/start').expect(200);

      const response = await request(app)
        .post('/api/controller/stop')
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toBe('Controller stop signal sent');

      const mockProc = spawn.mock.results[spawn.mock.results.length - 1].value;
      expect(mockProc.kill).toHaveBeenCalledWith('SIGTERM');
    });

    it('should return error when not running', async () => {
      const response = await request(app)
        .post('/api/controller/stop')
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toBe('No controller process running');
    });
  });

  // ============ QUEUE ENDPOINTS ============

  describe('GET /api/queue', () => {
    it('should return queue stats and files', async () => {
      const response = await request(app)
        .get('/api/queue')
        .expect(200);

      expect(response.body.stats).toBeDefined();
      expect(response.body.files).toBeDefined();
      expect(mockComboQueue.getStats).toHaveBeenCalled();
      expect(mockComboQueue.getFiles).toHaveBeenCalled();
    });

    it('should return error when queue not enabled', async () => {
      const noQueueApp = express();
      noQueueApp.use(express.json());
      noQueueApp.get('/api/queue', (req, res) => {
        res.status(503).json({ error: 'Queue is not enabled' });
      });

      await request(noQueueApp)
        .get('/api/queue')
        .expect(503);
    });
  });

  describe('POST /api/queue/add', () => {
    it('should add combos to queue', async () => {
      const response = await request(app)
        .post('/api/queue/add')
        .send({
          content: 'user1:pass1\nuser2:pass2',
          sourceName: 'test.txt',
          priority: 3
        })
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.stats).toBeDefined();
      expect(mockComboQueue.addCombos).toHaveBeenCalled();
    });

    it('should require content', async () => {
      const response = await request(app)
        .post('/api/queue/add')
        .send({ sourceName: 'test.txt' })
        .expect(400);

      expect(response.body.error).toContain('Content is required');
    });

    it('should require sourceName', async () => {
      const response = await request(app)
        .post('/api/queue/add')
        .send({ content: 'user:pass' })
        .expect(400);

      expect(response.body.error).toContain('Source name is required');
    });

    it('should use default priority when not provided', async () => {
      const response = await request(app)
        .post('/api/queue/add')
        .send({
          content: 'user:pass',
          sourceName: 'test.txt'
        })
        .expect(200);

      expect(response.body.success).toBe(true);
    });
  });

  describe('POST /api/queue/shuffle', () => {
    it('should shuffle queue', async () => {
      const response = await request(app)
        .post('/api/queue/shuffle')
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toContain('shuffled');
      expect(mockComboQueue.shuffle).toHaveBeenCalled();
    });
  });

  describe('PUT /api/queue/priority', () => {
    it('should update file priority', async () => {
      const response = await request(app)
        .put('/api/queue/priority')
        .send({ filename: 'test.txt', priority: 5 })
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(mockComboQueue.setPriority).toHaveBeenCalledWith('test.txt', 5);
    });

    it('should require filename', async () => {
      const response = await request(app)
        .put('/api/queue/priority')
        .send({ priority: 5 })
        .expect(400);

      expect(response.body.error).toContain('Filename is required');
    });

    it('should validate priority range', async () => {
      const response = await request(app)
        .put('/api/queue/priority')
        .send({ filename: 'test.txt', priority: 10 })
        .expect(400);

      expect(response.body.error).toContain('Priority must be between 1 and 5');
    });

    it('should return 404 when file not found', async () => {
      mockComboQueue.setPriority.mockReturnValue(false);

      const response = await request(app)
        .put('/api/queue/priority')
        .send({ filename: 'notfound.txt', priority: 3 })
        .expect(404);

      expect(response.body.error).toContain('not found');
    });
  });

  describe('DELETE /api/queue/file', () => {
    it('should remove file from queue', async () => {
      const response = await request(app)
        .delete('/api/queue/file')
        .send({ filename: 'test.txt' })
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(mockComboQueue.removeFile).toHaveBeenCalledWith('test.txt');
    });

    it('should require filename', async () => {
      const response = await request(app)
        .delete('/api/queue/file')
        .send({})
        .expect(400);

      expect(response.body.error).toContain('Filename is required');
    });

    it('should return 404 when file not found', async () => {
      mockComboQueue.removeFile.mockReturnValue(false);

      const response = await request(app)
        .delete('/api/queue/file')
        .send({ filename: 'notfound.txt' })
        .expect(404);

      expect(response.body.error).toContain('not found');
    });
  });

  describe('POST /api/queue/clear', () => {
    it('should clear completed items', async () => {
      const response = await request(app)
        .post('/api/queue/clear')
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.cleared).toBe(10);
      expect(mockComboQueue.clearCompleted).toHaveBeenCalled();
    });
  });

  describe('POST /api/queue/pause', () => {
    it('should pause queue processing', async () => {
      const response = await request(app)
        .post('/api/queue/pause')
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toContain('paused');
      expect(mockComboQueue.pause).toHaveBeenCalled();
    });
  });

  describe('POST /api/queue/resume', () => {
    it('should resume queue processing', async () => {
      const response = await request(app)
        .post('/api/queue/resume')
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toContain('resumed');
      expect(mockComboQueue.resume).toHaveBeenCalled();
    });
  });

  describe('GET /api/queue/stats', () => {
    it('should return queue statistics', async () => {
      const response = await request(app)
        .get('/api/queue/stats')
        .expect(200);

      expect(response.body.total).toBe(100);
      expect(response.body.pending).toBe(50);
      expect(mockComboQueue.getStats).toHaveBeenCalled();
    });
  });

  // ============ QUEUE IMPORT/EXPORT ENDPOINTS ============

  describe('GET /api/queue/export', () => {
    it('should export queue as text file', async () => {
      const response = await request(app)
        .get('/api/queue/export')
        .expect(200);

      expect(response.headers['content-type']).toBe('text/plain; charset=utf-8');
      expect(response.headers['content-disposition']).toContain('attachment');
      expect(response.headers['content-disposition']).toContain('.txt');
      expect(response.text).toContain('user1:pass1');
      expect(response.text).toContain('user2:pass2');
    });

    it('should return error when queue not enabled', async () => {
      const noQueueApp = express();
      noQueueApp.use(express.json());
      noQueueApp.get('/api/queue/export', (req, res) => {
        res.status(503).json({ error: 'Queue is not enabled' });
      });

      await request(noQueueApp)
        .get('/api/queue/export')
        .expect(503);
    });
  });

  describe('POST /api/queue/import', () => {
    it('should import combos from file content', async () => {
      const response = await request(app)
        .post('/api/queue/import')
        .send({
          content: 'user3:pass3\nuser4:pass4',
          sourceName: 'imported.txt',
          priority: 4
        })
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.stats).toBeDefined();
      expect(response.body.stats.added).toBe(10);
      expect(mockComboQueue.addCombos).toHaveBeenCalled();
    });

    it('should use default source name when not provided', async () => {
      const response = await request(app)
        .post('/api/queue/import')
        .send({
          content: 'user:pass'
        })
        .expect(200);

      expect(response.body.success).toBe(true);
    });

    it('should require content', async () => {
      const response = await request(app)
        .post('/api/queue/import')
        .send({ sourceName: 'test.txt' })
        .expect(400);

      expect(response.body.error).toContain('Content is required');
    });
  });

  // ============ HISTORY IMPORT/EXPORT ENDPOINTS ============

  describe('GET /api/history/export', () => {
    it('should export history as txt format', async () => {
      const response = await request(app)
        .get('/api/history/export?format=txt')
        .expect(200);

      expect(response.headers['content-type']).toBe('text/plain; charset=utf-8');
      expect(response.headers['content-disposition']).toContain('.txt');
      expect(response.text).toContain('user1:pass1');
      expect(response.text).toContain('user2:pass2');
    });

    it('should export history as csv format', async () => {
      const response = await request(app)
        .get('/api/history/export?format=csv')
        .expect(200);

      expect(response.headers['content-type']).toBe('text/csv; charset=utf-8');
      expect(response.headers['content-disposition']).toContain('.csv');
      expect(response.text).toContain('username,password,status');
      expect(response.text).toContain('user1,pass1,success');
    });

    it('should export history as json format', async () => {
      const response = await request(app)
        .get('/api/history/export?format=json')
        .expect(200);

      expect(response.headers['content-type']).toBe('application/json; charset=utf-8');
      expect(response.headers['content-disposition']).toContain('.json');
      const data = JSON.parse(response.text);
      expect(Array.isArray(data)).toBe(true);
      expect(data.length).toBe(2);
    });

    it('should export history as jsonl format by default', async () => {
      const response = await request(app)
        .get('/api/history/export')
        .expect(200);

      expect(response.headers['content-type']).toBe('application/x-ndjson; charset=utf-8');
      expect(response.headers['content-disposition']).toContain('.jsonl');
      expect(response.text).toContain('"u":"user1"');
    });

    it('should filter by status when provided', async () => {
      const response = await request(app)
        .get('/api/history/export?format=txt&status=success')
        .expect(200);

      expect(response.text).toContain('user1:pass1');
    });

    it('should return error when history not enabled', async () => {
      const noHistoryApp = express();
      noHistoryApp.use(express.json());
      noHistoryApp.get('/api/history/export', (req, res) => {
        res.status(400).json({ error: 'History not enabled' });
      });

      await request(noHistoryApp)
        .get('/api/history/export')
        .expect(400);
    });
  });

  describe('POST /api/history/import', () => {
    it('should import history from txt format', async () => {
      const response = await request(app)
        .post('/api/history/import')
        .send({
          content: 'user3:pass3\nuser4:pass4',
          format: 'txt',
          mode: 'merge'
        })
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.imported).toBeGreaterThanOrEqual(0);
      expect(response.body.skipped).toBeGreaterThanOrEqual(0);
      expect(response.body.mode).toBe('merge');
    });

    it('should import history from jsonl format', async () => {
      const content = '{"u":"user5","p":"pass5","s":"success","t":"2024-01-03T00:00:00.000Z"}\n{"u":"user6","p":"pass6","s":"failed","t":"2024-01-04T00:00:00.000Z"}';
      const response = await request(app)
        .post('/api/history/import')
        .send({
          content,
          format: 'jsonl',
          mode: 'merge'
        })
        .expect(200);

      expect(response.body.success).toBe(true);
    });

    it('should require content', async () => {
      const response = await request(app)
        .post('/api/history/import')
        .send({ format: 'txt' })
        .expect(400);

      expect(response.body.error).toContain('Content is required');
    });

    it('should require format', async () => {
      const response = await request(app)
        .post('/api/history/import')
        .send({ content: 'user:pass' })
        .expect(400);

      expect(response.body.error).toContain('Format is required');
    });

    it('should default to merge mode', async () => {
      const response = await request(app)
        .post('/api/history/import')
        .send({
          content: 'user:pass',
          format: 'txt'
        })
        .expect(200);

      expect(response.body.mode).toBe('merge');
    });
  });

  // ============ SYSTEM ENDPOINT ============

  describe('GET /api/system', () => {
    it('should return system information', async () => {
      const response = await request(app)
        .get('/api/system')
        .expect(200);

      expect(response.body.platform).toBe('linux');
      expect(response.body.arch).toBe('x64');
      expect(response.body.nodeVersion).toBe(process.version);
      expect(response.body.cpuCount).toBe(1);
      expect(response.body.cpuModel).toBe('Intel Core i7');
      expect(response.body.totalMemoryMB).toBeGreaterThan(0);
      expect(response.body.freeMemoryMB).toBeGreaterThan(0);
      expect(response.body.uptime).toBe(12345);
    });

    it('should handle system info errors', async () => {
      os.cpus.mockImplementation(() => {
        throw new Error('System error');
      });

      await request(app)
        .get('/api/system')
        .expect(500);
    });
  });

  // ============ CORS AND MIDDLEWARE ============

  describe('CORS Middleware', () => {
    it('should set CORS headers', async () => {
      const response = await request(app)
        .get('/api/config')
        .expect(200);

      expect(response.headers['access-control-allow-origin']).toBe('*');
      expect(response.headers['access-control-allow-methods']).toContain('GET');
    });

    it('should handle OPTIONS preflight', async () => {
      const response = await request(app)
        .options('/api/config')
        .expect(200);
    });
  });

  // ============ ERROR HANDLING ============

  describe('Error Handling', () => {
    it('should return 500 on server errors', async () => {
      const errorApp = express();
      errorApp.use(express.json());
      errorApp.get('/api/error', (req, res) => {
        throw new Error('Test error');
      });

      await request(errorApp)
        .get('/api/error')
        .expect(500);
    });

    it('should handle JSON parse errors', async () => {
      const response = await request(app)
        .put('/api/config')
        .set('Content-Type', 'application/json')
        .send('invalid json')
        .expect(400);
    });
  });

  // ============ SECURITY HEADERS ============

  describe('Security Headers', () => {
    it('should set X-Content-Type-Options to nosniff', async () => {
      const response = await request(app).get('/api/config');
      expect(response.headers['x-content-type-options']).toBe('nosniff');
    });

    it('should set X-Frame-Options to DENY', async () => {
      const response = await request(app).get('/api/config');
      expect(response.headers['x-frame-options']).toBe('DENY');
    });

    it('should set Referrer-Policy', async () => {
      const response = await request(app).get('/api/config');
      expect(response.headers['referrer-policy']).toBe('strict-origin-when-cross-origin');
    });

    it('should set Permissions-Policy', async () => {
      const response = await request(app).get('/api/config');
      expect(response.headers['permissions-policy']).toBe('camera=(), microphone=(), geolocation=()');
    });

    it('should not expose x-powered-by header', async () => {
      const response = await request(app).get('/api/config');
      expect(response.headers['x-powered-by']).toBeUndefined();
    });
  });

  // ============ INTEGRATION TESTS ============

  describe('Integration Tests', () => {
    it('should start and stop controller', async () => {
      // Start
      const startResp = await request(app)
        .post('/api/start')
        .expect(200);

      expect(startResp.body.success).toBe(true);

      // Check status
      const statusResp = await request(app)
        .get('/api/status')
        .expect(200);

      expect(statusResp.body.running).toBe(true);

      // Stop
      const stopResp = await request(app)
        .post('/api/stop')
        .expect(200);

      expect(stopResp.body.success).toBe(true);
    });

    it('should handle config update and save workflow', async () => {
      // Update config
      const updateResp = await request(app)
        .put('/api/config')
        .send({ batch: { maxParallelWorkers: 15 } })
        .expect(200);

      expect(updateResp.body.config.batch.maxParallelWorkers).toBe(15);

      // Save config
      const saveResp = await request(app)
        .post('/api/config/save')
        .expect(200);

      expect(saveResp.body.success).toBe(true);
      expect(fs.writeFileSync).toHaveBeenCalled();
    });

    it('should handle queue operations workflow', async () => {
      // Get queue
      await request(app)
        .get('/api/queue')
        .expect(200);

      // Add to queue
      await request(app)
        .post('/api/queue/add')
        .send({
          content: 'user:pass',
          sourceName: 'test.txt',
          priority: 3
        })
        .expect(200);

      // Pause queue
      await request(app)
        .post('/api/queue/pause')
        .expect(200);

      // Resume queue
      await request(app)
        .post('/api/queue/resume')
        .expect(200);

      // Shuffle queue
      await request(app)
        .post('/api/queue/shuffle')
        .expect(200);

      // Clear completed
      await request(app)
        .post('/api/queue/clear')
        .expect(200);
    });
  });
});