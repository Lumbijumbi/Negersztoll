'use strict';

/**
 * proxyHealthTracker.test.js – Unit tests for utils/proxyHealthTracker.js
 */

const fs = require('fs');
const path = require('path');

// Use the real module — no mocking needed for a pure data-structure class
const ProxyHealthTracker = require('../../utils/proxyHealthTracker');

describe('ProxyHealthTracker', () => {
  let tracker;

  beforeEach(() => {
    tracker = new ProxyHealthTracker();
  });

  afterEach(() => {
    tracker.destroy();
  });

  // --------------------------------------------------------------------------
  //  Construction
  // --------------------------------------------------------------------------
  describe('constructor', () => {
    it('should start with an empty proxy map', () => {
      expect(tracker.getAll()).toEqual([]);
    });

    it('should return zero stats when empty', () => {
      const stats = tracker.getStats();
      expect(stats.total).toBe(0);
      expect(stats.healthy).toBe(0);
      expect(stats.poolHealthPercent).toBe(0);
    });
  });

  // --------------------------------------------------------------------------
  //  recordSuccess
  // --------------------------------------------------------------------------
  describe('recordSuccess', () => {
    it('should create a new record on first call', () => {
      tracker.recordSuccess('1.2.3.4:8080', 150);
      const all = tracker.getAll();
      expect(all).toHaveLength(1);
      expect(all[0].address).toBe('1.2.3.4:8080');
      expect(all[0].successCount).toBe(1);
      expect(all[0].failCount).toBe(0);
    });

    it('should increment successCount on repeated calls', () => {
      tracker.recordSuccess('1.2.3.4:8080', 100);
      tracker.recordSuccess('1.2.3.4:8080', 200);
      tracker.recordSuccess('1.2.3.4:8080', 300);
      const r = tracker.getByProxy('1.2.3.4:8080');
      expect(r.successCount).toBe(3);
    });

    it('should track response times and compute average', () => {
      tracker.recordSuccess('p:1', 100);
      tracker.recordSuccess('p:1', 200);
      const r = tracker.getByProxy('p:1');
      expect(r.lastResponseTime).toBe(200);
      expect(r.avgResponseTime).toBe(150);
    });

    it('should reset consecutiveFailures on success', () => {
      tracker.recordFailure('p:1', 'err');
      tracker.recordFailure('p:1', 'err');
      expect(tracker.getByProxy('p:1').consecutiveFailures).toBe(2);
      tracker.recordSuccess('p:1', 100);
      expect(tracker.getByProxy('p:1').consecutiveFailures).toBe(0);
    });

    it('should set lastSuccess timestamp', () => {
      const before = Date.now();
      tracker.recordSuccess('p:1', 50);
      const r = tracker.getByProxy('p:1');
      expect(r.lastSuccess).toBeGreaterThanOrEqual(before);
    });

    it('should emit proxy_health_updated event', () => {
      const spy = jest.fn();
      tracker.on('proxy_health_updated', spy);
      tracker.recordSuccess('p:1', 100);
      expect(spy).toHaveBeenCalledTimes(1);
      expect(spy.mock.calls[0][0].proxy).toBe('p:1');
    });
  });

  // --------------------------------------------------------------------------
  //  recordFailure
  // --------------------------------------------------------------------------
  describe('recordFailure', () => {
    it('should increment failCount and consecutiveFailures', () => {
      tracker.recordFailure('p:1', 'timeout');
      tracker.recordFailure('p:1', 'refused');
      const r = tracker.getByProxy('p:1');
      expect(r.failCount).toBe(2);
      expect(r.consecutiveFailures).toBe(2);
    });

    it('should set lastFailure timestamp', () => {
      const before = Date.now();
      tracker.recordFailure('p:1', 'err');
      const r = tracker.getByProxy('p:1');
      expect(r.lastFailure).toBeGreaterThanOrEqual(before);
    });

    it('should add event to recentEvents', () => {
      tracker.recordFailure('p:1', 'timeout');
      const r = tracker.getByProxy('p:1');
      expect(r.recentEvents).toHaveLength(1);
      expect(r.recentEvents[0].type).toBe('failure');
      expect(r.recentEvents[0].detail).toBe('timeout');
    });
  });

  // --------------------------------------------------------------------------
  //  recordBlock
  // --------------------------------------------------------------------------
  describe('recordBlock', () => {
    it('should increment blockCount', () => {
      tracker.recordBlock('p:1', 'captcha');
      tracker.recordBlock('p:1', 'ip_banned');
      const r = tracker.getByProxy('p:1');
      expect(r.blockCount).toBe(2);
    });

    it('should reduce health score significantly', () => {
      // Start with a success to get a baseline
      tracker.recordSuccess('p:1', 100);
      const before = tracker.getByProxy('p:1').healthScore;
      tracker.recordBlock('p:1', 'captcha');
      const after = tracker.getByProxy('p:1').healthScore;
      expect(after).toBeLessThan(before);
    });
  });

  // --------------------------------------------------------------------------
  //  recordTcpFail
  // --------------------------------------------------------------------------
  describe('recordTcpFail', () => {
    it('should increment tcpFailCount', () => {
      tracker.recordTcpFail('p:1');
      tracker.recordTcpFail('p:1');
      const r = tracker.getByProxy('p:1');
      expect(r.tcpFailCount).toBe(2);
    });

    it('should increment consecutiveFailures', () => {
      tracker.recordTcpFail('p:1');
      expect(tracker.getByProxy('p:1').consecutiveFailures).toBe(1);
    });
  });

  // --------------------------------------------------------------------------
  //  recordBlacklist / removeBlacklist
  // --------------------------------------------------------------------------
  describe('blacklist management', () => {
    it('should mark proxy as blacklisted with reason and expiry', () => {
      tracker.recordBlacklist('p:1', 'ip_banned', 600000);
      const r = tracker.getByProxy('p:1');
      expect(r.currentlyBlacklisted).toBe(true);
      expect(r.blacklistReason).toBe('ip_banned');
      expect(r.blacklistExpiry).toBeGreaterThan(Date.now());
      expect(r.blacklistCount).toBe(1);
    });

    it('should reduce healthScore when blacklisted', () => {
      tracker.recordBlacklist('p:1', 'ip_banned', 600000);
      const r = tracker.getByProxy('p:1');
      expect(r.healthScore).toBeLessThanOrEqual(80);
    });

    it('should mark healthy=false on safe clone when blacklisted', () => {
      tracker.recordBlacklist('p:1', 'ip_banned', 600000);
      const r = tracker.getByProxy('p:1');
      expect(r.healthy).toBe(false);
    });

    it('removeBlacklist should clear blacklist state', () => {
      tracker.recordBlacklist('p:1', 'ip_banned', 600000);
      tracker.removeBlacklist('p:1');
      const r = tracker.getByProxy('p:1');
      expect(r.currentlyBlacklisted).toBe(false);
      expect(r.blacklistReason).toBeNull();
      expect(r.blacklistExpiry).toBeNull();
    });

    it('removeBlacklist on unknown proxy should not throw', () => {
      expect(() => tracker.removeBlacklist('unknown:1234')).not.toThrow();
    });

    it('should auto-expire blacklist in getAll', () => {
      jest.useFakeTimers();
      tracker.recordBlacklist('p:1', 'test', 1); // 1ms TTL
      jest.advanceTimersByTime(5);
      const all = tracker.getAll();
      expect(all[0].currentlyBlacklisted).toBe(false);
      jest.useRealTimers();
    });
  });

  // --------------------------------------------------------------------------
  //  recordRotation
  // --------------------------------------------------------------------------
  describe('recordRotation', () => {
    it('should increment lifetimeRotations', () => {
      tracker.recordSuccess('p:1', 100); // create the record
      tracker.recordRotation('p:1');
      tracker.recordRotation('p:1');
      expect(tracker.getByProxy('p:1').lifetimeRotations).toBe(2);
    });
  });

  // --------------------------------------------------------------------------
  //  setInUse / setPaused
  // --------------------------------------------------------------------------
  describe('setInUse', () => {
    it('should toggle inUse flag', () => {
      tracker.recordSuccess('p:1', 100);
      tracker.setInUse('p:1', true);
      expect(tracker.getByProxy('p:1').inUse).toBe(true);
      tracker.setInUse('p:1', false);
      expect(tracker.getByProxy('p:1').inUse).toBe(false);
    });
  });

  describe('setPaused', () => {
    it('should toggle paused flag', () => {
      tracker.recordSuccess('p:1', 100);
      tracker.setPaused('p:1', true);
      expect(tracker.getByProxy('p:1').paused).toBe(true);
      tracker.setPaused('p:1', false);
      expect(tracker.getByProxy('p:1').paused).toBe(false);
    });

    it('should not throw on unknown proxy', () => {
      expect(() => tracker.setPaused('unknown:1', true)).not.toThrow();
    });
  });

  // --------------------------------------------------------------------------
  //  Health score
  // --------------------------------------------------------------------------
  describe('health score', () => {
    it('should start at 100 for a new proxy with only successes', () => {
      tracker.recordSuccess('p:1', 100);
      expect(tracker.getByProxy('p:1').healthScore).toBe(100);
    });

    it('should decrease with failures', () => {
      tracker.recordSuccess('p:1', 100);
      tracker.recordFailure('p:1', 'err');
      const score = tracker.getByProxy('p:1').healthScore;
      expect(score).toBeLessThan(100);
      expect(score).toBeGreaterThan(0);
    });

    it('should be very low with many failures and blocks', () => {
      for (let i = 0; i < 20; i++) {
        tracker.recordFailure('p:1', 'err');
        tracker.recordBlock('p:1', 'ban');
      }
      expect(tracker.getByProxy('p:1').healthScore).toBeLessThanOrEqual(20);
    });

    it('should never exceed 100', () => {
      for (let i = 0; i < 100; i++) {
        tracker.recordSuccess('p:1', 50);
      }
      expect(tracker.getByProxy('p:1').healthScore).toBe(100);
    });

    it('should never go below 0', () => {
      for (let i = 0; i < 100; i++) {
        tracker.recordBlock('p:1', 'ban');
      }
      expect(tracker.getByProxy('p:1').healthScore).toBeGreaterThanOrEqual(0);
    });
  });

  // --------------------------------------------------------------------------
  //  getAll / getByProxy
  // --------------------------------------------------------------------------
  describe('getAll / getByProxy', () => {
    it('getByProxy returns null for unknown proxy', () => {
      expect(tracker.getByProxy('unknown:1')).toBeNull();
    });

    it('getAll returns records for all known proxies', () => {
      tracker.recordSuccess('a:1', 100);
      tracker.recordSuccess('b:2', 200);
      tracker.recordFailure('c:3', 'err');
      expect(tracker.getAll()).toHaveLength(3);
    });

    it('getAll returns cloned objects (mutations do not affect tracker)', () => {
      tracker.recordSuccess('p:1', 100);
      const all = tracker.getAll();
      all[0].successCount = 999;
      expect(tracker.getByProxy('p:1').successCount).toBe(1);
    });
  });

  // --------------------------------------------------------------------------
  //  getStats
  // --------------------------------------------------------------------------
  describe('getStats', () => {
    it('should categorise proxies correctly', () => {
      // healthy proxy (score >= 60)
      tracker.recordSuccess('healthy:1', 100);
      // degraded proxy (score < 60)
      for (let i = 0; i < 10; i++) tracker.recordFailure('degraded:1', 'err');
      // blacklisted proxy
      tracker.recordBlacklist('blocked:1', 'ban', 600000);
      // paused proxy
      tracker.recordSuccess('paused:1', 100);
      tracker.setPaused('paused:1', true);

      const stats = tracker.getStats();
      expect(stats.total).toBe(4);
      expect(stats.healthy).toBe(1);
      expect(stats.blacklisted).toBe(1);
      expect(stats.paused).toBe(1);
    });

    it('should compute poolHealthPercent', () => {
      tracker.recordSuccess('p:1', 100);
      tracker.recordSuccess('p:2', 200);
      const stats = tracker.getStats();
      expect(stats.poolHealthPercent).toBe(100);
    });

    it('should compute avgResponseTime', () => {
      tracker.recordSuccess('p:1', 100);
      tracker.recordSuccess('p:2', 200);
      const stats = tracker.getStats();
      expect(stats.avgResponseTime).toBe(150);
    });
  });

  // --------------------------------------------------------------------------
  //  seedFromList
  // --------------------------------------------------------------------------
  describe('seedFromList', () => {
    it('should populate proxies from a list of addresses', () => {
      tracker.seedFromList(['1.2.3.4:8080', '5.6.7.8:3128']);
      const all = tracker.getAll();
      expect(all).toHaveLength(2);
      expect(all[0].successCount).toBe(0);
    });

    it('should skip entries without a colon (invalid)', () => {
      tracker.seedFromList(['invalid', '1.2.3.4:8080', '']);
      expect(tracker.getAll()).toHaveLength(1);
    });

    it('should use sanitize function when provided', () => {
      const sanitize = (line) => {
        const parts = line.split(':');
        return parts.length >= 2 ? `${parts[0]}:${parts[1]}` : null;
      };
      tracker.seedFromList(['host:8080:user:pass'], sanitize);
      expect(tracker.getAll()).toHaveLength(1);
      expect(tracker.getAll()[0].address).toBe('host:8080');
    });
  });

  // --------------------------------------------------------------------------
  //  removeProxy / clear
  // --------------------------------------------------------------------------
  describe('removeProxy / clear', () => {
    it('removeProxy should remove a single proxy', () => {
      tracker.recordSuccess('a:1', 100);
      tracker.recordSuccess('b:2', 200);
      expect(tracker.removeProxy('a:1')).toBe(true);
      expect(tracker.getAll()).toHaveLength(1);
    });

    it('removeProxy returns false for unknown proxy', () => {
      expect(tracker.removeProxy('unknown:1')).toBe(false);
    });

    it('clear should remove all proxies', () => {
      tracker.recordSuccess('a:1', 100);
      tracker.recordSuccess('b:2', 200);
      tracker.clear();
      expect(tracker.getAll()).toHaveLength(0);
    });
  });

  // --------------------------------------------------------------------------
  //  weightedSelect
  // --------------------------------------------------------------------------
  describe('weightedSelect', () => {
    it('should return null for empty candidates', () => {
      expect(tracker.weightedSelect([])).toBeNull();
      expect(tracker.weightedSelect(null)).toBeNull();
    });

    it('should return a candidate from the list', () => {
      tracker.recordSuccess('a:1', 100);
      tracker.recordSuccess('b:2', 100);
      const selected = tracker.weightedSelect(['a:1', 'b:2']);
      expect(['a:1', 'b:2']).toContain(selected);
    });

    it('should skip blacklisted proxies', () => {
      tracker.recordSuccess('good:1', 100);
      tracker.recordBlacklist('bad:1', 'ban', 600000);
      // Run 50 selections — should never return bad:1
      for (let i = 0; i < 50; i++) {
        expect(tracker.weightedSelect(['good:1', 'bad:1'])).toBe('good:1');
      }
    });

    it('should skip paused proxies', () => {
      tracker.recordSuccess('good:1', 100);
      tracker.recordSuccess('paused:1', 100);
      tracker.setPaused('paused:1', true);
      for (let i = 0; i < 50; i++) {
        expect(tracker.weightedSelect(['good:1', 'paused:1'])).toBe('good:1');
      }
    });

    it('should return null when all candidates are blacklisted', () => {
      tracker.recordBlacklist('a:1', 'ban', 600000);
      tracker.recordBlacklist('b:1', 'ban', 600000);
      expect(tracker.weightedSelect(['a:1', 'b:1'])).toBeNull();
    });

    it('should prefer healthier proxies (statistical)', () => {
      // Give good:1 many successes, bad:1 many failures
      for (let i = 0; i < 50; i++) tracker.recordSuccess('good:1', 100);
      for (let i = 0; i < 50; i++) tracker.recordFailure('bad:1', 'err');

      const counts = { 'good:1': 0, 'bad:1': 0 };
      for (let i = 0; i < 200; i++) {
        const pick = tracker.weightedSelect(['good:1', 'bad:1']);
        if (pick) counts[pick]++;
      }
      // good:1 should be selected significantly more often
      expect(counts['good:1']).toBeGreaterThan(counts['bad:1']);
    });
  });

  // --------------------------------------------------------------------------
  //  Export
  // --------------------------------------------------------------------------
  describe('export', () => {
    it('exportJson should return valid JSON', () => {
      tracker.recordSuccess('p:1', 100);
      const json = tracker.exportJson();
      const parsed = JSON.parse(json);
      expect(Array.isArray(parsed)).toBe(true);
      expect(parsed).toHaveLength(1);
    });

    it('exportCsv should return valid CSV with headers', () => {
      tracker.recordSuccess('p:1', 100);
      tracker.recordFailure('p:2', 'err');
      const csv = tracker.exportCsv();
      const lines = csv.split('\n');
      expect(lines).toHaveLength(3); // header + 2 data rows
      expect(lines[0]).toContain('address');
      expect(lines[0]).toContain('healthScore');
    });
  });

  // --------------------------------------------------------------------------
  //  Recent events ring buffer
  // --------------------------------------------------------------------------
  describe('recentEvents ring buffer', () => {
    it('should cap at MAX_EVENTS_PER_PROXY', () => {
      for (let i = 0; i < 100; i++) {
        tracker.recordSuccess('p:1', i);
      }
      const r = tracker.getByProxy('p:1');
      expect(r.recentEvents.length).toBeLessThanOrEqual(50);
    });

    it('should store event type and detail', () => {
      tracker.recordBlock('p:1', 'captcha_triggered');
      const r = tracker.getByProxy('p:1');
      expect(r.recentEvents[0].type).toBe('block');
      expect(r.recentEvents[0].detail).toBe('captcha_triggered');
      expect(r.recentEvents[0].ts).toBeGreaterThan(0);
    });
  });

  // --------------------------------------------------------------------------
  //  Persistence
  // --------------------------------------------------------------------------
  describe('persistence', () => {
    const testFile = path.join('/tmp', `proxy_health_test_${Date.now()}.json`);

    afterEach(() => {
      try { fs.unlinkSync(testFile); } catch (_) {}
    });

    it('should save and load snapshot', () => {
      const t1 = new ProxyHealthTracker({ persistFile: testFile });
      t1.recordSuccess('a:1', 100);
      t1.recordFailure('b:2', 'err');
      t1.recordBlacklist('c:3', 'ban', 600000);
      t1.saveSnapshot();
      t1.destroy();

      const t2 = new ProxyHealthTracker({ persistFile: testFile });
      const all = t2.getAll();
      expect(all).toHaveLength(3);
      const a = t2.getByProxy('a:1');
      expect(a.successCount).toBe(1);
      const b = t2.getByProxy('b:2');
      expect(b.failCount).toBe(1);
      t2.destroy();
    });

    it('should handle missing file gracefully', () => {
      const t = new ProxyHealthTracker({ persistFile: '/tmp/does_not_exist_xyz.json' });
      expect(t.getAll()).toEqual([]);
      t.destroy();
    });

    it('should handle corrupt file gracefully', () => {
      fs.writeFileSync(testFile, 'NOT JSON!!!', 'utf8');
      const t = new ProxyHealthTracker({ persistFile: testFile });
      expect(t.getAll()).toEqual([]);
      t.destroy();
    });
  });

  // --------------------------------------------------------------------------
  //  Legacy compatibility
  // --------------------------------------------------------------------------
  describe('legacy compatibility', () => {
    it('should include healthy boolean on cloned records', () => {
      tracker.recordSuccess('good:1', 100);
      expect(tracker.getByProxy('good:1').healthy).toBe(true);

      tracker.recordBlacklist('bad:1', 'ban', 600000);
      expect(tracker.getByProxy('bad:1').healthy).toBe(false);
    });

    it('should include address, successCount, failCount, blockCount for GUI compat', () => {
      tracker.recordSuccess('p:1', 100);
      tracker.recordFailure('p:1', 'err');
      tracker.recordBlock('p:1', 'ban');
      const r = tracker.getByProxy('p:1');
      expect(r).toHaveProperty('address', 'p:1');
      expect(r).toHaveProperty('successCount', 1);
      expect(r).toHaveProperty('failCount', 1);
      expect(r).toHaveProperty('blockCount', 1);
    });
  });

  // --------------------------------------------------------------------------
  //  Proxy identifier sanitisation
  // --------------------------------------------------------------------------
  describe('proxy identifier sanitisation', () => {
    it('should strip scheme from URL-style proxies', () => {
      tracker.recordSuccess('http://proxy.example.com:8080', 100);
      const all = tracker.getAll();
      expect(all).toHaveLength(1);
      expect(all[0].address).toBe('proxy.example.com:8080');
    });

    it('should strip credentials from URL-style proxies', () => {
      tracker.recordSuccess('http://user:pass@proxy.example.com:8080', 100);
      const all = tracker.getAll();
      expect(all).toHaveLength(1);
      expect(all[0].address).toBe('proxy.example.com:8080');
    });

    it('should strip credentials from host:port:user:pass format', () => {
      tracker.recordSuccess('proxy.example.com:8080:myuser:mypass', 100);
      const all = tracker.getAll();
      expect(all).toHaveLength(1);
      expect(all[0].address).toBe('proxy.example.com:8080');
    });

    it('should handle socks5:// scheme with credentials', () => {
      tracker.recordSuccess('socks5://user:pass@socks.example.com:1080', 100);
      const all = tracker.getAll();
      expect(all).toHaveLength(1);
      expect(all[0].address).toBe('socks.example.com:1080');
    });

    it('should leave simple host:port unchanged', () => {
      tracker.recordSuccess('10.0.0.1:3128', 100);
      const all = tracker.getAll();
      expect(all).toHaveLength(1);
      expect(all[0].address).toBe('10.0.0.1:3128');
    });

    it('should handle bracketed IPv6 addresses', () => {
      tracker.recordSuccess('[::1]:8080', 100);
      const all = tracker.getAll();
      expect(all).toHaveLength(1);
      expect(all[0].address).toBe('[::1]:8080');
    });

    it('should strip path/query/fragment from proxy URLs', () => {
      tracker.recordSuccess('http://proxy.example.com:8080/path?q=1#frag', 100);
      const all = tracker.getAll();
      expect(all).toHaveLength(1);
      expect(all[0].address).toBe('proxy.example.com:8080');
    });

    it('should coalesce records for the same sanitised proxy', () => {
      tracker.recordSuccess('http://user1:pass1@proxy.example.com:8080', 100);
      tracker.recordSuccess('http://user2:pass2@proxy.example.com:8080', 200);
      const all = tracker.getAll();
      expect(all).toHaveLength(1);
      expect(all[0].address).toBe('proxy.example.com:8080');
      expect(all[0].successCount).toBe(2);
    });
  });

  // --------------------------------------------------------------------------
  //  mergeFromSnapshot
  // --------------------------------------------------------------------------
  describe('mergeFromSnapshot', () => {
    it('should merge counters taking the higher value', () => {
      tracker.recordSuccess('p:1', 100);
      tracker.mergeFromSnapshot([{
        address: 'p:1',
        successCount: 5,
        failCount: 3,
        blockCount: 1,
        tcpFailCount: 0,
        blacklistCount: 0,
        consecutiveFailures: 0,
        lifetimeRotations: 0
      }]);
      const r = tracker.getByProxy('p:1');
      expect(r.successCount).toBe(5);
      expect(r.failCount).toBe(3);
    });

    it('should merge timestamps from snapshot', () => {
      const now = Date.now();
      tracker.mergeFromSnapshot([{
        address: 'p:1',
        successCount: 0,
        failCount: 0,
        blockCount: 0,
        tcpFailCount: 0,
        lastSuccess: now + 1000,
        lastFailure: now + 2000,
        lastSeen: now + 5000
      }]);
      const r = tracker.getByProxy('p:1');
      expect(r.lastSuccess).toBe(now + 1000);
      expect(r.lastFailure).toBe(now + 2000);
    });

    it('should skip entries without address', () => {
      expect(() => tracker.mergeFromSnapshot([{ noAddr: true }, { address: 'p:1', successCount: 1 }])).not.toThrow();
      expect(tracker.getAll()).toHaveLength(1);
    });

    it('should handle non-array input gracefully', () => {
      expect(() => tracker.mergeFromSnapshot(null)).not.toThrow();
      expect(() => tracker.mergeFromSnapshot('string')).not.toThrow();
      expect(() => tracker.mergeFromSnapshot(42)).not.toThrow();
    });
  });
});
