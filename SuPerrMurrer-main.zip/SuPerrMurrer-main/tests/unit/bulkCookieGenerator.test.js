'use strict';

/**
 * Unit tests for BulkCookieGenerator._captureOne()
 *
 * Tests cover:
 *  - Successful cookie capture (happy path)
 *  - Context close + tmpdir removal on success
 *  - Context close + tmpdir removal when navigation fails
 *  - Context close + tmpdir removal when context.close() throws
 *  - Warning logged when tmpdir removal fails
 *  - Reuse of default page from context.pages()
 *  - New page created when context.pages() is empty
 *  - --proxy-server arg is filtered from launch args
 */

const fs   = require('fs');
const os   = require('os');
const path = require('path');

// ── shared test data ──────────────────────────────────────────────────────────

const FAKE_USER_DIR = path.join(os.tmpdir(), 'superrmurrer-bcg-test-0000');

const RAW_COOKIES = [
  { name: 'session', value: 'abc123', domain: '.example.com', path: '/', secure: true, httpOnly: true, sameSite: 'Strict' }
];

// ── helpers ───────────────────────────────────────────────────────────────────

/**
 * Build a minimal page mock.
 * @param {{ navError?: Error }} opts
 */
function makePage({ navError } = {}) {
  return {
    setDefaultTimeout: jest.fn(),
    goto:              navError
      ? jest.fn().mockRejectedValue(navError)
      : jest.fn().mockResolvedValue(undefined),
    click:             jest.fn().mockResolvedValue(undefined),
    press:             jest.fn().mockResolvedValue(undefined),
    waitForTimeout:    jest.fn().mockResolvedValue(undefined)
  };
}

/**
 * Build a minimal context mock.
 * @param {{ cookies?: object[], navError?: Error }} opts
 */
function makeContext({ cookies = RAW_COOKIES, navError } = {}) {
  const page = makePage({ navError });
  const ctx = {
    pages:   jest.fn().mockReturnValue([page]),
    cookies: jest.fn().mockResolvedValue(cookies),
    close:   jest.fn().mockResolvedValue(undefined),
    _page:   page                // expose for assertions
  };
  return ctx;
}

/**
 * Load a fresh copy of BulkCookieGenerator with the given persistent-context mock.
 * Must be called after jest.resetModules() is in effect.
 */
function loadBCG(mockContext) {
  jest.doMock('patchright', () => ({
    chromium: {
      launchPersistentContext: jest.fn().mockResolvedValue(mockContext)
    }
  }), { virtual: true });
  jest.doMock('../../formFill', () => ({ fastFill: jest.fn().mockResolvedValue(true) }));
  jest.doMock('../../config', () => ({
    browser: {
      args: ['--proxy-server=http://proxy:3128', '--disable-dev-shm-usage'],
      ignoreDefaultArgs: ['--enable-automation']
    },
    login: {
      url:              'https://login.example.com/',
      usernameSelector: '#username',
      passwordSelector: '#password',
      onetrust:         '#onetrust-accept-btn-handler'
    },
    bulkCookieGenerator: {
      defaultAmount:        100,
      maxConcurrency:       5,
      outputDir:            'CookieExports',
      headless:             false,
      delayBetweenCaptures: 0,
      navigationTimeout:    5000
    }
  }));
  return require('../../utils/bulkCookieGenerator');
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe('BulkCookieGenerator._captureOne()', () => {
  let fsSpy;
  let mkdtempSpy;

  beforeEach(() => {
    jest.resetModules();

    mkdtempSpy = jest.spyOn(fs, 'mkdtempSync').mockReturnValue(FAKE_USER_DIR);
    fsSpy      = jest.spyOn(fs, 'rmSync').mockReturnValue(undefined);

    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'warn').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
    jest.spyOn(process.stderr, 'write').mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('returns cookies on successful capture', async () => {
    const ctx = makeContext({ cookies: RAW_COOKIES });
    const BulkCookieGenerator = loadBCG(ctx);
    const gen = new BulkCookieGenerator({ amount: 1 });

    const result = await gen._captureOne(0);

    expect(result.index).toBe(0);
    expect(typeof result.capturedAt).toBe('string');
    expect(result.cookies).toHaveLength(1);
    expect(result.cookies[0].name).toBe('session');
    expect(result.cookies[0].value).toBe('abc123');
    expect(result.cookies[0].secure).toBe(true);
  });

  it('normalises missing cookie fields with defaults', async () => {
    const ctx = makeContext({ cookies: [{ name: 'tok', value: '1' }] });
    const BulkCookieGenerator = loadBCG(ctx);
    const gen = new BulkCookieGenerator({ amount: 1 });

    const result = await gen._captureOne(0);
    const c = result.cookies[0];
    expect(c.domain).toBe('');
    expect(c.path).toBe('/');
    expect(c.secure).toBe(false);
    expect(c.httpOnly).toBe(false);
    expect(c.sameSite).toBe('Lax');
  });

  it('closes context and removes tmpdir on success', async () => {
    const ctx = makeContext();
    const BulkCookieGenerator = loadBCG(ctx);
    const gen = new BulkCookieGenerator({ amount: 1 });

    await gen._captureOne(0);

    expect(ctx.close).toHaveBeenCalledTimes(1);
    expect(fsSpy).toHaveBeenCalledWith(FAKE_USER_DIR, { recursive: true, force: true });
  });

  it('closes context and removes tmpdir when navigation fails', async () => {
    const navError = new Error('net::ERR_NAME_NOT_RESOLVED');
    const ctx = makeContext({ navError });
    const BulkCookieGenerator = loadBCG(ctx);
    const gen = new BulkCookieGenerator({ amount: 1 });

    await expect(gen._captureOne(0)).rejects.toThrow('ERR_NAME_NOT_RESOLVED');

    expect(ctx.close).toHaveBeenCalledTimes(1);
    expect(fsSpy).toHaveBeenCalledWith(FAKE_USER_DIR, { recursive: true, force: true });
  });

  it('removes tmpdir even when context.close() throws', async () => {
    const ctx = makeContext();
    ctx.close.mockRejectedValue(new Error('close failed'));
    const BulkCookieGenerator = loadBCG(ctx);
    const gen = new BulkCookieGenerator({ amount: 1 });

    // close error is swallowed by .catch(() => {}) in the implementation
    const result = await gen._captureOne(0);
    expect(result.cookies).toHaveLength(1);
    expect(fsSpy).toHaveBeenCalledWith(FAKE_USER_DIR, { recursive: true, force: true });
  });

  it('logs a warning to stderr when tmpdir removal fails', async () => {
    const ctx = makeContext();
    fsSpy.mockImplementationOnce(() => { throw new Error('EBUSY: resource busy'); });
    const BulkCookieGenerator = loadBCG(ctx);
    const gen = new BulkCookieGenerator({ amount: 1 });

    await gen._captureOne(0);

    expect(process.stderr.write).toHaveBeenCalledWith(
      expect.stringContaining('Failed to remove tmpdir')
    );
  });

  it('reuses the default page from context.pages()', async () => {
    const ctx = makeContext();
    const BulkCookieGenerator = loadBCG(ctx);
    const gen = new BulkCookieGenerator({ amount: 1 });

    await gen._captureOne(0);

    expect(ctx.pages).toHaveBeenCalled();
    expect(ctx._page.goto).toHaveBeenCalledWith(
      expect.stringContaining('login.example.com'),
      expect.objectContaining({ waitUntil: 'domcontentloaded' })
    );
  });

  it('creates a new page when context.pages() returns empty', async () => {
    const ctx = makeContext();
    const newPage = makePage();
    ctx.pages.mockReturnValue([]);
    ctx.newPage = jest.fn().mockResolvedValue(newPage);

    const BulkCookieGenerator = loadBCG(ctx);
    const gen = new BulkCookieGenerator({ amount: 1 });

    await gen._captureOne(0);

    expect(ctx.newPage).toHaveBeenCalled();
    expect(newPage.goto).toHaveBeenCalled();
  });

  it('filters out --proxy-server arg from browser launch args', async () => {
    const ctx = makeContext();
    const BulkCookieGenerator = loadBCG(ctx);
    // Reach into the patchright mock to verify launch args
    const patchright = require('patchright');
    const gen = new BulkCookieGenerator({ amount: 1 });

    await gen._captureOne(0);

    const [, launchOpts] = patchright.chromium.launchPersistentContext.mock.calls[0];
    expect(launchOpts.args).not.toContain('--proxy-server=http://proxy:3128');
    expect(launchOpts.args).toContain('--disable-dev-shm-usage');
  });

  it('passes viewport:null, channel:"chrome" to launchPersistentContext', async () => {
    const ctx = makeContext();
    const BulkCookieGenerator = loadBCG(ctx);
    const patchright = require('patchright');
    const gen = new BulkCookieGenerator({ amount: 1 });

    await gen._captureOne(0);

    const [userDataDir, launchOpts] = patchright.chromium.launchPersistentContext.mock.calls[0];
    expect(userDataDir).toBe(FAKE_USER_DIR);
    expect(launchOpts.viewport).toBeNull();
    expect(launchOpts.channel).toBe('chrome');
  });
});

