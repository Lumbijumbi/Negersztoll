'use strict';

/**
 * guiServer2.test.js - Additional coverage for gui/server.js
 *
 * Uses jest.resetModules() in beforeEach so every test starts with a fresh
 * server module instance (controllerProcess = null), making controller
 * start/stop assertions fully deterministic.
 */

// ── Mock factories (hoisted by Jest) ─────────────────────────────────────────

// Mock fs with complete API including lstatSync (required by collectBackupData)
jest.mock('fs', () => {
  const stat = {
    isFile: () => true,
    isDirectory: () => false,
    isSymbolicLink: () => false,
    size: 100
  };
  return {
    existsSync: jest.fn().mockReturnValue(false), // default: no files present
    readFileSync: jest.fn().mockReturnValue('user1:pass1\nuser2:pass2\n'),
    writeFileSync: jest.fn(),
    unlinkSync: jest.fn(),
    mkdirSync: jest.fn(),
    readdirSync: jest.fn().mockReturnValue([]),
    statSync: jest.fn().mockReturnValue(stat),
    lstatSync: jest.fn().mockReturnValue(stat),
    stat: jest.fn((path, cb) => cb({ code: 'ENOENT' })),
    promises: {
      mkdir: jest.fn().mockResolvedValue(undefined),
      writeFile: jest.fn().mockResolvedValue(undefined),
      readFile: jest.fn().mockResolvedValue('content'),
      gzip: jest.fn().mockResolvedValue(Buffer.from('compressed')),
      gunzip: jest.fn()
    }
  };
});

// Provide zlib.promises.gzip/gunzip (undefined in Node.js v24 in this environment)
jest.mock('zlib', () => {
  const actualZlib = jest.requireActual('zlib');
  return {
    ...actualZlib,
    promises: {
      gzip: jest.fn().mockImplementation(data =>
        Promise.resolve(actualZlib.gzipSync(Buffer.isBuffer(data) ? data : Buffer.from(data)))
      ),
      gunzip: jest.fn().mockImplementation(data =>
        Promise.resolve(actualZlib.gunzipSync(Buffer.isBuffer(data) ? data : Buffer.from(data)))
      )
    }
  };
});

const request = require('supertest');
const { gzipSync } = jest.requireActual('zlib');

// Mock child_process – spawn factory returns a fresh process per call
jest.mock('child_process', () => ({
  spawn: jest.fn()
}));

// Mock os
jest.mock('os', () => ({
  platform: jest.fn().mockReturnValue('linux'),
  arch: jest.fn().mockReturnValue('x64'),
  cpus: jest.fn().mockReturnValue([{ model: 'Test CPU', speed: 2400 }]),
  totalmem: jest.fn().mockReturnValue(8 * 1024 * 1024 * 1024),
  freemem: jest.fn().mockReturnValue(4 * 1024 * 1024 * 1024),
  uptime: jest.fn().mockReturnValue(3600),
  hostname: jest.fn().mockReturnValue('test-host'),
  loadavg: jest.fn().mockReturnValue([0.5, 0.3, 0.2]),
  tmpdir: jest.fn().mockReturnValue('/tmp')
}));

// Mock config
jest.mock('../../config', () => ({
  browser: { headless: true },
  proxy: { enabled: false },
  proxyFile: 'Lightning_Proxies.txt',
  batch: { maxParallelWorkers: 5, credentialsPerProxy: 10 },
  history: { enabled: true, historyFile: 'test_history.jsonl' },
  queue: { enabled: true, queueFile: 'test_queue.jsonl', defaultPriority: 3 },
  retry: { maxRetries: 3 },
  errorRecovery: { maxRetries: 3 },
  cookieExport: { exportDir: 'CookieExports' },
  login: { url: 'https://login.supercard.ch/', usernameSelector: '#username', passwordSelector: '#password', onetrust: '#onetrust-accept-btn-handler' },
  bulkCookieGenerator: { defaultAmount: 100, allowedAmounts: [100, 500, 1000, 2000], maxConcurrency: 5, outputDir: 'CookieExports', headless: false }
}));

// Mock CredentialHistory
const mockCredentialHistory = {
  history: new Map(),
  _key: (u, p) => `${u}\t${p}`,
  load: jest.fn(),
  reload: jest.fn(),
  getAll: jest.fn(),
  getByStatus: jest.fn(),
  getStats: jest.fn(),
  compact: jest.fn(),
  deleteEntry: jest.fn().mockReturnValue(true),
  record: jest.fn(),
  add: jest.fn()
};
jest.mock('../../utils/credentialHistory', () => jest.fn().mockImplementation(() => mockCredentialHistory));

// Mock ComboQueue
const mockComboQueue = {
  combos: new Map([
    ['user1\tpass1', { username: 'user1', password: 'pass1', priority: 3 }]
  ]),
  getStats: jest.fn(),
  getFiles: jest.fn(),
  addCombos: jest.fn(),
  shuffle: jest.fn(),
  setPriority: jest.fn().mockReturnValue(true),
  removeFile: jest.fn().mockReturnValue(true),
  clearCompleted: jest.fn().mockReturnValue(5),
  pause: jest.fn(),
  resume: jest.fn()
};
jest.mock('../../utils/comboQueue', () => jest.fn().mockImplementation(() => mockComboQueue));

// Mock UsedEntries
const mockUsedEntries = {
  getAll: jest.fn().mockReturnValue([]),
  markUsed: jest.fn().mockImplementation((username, password, details = {}) => ({
    u: username, p: password, s: details.status || '', m: details.method || null,
    pts: details.pointsBalance || null, chf: details.moneyBalance || null,
    usedAt: '2024-01-01T00:00:00.000Z', notes: details.notes || ''
  })),
  unmarkUsed: jest.fn().mockReturnValue(true),
  updateNote: jest.fn().mockReturnValue(true),
  isUsed: jest.fn().mockReturnValue(false)
};
jest.mock('../../utils/usedEntries', () => jest.fn().mockImplementation(() => mockUsedEntries));

// Mock CookieExporter
const mockCookieExporter = {
  exportDir: '/fake/CookieExports',
  listExports: jest.fn(),
  readExport: jest.fn(),
  capture: jest.fn().mockResolvedValue('/path/to/export.json')
};
jest.mock('../../utils/cookieExporter', () => jest.fn().mockImplementation(() => mockCookieExporter));

// Mock BulkCookieGenerator
const EventEmitter = require('events');
class MockBulkCookieGenerator extends EventEmitter {
  constructor() { super(); }
  generate() { return Promise.resolve({ outputPath: '/fake/CookieExports/bulk_cookies.json', totalSets: 100, successful: 100, failed: 0 }); }
}
let mockBulkGeneratorFactory;
jest.mock('../../utils/bulkCookieGenerator', () => {
  mockBulkGeneratorFactory = jest.fn().mockImplementation(() => new MockBulkCookieGenerator());
  return mockBulkGeneratorFactory;
});

// Mock configProfiles
const mockConfigProfiles = {
  applyProfile: jest.fn((cfg, profileName) => ({
    ...cfg,
    activeProfile: profileName,
    browser: { timeout: 120000 }
  })),
  getProfile: jest.fn(name => (name === 'balanced' ? { browser: { timeout: 120000 } } : null))
};
jest.mock('../../utils/configProfiles', () => mockConfigProfiles);


let app;

/** Build a fresh mock spawn process for each test */
function makeMockSpawn() {
  return {
    pid: 12345,
    killed: false,
    startTime: Date.now(),
    kill: jest.fn(),
    once: jest.fn().mockReturnThis(),
    on: jest.fn().mockReturnThis(),
    stdout: { on: jest.fn().mockReturnThis() },
    stderr: { on: jest.fn().mockReturnThis() }
  };
}

describe('GUI Server - Additional Coverage (guiServer2)', () => {
  let mockFs;
  let mockSpawn;

  beforeEach(() => {
    // Fresh module registry → fresh server module → controllerProcess = null
    jest.resetModules();

    // Re-acquire mock instances created by the factories above
    mockFs = require('fs');
    const { spawn } = require('child_process');
    mockSpawn = spawn;

    // Restore default return values (clearAllMocks wiped these)
    mockSpawn.mockReturnValue(makeMockSpawn());
    mockFs.existsSync.mockReturnValue(false);
    mockFs.readdirSync.mockReturnValue([]);
    mockFs.promises.mkdir.mockResolvedValue(undefined);
    mockFs.promises.writeFile.mockResolvedValue(undefined);

    // Re-setup os mocks
    const os = require('os');
    os.platform.mockReturnValue('linux');
    os.arch.mockReturnValue('x64');
    os.cpus.mockReturnValue([{ model: 'Test CPU', speed: 2400 }]);
    os.totalmem.mockReturnValue(8 * 1024 * 1024 * 1024);
    os.freemem.mockReturnValue(4 * 1024 * 1024 * 1024);
    os.uptime.mockReturnValue(3600);

    // Re-setup shared mock return values
    mockCredentialHistory.history = new Map();
    mockCredentialHistory.load.mockReset();
    mockCredentialHistory.record.mockReset();
    mockCredentialHistory.getByStatus.mockReturnValue([
      { username: 'user1', password: 'pass1', status: 'success' }
    ]);
    mockCredentialHistory.getAll.mockReturnValue([
      { username: 'user1', password: 'pass1', status: 'success', timestamp: '2024-01-01T00:00:00.000Z' },
      { username: 'user2', password: 'pass2', status: 'failed', timestamp: '2024-01-02T00:00:00.000Z' }
    ]);
    mockCredentialHistory.getStats.mockReturnValue({ total: 2, success: 1, failed: 1, blocked: 0, captcha: 0, other: 0 });
    mockCredentialHistory.compact.mockReset();

    mockComboQueue.getStats.mockReturnValue({ total: 100, pending: 50, completed: 30, failed: 20 });
    mockComboQueue.getFiles.mockReturnValue([{ filename: 'test.txt', priority: 3, status: 'pending' }]);
    mockComboQueue.addCombos.mockReturnValue({ added: 5, duplicatesRemoved: 0, alreadyProcessed: 0, queued: 5 });

    mockCookieExporter.listExports.mockReturnValue([
      { filename: 'user_2024.json', capturedAt: '2024-01-01T00:00:00Z', username: 'user1', size: 500 }
    ]);
    mockCookieExporter.readExport.mockReturnValue({ capturedAt: '2024-01-01', username: 'user1', cookies: [], headers: {} });

    // Re-setup configProfiles mocks
    mockConfigProfiles.getProfile.mockImplementation(name =>
      name === 'balanced' ? { browser: { timeout: 120000 } } : null
    );
    mockConfigProfiles.applyProfile.mockImplementation((cfg, profileName) => ({
      ...cfg,
      activeProfile: profileName,
      browser: { timeout: 120000 }
    }));

    // Re-setup used entries mock
    mockUsedEntries.getAll.mockReturnValue([]);
    mockUsedEntries.markUsed.mockImplementation((username, password, details = {}) => ({
      u: username, p: password, s: details.status || '', m: details.method || null,
      pts: details.pointsBalance || null, chf: details.moneyBalance || null,
      usedAt: '2024-01-01T00:00:00.000Z', notes: details.notes || ''
    }));
    mockUsedEntries.unmarkUsed.mockReturnValue(true);
    mockUsedEntries.updateNote.mockReturnValue(true);

    // Suppress console noise
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
    jest.spyOn(console, 'warn').mockImplementation(() => {});

    // Load a fresh server after all mocks are in place
    app = require('../../gui/server');
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  // ── GET /api/status ──────────────────────────────────────────────────────────
  describe('GET /api/status', () => {
    it('should return 200 with controller not running and system info on fresh start', async () => {
      const res = await request(app).get('/api/status');
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('controller');
      expect(res.body).toHaveProperty('system');
      expect(res.body.controller.running).toBe(false);
      expect(res.body.controller.pid).toBeNull();
    });
  });

  // ── GET /api/logs ─────────────────────────────────────────────────────────────
  describe('GET /api/logs', () => {
    it('should return empty logs initially', async () => {
      const res = await request(app).get('/api/logs');
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('logs');
      expect(Array.isArray(res.body.logs)).toBe(true);
    });

    it('should accept cursor parameter', async () => {
      const res = await request(app).get('/api/logs?cursor=0&limit=10');
      expect(res.status).toBe(200);
    });

    it('should accept since parameter (legacy)', async () => {
      const res = await request(app).get('/api/logs?since=0');
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('offset');
    });
  });

  // ── GET /api/history ──────────────────────────────────────────────────────────
  describe('GET /api/history', () => {
    it('should return history entries', async () => {
      const res = await request(app).get('/api/history');
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('entries');
    });

    it('should support filtering by status', async () => {
      const res = await request(app).get('/api/history?status=success');
      expect(res.status).toBe(200);
    });

    it('should support search query', async () => {
      const res = await request(app).get('/api/history?search=user1');
      expect(res.status).toBe(200);
    });

    it('should support pagination', async () => {
      const res = await request(app).get('/api/history?page=1&limit=10');
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('page');
    });

    it('should support sorting', async () => {
      const res = await request(app).get('/api/history?sort=date_asc');
      expect(res.status).toBe(200);
    });
  });

  // ── GET /api/history/stats ────────────────────────────────────────────────────
  describe('GET /api/history/stats', () => {
    it('should return 200 with stats containing total', async () => {
      const res = await request(app).get('/api/history/stats');
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('total');
    });
  });

  // ── POST /api/history/compact ─────────────────────────────────────────────────
  describe('POST /api/history/compact', () => {
    it('should return 200 and call compact()', async () => {
      const res = await request(app).post('/api/history/compact');
      expect(res.status).toBe(200);
      expect(mockCredentialHistory.compact).toHaveBeenCalled();
    });
  });

  // ── GET /api/controller/status ────────────────────────────────────────────────
  describe('GET /api/controller/status', () => {
    it('should return 200 with running:false when no controller started', async () => {
      const res = await request(app).get('/api/controller/status');
      expect(res.status).toBe(200);
      expect(res.body.running).toBe(false);
    });
  });

  // ── POST /api/controller/start ────────────────────────────────────────────────
  describe('POST /api/controller/start', () => {
    it('should return 200 with success:true when controller is not running', async () => {
      // Fresh module → controllerProcess is null → spawn → 200
      const res = await request(app).post('/api/controller/start');
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body).toHaveProperty('pid');
    });

    it('should return 400 when controller is already running', async () => {
      await request(app).post('/api/controller/start');
      const res = await request(app).post('/api/controller/start');
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/already running/i);
    });
  });

  // ── POST /api/controller/stop ─────────────────────────────────────────────────
  describe('POST /api/controller/stop', () => {
    it('should return 400 when controller is not running', async () => {
      // Fresh module → controllerProcess is null → 400
      const res = await request(app).post('/api/controller/stop');
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/not running/i);
    });

    it('should return 200 with success:true when stopping a running controller', async () => {
      await request(app).post('/api/controller/start');
      const res = await request(app).post('/api/controller/stop');
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
    });
  });

  // ── POST /api/controller/restart ──────────────────────────────────────────────
  describe('POST /api/controller/restart', () => {
    it('should return success on restart attempt', async () => {
      const res = await request(app).post('/api/controller/restart');
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
    });
  });

  // ── POST /api/start (legacy) ──────────────────────────────────────────────────
  describe('POST /api/start (legacy)', () => {
    it('should return 200 with success:true when controller is not running', async () => {
      const res = await request(app).post('/api/start');
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
    });

    it('should return 400 when controller is already running', async () => {
      await request(app).post('/api/start');
      const res = await request(app).post('/api/start');
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/already running/i);
    });
  });

  // ── POST /api/stop (legacy) ───────────────────────────────────────────────────
  describe('POST /api/stop (legacy)', () => {
    it('should return 400 when controller is not running', async () => {
      const res = await request(app).post('/api/stop');
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/not running/i);
    });

    it('should return 200 with success:true when stopping a running controller', async () => {
      await request(app).post('/api/start');
      const res = await request(app).post('/api/stop');
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
    });
  });

  // ── GET /api/backup/create ────────────────────────────────────────────────────
  describe('GET /api/backup/create', () => {
    it('should return 200 with gzip content-type when backup files are absent', async () => {
      // existsSync returns false (default) → collectBackupData returns {} → gzip succeeds
      const res = await request(app).get('/api/backup/create');
      expect(res.status).toBe(200);
      expect(res.headers['content-type']).toContain('gzip');
    });
  });

  // ── POST /api/backup/restore ──────────────────────────────────────────────────
  describe('POST /api/backup/restore', () => {
    it('should return 400 when no data provided', async () => {
      const res = await request(app).post('/api/backup/restore').send({});
      expect(res.status).toBe(400);
      expect(res.body.error).toContain('No backup data');
    });

    it('should return 400 when invalid gzip data', async () => {
      const res = await request(app).post('/api/backup/restore').send({ data: 'bm90dmFsaWQ=' });
      expect(res.status).toBe(400);
    });

    it('should return 200 and restore files from a valid backup', async () => {
      const manifest = { created: new Date().toISOString(), files: { 'test.txt': 'content' } };
      const compressed = gzipSync(JSON.stringify(manifest));
      const res = await request(app).post('/api/backup/restore').send({ data: compressed.toString('base64') });
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(Array.isArray(res.body.restored)).toBe(true);
    });
  });

  // ── GET /api/cookie-exports ───────────────────────────────────────────────────
  describe('GET /api/cookie-exports', () => {
    it('should return list of cookie exports', async () => {
      const res = await request(app).get('/api/cookie-exports');
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('exports');
      expect(Array.isArray(res.body.exports)).toBe(true);
    });
  });

  // ── GET /api/cookie-exports/:filename ─────────────────────────────────────────
  describe('GET /api/cookie-exports/:filename', () => {
    it('should return cookie export data', async () => {
      const res = await request(app).get('/api/cookie-exports/user_2024.json');
      expect(res.status).toBe(200);
    });

    it('should return 404 when export not found', async () => {
      mockCookieExporter.readExport.mockReturnValueOnce(null);
      const res = await request(app).get('/api/cookie-exports/nonexistent.json');
      expect(res.status).toBe(404);
    });
  });

  // ── DELETE /api/cookie-exports/:filename ──────────────────────────────────────
  describe('DELETE /api/cookie-exports/:filename', () => {
    it('should delete export file when it exists and return 200', async () => {
      mockFs.existsSync.mockReturnValueOnce(true);
      const res = await request(app).delete('/api/cookie-exports/user_2024.json');
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
    });

    it('should return 404 when file does not exist', async () => {
      mockFs.existsSync.mockReturnValueOnce(false);
      const res = await request(app).delete('/api/cookie-exports/nonexistent.json');
      expect(res.status).toBe(404);
    });
  });

  // ── GET /api/system ───────────────────────────────────────────────────────────
  describe('GET /api/system', () => {
    it('should return 200 with platform, cpuCount, and memory fields', async () => {
      const res = await request(app).get('/api/system');
      expect(res.status).toBe(200);
      expect(res.body.platform).toBe('linux');
      expect(res.body.cpuCount).toBe(1);
      expect(res.body).toHaveProperty('totalMemoryMB');
      expect(res.body).toHaveProperty('freeMemoryMB');
    });
  });

  // ── GET /api/history/used ────────────────────────────────────────────────────
  describe('GET /api/history/used', () => {
    it('should return 200 with empty entries array', async () => {
      const res = await request(app).get('/api/history/used');
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('entries');
      expect(Array.isArray(res.body.entries)).toBe(true);
    });

    it('should return used entries when they exist', async () => {
      mockUsedEntries.getAll.mockReturnValueOnce([
        { username: 'user1', password: 'pass1', status: 'success', method: null,
          pointsBalance: null, moneyBalance: null, usedAt: '2024-01-01T00:00:00.000Z', notes: 'test note' }
      ]);
      const res = await request(app).get('/api/history/used');
      expect(res.status).toBe(200);
      expect(res.body.entries).toHaveLength(1);
      expect(res.body.entries[0].username).toBe('user1');
      expect(res.body.entries[0].notes).toBe('test note');
    });
  });

  // ── POST /api/history/mark-used ──────────────────────────────────────────────
  describe('POST /api/history/mark-used', () => {
    it('should return 200 and mark entry as used', async () => {
      const res = await request(app)
        .post('/api/history/mark-used')
        .send({ username: 'user1', password: 'pass1', status: 'success' });
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body).toHaveProperty('entry');
      expect(mockUsedEntries.markUsed).toHaveBeenCalledWith(
        'user1', 'pass1', expect.objectContaining({ status: 'success' })
      );
    });

    it('should return 400 when username is missing', async () => {
      const res = await request(app)
        .post('/api/history/mark-used')
        .send({ password: 'pass1' });
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/username and password are required/i);
    });

    it('should return 400 when password is missing', async () => {
      const res = await request(app)
        .post('/api/history/mark-used')
        .send({ username: 'user1' });
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/username and password are required/i);
    });
  });

  // ── POST /api/history/unmark-used ────────────────────────────────────────────
  describe('POST /api/history/unmark-used', () => {
    it('should return 200 and unmark entry', async () => {
      const res = await request(app)
        .post('/api/history/unmark-used')
        .send({ username: 'user1', password: 'pass1' });
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body).toHaveProperty('existed');
      expect(mockUsedEntries.unmarkUsed).toHaveBeenCalledWith('user1', 'pass1');
    });

    it('should return 400 when username is missing', async () => {
      const res = await request(app)
        .post('/api/history/unmark-used')
        .send({ password: 'pass1' });
      expect(res.status).toBe(400);
    });
  });

  // ── PUT /api/history/update-note ─────────────────────────────────────────────
  describe('PUT /api/history/update-note', () => {
    it('should return 200 and update note', async () => {
      const res = await request(app)
        .put('/api/history/update-note')
        .send({ username: 'user1', password: 'pass1', notes: 'my note' });
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(mockUsedEntries.updateNote).toHaveBeenCalledWith('user1', 'pass1', 'my note');
    });

    it('should return 404 when entry not found', async () => {
      mockUsedEntries.updateNote.mockReturnValueOnce(false);
      const res = await request(app)
        .put('/api/history/update-note')
        .send({ username: 'unknown', password: 'nope', notes: 'note' });
      expect(res.status).toBe(404);
      expect(res.body.error).toMatch(/not found/i);
    });

    it('should return 400 when notes is missing', async () => {
      const res = await request(app)
        .put('/api/history/update-note')
        .send({ username: 'user1', password: 'pass1' });
      expect(res.status).toBe(400);
    });

    it('should return 400 when username is missing', async () => {
      const res = await request(app)
        .put('/api/history/update-note')
        .send({ password: 'pass1', notes: 'note' });
      expect(res.status).toBe(400);
    });
  });

  // ── POST /api/history/import (JSONL rich data) ────────────────────────────────
  describe('POST /api/history/import (jsonl rich data)', () => {
    it('should preserve method, confidence, reason when importing jsonl', async () => {
      mockCredentialHistory.history = new Map();
      const line = JSON.stringify({ u: 'u1', p: 'p1', s: 'success', m: 'cookie', c: 0.95, t: '2024-01-01T00:00:00.000Z' });
      const res = await request(app)
        .post('/api/history/import')
        .send({ content: line, format: 'jsonl', mode: 'merge' })
        .expect(200);
      expect(res.body.success).toBe(true);
      expect(res.body.imported).toBe(1);
      expect(mockCredentialHistory.record).toHaveBeenCalledWith('u1', 'p1', 'success', expect.objectContaining({ method: 'cookie', confidence: 0.95 }));
    });

    it('should support username/password keys in jsonl', async () => {
      mockCredentialHistory.history = new Map();
      const line = JSON.stringify({ username: 'u2', password: 'p2', status: 'failed', reason: 'wrong' });
      const res = await request(app)
        .post('/api/history/import')
        .send({ content: line, format: 'jsonl', mode: 'merge' })
        .expect(200);
      expect(res.body.success).toBe(true);
      expect(res.body.imported).toBe(1);
    });
  });

  // ── POST /api/history/import-logs ─────────────────────────────────────────────
  describe('POST /api/history/import-logs', () => {
    const dirStat = { isFile: () => false, isDirectory: () => true, isSymbolicLink: () => false, size: 0 };

    it('should return 400 when logs directory does not exist', async () => {
      mockFs.existsSync.mockReturnValue(false);
      const res = await request(app)
        .post('/api/history/import-logs')
        .send({ logsDir: '/nonexistent/path' })
        .expect(400);
      expect(res.body.error).toMatch(/not found/i);
    });

    it('should return 400 when logsDir is not a string', async () => {
      const res = await request(app)
        .post('/api/history/import-logs')
        .send({ logsDir: 12345 })
        .expect(400);
      expect(res.body.error).toMatch(/must be a string/i);
    });

    it('should return 400 when logsDir contains null bytes', async () => {
      const res = await request(app)
        .post('/api/history/import-logs')
        .send({ logsDir: '/tmp/logs\x00/evil' })
        .expect(400);
      expect(res.body.error).toMatch(/invalid characters/i);
    });

    it('should return 400 when path is not a directory', async () => {
      mockFs.existsSync.mockReturnValue(true);
      // default statSync returns isDirectory: false
      const res = await request(app)
        .post('/api/history/import-logs')
        .send({ logsDir: '/some/file.txt' })
        .expect(400);
      expect(res.body.error).toMatch(/not a directory/i);
    });

    it('should return 403 when directory is not accessible', async () => {
      mockFs.existsSync.mockReturnValue(true);
      const permErr = new Error('EACCES: permission denied');
      permErr.code = 'EACCES';
      mockFs.statSync.mockImplementation(() => { throw permErr; });
      const res = await request(app)
        .post('/api/history/import-logs')
        .send({ logsDir: '/restricted/logs' })
        .expect(403);
      expect(res.body.error).toMatch(/cannot access/i);
    });

    it('should scan subdirs and import entries', async () => {
      mockCredentialHistory.history = new Map();
      const entry = JSON.stringify({ username: 'user1', password: 'pass1', method: 'cookie', confidence: 0.9 });

      mockFs.existsSync.mockImplementation(p => {
        // logs dir exists, successful subdir exists, others don't
        if (p && (p.endsWith('/logs') || p.endsWith('\\logs') || p === '/fake/logs')) return true;
        if (p && (p.includes('successful'))) return true;
        return false;
      });
      mockFs.statSync.mockReturnValue(dirStat);
      mockFs.readdirSync.mockImplementation(p => {
        if (p && p.includes('successful')) return ['successes_2024-01-01.jsonl'];
        return [];
      });
      mockFs.readFileSync.mockReturnValue(entry + '\n');

      const res = await request(app)
        .post('/api/history/import-logs')
        .send({ logsDir: '/fake/logs', mode: 'merge' })
        .expect(200);

      expect(res.body.success).toBe(true);
      expect(res.body.totalImported).toBeGreaterThanOrEqual(1);
      expect(res.body.breakdown).toHaveProperty('successful');
      expect(mockCredentialHistory.compact).toHaveBeenCalled();
    });

    it('should support replace mode', async () => {
      mockCredentialHistory.history = new Map();
      mockFs.existsSync.mockReturnValue(true);
      mockFs.statSync.mockReturnValue(dirStat);
      mockFs.readdirSync.mockReturnValue([]);

      const res = await request(app)
        .post('/api/history/import-logs')
        .send({ logsDir: '/fake/logs', mode: 'replace' })
        .expect(200);

      expect(res.body.success).toBe(true);
      expect(res.body.mode).toBe('replace');
    });

    it('should use default logs dir and succeed when no logsDir is provided', async () => {
      mockFs.existsSync.mockReturnValue(true);
      mockFs.statSync.mockReturnValue(dirStat);
      mockFs.readdirSync.mockReturnValue([]);
      const res = await request(app)
        .post('/api/history/import-logs')
        .send({})
        .expect(200);
      expect(res.body.success).toBe(true);
    });

    it('should import from an external directory path', async () => {
      mockCredentialHistory.history = new Map();
      const entry = JSON.stringify({ username: 'ext_user', password: 'ext_pass', reason: 'bad creds' });

      mockFs.existsSync.mockImplementation(p => {
        if (p && p.includes('/mnt/backup/old-logs')) return true;
        if (p && p.includes('failed')) return true;
        return false;
      });
      mockFs.statSync.mockReturnValue(dirStat);
      mockFs.readdirSync.mockImplementation(p => {
        if (p && p.includes('failed')) return ['failed_2024-06-01.jsonl'];
        return [];
      });
      mockFs.readFileSync.mockReturnValue(entry + '\n');

      const res = await request(app)
        .post('/api/history/import-logs')
        .send({ logsDir: '/mnt/backup/old-logs', mode: 'merge' })
        .expect(200);

      expect(res.body.success).toBe(true);
      expect(res.body.logsDir).toContain('old-logs');
      expect(res.body.totalImported).toBeGreaterThanOrEqual(1);
      expect(res.body.breakdown).toHaveProperty('failed');
    });
  });

  // ── GET /api/logs — data format ───────────────────────────────────────────────
  describe('GET /api/logs — data format', () => {
    it('should return plain strings even after controller start (internal buffer stores objects)', async () => {
      // Start controller so logBuffer gets populated with { ts, line } objects
      await request(app).post('/api/controller/start').expect(200);
      const res = await request(app).get('/api/logs');
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body.logs)).toBe(true);
      // Every entry must be a plain string, not an object
      res.body.logs.forEach(entry => {
        expect(typeof entry).toBe('string');
      });
    });

    it('should return non-empty logs after controller start', async () => {
      await request(app).post('/api/controller/start').expect(200);
      const res = await request(app).get('/api/logs');
      expect(res.status).toBe(200);
      expect(res.body.logs.length).toBeGreaterThan(0);
    });
  });

  // ── loadLogs rendering logic ──────────────────────────────────────────────────
  describe('loadLogs rendering logic', () => {
    // Mirrors the fix: typeof log === 'object' && log !== null ? log.line || log : log
    function renderLogEntry(log) {
      return typeof log === 'object' && log !== null ? log.line || log : log;
    }

    it('should return the string itself for a plain string entry', () => {
      expect(renderLogEntry('hello world')).toBe('hello world');
    });

    it('should extract .line from a { ts, line } object entry', () => {
      expect(renderLogEntry({ ts: 1234567890, line: 'log line text' })).toBe('log line text');
    });

    it('should fall back to the object itself when .line is missing', () => {
      const obj = { ts: 1234567890 };
      expect(renderLogEntry(obj)).toBe(obj);
    });

    it('should handle null safely by treating it as a falsy plain value', () => {
      expect(renderLogEntry(null)).toBe(null);
    });

    it('should handle empty string entry', () => {
      expect(renderLogEntry('')).toBe('');
    });
  });

  // ── POST /api/recheck ────────────────────────────────────────────────────────
  describe('POST /api/recheck', () => {
    it('should return 200 with success:true for valid username and password', async () => {
      const res = await request(app)
        .post('/api/recheck')
        .send({ username: 'user1', password: 'pass1' });
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.message).toMatch(/user1/);
    });

    it('should return 400 when username is missing', async () => {
      const res = await request(app)
        .post('/api/recheck')
        .send({ password: 'pass1' });
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/username/i);
    });

    it('should return 400 when password is missing', async () => {
      const res = await request(app)
        .post('/api/recheck')
        .send({ username: 'user1' });
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/password/i);
    });

    it('should return 400 when controller is already running', async () => {
      await request(app).post('/api/controller/start');
      const res = await request(app)
        .post('/api/recheck')
        .send({ username: 'user1', password: 'pass1' });
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/already running/i);
    });
  });

  // ── POST /api/recheck-all ─────────────────────────────────────────────────────
  describe('POST /api/recheck-all', () => {
    it('should return 200 with success:true when history has matching entries', async () => {
      const res = await request(app)
        .post('/api/recheck-all')
        .send({ status: 'success' });
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.count).toBe(1);
    });

    it('should return 400 when no entries found for the given status', async () => {
      mockCredentialHistory.getByStatus.mockReturnValueOnce([]);
      const res = await request(app)
        .post('/api/recheck-all')
        .send({ status: 'success' });
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/no entries found/i);
    });

    it('should return 400 when history is not enabled', async () => {
      // Reload the server without history
      jest.resetModules();
      jest.mock('../../config', () => ({
        browser: { headless: true },
        proxy: { enabled: false },
        batch: { maxParallelWorkers: 5, credentialsPerProxy: 10 },
        history: { enabled: false },
        queue: { enabled: false },
        retry: { maxRetries: 3 },
        errorRecovery: { maxRetries: 3 },
        cookieExport: { exportDir: 'CookieExports' }
      }));
      const appNoHistory = require('../../gui/server');
      const res = await request(appNoHistory)
        .post('/api/recheck-all')
        .send({ status: 'success' });
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/history not enabled/i);
    });
  });

  // ── POST /api/reverify ───────────────────────────────────────────────────────
  describe('POST /api/reverify', () => {
    it('should return 200 with success:true for valid username and password', async () => {
      const res = await request(app)
        .post('/api/reverify')
        .send({ username: 'user1', password: 'pass1' });
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.message).toMatch(/user1/);
    });

    it('should return 400 when username is missing', async () => {
      const res = await request(app)
        .post('/api/reverify')
        .send({ password: 'pass1' });
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/username/i);
    });

    it('should return 400 when password is missing', async () => {
      const res = await request(app)
        .post('/api/reverify')
        .send({ username: 'user1' });
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/password/i);
    });
  });

  // ── Controller syntax check ───────────────────────────────────────────────────
  describe('Controller syntax', () => {
    it('play_version2_controller.js should have valid JavaScript syntax', () => {
      const { execSync } = jest.requireActual('child_process');
      const path = require('path');
      const controllerPath = path.resolve(__dirname, '..', '..', 'play_version2_controller.js');
      expect(() => {
        execSync(`node --check "${controllerPath}"`, { stdio: 'pipe' });
      }).not.toThrow();
    });

    it('handleWorkerMessage if/else chain covers ok, blocked, failed, and unknown statuses', () => {
      const realFs = jest.requireActual('fs');
      const path = require('path');
      const src = realFs.readFileSync(
        path.resolve(__dirname, '..', '..', 'play_version2_controller.js'),
        'utf8'
      );
      // Verify all four status branches are present in the source
      expect(src).toContain("workerMsg.status === 'ok'");
      expect(src).toContain("workerMsg.status === 'blocked'");
      expect(src).toContain("workerMsg.status === 'failed'");
      // Unknown status catch-all (the else branch)
      expect(src).toContain('Unknown status');
    });

    it('credential_result handler normalises ok→success and handles error status', () => {
      const realFs = jest.requireActual('fs');
      const path = require('path');
      const src = realFs.readFileSync(
        path.resolve(__dirname, '..', '..', 'play_version2_controller.js'),
        'utf8'
      );
      // 'ok' must be treated as alias for 'success' in credential_result IPC handler
      expect(src).toContain("status === 'ok' ? 'success' : status");
      // 'error' status must be recorded as failed
      expect(src).toContain("normStatus === 'error'");
      // Unknown status in credential_result must have a fallback else block
      expect(src).toContain("Unknown credential_result status");
      // Warning when credentialHistory is null
      expect(src).toContain('history is not enabled');
      // retryQueue.markSuccess must appear BEFORE the !credentialHistory guard so
      // successful credentials are unmarked from the retry queue even when history
      // is disabled.
      const retryQueueIdx = src.indexOf("retryQueue.markSuccess({ username })");
      const nullCheckIdx = src.indexOf("if (!credentialHistory)");
      expect(retryQueueIdx).toBeGreaterThan(-1);
      expect(nullCheckIdx).toBeGreaterThan(-1);
      expect(retryQueueIdx).toBeLessThan(nullCheckIdx);
    });

    it('worker crash handler records credentials in history', () => {
      const realFs = jest.requireActual('fs');
      const path = require('path');
      const src = realFs.readFileSync(
        path.resolve(__dirname, '..', '..', 'play_version2_controller.js'),
        'utf8'
      );
      // Both crash paths must record each credential as failed in history
      expect(src).toContain("recordFailed(cred.username, cred.password, 'worker_crash')");
      expect(src).toContain("recordFailed(cred.username, cred.password, 'worker_no_response')");
    });

    it('history polling in gui/server.js uses getFileFingerprint() instead of private fields', () => {
      const realFs = jest.requireActual('fs');
      const path = require('path');
      const src = realFs.readFileSync(
        path.resolve(__dirname, '..', '..', 'gui', 'server.js'),
        'utf8'
      );
      // Must call the public getter, not access private underscore fields
      expect(src).toContain('getFileFingerprint()');
      expect(src).not.toContain('_lastMtimeMs');
      expect(src).not.toContain('_lastSize');
    });
  });

  // ── POST /api/profiles/apply ──────────────────────────────────────────────────
  describe('POST /api/profiles/apply', () => {
    it('should return 400 when profile name is missing', async () => {
      const res = await request(app)
        .post('/api/profiles/apply')
        .send({});
      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
      expect(res.body.error).toMatch(/profile name is required/i);
    });

    it('should return 400 when profile name is not a string', async () => {
      const res = await request(app)
        .post('/api/profiles/apply')
        .send({ profile: 42 });
      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
      expect(res.body.error).toMatch(/profile name is required/i);
    });

    it('should return 404 when profile name is unknown', async () => {
      const res = await request(app)
        .post('/api/profiles/apply')
        .send({ profile: 'nonexistent' });
      expect(res.status).toBe(404);
      expect(res.body.success).toBe(false);
      expect(res.body.error).toMatch(/unknown profile/i);
    });

    it('should return 200 with success:true and update activeProfile on valid profile', async () => {
      mockFs.copyFileSync = jest.fn();
      mockFs.writeFileSync = jest.fn();
      const res = await request(app)
        .post('/api/profiles/apply')
        .send({ profile: 'balanced' });
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(mockConfigProfiles.getProfile).toHaveBeenCalledWith('balanced');
      expect(mockConfigProfiles.applyProfile).toHaveBeenCalled();
    });

    it('should return persisted:true when disk write succeeds', async () => {
      mockFs.copyFileSync = jest.fn();
      mockFs.writeFileSync = jest.fn();
      const res = await request(app)
        .post('/api/profiles/apply')
        .send({ profile: 'balanced' });
      expect(res.status).toBe(200);
      expect(res.body.persisted).toBe(true);
    });

    it('should return persisted:false when disk write throws', async () => {
      mockFs.copyFileSync = jest.fn(() => { throw new Error('disk full'); });
      const res = await request(app)
        .post('/api/profiles/apply')
        .send({ profile: 'balanced' });
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.persisted).toBe(false);
    });
  });

  // ── POST /api/cookie-exports/generate-bulk ────────────────────────────────
  describe('POST /api/cookie-exports/generate-bulk', () => {
    it('should return 202 with jobId when no job is running', async () => {
      const res = await request(app)
        .post('/api/cookie-exports/generate-bulk')
        .send({ amount: 100, concurrency: 1 });
      expect(res.status).toBe(202);
      expect(res.body.success).toBe(true);
      expect(res.body.message).toMatch(/started/i);
      expect(res.body.amount).toBe(100);
      expect(typeof res.body.jobId).toBe('string');
    });

    it('should default amount to 100 when not provided', async () => {
      const res = await request(app)
        .post('/api/cookie-exports/generate-bulk')
        .send({});
      expect(res.status).toBe(202);
      expect(res.body.amount).toBe(100);
    });

    it('should return 400 when amount exceeds 2000', async () => {
      const res = await request(app)
        .post('/api/cookie-exports/generate-bulk')
        .send({ amount: 9999 });
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/2000/);
    });

    it('should return 409 when a job is already running', async () => {
      // Start first job
      await request(app)
        .post('/api/cookie-exports/generate-bulk')
        .send({ amount: 100 });
      // Attempt second job immediately while first is "running"
      const res = await request(app)
        .post('/api/cookie-exports/generate-bulk')
        .send({ amount: 100 });
      expect(res.status).toBe(409);
      expect(res.body.error).toMatch(/already running/i);
    });
  });

  // ── GET /api/cookie-exports/generate-bulk/status ─────────────────────────
  describe('GET /api/cookie-exports/generate-bulk/status', () => {
    it('should return { running: false } when no job has been started', async () => {
      const res = await request(app).get('/api/cookie-exports/generate-bulk/status');
      expect(res.status).toBe(200);
      expect(res.body.running).toBe(false);
    });

    it('should return job state after a job is started', async () => {
      await request(app)
        .post('/api/cookie-exports/generate-bulk')
        .send({ amount: 100, concurrency: 1 });
      const res = await request(app).get('/api/cookie-exports/generate-bulk/status');
      expect(res.status).toBe(200);
      expect(typeof res.body.id).toBe('string');
      expect(res.body).toHaveProperty('progress');
    });

    it('should return basename (not full path) for outputPath', async () => {
      // Start a job and wait for done event so outputPath is set
      const EventEmitterActual = jest.requireActual('events');
      class ImmediateDoneGenerator extends EventEmitterActual {
        constructor() { super(); }
        generate() {
          setImmediate(() => this.emit('done', {
            outputPath: '/some/absolute/dir/bulk_cookies_file.json',
            totalSets: 100, successful: 100, failed: 0
          }));
          return Promise.resolve({ outputPath: '/some/absolute/dir/bulk_cookies_file.json', totalSets: 100, successful: 100, failed: 0 });
        }
      }
      mockBulkGeneratorFactory.mockImplementationOnce(() => new ImmediateDoneGenerator());
      await request(app)
        .post('/api/cookie-exports/generate-bulk')
        .send({ amount: 100 });
      // Wait a tick for done event to fire
      await new Promise(r => setImmediate(r));
      const res = await request(app).get('/api/cookie-exports/generate-bulk/status');
      expect(res.status).toBe(200);
      if (res.body.outputPath) {
        expect(res.body.outputPath).not.toContain('/');
        expect(res.body.outputPath).toBe('bulk_cookies_file.json');
      }
    });
  });

  // ── GET /api/proxies/status ─────────────────────────────────────────────────
  describe('GET /api/proxies/status', () => {
    it('should return 200 with proxies array', async () => {
      const res = await request(app).get('/api/proxies/status');
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('proxies');
      expect(Array.isArray(res.body.proxies)).toBe(true);
    });

    it('should return empty proxies when no log data and no proxy file', async () => {
      const res = await request(app).get('/api/proxies/status');
      expect(res.status).toBe(200);
      expect(res.body.proxies).toEqual([]);
    });

    it('should return proxy entries from proxy file when no log data', async () => {
      const mockFs = require('fs');
      mockFs.existsSync.mockReturnValue(true);
      mockFs.readFileSync.mockReturnValue('10.0.0.1:8080\nuser:pass@10.0.0.2:9090\n');
      const res = await request(app).get('/api/proxies/status');
      expect(res.status).toBe(200);
      expect(res.body.proxies.length).toBe(2);
      // Should strip credentials — only host:port
      const addresses = res.body.proxies.map(p => p.address);
      expect(addresses).toContain('10.0.0.1:8080');
      expect(addresses).toContain('10.0.0.2:9090');
      // Should never contain credentials
      addresses.forEach(a => expect(a).not.toContain('@'));
    });

    it('should include health fields on each proxy entry', async () => {
      const mockFs = require('fs');
      mockFs.existsSync.mockReturnValue(true);
      mockFs.readFileSync.mockReturnValue('10.0.0.1:8080\n');
      const res = await request(app).get('/api/proxies/status');
      expect(res.status).toBe(200);
      const p = res.body.proxies[0];
      expect(p).toHaveProperty('address');
      expect(p).toHaveProperty('successCount', 0);
      expect(p).toHaveProperty('failCount', 0);
      expect(p).toHaveProperty('blockCount', 0);
      expect(p).toHaveProperty('healthy', true);
    });
  });

  // ── GET /api/workers ────────────────────────────────────────────────────────
  describe('GET /api/workers', () => {
    it('should return 200 with workers array', async () => {
      const res = await request(app).get('/api/workers');
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('workers');
      expect(Array.isArray(res.body.workers)).toBe(true);
    });

    it('should return empty workers array on fresh server', async () => {
      const res = await request(app).get('/api/workers');
      expect(res.status).toBe(200);
      expect(res.body.workers).toEqual([]);
    });
  });

  // ── GET /api/history/timeseries ─────────────────────────────────────────────
  describe('GET /api/history/timeseries', () => {
    it('should return 200 with buckets array', async () => {
      const res = await request(app).get('/api/history/timeseries');
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('buckets');
      expect(Array.isArray(res.body.buckets)).toBe(true);
    });

    it('should return 12 five-minute buckets', async () => {
      const res = await request(app).get('/api/history/timeseries');
      expect(res.status).toBe(200);
      expect(res.body.buckets.length).toBe(12);
    });

    it('should include label, count, and failureCategories on each bucket', async () => {
      const res = await request(app).get('/api/history/timeseries');
      expect(res.status).toBe(200);
      const bucket = res.body.buckets[0];
      expect(bucket).toHaveProperty('label');
      expect(bucket).toHaveProperty('count');
      expect(bucket).toHaveProperty('failureCategories');
      expect(bucket.failureCategories).toHaveProperty('credential');
      expect(bucket.failureCategories).toHaveProperty('infrastructure');
      expect(bucket.failureCategories).toHaveProperty('detection');
    });

    it('should count recent entries into the correct bucket', async () => {
      // Re-mock config with history enabled (needed because earlier tests may
      // override the config mock with history.enabled: false)
      jest.resetModules();
      jest.mock('../../config', () => ({
        browser: { headless: true },
        proxy: { enabled: false },
        proxyFile: 'Lightning_Proxies.txt',
        batch: { maxParallelWorkers: 5, credentialsPerProxy: 10 },
        history: { enabled: true, historyFile: 'test_history.jsonl' },
        queue: { enabled: true, queueFile: 'test_queue.jsonl', defaultPriority: 3 },
        retry: { maxRetries: 3 },
        errorRecovery: { maxRetries: 3 },
        cookieExport: { exportDir: 'CookieExports' },
        login: { url: 'https://login.supercard.ch/', usernameSelector: '#username', passwordSelector: '#password', onetrust: '#onetrust-accept-btn-handler' },
        bulkCookieGenerator: { defaultAmount: 100, allowedAmounts: [100, 500, 1000, 2000], maxConcurrency: 5, outputDir: 'CookieExports', headless: false }
      }));

      // Provide entries from a minute ago (not exactly now, to avoid boundary condition)
      const recentTs = new Date(Date.now() - 60000).toISOString();
      mockCredentialHistory.getAll.mockReturnValue([
        { username: 'u1', password: 'p1', status: 'success', timestamp: recentTs },
        { username: 'u2', password: 'p2', status: 'failed', reason: 'invalid credentials', timestamp: recentTs },
        { username: 'u3', password: 'p3', status: 'blocked', reason: 'captcha detected', timestamp: recentTs }
      ]);

      const freshApp = require('../../gui/server');
      const res = await request(freshApp).get('/api/history/timeseries');
      expect(res.status).toBe(200);
      // Sum all bucket counts — entries should appear in exactly one bucket
      const totalCount = res.body.buckets.reduce((sum, b) => sum + b.count, 0);
      expect(totalCount).toBe(3);
      // Verify failure categories are aggregated
      const totalCred = res.body.buckets.reduce((sum, b) => sum + b.failureCategories.credential, 0);
      const totalDetect = res.body.buckets.reduce((sum, b) => sum + b.failureCategories.detection, 0);
      expect(totalCred).toBe(1);
      expect(totalDetect).toBe(1);
    });

    it('should not include internal start/end fields in response', async () => {
      const res = await request(app).get('/api/history/timeseries');
      expect(res.status).toBe(200);
      const bucket = res.body.buckets[0];
      expect(bucket).not.toHaveProperty('start');
      expect(bucket).not.toHaveProperty('end');
    });
  });

  // ── POST /api/proxies/pause ─────────────────────────────────────────────────
  describe('POST /api/proxies/pause', () => {
    it('should return 400 when address is missing', async () => {
      const res = await request(app).post('/api/proxies/pause').send({});
      expect(res.status).toBe(400);
      expect(res.body.error).toBe('Missing address');
    });

    it('should pause a proxy', async () => {
      const res = await request(app).post('/api/proxies/pause').send({ address: '10.0.0.1:8080', paused: true });
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.paused).toBe(true);
    });

    it('should unpause a proxy', async () => {
      await request(app).post('/api/proxies/pause').send({ address: '10.0.0.1:8080', paused: true });
      const res = await request(app).post('/api/proxies/pause').send({ address: '10.0.0.1:8080', paused: false });
      expect(res.status).toBe(200);
      expect(res.body.paused).toBe(false);
    });
  });

  // ── POST /api/proxies/unblacklist ───────────────────────────────────────────
  describe('POST /api/proxies/unblacklist', () => {
    it('should return 400 when address is missing', async () => {
      const res = await request(app).post('/api/proxies/unblacklist').send({});
      expect(res.status).toBe(400);
      expect(res.body.error).toBe('Missing address');
    });

    it('should unblacklist a proxy', async () => {
      const res = await request(app).post('/api/proxies/unblacklist').send({ address: '10.0.0.1:8080' });
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
    });
  });

  // ── POST /api/proxies/check ─────────────────────────────────────────────────
  describe('POST /api/proxies/check', () => {
    it('should return 400 for invalid proxy address', async () => {
      const res = await request(app).post('/api/proxies/check').send({ address: 'invalid' });
      expect(res.status).toBe(400);
      expect(res.body.error).toBe('Invalid proxy address');
    });

    it('should return 400 for empty body', async () => {
      const res = await request(app).post('/api/proxies/check').send({});
      expect(res.status).toBe(400);
    });

    it('should return reachable result for valid address', async () => {
      const res = await request(app).post('/api/proxies/check').send({ address: '10.0.0.1:8080' });
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('address', '10.0.0.1:8080');
      expect(res.body).toHaveProperty('reachable');
    });
  });

  // ── GET /api/proxies/export ─────────────────────────────────────────────────
  describe('GET /api/proxies/export', () => {
    it('should export JSON by default', async () => {
      const res = await request(app).get('/api/proxies/export');
      expect(res.status).toBe(200);
      expect(res.headers['content-type']).toMatch(/json/);
    });

    it('should export CSV when format=csv', async () => {
      const res = await request(app).get('/api/proxies/export?format=csv');
      expect(res.status).toBe(200);
      expect(res.headers['content-type']).toMatch(/csv/);
    });
  });

  // ── DELETE /api/proxies/:address ────────────────────────────────────────────
  describe('DELETE /api/proxies/:address', () => {
    it('should return success for valid address', async () => {
      const res = await request(app).delete('/api/proxies/' + encodeURIComponent('10.0.0.1:8080'));
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('success');
      expect(res.body).toHaveProperty('address', '10.0.0.1:8080');
    });
  });
});
