/**
 * Unit Tests for Block Detection and Respawn Logic
 * 
 * Tests:
 * 1. checkForEarlyFailure in casDetection — block phrase, captcha, bot check detection
 * 2. Config: blockPhrases, locale, timezone correctly configured
 * 3. launchBrowser context options include locale/timezoneId
 * 4. All block paths send respawn_with_new_proxy IPC before process.exit
 */

const config = require('../../config');
const { checkForEarlyFailure } = require('../../utils/casDetection');

// ──────────────────────────────────────────────────────────────────────────────
// Helpers
// ──────────────────────────────────────────────────────────────────────────────

/** Create a minimal mock Playwright page whose body text is `text`. */
function mockPage(text) {
  return {
    evaluate: jest.fn().mockResolvedValue(text)
  };
}

// ──────────────────────────────────────────────────────────────────────────────
// 1. checkForEarlyFailure — block phrase detection
// ──────────────────────────────────────────────────────────────────────────────

describe('checkForEarlyFailure', () => {
  it('should detect "Der Zugriff ist vorübergehend eingeschränkt" as proxy_blocked', async () => {
    const page = mockPage('Der Zugriff ist vorübergehend eingeschränkt');
    const result = await checkForEarlyFailure(page);

    expect(result).not.toBeNull();
    expect(result.ok).toBe(false);
    expect(result.type).toBe('blocked');
    expect(result.reason).toBe('proxy_blocked');
    expect(result.retryOnDifferentProxy).toBe(true);
  });

  it('should detect block phrase with extra whitespace', async () => {
    const page = mockPage('Fehler:  Der  Zugriff  ist  vorübergehend  eingeschränkt  — bitte warten.');
    const result = await checkForEarlyFailure(page);

    expect(result).not.toBeNull();
    expect(result.type).toBe('blocked');
    expect(result.reason).toBe('proxy_blocked');
  });

  it('should detect block phrase case-insensitively', async () => {
    const page = mockPage('DER ZUGRIFF IST VORÜBERGEHEND EINGESCHRÄNKT');
    const result = await checkForEarlyFailure(page);

    expect(result).not.toBeNull();
    expect(result.type).toBe('blocked');
    expect(result.reason).toBe('proxy_blocked');
  });

  it('should detect invalid credentials phrase', async () => {
    const page = mockPage('Bitte überprüfen Sie Ihre Eingaben und versuchen Sie es erneut.');
    const result = await checkForEarlyFailure(page);

    expect(result).not.toBeNull();
    expect(result.type).toBe('failure');
    expect(result.reason).toBe('invalid_credentials');
  });

  it('should detect suspicious behavior phrase', async () => {
    const page = mockPage('Etwas im Verhalten des Browsers hat uns stutzig gemacht.');
    const result = await checkForEarlyFailure(page);

    expect(result).not.toBeNull();
    expect(result.type).toBe('blocked');
    expect(result.reason).toBe('suspicious_behavior');
    expect(result.retryOnDifferentProxy).toBe(true);
  });

  it('should detect bot check phrase as captcha', async () => {
    const page = mockPage('Wir vergewissern uns, dass wir es wirklich mit Ihnen zu tun haben, und nicht mit einem Roboter.');
    const result = await checkForEarlyFailure(page);

    expect(result).not.toBeNull();
    // bot_check or captcha — both use the same phrase
    expect(['blocked', 'captcha']).toContain(result.type);
    expect(result.retryOnDifferentProxy).toBe(true);
  });

  it('should detect account lock phrase', async () => {
    const page = mockPage('Ihr Konto wurde aufgrund von zu vielen Loginversuchen temporär gesperrt. Zum Freischalten setzen Sie jetzt ihr Passwort zurück');
    const result = await checkForEarlyFailure(page);

    expect(result).not.toBeNull();
    expect(result.type).toBe('account_locked');
    expect(result.reason).toBe('account_lock_unlockable');
  });

  it('should return null for clean login page', async () => {
    const page = mockPage('Login — Supercard.ch\nBenutzername\nPasswort\nAnmelden');
    const result = await checkForEarlyFailure(page);

    expect(result).toBeNull();
  });

  it('should return null for empty body text', async () => {
    const page = mockPage('');
    const result = await checkForEarlyFailure(page);

    expect(result).toBeNull();
  });

  it('should handle page.evaluate failure gracefully', async () => {
    const page = {
      evaluate: jest.fn().mockRejectedValue(new Error('Page crashed'))
    };
    const result = await checkForEarlyFailure(page);

    expect(result).toBeNull();
  });
});

// ──────────────────────────────────────────────────────────────────────────────
// 2. Config structure validation
// ──────────────────────────────────────────────────────────────────────────────

describe('Config: block detection and browser settings', () => {
  it('should have blockPhrases array with "Der Zugriff ist vorübergehend eingeschränkt"', () => {
    expect(Array.isArray(config.detection.blockPhrases)).toBe(true);
    expect(config.detection.blockPhrases.length).toBeGreaterThanOrEqual(1);
    expect(config.detection.blockPhrases).toContain('Der Zugriff ist vorübergehend eingeschränkt');
  });

  it('should have suspiciousBehaviorPhrase', () => {
    expect(typeof config.detection.suspiciousBehaviorPhrase).toBe('string');
    expect(config.detection.suspiciousBehaviorPhrase.length).toBeGreaterThan(0);
  });

  it('should have botCheckPhrase', () => {
    expect(typeof config.detection.botCheckPhrase).toBe('string');
    expect(config.detection.botCheckPhrase.length).toBeGreaterThan(0);
  });

  it('should have captchaPhrase', () => {
    expect(typeof config.detection.captchaPhrase).toBe('string');
    expect(config.detection.captchaPhrase.length).toBeGreaterThan(0);
  });

  it('should have locale set to de-CH for Swiss German fingerprinting', () => {
    expect(config.browser.locale).toBe('de-CH');
  });

  it('should have timezone set to Europe/Zurich', () => {
    expect(config.browser.timezone).toBe('Europe/Zurich');
  });

  it('should have ignoreDefaultArgs set to stealth array excluding automation flags', () => {
    expect(Array.isArray(config.browser.ignoreDefaultArgs)).toBe(true);
    expect(config.browser.ignoreDefaultArgs).toContain('--enable-automation');
    expect(config.browser.ignoreDefaultArgs).toContain('--enable-blink-features=IdleDetection');
  });

  it('should have resourceBlocking disabled (breaks Patchright stealth injection)', () => {
    expect(config.browser.resourceBlocking.enabled).toBe(false);
  });

  it('should have proxy blacklist TTLs configured', () => {
    expect(config.proxy.blacklistTTLs).toBeDefined();
    expect(config.proxy.blacklistTTLs.rate_limited).toBeGreaterThan(0);
    expect(config.proxy.blacklistTTLs.ip_banned).toBeGreaterThan(0);
    expect(config.proxy.blacklistTTLs.captcha_triggered).toBeGreaterThan(0);
    expect(config.proxy.blacklistTTLs.bot_check_triggered).toBeGreaterThan(0);
  });
});

// ──────────────────────────────────────────────────────────────────────────────
// 3. launchBrowser context options (source code analysis)
// ──────────────────────────────────────────────────────────────────────────────

describe('launchBrowser context options', () => {
  const fs = require('fs');
  const workerSource = fs.readFileSync(
    require('path').join(__dirname, '..', '..', 'play_version2_worker_integrated_Version5.js'),
    'utf8'
  );

  it('should pass locale from config to launchPersistentContext', () => {
    // Verify that the source code sets contextOptions.locale
    expect(workerSource).toContain('contextOptions.locale = config.browser.locale');
  });

  it('should pass timezoneId from config to launchPersistentContext', () => {
    // Verify that the source code sets contextOptions.timezoneId
    expect(workerSource).toContain('contextOptions.timezoneId = config.browser.timezone');
  });

  it('should use launchPersistentContext (not chromium.launch)', () => {
    expect(workerSource).toContain('chromium.launchPersistentContext(userDataDir, contextOptions)');
  });

  it('should import chromium from patchright (not playwright)', () => {
    expect(workerSource).toContain("const { chromium } = require('patchright')");
  });

  it('should not use page.route (breaks Patchright stealth)', () => {
    // Verify no page.route calls that could break Patchright stealth injection
    const routeCalls = workerSource.match(/page\.route\(/g);
    expect(routeCalls).toBeNull();
  });
});

// ──────────────────────────────────────────────────────────────────────────────
// 4. Respawn IPC consistency across all block paths (source code analysis)
// ──────────────────────────────────────────────────────────────────────────────

describe('Respawn IPC consistency', () => {
  const fs = require('fs');
  const workerSource = fs.readFileSync(
    require('path').join(__dirname, '..', '..', 'play_version2_worker_integrated_Version5.js'),
    'utf8'
  );

  it('should send respawn_with_new_proxy IPC in pre-input proxy_blocked path', () => {
    // The pre-input proxy_blocked path (detectBlockOrCaptcha → proxy_blocked)
    // should contain respawn_with_new_proxy
    expect(workerSource).toContain("type: 'respawn_with_new_proxy'");
  });

  it('should send block_detected IPC in initial block detection loop', () => {
    // The initial block detection loop should notify controller
    // Search for block_detected in the context of initial block detection
    const initialBlockMarkerIndex = workerSource.indexOf('INITIAL BLOCK DETECTION WITH RETRY LOOP');
    expect(initialBlockMarkerIndex).not.toBe(-1);
    const initialBlockSection = workerSource.substring(
      initialBlockMarkerIndex,
      initialBlockMarkerIndex + 2000
    );
    expect(initialBlockSection).toContain("type: 'block_detected'");
  });

  it('should have multiple respawn_with_new_proxy sends for all block types', () => {
    // Count occurrences of respawn_with_new_proxy sends — should be >= 5:
    // 1. pre-input proxy_blocked, 2. pre-input captcha, 3. pre-input bot_check,
    // 4. post-submit blocked, 5. post-submit captcha
    const matches = workerSource.match(/type: 'respawn_with_new_proxy'/g);
    expect(matches).not.toBeNull();
    expect(matches.length).toBeGreaterThanOrEqual(5);
  });

  it('should include remainingSlice in all respawn messages', () => {
    // Every respawn_with_new_proxy should include remainingSlice
    const respawnSections = workerSource.split("type: 'respawn_with_new_proxy'");
    // There are N+1 sections after split; sections 1..N should have remainingSlice nearby
    for (let i = 1; i < respawnSections.length; i++) {
      const nearby = respawnSections[i].substring(0, 200);
      expect(nearby).toContain('remainingSlice');
    }
  });

  it('should call forceCleanup before process.exit in all respawn paths', () => {
    // Every respawn path should clean up before exiting
    const respawnPaths = workerSource.split("type: 'respawn_with_new_proxy'");
    for (let i = 1; i < respawnPaths.length; i++) {
      const afterRespawn = respawnPaths[i].substring(0, 500);
      expect(afterRespawn).toContain('forceCleanup');
    }
  });

  it('should await IPC send callback before process.exit in respawn paths', () => {
    // Each respawn should use await new Promise pattern to flush IPC
    const respawnPaths = workerSource.split("type: 'respawn_with_new_proxy'");
    for (let i = 1; i < respawnPaths.length; i++) {
      // Check that the respawn is wrapped in a Promise for IPC flush
      const beforeRespawn = respawnPaths[i - 1].slice(-300);
      expect(beforeRespawn).toContain('new Promise');
    }
  });
});

// ──────────────────────────────────────────────────────────────────────────────
// 5. Controller respawn handler validation (source code analysis)
// ──────────────────────────────────────────────────────────────────────────────

describe('Controller respawn handler', () => {
  const fs = require('fs');
  const controllerSource = fs.readFileSync(
    require('path').join(__dirname, '..', '..', 'play_version2_controller.js'),
    'utf8'
  );

  it('should handle respawn_with_new_proxy message type', () => {
    expect(controllerSource).toContain("msg.type === 'respawn_with_new_proxy'");
  });

  it('should set respawning flag to prevent double resolution', () => {
    expect(controllerSource).toContain('respawning = true');
  });

  it('should guard exit handler against respawning flag', () => {
    expect(controllerSource).toContain('if (respawning) return');
  });

  it('should filter blocked proxy from alternates', () => {
    expect(controllerSource).toContain('rawProxies.filter(p => p !== upstream)');
  });

  it('should handle no-alternate-proxy case gracefully', () => {
    expect(controllerSource).toContain("'no_alternate_proxy'");
  });

  it('should handle block_detected message type for tracking', () => {
    expect(controllerSource).toContain("msg.type === 'block_detected'");
  });
});

// ──────────────────────────────────────────────────────────────────────────────
// 6. Cookie export placement validation (source code analysis)
// ──────────────────────────────────────────────────────────────────────────────

describe('Cookie export placement in worker', () => {
  const fs = require('fs');
  const workerSource = fs.readFileSync(
    require('path').join(__dirname, '..', '..', 'play_version2_worker_integrated_Version5.js'),
    'utf8'
  );

  it('should have unified post-success cookie export marker after CAS detection', () => {
    const casIndex    = workerSource.indexOf('REFINED CAS DETECTION WITH TGC PRIORITY');
    const exportIndex = workerSource.indexOf('COOKIE EXPORT: capture cookies after successful login');

    expect(casIndex).toBeGreaterThan(-1);
    expect(exportIndex).toBeGreaterThan(-1);
    expect(exportIndex).toBeGreaterThan(casIndex);
  });

  it('should NOT have the old pre-CAS export block', () => {
    expect(workerSource).not.toContain('COOKIE EXPORT: capture cookies after form fill');
  });

  it('should NOT guard post-success export with format !== DatadomePostRequestCookieonly', () => {
    expect(workerSource).not.toContain("format !== 'DatadomePostRequestCookieonly'");
  });

  it('should NOT have a separate DatadomePostRequestCookieonly-only post-success block', () => {
    expect(workerSource).not.toContain("COOKIE EXPORT (DatadomePostRequestCookieonly only)");
    expect(workerSource).not.toContain("format === 'DatadomePostRequestCookieonly'");
  });

  it('should use a single unified capture() call after successful login for all formats', () => {
    const exportIndex = workerSource.indexOf('COOKIE EXPORT: capture cookies after successful login');
    expect(exportIndex).toBeGreaterThan(-1);
    // The block must not have any format guard
    const captureSection = workerSource.substring(exportIndex, exportIndex + 400);
    expect(captureSection).toContain('cookieExporter.capture(');
    expect(captureSection).not.toContain("format ===");
    expect(captureSection).not.toContain("format !==");
  });

  it('should track navCompleted before capturing cookies', () => {
    // navCompleted must be declared and set to true when navigation fires
    expect(workerSource).toContain('navCompleted = true');
    // And checked before the fallback waitForLoadState
    const navCompletedIndex = workerSource.indexOf('navCompleted = true');
    const loadStateIndex    = workerSource.indexOf('waitForLoadState');
    expect(loadStateIndex).toBeGreaterThan(navCompletedIndex);
  });
});

