# Configuration Guide

This document provides a comprehensive guide to all configuration options available in `config.js`.

## Table of Contents

- [Browser Configuration](#browser-configuration)
- [Proxy Configuration](#proxy-configuration)
- [Batch & Worker Configuration](#batch--worker-configuration)
- [Form Input Configuration](#form-input-configuration)
- [Navigation Configuration](#navigation-configuration)
- [Login Page Configuration](#login-page-configuration)
- [Account Page Configuration](#account-page-configuration)
- [Detection Configuration](#detection-configuration)
- [Output Files Configuration](#output-files-configuration)
- [Cookie Export Configuration](#cookie-export-configuration)
- [Logging & Monitoring](#logging--monitoring)
- [CAS Detection Options](#cas-detection-options)
- [Browser Context Isolation](#browser-context-isolation)
- [Error Recovery](#error-recovery)
- [Testing Configuration](#testing-configuration)

## Browser Configuration

```javascript
browser: {
  timeout: 180 * 1000,           // Worker timeout in milliseconds (3 minutes)
  gracefulKillWait: 5 * 1000,    // Grace period before SIGKILL (5 seconds)
  headless: false,                // Run browser in visible mode
  channel: 'chrome',              // Browser type: 'chrome' or 'chromium'
  dumpio: false,                  // Pipe browser process stdout/stderr
  args: [                         // Chrome command-line arguments
    '--proxy-server={PROXY}',     // Proxy (replaced at runtime)
    '--disable-dev-shm-usage',
    '--disable-accelerated-2d-canvas',
    '--disable-gpu',
    '--disable-software-rasterizer',
    '--disable-gl-drawing-for-tests',
    '--disable-canvas-aa',
    '--disable-2d-canvas-clip-aa',
    '--disable-features=VizDisplayCompositor',
    '--log-level=3'
  ],
  adaptiveTimeout: {
    initial: 180 * 1000,          // Initial timeout
    perCredential: 30 * 1000,     // Additional time per credential
    captchaRetry: 60 * 1000       // Timeout when retrying after CAPTCHA
  }
}
```

### Options Explained

#### `timeout` (number)
Maximum time in milliseconds for a worker to complete. After this time, the worker will be terminated.

**Default:** `180000` (3 minutes)  
**Recommended:** `120000` - `300000` depending on proxy speed

#### `gracefulKillWait` (number)
Time to wait after SIGTERM before sending SIGKILL to worker.

**Default:** `5000` (5 seconds)  
**Recommended:** Keep at default

#### `headless` (boolean)
Whether to run browser in headless mode (no visible window).

**Default:** `false` (visible)  
**Options:**
- `false` - Visible browser (useful for debugging)
- `true` - Headless mode (faster, lower resource usage)

#### `channel` (string)
Browser type to use.

**Default:** `'chrome'`  
**Options:**
- `'chrome'` - Google Chrome (recommended for better compatibility)
- `'chromium'` - Chromium browser

#### `args` (array)
Chrome command-line arguments for optimization and stealth.

**Key Arguments:**
- `--disable-dev-shm-usage` - Prevents shared memory issues in Docker
- `--disable-gpu` - Disables GPU hardware acceleration
- `--log-level=3` - Reduces console noise

### Traffic Optimization (NEW!)

**Reduce proxy bandwidth by 60-85%!** See [TRAFFIC_OPTIMIZATION.md](TRAFFIC_OPTIMIZATION.md) for complete guide.

```javascript
browser: {
  resourceBlocking: {
    enabled: true,                // Enable request interception
    blockTypes: [
      'image',                    // Block images (~40% traffic savings)
      'font',                     // Block web fonts (~10% savings)
      'media',                    // Block video/audio
      'stylesheet'                // Block CSS (test carefully!)
    ],
    blockThirdParty: true,        // Block 3rd-party analytics/tracking
    allowList: [
      'login.supercard.ch',       // Always allow authentication domain
      'www.supercard.ch',         // Always allow account domain
      'cas/login',                // Allow CAS endpoints
      'cas/oidc'                  // Allow OIDC endpoints
    ]
  }
}
```

**Key Points:**
- **No Impact** on main testing loop (uses DOM/scripts only)
- **60-85% bandwidth reduction** depending on configuration
- **20-40% faster** page loads
- Start with `['image', 'font', 'media']` for safety
- Always keep authentication domains in allowList

**Recommended Profiles:**
- **Conservative**: `['image', 'font']` → 40-55% savings
- **Balanced**: `['image', 'font', 'media']` → 60-75% savings  (RECOMMENDED)
- **Aggressive**: `['image', 'font', 'media', 'stylesheet']` → 70-85% savings

## Proxy Configuration

```javascript
proxy: {
  blacklistTTL: 10 * 60 * 1000,  // Blacklist duration (10 minutes)
  tcpTimeout: 3 * 1000,          // TCP connection timeout (3 seconds)
  attemptsBeforeGiveUp: 5        // Max proxy retry attempts
}
```

### Options Explained

#### `blacklistTTL` (number)
How long to keep a proxy blacklisted after failure.

**Default:** `600000` (10 minutes)  
**Recommended:** `300000` - `900000` (5-15 minutes)

#### `tcpTimeout` (number)
Maximum time to wait for TCP connection to proxy.

**Default:** `3000` (3 seconds)  
**Recommended:** `2000` - `5000`

#### `attemptsBeforeGiveUp` (number)
Number of failed proxy attempts before giving up on a batch.

**Default:** `5`  
**Recommended:** `3` - `10`

## Batch & Worker Configuration

```javascript
batch: {
  credentialsPerProxy: 4,        // Credentials per batch
  maxParallelWorkers: 4,         // Maximum concurrent workers
  pauseBetweenBatchMin: 1 * 1000,    // Min pause between batches
  pauseBetweenBatchMax: 5 * 1000,    // Max pause between batches
  finishWaitMin: 5 * 1000 + 50,      // Min wait after batch finishes
  finishWaitMax: 11 * 1000           // Max wait after batch finishes
}
```

### Options Explained

#### `credentialsPerProxy` (number)
Number of credentials to test in each batch/worker.

**Default:** `4`  
**Recommended:** `2` - `10`

**Considerations:**
- Lower values = More frequent proxy rotation, better anonymity
- Higher values = Better resource utilization, faster overall speed
- Consider proxy quality and target site rate limiting

#### `maxParallelWorkers` (number)
Maximum number of worker processes to run simultaneously.

**Default:** `4`  
**Recommended:** Based on system resources

**Guidelines:**
- 1-2 workers: Low-end systems (2-4 GB RAM)
- 4-6 workers: Mid-range systems (8 GB RAM)
- 8-12 workers: High-end systems (16+ GB RAM)

Each worker uses ~500MB-1GB RAM and 1 CPU core.

#### `pauseBetweenBatchMin` / `pauseBetweenBatchMax` (number)
Random delay between launching batches to avoid patterns.

**Default:** `1000` - `5000` (1-5 seconds)  
**Recommended:** `1000` - `10000`

**Purpose:** Prevents detection through timing analysis.

#### `finishWaitMin` / `finishWaitMax` (number)
Random delay after batch completes before starting next.

**Default:** `5050` - `11000` (5-11 seconds)  
**Recommended:** `3000` - `15000`

## Form Input Configuration

```javascript
form: {
  typeDelayMin: 4,               // Minimum delay between keystrokes (ms)
  typeDelayMax: 10,              // Maximum delay between keystrokes (ms)
  pauseBetweenCredsMin: 100,     // Min pause between credentials
  pauseBetweenCredsMax: 350      // Max pause between credentials
}
```

### Options Explained

#### `typeDelayMin` / `typeDelayMax` (number)
Random delay between individual keystrokes when typing.

**Default:** `4` - `10` ms  
**Recommended:** `3` - `15` ms

**Purpose:** Simulates human typing speed to avoid bot detection.

**Trade-offs:**
- Lower values = Faster but less human-like
- Higher values = Slower but more realistic

#### `pauseBetweenCredsMin` / `pauseBetweenCredsMax` (number)
Pause between testing different credentials in same batch.

**Default:** `100` - `350` ms  
**Recommended:** `50` - `500` ms

## Navigation Configuration

```javascript
navigation: {
  timeout: 12 * 1000 + 500,      // Page navigation timeout
  domWaitUntil: 'domcontentloaded',  // Wait condition
  shortRetryWait: 300            // Quick retry delay
}
```

### Options Explained

#### `timeout` (number)
Maximum time to wait for page navigation.

**Default:** `12500` (12.5 seconds)  
**Recommended:** `10000` - `30000` (10-30 seconds)

**Note:** Slow proxies may need higher values.

#### `domWaitUntil` (string)
Playwright wait condition for navigation.

**Default:** `'domcontentloaded'`  
**Options:**
- `'domcontentloaded'` - Wait for DOM ready (faster)
- `'load'` - Wait for all resources (slower but more reliable)
- `'networkidle'` - Wait for network idle

#### `shortRetryWait` (number)
Delay before quick retries on transient errors.

**Default:** `300` ms  
**Recommended:** `200` - `1000` ms

## Login Page Configuration

```javascript
login: {
  url: 'https://login.supercard.ch/',
  usernameSelector: '#username',
  passwordSelector: '#password',
  submitSelectors: [
    '#btnSubmit',
    'button[type="submit"]',
    'button.btn-primary',
    'button.loginbtn',
    'button.btn.btn-blue',
    'input[type="submit"]'
  ],
  submitXPath: '/html/body/div[1]/main/div/div/div[1]/div[1]/div/div/form/button',
  onetrust: '#onetrust-accept-btn-handler',
  accountTab: '#a-accountLogin-desktop > span.text',
  recaptcha: {
    enabled: true,
    selectors: [
      '.g-recaptcha',
      'iframe[src*="recaptcha"]',
      'div[data-sitekey]'
    ],
    callbackFunction: 'onRecaptchaV2Submit',
    version: 'v2'
  },
  // buttonOpacity removed — submit path uses native button.isEnabled() instead
  rememberMeCheckbox: '#remember-me',
  forgotPasswordLink: 'a[href*="forgot"]',
  errorMessageSelector: '.alert.alert-danger, .error, [role="alert"]',
  successIndicator: '.success-message, [class*="success"]'
}
```

### Target Site Customization

To adapt the system for a different login page:

1. **Update URL:**
```javascript
url: 'https://your-target-site.com/login'
```

2. **Update Selectors:**
Inspect the target page and update:
- `usernameSelector` - CSS selector for username/email input
- `passwordSelector` - CSS selector for password input
- `submitSelectors` - Array of possible submit button selectors

3. **Test Selectors:**
Use browser DevTools to verify selectors work.

### reCAPTCHA Detection

```javascript
recaptcha: {
  enabled: true,              // Enable CAPTCHA detection
  selectors: [...],           // Selectors to detect CAPTCHA
  version: 'v2'               // reCAPTCHA version
}
```

Set `enabled: false` if target site doesn't use CAPTCHA.

## Account Page Configuration

```javascript
account: {
  url: 'https://www.supercard.ch/de/mein-konto.html',
  logoutPhrases: ['Abmelden', 'Logout', 'Sign out', 'Log out'],
  logoutSelectors: [
    'a[href*="logout"]',
    'a[href*="signout"]',
    'a.logout',
    'button.logout',
    'button[title*="Abmelden"]',
    'a[title*="Abmelden"]'
  ],
  logoutPostDelay: 2 * 1000
}
```

### Options Explained

#### `url` (string)
Account/dashboard page URL after successful login.

**Purpose:** Used for navigation-based success detection.

#### `logoutPhrases` (array)
Text phrases that indicate logout buttons.

**Purpose:** Multi-language support for logout detection.

#### `logoutSelectors` (array)
CSS selectors for logout buttons/links.

**Purpose:** Alternative logout detection methods.

## Detection Configuration

```javascript
detection: {
  blockPhrases: ['gesperrt', 'blocked', 'forbidden'],
  suspiciousBehaviorPhrase: 'Etwas im Verhalten des Browsers hat uns stutzig gemacht.',
  captchaPhrase: 'Wir vergewissern uns, dass wir es wirklich mit Ihnen zu tun haben',
  cas: {
    loginPath: '/cas/login',
    callbackPath: 'callbackAuthorize',
    ticketPattern: null, // may be null; check before calling .test(), actual pattern may be provided elsewhere
    oidcAuthorize: '/cas/oidc/authorize',
    timeout: 8000
  },
  blockDetection: {
    statusCodes: [400, 401, 403, 404, 500, 502, 503]
  },
  confidenceThresholds: {
    tgc_cookie: { minConfidence: 0.99, category: 'TGC_COOKIE' },
    cas_ticket: { minConfidence: 0.99, category: 'REDIRECT_302' },
    oidc: { minConfidence: 0.95, category: 'REDIRECT_OIDC' },
    body_token: { minConfidence: 0.90, category: 'BODY_TOKEN' },
    set_cookie: { minConfidence: 0.85, category: 'SET_COOKIE' }
  },
  minimumSuccessConfidence: 0.85
}
```

### Confidence Thresholds

Detection methods are ranked by confidence level:

| Method | Confidence | Description |
|--------|-----------|-------------|
| TGC Cookie | 99% | CAS Ticket Granting Cookie found |
| CAS Ticket | 99% | Redirect with ST- ticket parameter |
| OIDC | 95% | OAuth/OIDC authorization redirect |
| Body Token | 90% | Authentication token in response body |
| Set-Cookie | 85% | Session cookie set in headers |

#### `minimumSuccessConfidence` (number)
Minimum confidence required to log as successful.

**Default:** `0.85` (85%)  
**Recommended:** `0.80` - `0.95`

**Lower values:** More false positives, higher reported success rate  
**Higher values:** Fewer false positives, lower reported success rate

## Output Files Configuration

```javascript
output: {
  failedFile: 'ichfiggdinimueter.txt',
  noScreenshotFile: 'noShot.txt',
  pageLoadErrorFile: 'pageLoadErrors.txt',
  badProxiesFile: 'bad_proxies.txt',
  screenshotDir: process.cwd()
}
```

### Options Explained

#### `failedFile` (string)
Legacy file for failed credentials.

**Default:** `'ichfiggdinimueter.txt'`  
**Note:** Also logged to `logs/failed/`

#### `screenshotDir` (string)
Base directory for screenshots.

**Default:** `process.cwd()` (current directory)
**Recommended:** Use `logs/screenshots`

## Cookie Export Configuration

The cookie export feature captures session data (cookies, headers, proxy info) after successful login page loads and exports them in various formats for external usage outside the app.

```javascript
cookieExport: {
  enabled: false,
  exportDir: 'CookieExports',
  format: 'sessionComplete'
}
```

### Options Explained

#### `enabled` (boolean)
Enable or disable the cookie export feature.

**Default:** `false`
**When enabled:** Session data is captured and exported after each successful login page load.

#### `exportDir` (string)
Directory where export files will be saved.

**Default:** `'CookieExports'`
**Location:** Relative to project root

#### `format` (string)
Export format for the captured session data. Three formats are available:

**Options:**
- `'sessionComplete'` (default): Single JSON file with cookies, headers, proxy, AND Python snippet
- `'sessionOnly'`: Single JSON file with cookies, headers, proxy (NO Python snippet)
- `'dataDomeOnly'`: Three separate JSON files for DataDome-specific workflows
- `'DatadomePostRequestCookieonly'`: Single JSON file with only the datadome value read from the browser context cookie store after successful login

**Default:** `'sessionComplete'`

### Export Formats in Detail

#### 1. sessionComplete (Default)
Best for: Quick Python requests integration

**Output:** `{username}_{timestamp}.json`

**Contents:**
```json
{
  "capturedAt": "2024-03-04T12:00:00.000Z",
  "username": "user@example.com",
  "loginUrl": "https://login.example.com",
  "proxy": "proxy.example.com:8080",
  "userAgent": "Mozilla/5.0...",
  "cookies": [
    { "name": "session", "value": "abc123", "domain": ".example.com", ... }
  ],
  "headers": {
    "User-Agent": "Mozilla/5.0...",
    "Accept": "text/html...",
    "Accept-Language": "en-US",
    "Accept-Encoding": "gzip, deflate, br"
  },
  "pythonSnippet": "import requests\n\n# Session captured by SuPerrMurrer..."
}
```

The `pythonSnippet` field contains ready-to-paste Python code that can immediately replay the session.

#### 2. sessionOnly
Best for: Clean JSON export for any HTTP client

**Output:** `{username}_{timestamp}.json`

**Contents:** Same as `sessionComplete` but WITHOUT the `pythonSnippet` field. Pure JSON data only.

Use this format when integrating with non-Python tools or when you want to process the data programmatically without the embedded code snippet.

#### 3. dataDomeOnly
Best for: External DataDome challenge handling and specialized workflows

**Output:** Three separate JSON files per capture:
1. `{username}_{timestamp}_datadome.json` - Just the datadome cookie
2. `{username}_{timestamp}_headers.json` - Request headers
3. `{username}_{timestamp}_proxy.json` - Proxy connection info with IP

**Example file 1 (datadome):**
```json
{
  "capturedAt": "2024-03-04T12:00:00.000Z",
  "username": "user@example.com",
  "cookie": {
    "name": "datadome",
    "value": "DD_TOKEN_HERE",
    "domain": ".example.com",
    "path": "/",
    "secure": true,
    "httpOnly": false,
    "sameSite": "Lax"
  }
}
```

**Example file 2 (headers):**
```json
{
  "capturedAt": "2024-03-04T12:00:00.000Z",
  "username": "user@example.com",
  "headers": {
    "User-Agent": "Mozilla/5.0...",
    "Accept": "text/html...",
    "Accept-Language": "en-US",
    "Accept-Encoding": "gzip, deflate, br"
  }
}
```

**Example file 3 (proxy):**
```json
{
  "capturedAt": "2024-03-04T12:00:00.000Z",
  "username": "user@example.com",
  "proxy": "proxy.example.com:8080",
  "proxyIP": "proxy.example.com"
}
```

**Note:** If no datadome cookie is found, only the headers and proxy files will be created.

#### 4. DatadomePostRequestCookieonly
Best for: Stealth-safe capture of the datadome token after successful login

Reads the `datadome` cookie directly from the browser context cookie store after CAS authentication completes. Uses zero event listeners, zero `page.route()` calls, and zero timers during credential processing — the same approach used by all other export formats.

**Output:** Single JSON file:
- `{username}_{timestamp}_datadome_post.json`

**Example file:**
```json
{ "datadome": "jYj65Q3J_Fkf~DGawj~V7aA33AUIstwh2YtBcv0pWVH0sVUnw~..." }
```

**Notes:**
- Only `{ "datadome": "<value>" }` is written — no metadata (capturedAt, username, etc.)
- Cookie name matching is case-insensitive (matches `datadome`, `DataDome`, etc.)
- If no datadome cookie is found in the context after login, `null` is returned (no file written)
- Identical capture timing to `sessionComplete` and `dataDomeOnly` formats

### Usage Examples

#### Enable with default format (sessionComplete)
```javascript
cookieExport: {
  enabled: true,
  exportDir: 'CookieExports',
  format: 'sessionComplete'
}
```

#### Enable with sessionOnly format (no Python snippet)
```javascript
cookieExport: {
  enabled: true,
  exportDir: 'MyExports',
  format: 'sessionOnly'
}
```

#### Enable with dataDomeOnly format (3 separate files)
```javascript
cookieExport: {
  enabled: true,
  exportDir: 'DataDomeExports',
  format: 'dataDomeOnly'
}
```

#### Enable with DatadomePostRequestCookieonly format (context cookie store after login)
```javascript
cookieExport: {
  enabled: true,
  exportDir: 'DataDomeExports',
  format: 'DatadomePostRequestCookieonly'
}
```

### GUI Integration

When cookie export is enabled, exported files can be managed through the web GUI:

1. **List exports:** `GET /api/cookie-exports`
2. **Download export:** `GET /api/cookie-exports/{filename}`
3. **Delete export:** `DELETE /api/cookie-exports/{filename}`

The Settings panel in the GUI provides buttons to refresh, download, and delete exports.

## Logging & Monitoring

```javascript
logging: {
  enableStructuredLogging: true,
  logLevel: 'debug',
  enableMetrics: true,
  metricsInterval: 30 * 1000
}
```

### Options Explained

#### `logLevel` (string)
Verbosity level for console output.

**Options:**
- `'debug'` - Show all messages (verbose)
- `'info'` - Show info, warnings, errors (default)
- `'warn'` - Show warnings and errors only
- `'error'` - Show errors only

#### `enableStructuredLogging` (boolean)
Enable JSONL structured logs.

**Default:** `true`  
**Recommendation:** Keep enabled for analysis

#### `enableMetrics` (boolean)
Enable real-time metrics collection.

**Default:** `true`  
**Recommendation:** Keep enabled

#### `metricsInterval` (number)
Interval for metrics updates in milliseconds.

**Default:** `30000` (30 seconds)  
**Recommended:** `10000` - `60000`

## CAS Detection Options

```javascript
casDetection: {
  tgcCookieNames: ['TGC'],
  monitoringStrategies: {
    tgc_cookie: {
      enabled: true,
      description: 'CAS Ticket Granting Cookie (99% confidence)'
    },
    redirect_location: {
      enabled: true,
      description: 'Detect redirect to /cas/'
    },
    set_cookie: {
      enabled: true,
      description: 'Detect session/auth cookies'
    },
    body_token: {
      enabled: true,
      description: 'Look for token in response body'
    },
    navigation_detected: {
      enabled: true,
      description: 'Detect URL change'
    },
    dom_username: {
      enabled: false,
      description: 'Check if username in DOM'
    },
    cookie_detect: {
      enabled: true,
      description: 'Look for auth cookies'
    }
  },
  fallbackStrategies: {
    checkTGC: true,
    checkDOM: true,
    checkCookies: true,
    checkLocalStorage: true
  }
}
```

### Monitoring Strategies

Enable/disable detection methods individually:

```javascript
monitoringStrategies: {
  tgc_cookie: { enabled: true },        // HIGHEST priority
  redirect_location: { enabled: true }, // HIGH priority
  set_cookie: { enabled: true },        // MEDIUM priority
  body_token: { enabled: true },        // MEDIUM priority
  dom_username: { enabled: false }      // LOW priority (disabled)
}
```

**Recommendation:** Keep TGC and redirect enabled, disable unreliable methods.

## Browser Context Isolation

```javascript
context: {
  ignoreHTTPSErrors: true,
  bypassCSP: true,
  strictIsolation: true
}
```

### Options Explained

#### `ignoreHTTPSErrors` (boolean)
Ignore SSL/TLS certificate errors.

**Default:** `true`  
**Use case:** Necessary when proxies use self-signed certificates

#### `bypassCSP` (boolean)
Bypass Content Security Policy.

**Default:** `true`  
**Use case:** Allows script injection for detection

#### `strictIsolation` (boolean)
Enable strict browser context isolation.

**Default:** `true`  
**Purpose:** Prevents cookie/storage leakage between tests

## Error Recovery

```javascript
errorRecovery: {
  maxRetries: 3,
  retryStrategies: {
    exponentialBackoff: true,
    backoffBase: 2,
    maxBackoffDelay: 30 * 1000
  },
  tunnelErrorThreshold: 3
}
```

### Options Explained

#### `maxRetries` (number)
Maximum retry attempts for failed operations.

**Default:** `3`  
**Recommended:** `2` - `5`

#### `exponentialBackoff` (boolean)
Use exponential backoff for retries.

**Default:** `true`  
**Formula:** delay = base^attempt * 1000 (capped at maxBackoffDelay)

#### `backoffBase` (number)
Base for exponential backoff calculation.

**Default:** `2`  
**Delays:** 2s, 4s, 8s, 16s, 30s (capped)

#### `maxBackoffDelay` (number)
Maximum delay for exponential backoff.

**Default:** `30000` (30 seconds)  
**Recommended:** `20000` - `60000`

#### `tunnelErrorThreshold` (number)
Number of consecutive tunnel errors before blacklisting proxy.

**Default:** `3`  
**Recommended:** `2` - `5`

## Testing Configuration

```javascript
test: {
  patchrightTestEnabled: true,
  testViewportWidth: 1893,
  testViewportHeight: 1279,
  testScreenshotPath: 'patchright_login_page.png'
}
```

### Options Explained

Used for initial system verification and debugging.

#### `patchrightTestEnabled` (boolean)
Enable test mode.

**Default:** `true`  
**Purpose:** Verify Patchright installation

## Environment Variables

Some settings can be overridden via environment variables:

```bash
# Override log level
LOG_LEVEL=debug node play_version2_controller.js

# Override worker timeout
WORKER_TIMEOUT=240000 node play_version2_controller.js

# Override max workers
MAX_WORKERS=8 node play_version2_controller.js
```

## Best Practices

### For Speed
```javascript
batch: {
  credentialsPerProxy: 8,
  maxParallelWorkers: 8
},
form: {
  typeDelayMin: 2,
  typeDelayMax: 5
}
```

### For Stealth
```javascript
batch: {
  credentialsPerProxy: 2,
  maxParallelWorkers: 2,
  pauseBetweenBatchMin: 5000,
  pauseBetweenBatchMax: 15000
},
form: {
  typeDelayMin: 10,
  typeDelayMax: 30
}
```

### For Reliability
```javascript
browser: {
  timeout: 300 * 1000
},
navigation: {
  timeout: 30 * 1000
},
errorRecovery: {
  maxRetries: 5
}
```

## Troubleshooting Configuration

### Workers timing out
Increase `browser.timeout` and `navigation.timeout`

### Too slow
Reduce `form.typeDelayMin/Max`, increase `batch.maxParallelWorkers`

### High detection rate
Increase delays, reduce workers, enable more browser flags

### Proxy failures
Adjust `proxy.tcpTimeout` and `proxy.blacklistTTL`

---

**Next:** [API Reference](API.md) | [Architecture](ARCHITECTURE.md)
