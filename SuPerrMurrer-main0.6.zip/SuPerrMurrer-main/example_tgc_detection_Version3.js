const { submitAndDetectCasFlow } = require('./utils/casDetection');

// Example 1: Default CAS Ticket Redirect detection (PRIMARY - OAuth2.0 callbackAuthorize)
const result = await submitAndDetectCasFlow(page, 'user@example.com', 'password123');

console.log(result);
// Output:
// {
//   ok: true,
//   type:  'success',
//   reason: 'cas_ticket_redirect',
//   confidence:  0.99,  ⭐ Highest confidence - PRIMARY
//   details: 'CAS OAuth2.0 callbackAuthorize redirect detected with ticket: ST-640785-VaZZsxTi7MZLHNeIgjoteDGW3og',
//   detectionMethod: 'cas_ticket_redirect',
//   ticket: 'ST-640785-VaZZsxTi7MZLHNeIgjoteDGW3og',
//   url: 'https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?...'
// }

// ============================================================

// Example 2: Custom TGC cookie names (if service uses different name)
const customResult = await submitAndDetectCasFlow(
  page,
  'user@example.com',
  'password123',
  {
    tgcCookieNames: ['TGC', 'CASTGC', 'CAS_TICKET'],  // Check multiple names
    verbose: true
  }
);

// ============================================================

// Example 3: Priority-based detection with CAS Ticket Redirect as PRIMARY
const detectionPriority = await submitAndDetectCasFlow(
  page,
  username,
  password,
  {
    tgcCookieNames: ['TGC'],
    monitoringStrategies: {
      cas_ticket_redirect: true,     // ⭐ Check first (99% confidence - PRIMARY)
      tgc_cookie: true,              // Check second (99% confidence - SECONDARY)
      redirect_location: true,        // Check third (99% confidence)
      set_cookie: true,              // Check fourth (85% confidence)
      body_token: true,              // Check fifth (90% confidence)
      navigation_detected: true,      // Fallback (90% confidence)
      dom_username: true,            // Fallback (80% confidence)
      cookie_detect: true            // Fallback (85% confidence)
    }
  }
);

// ============================================================

// Example 4: Integration in worker process
if (detectionPriority.ok) {
  console.log(`✅ Login successful - Detection Method: ${detectionPriority.detectionMethod}`);
  console.log(`   Confidence: ${(detectionPriority.confidence * 100).toFixed(0)}%`);
  
  if (detectionPriority.reason === 'cas_ticket_redirect') {
    console.log(`   ⭐ CAS Ticket Redirect confirmed (PRIMARY):  ${detectionPriority.ticket}`);
    console.log(`   URL: ${detectionPriority.url}`);
  } else if (detectionPriority.reason === 'tgc_cookie_detected') {
    console.log(`   🔑 TGC Cookie confirmed (SECONDARY):  ${detectionPriority.cookie.name}`);
    console.log(`   Domain: ${detectionPriority.cookie.domain}`);
    console.log(`   Secure: ${detectionPriority.cookie.secure}`);
  }
  
  processedCount++;
  metricsCollector.record('login_success', { duration: Date.now() - startTime });
} else {
  console.log(`❌ Login failed - Reason: ${detectionPriority.reason}`);
  writeFailedLine(username, password, detectionPriority.reason, batchNum);
  metricsCollector.record('login_failed', { reason: detectionPriority.reason });
}