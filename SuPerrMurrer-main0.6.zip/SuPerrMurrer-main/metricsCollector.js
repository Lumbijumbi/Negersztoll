/**
 * Real-time metrics collection and reporting
 */
const EventEmitter = require('events');

class MetricsCollector extends EventEmitter {
  constructor(options = {}) {
    super();
    this.metricsInterval = options.metricsInterval || 30 * 1000;
    this.enableConsoleOutput = options.enableConsoleOutput !== false;

    this.metrics = {
      totalAttempts: 0,
      successfulLogins: 0,
      failedLogins: 0,
      captchasDetected: 0,
      blocksDetected: 0,
      proxyFailures: 0,
      navigationErrors: 0,
      screenshotFailures: 0,
      tunnelErrors: 0,
      timeStarted: Date.now(),
      timeLastMetric: Date.now(),
      totalResponseTime: 0,
      avgResponseTime: 0,
    };

    this.detailedMetrics = {
      byReason: {},        // Count errors by reason
      byProxy: {},         // Track proxy performance
      byBatch: {},         // Track batch performance
      timeline: []         // Time-series data
    };

    this.startMetricsInterval();
  }

  /**
   * Record an event
   */
  record(event, data = {}) {
    const timestamp = Date.now();

    switch (event) {
      case 'login_success':
        this.metrics.successfulLogins++;
        this.metrics.totalAttempts++;
        this.metrics.totalResponseTime += data.duration || 0;
        break;

      case 'login_failed':
        this.metrics.failedLogins++;
        this.metrics.totalAttempts++;
        this.recordByReason(data.reason || 'unknown');
        break;

      case 'captcha': 
        this.metrics.captchasDetected++;
        this.recordByReason('captcha');
        break;

      case 'blocked':
        this.metrics.blocksDetected++;
        this.recordByReason(data.reason || 'blocked');
        break;

      case 'proxy_failure':
        this.metrics.proxyFailures++;
        this.recordByProxy(data.proxy, 'failure');
        this.recordByReason(data.reason || 'proxy_failure');
        break;

      case 'navigation_error': 
        this.metrics.navigationErrors++;
        this.recordByReason(data.reason || 'navigation');
        break;

      case 'screenshot_failure':
        this.metrics.screenshotFailures++;
        break;

      case 'tunnel_error':
        this.metrics.tunnelErrors++;
        this.recordByReason('tunnel_error');
        break;

      case 'batch_complete':
        this.recordByBatch(data.batchNum, {
          processed: data.processed,
          duration: data.duration,
          status: data.status
        });
        break;
    }

    // Record timeline entry
    this.detailedMetrics.timeline.push({
      event,
      timestamp,
      data
    });

    // Emit for external listeners (websocket, API, etc.)
    this.emit('metric', { event, timestamp, data, metrics: this.getMetrics() });
  }

  recordByReason(reason) {
    if (!this.detailedMetrics.byReason[reason]) {
      this.detailedMetrics.byReason[reason] = 0;
    }
    this.detailedMetrics.byReason[reason]++;
  }

  recordByProxy(proxy, status) {
    if (!this.detailedMetrics.byProxy[proxy]) {
      this.detailedMetrics.byProxy[proxy] = { success: 0, failure: 0 };
    }
    this.detailedMetrics.byProxy[proxy][status]++;
  }

  recordByBatch(batchNum, data) {
    this.detailedMetrics.byBatch[batchNum] = data;
  }

  /**
   * Get current metrics
   */
  getMetrics() {
    const elapsed = (Date.now() - this.metrics.timeStarted) / 1000;
    const minutesElapsed = elapsed / 60;

    return {
      ...this.metrics,
      avgResponseTime: this.metrics.totalAttempts > 0
        ? (this.metrics.totalResponseTime / this.metrics.totalAttempts).toFixed(2)
        : 0,
      successRate: this.metrics.totalAttempts > 0
        ? ((this.metrics.successfulLogins / this.metrics.totalAttempts) * 100).toFixed(2)
        : 0,
      credentialsPerMinute: minutesElapsed > 0
        ? (this.metrics.totalAttempts / minutesElapsed).toFixed(2)
        : 0,
      elapsedSeconds: elapsed.toFixed(1),
      errorBreakdown: this.detailedMetrics.byReason,
      proxyPerformance: this.detailedMetrics.byProxy,
    };
  }

  /**
   * Get report
   */
  getReport() {
    const m = this.getMetrics();
    return `
╔════════════════════════════════════════════════════════════╗
║                    METRICS REPORT                          ║
╠════════════════════════════════════════════════════════════╣
║ Total Attempts:      ${this.padRight(m.totalAttempts, 44)}║
║ Successful:           ${this.padRight(m.successfulLogins, 44)}║
║ Failed:              ${this.padRight(m.failedLogins, 44)}║
║ Success Rate:        ${this.padRight(m.successRate + '%', 44)}║
║                                                            ║
║ CAPTCHAs Detected:   ${this.padRight(m.captchasDetected, 44)}║
║ Blocks Detected:     ${this.padRight(m.blocksDetected, 44)}║
║ Tunnel Errors:       ${this.padRight(m.tunnelErrors, 44)}║
║ Proxy Failures:      ${this.padRight(m.proxyFailures, 44)}║
║                                                            ║
║ Credentials/Minute:  ${this.padRight(m.credentialsPerMinute, 44)}║
║ Avg Response Time:   ${this.padRight(m.avgResponseTime + 'ms', 44)}║
║ Elapsed Time:        ${this.padRight(m.elapsedSeconds + 's', 44)}║
╚════════════════════════════════════════════════════════════╝
    `;
  }

  padRight(str, width) {
    return String(str).padEnd(width - 2);
  }

  /**
   * Start periodic metric emission
   */
  startMetricsInterval() {
    this.metricsIntervalHandle = setInterval(() => {
      if (this.enableConsoleOutput) {
        console.log(this.getReport());
      }
      this.emit('periodic_report', this.getMetrics());
    }, this.metricsInterval);
  }

  /**
   * Stop metrics interval
   */
  stopMetricsInterval() {
    if (this.metricsIntervalHandle) {
      clearInterval(this.metricsIntervalHandle);
    }
  }

  /**
   * Reset metrics
   */
  reset() {
    this.metrics = {
      totalAttempts: 0,
      successfulLogins: 0,
      failedLogins: 0,
      captchasDetected: 0,
      blocksDetected: 0,
      proxyFailures: 0,
      navigationErrors: 0,
      screenshotFailures: 0,
      tunnelErrors: 0,
      timeStarted: Date.now(),
      timeLastMetric: Date.now(),
      totalResponseTime: 0,
      avgResponseTime: 0,
    };
  }

  /**
   * Cleanup
   */
  destroy() {
    this.stopMetricsInterval();
    this.removeAllListeners();
  }
}

module.exports = MetricsCollector;