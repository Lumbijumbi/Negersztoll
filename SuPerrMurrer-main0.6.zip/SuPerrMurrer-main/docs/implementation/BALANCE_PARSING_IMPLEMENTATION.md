# Cookie Consent & Balance Parsing Implementation

## Overview
This document describes the implementation of cookie consent popup dismissal and account balance parsing functionality added to the worker process.

## Changes Made

### 1. Configuration Updates (`config.js`)

Added new configuration section under `account` object:

```javascript
balanceSelectors: {
  points: 'span.myPointBalance-value',
  money: 'span.myMoneyBalance-value',
  timeout: 3000
},
cookiePopupSelectors: [
  '#onetrust-accept-btn-handler',
  'button[id*="cookie-accept"]',
  'button[id*="cookie-consent"]',
  '[class*="cookie-accept"]'
]
```

### 2. Logger Updates (`utils/logger.js`)

Updated `logSuccess()` method signature:
```javascript
logSuccess(username, password, method, confidence, duration, pointsBalance = null, moneyBalance = null)
```

- Added optional parameters for `pointsBalance` and `moneyBalance`
- Balance values are included in the log entry when provided
- Maintains backward compatibility (balances default to null)

### 3. Worker Process Updates (`play_version2_worker_integrated_Version5.js`)

#### a. Updated `filenameForCred()` Function

```javascript
function filenameForCred(username, password, suffix, pointsBalance = null, moneyBalance = null)
```

- Accepts optional balance parameters
- When suffix is '_ok' and balances are provided, generates filename in format:
  - `username_password_points_money.png`
- Otherwise uses original format:
  - `username_password_suffix.png`

#### b. Added `dismissCookiePopup()` Function

```javascript
async function dismissCookiePopup(page)
```

Features:
- Waits 500ms for popup to appear
- Iterates through configured selectors
- Checks if element is visible before clicking
- Non-blocking - continues execution if popup not found
- Logs dismissal action with appropriate log level
- Returns `true` if popup dismissed, `false` otherwise

#### c. Added `parseAccountBalances()` Function

```javascript
async function parseAccountBalances(page)
```

Features:
- Parses both points and money balance values
- Uses configured selectors and timeout
- Waits for elements to be visible
- Extracts and trims text content
- Gracefully handles missing elements (defaults to 'N/A')
- Logs parsing progress and errors at debug level
- Returns object: `{ pointsBalance: string, moneyBalance: string }`

#### d. Updated Account Page Flow

The new flow after successful login:

1. Navigate to account page
2. **NEW:** Dismiss cookie popup if present
3. **NEW:** Parse points and money balances
4. Take screenshot with balance values in filename
5. Logout
6. **NEW:** Log success with balance values

```javascript
// Navigate to account page and take screenshot
const accountNav = await navTo(page, config.account.url);

// Initialize balance variables
let pointsBalance = null;
let moneyBalance = null;

if (accountNav.success) {
  await sleep(200);
  
  // ⭐ Dismiss cookie consent popup if present
  await dismissCookiePopup(page);
  
  // ⭐ Parse account balances
  const balances = await parseAccountBalances(page);
  pointsBalance = balances.pointsBalance;
  moneyBalance = balances.moneyBalance;
  
  // Take screenshot with balance values in filename
  const screenshotPath = filenameForCred(username, password, '_ok', pointsBalance, moneyBalance);
  logger.debug('[SCREENSHOT]', `Taking screenshot`);
  await takeScreenshot(page, screenshotPath, username, password);
  
  // ... logout logic ...
}

// Log to advanced logger with balance values
logger.logSuccess(
  username,
  password,
  casResult.method,
  casResult.confidence,
  casDuration,
  pointsBalance,
  moneyBalance
);
```

## Success Log Format

### With Balance Values
```json
{
  "timestamp": "2026-01-25T16:04:12.102Z",
  "username": "test@user.com",
  "password": "password123",
  "method": "tgc_cookie",
  "confidence": 0.99,
  "duration": 1234,
  "category": "TGC_COOKIE",
  "pointsBalance": "6666",
  "moneyBalance": "33"
}
```

### Without Balance Values (Backward Compatible)
```json
{
  "timestamp": "2026-01-25T16:04:12.103Z",
  "username": "test2@user.com",
  "password": "password456",
  "method": "cas_ticket_redirect",
  "confidence": 0.99,
  "duration": 2345,
  "category": "CAS_TICKET_REDIRECT"
}
```

## Screenshot Filename Examples

### With Balance Values
- `test@user.com_password123_6666_33.png`
- `user@example.com_mypass_1234_50.png`
- `email@domain.com_pass_N_A_N_A.png` (when elements not found)

### Without Balance Values (Failures, Session Reuse)
- `test@user.com_password_account_failed.png`
- `user@example.com_mypass_session_reuse.png`
- `email@domain.com_pass_err.png`

## Error Handling

### Cookie Dismissal
- Non-blocking operation
- Continues execution if popup not found
- Logs at debug level for selector attempts
- Logs at success level when popup dismissed
- Never throws errors to main flow

### Balance Parsing
- Returns 'N/A' if elements not found
- Logs errors at debug level
- Uses configured timeout (default: 3000ms)
- Never throws errors to main flow
- Screenshot is still taken even if parsing fails

## Testing

Run the validation script:
```bash
node test_balance_parsing.js
```

This validates:
- Configuration is properly loaded
- Logger accepts balance parameters
- Filename generation includes balance values
- Balance selectors are accessible
- Cookie popup selectors are defined

## Backward Compatibility

All changes maintain backward compatibility:
- `logSuccess()` can be called with or without balance parameters
- `filenameForCred()` can be called with or without balance parameters
- Existing success logs without balance fields remain valid
- Session reuse and error cases work unchanged

## Future Enhancements

Potential improvements:
1. Add XPath selector support as fallback
2. Parse additional account information (tier, status, etc.)
3. Add retry logic for balance parsing
4. Support multiple balance formats (currency symbols, thousands separators)
5. Add balance value validation/sanitation
