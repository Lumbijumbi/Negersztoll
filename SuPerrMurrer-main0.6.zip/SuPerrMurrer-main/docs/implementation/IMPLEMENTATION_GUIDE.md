# Quick Implementation Guide - Next Steps

This guide provides actionable steps to implement the improvements outlined in VERIFICATION_REPORT.md.

## ✅ Completed (Week 0)

- [x] Repository verification and testing
- [x] Fixed all failing tests (4 connectionPool tests)
- [x] Created comprehensive verification report
- [x] Added Docker containerization
- [x] Created configuration templates
- [x] Added deployment documentation

## 🚀 Quick Wins (Week 1 - Priority HIGH)

### 1. Test Docker Setup (30 minutes)

```bash
# Build and test Docker image
docker-compose build
docker-compose up -d

# Verify it works
docker-compose logs -f superrmurrer

# Stop
docker-compose down
```

**Success Criteria:** Container runs and GUI accessible on port 3773

---

### 2. Implement Environment-Specific Configuration (2-4 hours)

**Create config loader:**

```javascript
// config/index.js
const path = require('path');
const defaultConfig = require('../config.js');

const env = process.env.NODE_ENV || 'development';

// Load environment-specific overrides
let envConfig = {};
try {
  envConfig = require(`./${env}.js`);
} catch (e) {
  console.log(`No config for environment: ${env}, using defaults`);
}

// Merge configurations
const config = Object.assign({}, defaultConfig, envConfig);

// Override with environment variables
if (process.env.BROWSER_HEADLESS !== undefined) {
  config.browser.headless = process.env.BROWSER_HEADLESS === 'true';
}
if (process.env.MAX_WORKERS !== undefined) {
  config.batch.maxParallelWorkers = parseInt(process.env.MAX_WORKERS);
}
// Add more overrides as needed

module.exports = config;
```

**Create environment configs:**

```javascript
// config/development.js
module.exports = {
  browser: {
    headless: false,
    dumpio: true
  },
  batch: {
    maxParallelWorkers: 2
  }
};

// config/production.js
module.exports = {
  browser: {
    headless: true,
    dumpio: false
  },
  batch: {
    maxParallelWorkers: 8
  }
};

// config/test.js
module.exports = {
  browser: {
    headless: true,
    timeout: 30000
  },
  batch: {
    maxParallelWorkers: 1
  }
};
```

**Update main files to use config/index.js:**

```javascript
// At the top of play_version2_controller.js, cli.js, gui/server.js
const config = require('./config'); // instead of './config.js'
```

**Test:**
```bash
NODE_ENV=production node cli.js
NODE_ENV=development node cli.js
```

---

### 3. Enhanced Configuration Validation (4-6 hours)

**Enhance utils/configValidator.js:**

```javascript
class ConfigValidator {
  static validate(config) {
    const errors = [];
    const warnings = [];
    const info = [];
    
    // File existence checks
    const fs = require('fs');
    if (!fs.existsSync('test.txt')) {
      errors.push('❌ test.txt not found - credential file is required');
    }
    if (!fs.existsSync('Lightning_Proxies.txt')) {
      warnings.push('⚠️  Lightning_Proxies.txt not found - proxy file recommended');
    }
    
    // Value range checks
    if (config.batch.maxParallelWorkers > 16) {
      warnings.push('⚠️  maxParallelWorkers > 16 may cause performance issues');
    }
    if (config.batch.maxParallelWorkers < 1) {
      errors.push('❌ maxParallelWorkers must be at least 1');
    }
    
    if (config.browser.timeout < 30000) {
      warnings.push('⚠️  browser.timeout < 30s may cause false failures');
    }
    
    // Check for conflicting settings
    if (config.browser.headless === false && config.batch.maxParallelWorkers > 4) {
      warnings.push('⚠️  Non-headless mode with >4 workers may impact performance');
    }
    
    // Recommendations
    if (config.activeProfile === 'balanced') {
      info.push('💡 Using balanced profile - good for most use cases');
    }
    
    return {
      valid: errors.length === 0,
      errors,
      warnings,
      info
    };
  }
  
  static printValidation(result) {
    console.log('\n🔍 Configuration Validation\n');
    
    if (result.errors.length > 0) {
      console.log('❌ ERRORS:');
      result.errors.forEach(e => console.log(`   ${e}`));
      console.log('');
    }
    
    if (result.warnings.length > 0) {
      console.log('⚠️  WARNINGS:');
      result.warnings.forEach(w => console.log(`   ${w}`));
      console.log('');
    }
    
    if (result.info.length > 0) {
      console.log('💡 INFO:');
      result.info.forEach(i => console.log(`   ${i}`));
      console.log('');
    }
    
    if (result.valid) {
      console.log('✅ Configuration is valid!\n');
    } else {
      console.log('❌ Configuration has errors - please fix them before running.\n');
    }
    
    return result.valid;
  }
}
```

**Add validation to startup:**

```javascript
// In play_version2_controller.js and cli.js
const ConfigValidator = require('./utils/configValidator');
const validationResult = ConfigValidator.validate(config);

if (!ConfigValidator.printValidation(validationResult)) {
  process.exit(1);
}
```

**Test:**
```bash
# Should show validation results
node cli.js
```

---

## ⚡ High Priority (Week 2-3)

### 4. GUI Authentication (8-12 hours)

**Install dependencies:**
```bash
npm install jsonwebtoken bcrypt express-session
```

**Create authentication middleware:**

```javascript
// middleware/auth.js
const jwt = require('jsonwebtoken');

const SECRET = process.env.JWT_SECRET || 'change-me-in-production';

function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }
  
  jwt.verify(token, SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
}

module.exports = { authenticateToken, SECRET };
```

**Add login endpoint:**

```javascript
// In gui/server.js
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { SECRET, authenticateToken } = require('../middleware/auth');

// Simple user store (replace with database in production)
const users = [
  {
    username: 'admin',
    password: await bcrypt.hash('admin', 10) // Change in production!
  }
];

// Login endpoint
app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body;
  
  const user = users.find(u => u.username === username);
  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  
  const validPassword = await bcrypt.compare(password, user.password);
  if (!validPassword) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  
  const token = jwt.sign({ username }, SECRET, { expiresIn: '24h' });
  res.json({ token, username });
});

// Protect API endpoints
app.use('/api/', authenticateToken);
```

**Add login page:**

```html
<!-- gui/public/login.html -->
<!DOCTYPE html>
<html>
<head>
  <title>Login - SuPerrMurrer</title>
  <style>
    body {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      background: #1a1a1a;
      color: #fff;
      font-family: Arial, sans-serif;
    }
    .login-box {
      background: #2a2a2a;
      padding: 40px;
      border-radius: 8px;
      box-shadow: 0 4px 6px rgba(0,0,0,0.3);
    }
    input {
      width: 100%;
      padding: 12px;
      margin: 10px 0;
      border: 1px solid #444;
      border-radius: 4px;
      background: #333;
      color: #fff;
    }
    button {
      width: 100%;
      padding: 12px;
      background: #4CAF50;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
    }
    button:hover {
      background: #45a049;
    }
    .error {
      color: #ff4444;
      margin-top: 10px;
    }
  </style>
</head>
<body>
  <div class="login-box">
    <h2>🚀 SuPerrMurrer Login</h2>
    <form id="loginForm">
      <input type="text" id="username" placeholder="Username" required>
      <input type="password" id="password" placeholder="Password" required>
      <button type="submit">Login</button>
      <div id="error" class="error"></div>
    </form>
  </div>
  
  <script>
    document.getElementById('loginForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const username = document.getElementById('username').value;
      const password = document.getElementById('password').value;
      
      try {
        const response = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password })
        });
        
        if (response.ok) {
          const { token } = await response.json();
          localStorage.setItem('token', token);
          window.location.href = '/';
        } else {
          document.getElementById('error').textContent = 'Invalid credentials';
        }
      } catch (error) {
        document.getElementById('error').textContent = 'Login failed';
      }
    });
  </script>
</body>
</html>
```

---

### 5. Prometheus Metrics Export (6-8 hours)

**Install prom-client:**
```bash
npm install prom-client
```

**Create metrics exporter:**

```javascript
// utils/prometheusExporter.js
const client = require('prom-client');

const register = new client.Registry();

// Default metrics
client.collectDefaultMetrics({ register });

// Custom metrics
const credentialsProcessed = new client.Counter({
  name: 'credentials_processed_total',
  help: 'Total number of credentials processed',
  labelNames: ['status'], // success, failure, blocked
  registers: [register]
});

const processingDuration = new client.Histogram({
  name: 'credential_processing_duration_seconds',
  help: 'Credential processing duration in seconds',
  buckets: [1, 5, 10, 30, 60, 120],
  registers: [register]
});

const activeWorkers = new client.Gauge({
  name: 'active_workers',
  help: 'Number of currently active workers',
  registers: [register]
});

const queueDepth = new client.Gauge({
  name: 'queue_depth',
  help: 'Number of items in processing queue',
  registers: [register]
});

module.exports = {
  register,
  credentialsProcessed,
  processingDuration,
  activeWorkers,
  queueDepth
};
```

**Add metrics endpoint:**

```javascript
// In gui/server.js
const { register } = require('../utils/prometheusExporter');

app.get('/metrics', async (req, res) => {
  res.set('Content-Type', register.contentType);
  res.end(await register.metrics());
});
```

**Instrument code:**

```javascript
// In play_version2_controller.js
const { credentialsProcessed, activeWorkers, queueDepth } = require('./utils/prometheusExporter');

// After processing credential
if (result.success) {
  credentialsProcessed.inc({ status: 'success' });
} else if (result.blocked) {
  credentialsProcessed.inc({ status: 'blocked' });
} else {
  credentialsProcessed.inc({ status: 'failure' });
}

// Update gauges
activeWorkers.set(currentWorkerCount);
queueDepth.set(remainingCredentials);
```

---

## 📊 Medium Priority (Week 4-6)

### 6. WebSocket Real-time Updates (8-12 hours)

**Install ws:**
```bash
npm install ws
```

**Add WebSocket server:**

```javascript
// In gui/server.js
const WebSocket = require('ws');

const wss = new WebSocket.Server({ 
  server: httpServer, // Use same HTTP server
  path: '/ws'
});

// Broadcast helper
function broadcast(data) {
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(data));
    }
  });
}

// On client connect
wss.on('connection', (ws) => {
  console.log('WebSocket client connected');
  
  ws.on('close', () => {
    console.log('WebSocket client disconnected');
  });
});

// Export broadcast for use in other modules
module.exports.broadcast = broadcast;
```

**Update progress broadcasts:**

```javascript
// When progress updates occur
const { broadcast } = require('./gui/server');

broadcast({
  type: 'progress',
  data: {
    processed: stats.processed,
    total: stats.total,
    success: stats.success,
    failed: stats.failed
  }
});
```

**Client-side WebSocket:**

```javascript
// In gui/public/index.html
const ws = new WebSocket('ws://localhost:3773/ws');

ws.onmessage = (event) => {
  const message = JSON.parse(event.data);
  
  if (message.type === 'progress') {
    updateProgressBar(message.data);
  }
};
```

---

## 🎯 Lower Priority (Week 7+)

### 7. Rate Limiting Per Proxy
### 8. Hot-Reload Configuration
### 9. Distributed Worker Architecture

See VERIFICATION_REPORT.md for detailed implementation plans.

---

## Testing Each Feature

After implementing each feature:

```bash
# Run tests
npm test

# Test specific module
npm test -- utils/configValidator.test.js

# Start application
npm start

# Test GUI
npm run gui
```

---

## Success Metrics

- [ ] Docker container builds successfully
- [ ] Environment configs load correctly
- [ ] Config validation shows helpful messages
- [ ] GUI authentication works
- [ ] Prometheus metrics are exported
- [ ] WebSocket updates work in real-time
- [ ] All tests pass
- [ ] No new security vulnerabilities

---

## Getting Help

- Check VERIFICATION_REPORT.md for detailed information
- Check docs/ directory for guides
- Review existing code patterns
- Ask questions in GitHub issues

---

**Version:** 1.0  
**Last Updated:** February 18, 2026
