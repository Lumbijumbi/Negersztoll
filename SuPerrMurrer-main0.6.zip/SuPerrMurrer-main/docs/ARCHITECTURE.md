# Architecture Deep Dive

This document provides a detailed analysis of the SuPerrMurrer system architecture, including design decisions, data flow, and component interactions.

## Table of Contents

- [System Overview](#system-overview)
- [Architecture Pattern](#architecture-pattern)
- [Component Breakdown](#component-breakdown)
- [Data Flow](#data-flow)
- [Process Communication](#process-communication)
- [State Management](#state-management)
- [Error Handling Strategy](#error-handling-strategy)
- [Performance Considerations](#performance-considerations)
- [Security Architecture](#security-architecture)

## System Overview

SuPerrMurrer is a distributed credential testing system built on a **Controller-Worker** pattern using Node.js child processes. The architecture prioritizes:

1. **Parallel Processing** - Multiple workers for throughput
2. **Isolation** - Each worker has independent browser context
3. **Fault Tolerance** - Workers can fail without affecting others
4. **Resource Management** - Controlled concurrency limits
5. **Observable** - Comprehensive logging and metrics

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         USER SPACE                               │
│                                                                   │
│  Input Files:                  Configuration:                    │
│  ├─ test.txt                   └─ config.js                      │
│  └─ Lightning_Proxies.txt                                        │
└───────────────────┬─────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────────────────────────┐
│                    CONTROLLER PROCESS                             │
│              (play_version2_controller.js)                        │
│                                                                   │
│  Components:                                                      │
│  ├─ File Reader (credentials, proxies)                          │
│  ├─ Batch Scheduler                                              │
│  ├─ Worker Manager                                               │
│  ├─ IPC Handler                                                  │
│  ├─ Results Aggregator                                           │
│  └─ Metrics Reporter                                             │
│                                                                   │
│  State:                                                           │
│  ├─ Active workers (Set)                                         │
│  ├─ Batch queue (Array)                                          │
│  ├─ Global counters                                              │
│  └─ Results accumulator                                          │
└───────┬───────────────┬───────────────┬───────────────┬─────────┘
        │               │               │               │
        │ fork()        │ fork()        │ fork()        │ fork()
        ▼               ▼               ▼               ▼
   ┌─────────┐     ┌─────────┐     ┌─────────┐     ┌─────────┐
   │ Worker 1│     │ Worker 2│     │ Worker 3│     │ Worker 4│
   └────┬────┘     └────┬────┘     └────┬────┘     └────┬────┘
        │               │               │               │
   ┌────┴────────────────┴───────────────┴───────────────┴────┐
   │              WORKER PROCESS LAYER                          │
   │       (play_version2_worker_integrated_Version5.js)        │
   │                                                            │
   │  Each Worker Contains:                                     │
   │  ├─ Browser Launcher                                       │
   │  ├─ Proxy Manager                                          │
   │  ├─ Credential Processor                                   │
   │  ├─ Form Filler                                            │
   │  ├─ CAS Detector                                           │
   │  ├─ Screenshot Manager                                     │
   │  └─ Result Reporter                                        │
   └──────────────────────┬─────────────────────────────────────┘
                          │
                          ▼
   ┌──────────────────────────────────────────────────────────┐
   │                   UTILITY LAYER                           │
   │                                                            │
   │  ├─ logger.js          - Structured logging              │
   │  ├─ casDetection.js    - Auth detection                  │
   │  ├─ formFill.js        - Form automation                 │
   │  ├─ formSubmit.js      - Submit handling                 │
   │  ├─ errorRecovery.js   - Retry logic                     │
   │  └─ metricsCollector.js - Metrics tracking               │
   └──────────────────────┬─────────────────────────────────────┘
                          │
                          ▼
   ┌──────────────────────────────────────────────────────────┐
   │                 EXTERNAL DEPENDENCIES                      │
   │                                                            │
   │  ├─ Patchright (Playwright) - Browser automation         │
   │  ├─ proxy-chain         - Proxy tunneling                │
   │  └─ Chrome Browser      - Rendering engine               │
   └──────────────────────┬─────────────────────────────────────┘
                          │
                          ▼
   ┌──────────────────────────────────────────────────────────┐
   │                    OUTPUT LAYER                           │
   │                                                            │
   │  logs/                                                     │
   │  ├─ successful/     - Success logs (JSONL)               │
   │  ├─ failed/         - Failure logs (JSONL)               │
   │  ├─ blocked/        - Blocked accounts                    │
   │  ├─ captcha/        - CAPTCHA encounters                  │
   │  ├─ screenshots/    - Browser screenshots                 │
   │  └─ reports/        - CSV and JSON reports                │
   └────────────────────────────────────────────────────────────┘
```

## Architecture Pattern

### Controller-Worker Pattern

The system uses a **Master-Slave** (Controller-Worker) pattern:

**Controller (Master)**
- Single process
- Manages work distribution
- Monitors worker health
- Aggregates results
- No heavy computation

**Workers (Slaves)**
- Multiple processes
- Independent execution
- Browser automation
- CPU/memory intensive
- Report results back

### Why This Pattern?

1. **Scalability**: Easy to add more workers
2. **Isolation**: Worker crashes don't affect controller
3. **Resource Control**: Limit concurrent browsers
4. **Simplicity**: Clear separation of concerns

### Alternative Patterns Considered

#### Thread Pool
**Rejected**: Node.js is single-threaded, worker_threads don't support browser automation well.

#### Message Queue
**Rejected**: Adds complexity, overkill for single-machine deployment.

#### Async/Await Only
**Rejected**: Doesn't provide process isolation, harder to limit concurrency.

## Component Breakdown

### 1. Controller Process

**File:** `play_version2_controller.js`

**Responsibilities:**
- Read input files
- Create credential batches
- Spawn worker processes
- Monitor worker timeouts
- Collect results
- Generate reports

**Key Classes/Functions:**

```javascript
// File reading
readCredentials(filepath) → Array<{username, password, index}>
readProxies(filepath) → Array<string>

// Worker management
launchWorkerForSlice(slice, proxy, batchNum) → Promise<Result>

// Main loop
(async () => { ... })()  // IIFE for async main
```

**State Management:**
```javascript
{
  activeWorkers: Set<Promise>,     // Currently running workers
  batchResults: Array<Result>,      // Completed results
  totalProcessed: number,           // Counter
  totalSuccessful: number,          // Counter
  totalTGC: number,                 // Counter
  totalRedirect302: number,         // Counter
  totalBlocked: number,             // Counter
  totalCaptchas: number             // Counter
}
```

### 2. Worker Process

**File:** `play_version2_worker_integrated_Version5.js`

**Responsibilities:**
- Receive credential batch via environment variables
- Launch browser with proxy
- Test each credential
- Perform CAS detection
- Capture screenshots
- Report results to controller

**Key Classes/Functions:**

```javascript
// Proxy management
loadBlacklist() → void
isBlacklisted(proxy) → boolean
testProxyTcp(proxy) → Promise<boolean>

// Browser lifecycle
launchBrowserWithProxy(proxy) → Promise<Browser>
closeBrowser(browser) → Promise<void>

// Credential testing
processCredentials(browser, credentials) → Promise<Stats>
testSingleCredential(page, cred) → Promise<Result>

// Main entry
(async () => { ... })()  // Worker main
```

**State Management:**
```javascript
{
  browser: Browser | null,
  context: BrowserContext | null,
  page: Page | null,
  stats: {
    totalAttempts: number,
    successful: number,
    tgcSuccess: number,
    redirect302Success: number,
    captchas: number,
    blocked: number,
    failed: number
  }
}
```

### 3. Logging System

**File:** `logger.js`

**Class:** `AdvancedLogger`

**Features:**
- Colored console output
- JSONL file logging
- Progress bars
- Result categorization
- CSV/JSON exports

**Architecture:**
```javascript
class AdvancedLogger {
  constructor(options)
  
  // Console logging
  log(level, prefix, message, data)
  debug(), info(), warn(), error(), success()
  
  // Progress tracking
  progressBar(current, total, prefix, barLength)
  clearProgressBar()
  
  // Result logging
  logSuccess(username, password, method, confidence, duration)
  logFailed(username, password, reason, details)
  logBlocked(username, password, reason, batchNum)
  logCaptcha(username, password, version, batchNum)
  
  // File operations
  writeSuccessFile(entry)
  writeFailedFile(entry)
  
  // Reporting
  generateSummaryReport()
  exportResults(format)
}
```

**Storage Strategy:**
- **Append-only JSONL** for real-time logging
- **JSON** for final aggregated reports
- **CSV** for spreadsheet compatibility

### 4. CAS Detection System

**File:** `casDetection.js`

**Main Function:** `submitAndDetectCasFlow(page, username, password, opts)`

**Detection Strategies:**

```javascript
const strategies = [
  {
    name: 'tgc_cookie',
    confidence: 0.99,
    check: async () => {
      const cookies = await page.cookies();
      return cookies.find(c => c.name === 'TGC');
    }
  },
  {
    name: 'cas_ticket_redirect',
    confidence: 0.99,
    check: async () => {
      const url = page.url();
      return /ticket=ST-/.test(url);
    }
  },
  {
    name: 'oidc_authorize',
    confidence: 0.95,
    check: async () => {
      const url = page.url();
      return url.includes('/cas/oidc/authorize');
    }
  },
  // ... more strategies
];
```

**Detection Flow:**
1. Submit form
2. Monitor requests/responses
3. Check strategies in priority order
4. Return first match above threshold
5. Fallback to lower confidence methods

### 5. Form Automation

**File:** `formFill.js`

**Strategy:** Multi-level fallback

```javascript
async function fastFill(page, selector, text, options) {
  // Level 1: Character-by-character typing
  try {
    for (const char of text) {
      await page.type(selector, char, { delay: random(4, 10) });
    }
    if (await verify()) return true;
  } catch (e) {}
  
  // Level 2: page.fill() method
  try {
    await page.fill(selector, text);
    if (await verify()) return true;
  } catch (e) {}
  
  // Level 3: Direct DOM manipulation
  try {
    await page.evaluate((sel, val) => {
      document.querySelector(sel).value = val;
      // Trigger events
    }, selector, text);
    if (await verify()) return true;
  } catch (e) {}
  
  return false;  // All methods failed
}
```

### 6. Error Recovery

**File:** `errorRecovery.js`

**Pattern:** Exponential Backoff with Jitter

```javascript
async function retryWithBackoff(fn, options) {
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      if (!shouldRetry(error, attempt)) throw error;
      
      const delay = Math.min(
        Math.pow(2, attempt) * 1000,  // Exponential
        maxBackoffDelay
      );
      
      await sleep(delay);
    }
  }
  throw new Error('Max retries exceeded');
}
```

**Error Classification:**
```javascript
{
  NETWORK: { transient: true, recoverable: true },
  TIMEOUT: { transient: true, recoverable: true },
  BLOCKED: { transient: false, recoverable: false },
  NOT_FOUND: { transient: false, recoverable: false },
  BROWSER_CRASH: { transient: true, recoverable: true }
}
```

## Data Flow

### 1. Initialization Flow

```
Start
  ↓
Controller reads config.js
  ↓
Controller reads test.txt → Parse credentials
  ↓
Controller reads Lightning_Proxies.txt → Parse proxies
  ↓
Controller creates batches (4 creds each)
  ↓
Controller initializes logger
  ↓
Ready to spawn workers
```

### 2. Worker Lifecycle

```
Controller spawns worker (fork)
  ↓
Worker receives environment variables:
  - UPSTREAM (proxy)
  - SLICE (credentials JSON)
  - PROXIES (proxy list JSON)
  - BATCH_NUM
  ↓
Worker initializes:
  - Load blacklisted proxies
  - Check proxy TCP connectivity
  - Launch browser with proxy
  ↓
Worker processes credentials:
  FOR EACH credential:
    - Navigate to login page
    - Fill username & password
    - Submit form
    - Detect success/failure
    - Capture screenshot
    - Log result
  ↓
Worker sends IPC message to controller:
  {
    status: 'ok' | 'blocked' | 'failed',
    processed: number,
    stats: { ... }
  }
  ↓
Worker exits
  ↓
Controller receives exit event
  ↓
Controller aggregates results
  ↓
Controller spawns next worker (if any)
```

### 3. Detection Flow

```
Submit form
  ↓
Start monitoring (12 seconds)
  ↓
PARALLEL:
  ├─ Monitor requests/responses
  ├─ Check TGC cookie every 300ms
  ├─ Check URL changes
  └─ Check page content
  ↓
First match found?
  ├─ YES → Return result with confidence
  └─ NO → Continue monitoring
  ↓
Timeout reached?
  ├─ YES → Return failure
  └─ NO → Continue monitoring
```

### 4. Result Flow

```
Worker completes credential test
  ↓
Determine result type:
  - Success (confidence >= 85%)
  - Failed
  - Blocked
  - CAPTCHA
  ↓
Log to appropriate file:
  - logs/successful/*.jsonl
  - logs/failed/*.jsonl
  - logs/blocked/*.jsonl
  - logs/captcha/*.jsonl
  ↓
Update worker stats
  ↓
Worker sends stats to controller via IPC
  ↓
Controller updates global stats
  ↓
Controller displays progress
  ↓
On completion:
  - Export CSV reports
  - Export JSON reports
  - Display final summary
```

## Process Communication

### IPC (Inter-Process Communication)

**Channel:** Node.js built-in IPC via `child_process.fork()`

**Messages: Worker → Controller**

```javascript
// Success message
{
  status: 'ok',
  processed: 4,
  stats: {
    totalAttempts: 4,
    successful: 2,
    tgcSuccess: 1,
    redirect302Success: 1,
    captchas: 0,
    blocked: 0,
    failed: 2
  }
}

// Blocked message
{
  status: 'blocked',
  reason: 'IP blocked by target',
  processed: 2,
  failedCred: { username: 'user@example.com' }
}

// Failed message
{
  status: 'failed',
  reason: 'Browser launch failed',
  processed: 0
}
```

**Sending (Worker):**
```javascript
process.send({
  status: 'ok',
  processed: count,
  stats: stats
});
```

**Receiving (Controller):**
```javascript
child.on('message', (msg) => {
  if (msg.status === 'ok') {
    // Handle success
  }
});
```

### Timeout Mechanism

**Controller-side:**
```javascript
const timeout = setTimeout(() => {
  child.kill('SIGTERM');  // Graceful
  setTimeout(() => {
    child.kill('SIGKILL');  // Forceful
  }, 5000);
}, 180000);  // 3 minutes

child.on('message', () => {
  clearTimeout(timeout);  // Cancel on success
});
```

## State Management

### Controller State

**Global Variables:**
- Simple counters (totalProcessed, totalSuccessful, etc.)
- Collections (activeWorkers Set, batchResults Array)

**Why not Redux/MobX?**
- Overkill for single-process state
- No UI to react to changes
- Simple counters are sufficient

### Worker State

**Instance Variables:**
- Browser instance
- Current page
- Statistics object

**Lifecycle:**
- Created on worker start
- Updated during execution
- Sent to controller on completion
- Destroyed on worker exit

### Shared State

**Files as State:**
- `bad_proxies.txt` - Shared blacklist
- `logs/*.jsonl` - Append-only event log

**Synchronization:**
- Append-only writes (no conflicts)
- Each worker has unique log file per day
- Controller aggregates at end

## Error Handling Strategy

### Error Categories

1. **Transient Errors** (Retry)
   - Network timeouts
   - Proxy connection failures
   - Browser crashes
   
2. **Permanent Errors** (Don't Retry)
   - Invalid credentials
   - Blocked accounts
   - 404 Not Found

3. **Rate Limit Errors** (Backoff)
   - CAPTCHA detection
   - Suspicious behavior messages
   - HTTP 429

### Handling Strategy

```javascript
try {
  await operation();
} catch (error) {
  const classification = classifyError(error);
  
  if (classification.recoverable) {
    await retryWithBackoff(operation, {
      maxRetries: 3,
      shouldRetry: (err, attempt) => {
        return classification.isTransient;
      }
    });
  } else {
    logError(error);
    // Don't retry
  }
}
```

### Graceful Degradation

1. **Proxy Failure** → Try another proxy
2. **Browser Crash** → Relaunch browser
3. **Form Fill Failure** → Try fallback methods
4. **Detection Failure** → Use lower confidence methods
5. **Screenshot Failure** → Continue without screenshot

## Performance Considerations

### Bottlenecks

1. **Browser Launch** (~5 seconds per worker)
   - **Mitigation:** Reuse browser for multiple credentials
   
2. **Network Latency** (proxy-dependent)
   - **Mitigation:** Parallel workers, proxy quality checks
   
3. **Form Filling** (character-by-character typing)
   - **Mitigation:** Configurable delays, fallback to fast methods

### Optimization Strategies

#### Concurrency
```javascript
// Balance between speed and resources
maxParallelWorkers: 4  // Tune based on CPU/memory
```

#### Batching
```javascript
// More credentials per worker = less overhead
credentialsPerProxy: 4  // Reduce browser relaunches
```

#### Browser Reuse
- Worker tests multiple credentials in same browser session
- Reduces launch overhead from 5s per credential to 5s per batch

### Resource Usage

**Per Worker:**
- CPU: ~25-50% of 1 core
- Memory: ~500MB-1GB
- Network: Variable (depends on proxy)

**System Requirements:**
- 4 workers: 4 cores, 8GB RAM
- 8 workers: 8 cores, 16GB RAM

### Throughput Calculation

```
Throughput = (credentialsPerProxy × maxParallelWorkers) / avgTimePerBatch

Example:
- credentialsPerProxy: 4
- maxParallelWorkers: 4
- avgTimePerBatch: 60 seconds

Throughput = (4 × 4) / 60 = 0.267 credentials/second
           = 16 credentials/minute
           = 960 credentials/hour
```

## Security Architecture

### Threat Model

**Threats:**
1. Credential leakage in logs
2. Man-in-the-middle attacks
3. Proxy provider logging
4. Rate limiting / detection
5. Account lockouts

### Mitigations

#### 1. Credential Protection
```javascript
// ✅ Good: Restricted file permissions
chmod 600 test.txt

// ✅ Good: Logs in isolated directory
logs/ (chmod 700)

// ❌ Bad: Credentials in version control
// Don't commit test.txt
```

#### 2. Proxy Security
```javascript
// ✅ Good: HTTPS proxies
http://proxy.example.com:8080

// ✅ Good: Authenticated proxies
http://user:pass@proxy.example.com:8080

// ⚠️ Risky: Verify proxy provider trustworthiness
```

#### 3. Rate Limiting
```javascript
// ✅ Good: Random delays
pauseBetweenBatchMin: 1000,
pauseBetweenBatchMax: 5000

// ✅ Good: Proxy rotation
// Different IP per batch

// ✅ Good: Human-like typing
typeDelayMin: 4,
typeDelayMax: 10
```

#### 4. Detection Avoidance
```javascript
// ✅ Good: Use real Chrome
channel: 'chrome'

// ✅ Good: Disable automation flags
args: ['--disable-blink-features=AutomationControlled']

// ✅ Good: Random user agents (future)
```

### Privacy Considerations

**What's Logged:**
- Usernames (in logs)
- Passwords (in logs) ⚠️
- Timestamps
- IP addresses (proxy addresses)
- Success/failure results

**Best Practices:**
1. Secure log directory
2. Encrypt logs at rest (optional)
3. Purge old logs regularly
4. Use minimal logging in production

## Extensibility

### Adding New Detection Methods

1. Add to `casDetection.js`:
```javascript
async function detectNewMethod(page) {
  // Your detection logic
  return { ok: true, confidence: 0.90 };
}
```

2. Add to confidence thresholds in `config.js`:
```javascript
confidenceThresholds: {
  new_method: { minConfidence: 0.90, category: 'NEW_METHOD' }
}
```

3. Update detection flow to call new method

### Supporting New Target Sites

1. Update `config.js`:
```javascript
login: {
  url: 'https://new-site.com/login',
  usernameSelector: '#email',
  passwordSelector: '#pass',
  submitSelectors: ['button[type="submit"]']
}
```

2. Update detection logic if needed:
```javascript
// Adjust CAS detection for new auth flow
```

### Adding New Output Formats

1. Extend `logger.js`:
```javascript
exportResults(format) {
  if (format === 'xml') {
    this.exportXML();
  }
}
```

## Future Architecture Improvements

### 1. Distributed Architecture
```
Controller → Message Queue → Multiple Machines (Workers)
```

### 2. Database Storage
```
Worker → Database → Web UI
```

### 3. Real-time Monitoring
```
Worker → WebSocket → Dashboard
```

### 4. Plugin System
```
Core → Plugin API → Custom Detectors
```

---

**Next:** [Detection Strategies](DETECTION.md) | [API Reference](API.md)
