# Documentation Index

Welcome to the SuPerrMurrer documentation! This index will help you find what you need quickly.

## 📚 Getting Started

New to SuPerrMurrer? Start here:

1. **[Quick Start Guide](QUICKSTART.md)** - Get up and running in 5 minutes
2. **[Installation Guide](../README.md#-installation)** - Detailed installation instructions
3. **[Configuration Guide](CONFIGURATION.md)** - Configure your setup
4. **[Usage Examples](../README.md#-usage)** - Basic usage patterns

## 📖 Core Documentation

### User Guides

- **[README](../README.md)** - Project overview, features, and quick start
- **[Quick Start](QUICKSTART.md)** - 5-minute setup guide
- **[Configuration](CONFIGURATION.md)** - Comprehensive configuration reference
- **[Advanced Usage](ADVANCED_USAGE.md)** - Power user features and tips
- **[Troubleshooting](TROUBLESHOOTING.md)** - Common issues and solutions

### Technical Documentation

- **[Architecture](ARCHITECTURE.md)** - System design and internals
- **[API Reference](API.md)** - Complete API documentation
- **[Detection Strategies](DETECTION.md)** - How CAS/OAuth detection works

### Specialized Guides

- **[Traffic Optimization](TRAFFIC_OPTIMIZATION.md)** - Reduce proxy bandwidth by 60-85%
- **[Docker Deployment](DOCKER_DEPLOYMENT.md)** - Container deployment guide
- **[Combo Extractor](COMBO_EXTRACTOR.md)** - Python utility for credential extraction
- **[Project Tracking](PROJECT_TRACKING_QUICKSTART.md)** - Development tracking tools

## 🚀 Development Documentation

### For Contributors

- **[Contributing Guide](../CONTRIBUTING.md)** - How to contribute
- **[Code of Conduct](../CODE_OF_CONDUCT.md)** - Community guidelines
- **[Testing Guide](../tests/README.md)** - Test suite documentation

### Project Status & Planning

Located in [`/docs/status/`](status/):

- **[Development Plan](status/DEVELOPMENT_PLAN.md)** - Comprehensive v3.0 roadmap (1,237 lines)
- **[Project Status](status/PROJECT_STATUS.md)** - Real-time development tracking
- **[Features Roadmap](status/FEATURES_ROADMAP.md)** - Feature planning and milestones

### Implementation Documentation

Located in [`/docs/implementation/`](implementation/):

- **[Implementation Summary](implementation/IMPLEMENTATION_SUMMARY.md)** - Completed features
- **[Implementation Guide](implementation/IMPLEMENTATION_GUIDE.md)** - Implementation details
- **[Verification Report](implementation/VERIFICATION_REPORT.md)** - Testing and verification
- **[Test Implementation](implementation/TEST_IMPLEMENTATION_SUMMARY.md)** - Test suite development
- **[Test Summary](implementation/TEST_SUMMARY.md)** - Test coverage overview
- **[Workflow Implementation](implementation/WORKFLOW_IMPLEMENTATION_SUMMARY.md)** - Workflow features
- **[Traffic Optimization](implementation/TRAFFIC_OPTIMIZATION_SUMMARY.md)** - Optimization results
- **[Performance Optimization](implementation/PERFORMANCE_OPTIMIZATION_REPORT.md)** - Performance improvements
- **[Balance Parsing](implementation/BALANCE_PARSING_IMPLEMENTATION.md)** - Balance extraction feature

### Guides & Resolution

Located in [`/docs/guides/`](guides/):

- **[Development Plan Summary](guides/DEVELOPMENT_PLAN_SUMMARY.md)** - Executive summary
- **[Project Summary](guides/SUMMARY.md)** - Overall project summary
- **[Issue Resolution Report](guides/ISSUE_RESOLUTION_REPORT.md)** - Bug fixes and solutions
- **[Conflict Resolution](guides/CONFLICT_RESOLUTION.md)** - Resolving merge conflicts
- **[PR Resolution Guide](guides/PR3_RESOLUTION_GUIDE.md)** - Pull request guidance

## 🔒 Security & Policies

- **[Security Policy](../SECURITY.md)** - Vulnerability reporting and security best practices
- **[License](../LICENSE)** - MIT License with educational use disclaimer
- **[Code of Conduct](../CODE_OF_CONDUCT.md)** - Community standards and ethics

## 📝 Reference

### Configuration Files

- **`config.js`** - Main configuration file
- **`.env.example`** - Environment variables template
- **`config/README.md`** - Configuration management guide

### Data Files

- **`test.txt`** - Credentials input (format: `username:password`)
- **`Lightning_Proxies.txt`** - Proxy list
- **`retry_queue.json`** - Retry queue persistence
- **`sessions/*.json`** - Session cookie storage

### Output Files

- **`logs/successful/`** - Success logs (JSONL)
- **`logs/failed/`** - Failure logs (JSONL)
- **`logs/blocked/`** - Blocked accounts
- **`logs/captcha/`** - CAPTCHA detections
- **`logs/screenshots/`** - Browser screenshots
- **`logs/reports/`** - CSV and JSON reports

## 🛠️ Tools & Utilities

### Python Scripts

Located in [`/scripts/`](../scripts/):

- **`combo_extractor.py`** - GUI tool for extracting credentials from text files
- **`extractor_core.py`** - Core extraction logic

### Node.js Utilities

Located in [`/utils/`](../utils/):

- **Logging**: `logger.js`, `enhancedConsole.js`, `progressDashboard.js`
- **Detection**: `casDetection.js`, `formSubmit.js`
- **Queue Management**: `retryQueue.js`, `comboQueue.js`
- **Session**: `sessionManager.js`, `sessionState.js`, `credentialHistory.js`
- **Configuration**: `configValidator.js`, `configHelper.js`, `configProfiles.js`
- **System**: `healthCheck.js`, `resourceManager.js`, `autoRecovery.js`
- **UI**: `interactiveMenu.js`, `interactiveCLI.js`

## 📊 Quick Reference

### Common Tasks

| Task | Documentation |
|------|---------------|
| First time setup | [Quick Start](QUICKSTART.md) |
| Configure workers | [Configuration § Batch](CONFIGURATION.md#batch--worker-configuration) |
| Add proxies | [Configuration § Proxy](CONFIGURATION.md#proxy-configuration) |
| Enable retries | [Configuration § Retry](CONFIGURATION.md#retry-configuration) |
| Setup webhooks | [README § Webhooks](../README.md#webhook-notifications) |
| Reduce bandwidth | [Traffic Optimization](TRAFFIC_OPTIMIZATION.md) |
| Fix errors | [Troubleshooting](TROUBLESHOOTING.md) |
| Run tests | [Testing Guide](../tests/README.md) |
| Contribute code | [Contributing](../CONTRIBUTING.md) |
| Report security issue | [Security Policy](../SECURITY.md#reporting-a-vulnerability) |

### Architecture Overview

```
Controller (play_version2_controller.js)
    │
    ├── Reads credentials (test.txt)
    ├── Reads proxies (Lightning_Proxies.txt)
    ├── Creates batches
    │
    └── Spawns Workers (play_version2_worker_integrated_Version5.js)
         │
         ├── Launches browser with proxy
         ├── Tests credentials
         ├── Performs CAS detection
         ├── Captures screenshots
         └── Reports results
```

See [Architecture](ARCHITECTURE.md) for detailed information.

### Detection Methods (Confidence Scores)

1. **TGC Cookie** (99%) - CAS Ticket Granting Cookie
2. **CAS Ticket** (99%) - Redirect with `ticket=ST-` parameter
3. **OIDC** (95%) - OAuth/OIDC authorization flow
4. **Body Token** (90%) - Authentication token in response
5. **Set-Cookie** (85%) - Session cookies in headers

See [Detection Strategies](DETECTION.md) for details.

## 🔍 Search Tips

### Finding Information

- **Installation issues?** → [Quick Start](QUICKSTART.md) or [Troubleshooting](TROUBLESHOOTING.md)
- **Configuration options?** → [Configuration](CONFIGURATION.md)
- **How does X work?** → [Architecture](ARCHITECTURE.md) or [API](API.md)
- **Error messages?** → [Troubleshooting](TROUBLESHOOTING.md)
- **Contributing?** → [Contributing](../CONTRIBUTING.md)
- **Project status?** → [Project Status](status/PROJECT_STATUS.md)
- **Implementation details?** → [Implementation docs](implementation/)

### Documentation Structure

```
docs/
├── INDEX.md (this file)          # Documentation index
├── QUICKSTART.md                  # 5-minute setup
├── CONFIGURATION.md               # Config reference
├── ARCHITECTURE.md                # System design
├── API.md                         # API documentation
├── DETECTION.md                   # Detection strategies
├── ADVANCED_USAGE.md              # Power user guide
├── TROUBLESHOOTING.md             # Problem solving
├── TRAFFIC_OPTIMIZATION.md        # Network optimization
├── DOCKER_DEPLOYMENT.md           # Container deployment
├── PROJECT_TRACKING_QUICKSTART.md # Project tracking
├── COMBO_EXTRACTOR.md             # Python utility
│
├── status/                        # Project planning
│   ├── DEVELOPMENT_PLAN.md
│   ├── PROJECT_STATUS.md
│   └── FEATURES_ROADMAP.md
│
├── implementation/                # Implementation docs
│   ├── IMPLEMENTATION_SUMMARY.md
│   ├── IMPLEMENTATION_GUIDE.md
│   ├── VERIFICATION_REPORT.md
│   └── ... (10 implementation docs)
│
└── guides/                        # Guides & resolutions
    ├── DEVELOPMENT_PLAN_SUMMARY.md
    ├── SUMMARY.md
    ├── ISSUE_RESOLUTION_REPORT.md
    └── ... (5 guide docs)
```

## 📞 Getting Help

### Resources

1. **Documentation** - Start with this index
2. **README** - [Project overview](../README.md)
3. **Troubleshooting** - [Common issues](TROUBLESHOOTING.md)
4. **GitHub Issues** - [Search existing issues](https://github.com/Lumbijumbi/SuPerrMurrer/issues)
5. **Security** - [Security policy](../SECURITY.md)

### Reporting Issues

- **Bug?** → Use [bug report template](../.github/ISSUE_TEMPLATE/bug_report.md)
- **Feature idea?** → Use [feature request template](../.github/ISSUE_TEMPLATE/feature_request.md)
- **Docs issue?** → Use [documentation template](../.github/ISSUE_TEMPLATE/documentation.md)
- **Security?** → Follow [security policy](../SECURITY.md#reporting-a-vulnerability)

## 🔄 Document Updates

This documentation is continuously updated. Last major reorganization: 2026-03-04

### Recent Changes

- ✅ Reorganized documentation structure
- ✅ Created status/, implementation/, and guides/ directories
- ✅ Added LICENSE, SECURITY.md, CODE_OF_CONDUCT.md
- ✅ Created GitHub issue and PR templates
- ✅ Added CODEOWNERS file
- ✅ Created this documentation index

### Contributing to Docs

Found an error or want to improve documentation? See [Contributing Guide](../CONTRIBUTING.md#documentation).

---

**Need something not listed here?** [Open a documentation issue](https://github.com/Lumbijumbi/SuPerrMurrer/issues/new?template=documentation.md)
