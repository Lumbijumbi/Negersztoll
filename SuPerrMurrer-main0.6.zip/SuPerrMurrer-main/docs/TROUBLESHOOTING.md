# Troubleshooting Guide

Common issues and solutions for SuPerrMurrer.

## Table of Contents

- [Installation Issues](#installation-issues)
- [Browser Launch Issues](#browser-launch-issues)
- [Proxy Issues](#proxy-issues)
- [Detection Issues](#detection-issues)
- [Performance Issues](#performance-issues)
- [Worker Issues](#worker-issues)
- [Logging Issues](#logging-issues)
- [Target Site Issues](#target-site-issues)

---

## Installation Issues

### Error: Cannot find module 'patchright'

**Symptoms:**
```
Error: Cannot find module 'patchright'
```

**Cause:** Patchright not installed

**Solution:**
```bash
npm install patchright
```

### Error: Cannot find module 'proxy-chain'

**Symptoms:**
```
Error: Cannot find module 'proxy-chain'
```

**Solution:**
```bash
npm install proxy-chain
```

### Chrome Binary Not Found

**Symptoms:**
```
Error: Failed to launch chrome! No Chromium/Chrome installation found
```

**Solutions:**

**Linux:**
```bash
# Install Chrome
wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
sudo dpkg -i google-chrome-stable_current_amd64.deb
sudo apt-get install -f
```

**macOS:**
```bash
# Install Chrome via Homebrew
brew install --cask google-chrome
```

**Windows:**
Download and install from: https://www.google.com/chrome/

### Permission Denied Errors

**Symptoms:**
```
Error: EACCES: permission denied, mkdir 'logs'
```

**Solution:**
```bash
# Fix directory permissions
chmod 755 .
chmod -R 755 logs/
```

---

## Browser Launch Issues

### Error: Browser Launch Timeout

**Symptoms:**
```
[WORKER] Browser launch timeout after 180000ms
```

**Causes:**
1. Slow system/insufficient resources
2. Proxy connection issues
3. Firewall blocking browser

**Solutions:**

**Increase timeout:**
```javascript
// config.js
browser: {
  timeout: 300 * 1000  // 5 minutes
}
```

**Reduce parallel workers:**
```javascript
batch: {
  maxParallelWorkers: 2  // Reduce from 4
}
```

**Check system resources:**
```bash
# Check memory
free -h

# Check CPU
top

# Check disk space
df -h
```

### Error: Browser Crashed

**Symptoms:**
```
[WORKER] Browser process crashed
```

**Causes:**
1. Out of memory
2. GPU issues
3. Corrupted browser installation

**Solutions:**

**Add more Chrome flags:**
```javascript
// config.js
browser: {
  args: [
    '--disable-gpu',
    '--no-sandbox',
    '--disable-setuid-sandbox',
    '--disable-dev-shm-usage',
    '--single-process'  // Use with caution
  ]
}
```

**Reinstall Chrome:**
```bash
# Linux
sudo apt-get remove google-chrome-stable
sudo apt-get install google-chrome-stable

# macOS
brew reinstall --cask google-chrome
```

### Error: Protocol Error

**Symptoms:**
```
Error: Protocol error: Target closed
```

**Causes:**
1. Browser closed unexpectedly
2. Page navigation timeout
3. Worker killed

**Solutions:**

**Add error handling:**
```javascript
try {
  await page.goto(url);
} catch (error) {
  if (error.message.includes('Target closed')) {
    // Relaunch browser
    browser = await launchBrowser();
    page = await browser.newPage();
  }
}
```

**Increase navigation timeout:**
```javascript
navigation: {
  timeout: 30 * 1000  // 30 seconds
}
```

---

## Proxy Issues

### Error: ECONNREFUSED

**Symptoms:**
```
Error: connect ECONNREFUSED 127.0.0.1:8080
```

**Causes:**
1. Proxy is offline
2. Wrong proxy address
3. Firewall blocking connection

**Solutions:**

**Test proxy manually:**
```bash
# Test HTTP proxy
curl -x http://proxy:8080 https://www.google.com

# Test HTTPS proxy
curl -x https://proxy:8443 https://www.google.com
```

**Verify proxy format:**
```
# Correct formats
http://1.2.3.4:8080
http://username:password@proxy.example.com:8080
socks5://proxy.example.com:1080
```

**Check proxy in Lightning_Proxies.txt:**
```bash
# View file
cat Lightning_Proxies.txt

# Test each proxy
while read proxy; do
  echo "Testing: $proxy"
  curl -x "$proxy" -I https://www.google.com
done < Lightning_Proxies.txt
```

### Error: Proxy Tunnel Failed

**Symptoms:**
```
[PROXY] Proxy tunnel creation failed
```

**Causes:**
1. Proxy requires authentication
2. Proxy doesn't support CONNECT method
3. Target site blocked by proxy

**Solutions:**

**Add authentication:**
```
# Format: http://username:password@host:port
http://myuser:mypass@proxy.example.com:8080
```

**Try different proxy:**
```javascript
// System will automatically blacklist failed proxies
// and try next one from list
```

**Increase timeout:**
```javascript
proxy: {
  tcpTimeout: 10 * 1000  // 10 seconds
}
```

### All Proxies Blacklisted

**Symptoms:**
```
[PROXY] All proxies blacklisted, cannot proceed
```

**Causes:**
1. All proxies are down
2. Aggressive blacklisting
3. Network issues

**Solutions:**

**Clear blacklist:**
```bash
rm bad_proxies.txt
```

**Reduce blacklist TTL:**
```javascript
proxy: {
  blacklistTTL: 5 * 60 * 1000  // 5 minutes instead of 10
}
```

**Check proxy health:**
```bash
# Test all proxies
node -e "
const fs = require('fs');
const proxies = fs.readFileSync('Lightning_Proxies.txt', 'utf8').split('\n');
proxies.forEach(p => console.log('Test:', p));
"
```

---

## Detection Issues

### TGC Cookie Not Detected

**Symptoms:**
```
[DETECT] TGC cookie not found, login may have failed
```

**Causes:**
1. Credentials are invalid
2. Target site doesn't use CAS
3. Cookie name is different
4. Detection timeout too short

**Solutions:**

**Verify cookie name:**
```javascript
// In browser console after manual login
document.cookie.split(';').forEach(c => console.log(c.trim()));
```

**Update config if different name:**
```javascript
casDetection: {
  tgcCookieNames: ['TGC', 'CASTGC', 'CAS_TICKET']
}
```

**Increase detection timeout:**
```javascript
detection: {
  cas: {
    timeout: 20 * 1000  // 20 seconds
  }
}
```

**Enable debug logging:**
```javascript
logging: {
  logLevel: 'debug'
}
```

### High False Positive Rate

**Symptoms:**
```
[RESULTS] Many "successful" logins but credentials don't work
```

**Causes:**
1. Low confidence threshold
2. Unreliable detection methods enabled
3. Error pages being detected as success

**Solutions:**

**Increase minimum confidence:**
```javascript
detection: {
  minimumSuccessConfidence: 0.95  // Only TGC and CAS ticket
}
```

**Disable unreliable methods:**
```javascript
casDetection: {
  monitoringStrategies: {
    tgc_cookie: { enabled: true },        // Keep
    redirect_location: { enabled: true }, // Keep
    navigation_detected: { enabled: false }, // Disable
    dom_username: { enabled: false }      // Disable
  }
}
```

**Review detection logs:**
```bash
# Check what methods are being used
grep "detectionMethod" logs/successful/*.jsonl

# Count by method
grep -o '"detectionMethod":"[^"]*"' logs/successful/*.jsonl | sort | uniq -c
```

### Low Success Rate

**Symptoms:**
```
[RESULTS] Valid credentials marked as failed
```

**Causes:**
1. Detection timeout too short
2. Slow proxy/network
3. Wrong detection configuration

**Solutions:**

**Increase timeouts:**
```javascript
detection: {
  cas: {
    timeout: 20 * 1000  // Increase to 20s
  }
},
navigation: {
  timeout: 30 * 1000  // Increase to 30s
}
```

**Lower confidence threshold (carefully):**
```javascript
detection: {
  minimumSuccessConfidence: 0.80  // Lower to 80%
}
```

**Enable more detection methods:**
```javascript
casDetection: {
  monitoringStrategies: {
    set_cookie: { enabled: true },
    body_token: { enabled: true },
    cookie_detect: { enabled: true }
  }
}
```

---

## Performance Issues

### Very Slow Processing

**Symptoms:**
```
[RESULTS] Processing Rate: 2 credentials/minute (expected 10-20)
```

**Causes:**
1. Slow proxies
2. Conservative delays
3. Insufficient parallel workers
4. Slow network/system

**Solutions:**

**Increase parallel workers:**
```javascript
batch: {
  maxParallelWorkers: 8  // Increase from 4
}
```

**Reduce typing delays:**
```javascript
form: {
  typeDelayMin: 2,  // Reduce from 4
  typeDelayMax: 5   // Reduce from 10
}
```

**Reduce batch pauses:**
```javascript
batch: {
  pauseBetweenBatchMin: 500,   // Reduce from 1000
  pauseBetweenBatchMax: 2000   // Reduce from 5000
}
```

**Use faster proxies:**
```bash
# Test proxy speed
time curl -x http://proxy:8080 https://www.google.com
```

### High Memory Usage

**Symptoms:**
```
System memory at 90%+
Workers being killed by OOM
```

**Causes:**
1. Too many parallel workers
2. Memory leaks in browser
3. Insufficient system RAM

**Solutions:**

**Reduce parallel workers:**
```javascript
batch: {
  maxParallelWorkers: 2  // Reduce from 4 or 8
}
```

**Enable headless mode:**
```javascript
browser: {
  headless: true  // Uses less memory
}
```

**Reduce credentials per batch:**
```javascript
batch: {
  credentialsPerProxy: 2  // Reduce from 4
}
```

**Monitor memory:**
```bash
# Watch memory usage
watch -n 1 'free -h'

# Check per-process memory
ps aux | grep chrome | awk '{print $6, $11}'
```

### High CPU Usage

**Symptoms:**
```
CPU at 100% constantly
System becoming unresponsive
```

**Solutions:**

**Reduce workers:**
```javascript
batch: {
  maxParallelWorkers: Math.ceil(require('os').cpus().length / 2)
}
```

**Enable headless:**
```javascript
browser: {
  headless: true
}
```

**Reduce browser load:**
```javascript
browser: {
  args: [
    '--disable-gpu',
    '--disable-software-rasterizer',
    '--disable-animations'
  ]
}
```

---

## Worker Issues

### Workers Timing Out

**Symptoms:**
```
[BATCH] Worker timeout (180s), terminating...
```

**Causes:**
1. Browser hang
2. Slow proxy
3. Page load timeout
4. CAPTCHA blocking

**Solutions:**

**Increase worker timeout:**
```javascript
browser: {
  timeout: 300 * 1000  // 5 minutes
}
```

**Check for CAPTCHA:**
```bash
# Review logs
grep "captcha" logs/*/*.jsonl
```

**Monitor worker health:**
```javascript
// Add logging to worker
console.log('[WORKER] Processing credential', index);
```

### Workers Not Starting

**Symptoms:**
```
[CONTROLLER] Launching worker...
(No response)
```

**Causes:**
1. Node.js memory limit
2. System resource exhaustion
3. Worker script error

**Solutions:**

**Increase Node.js memory:**
```bash
export NODE_OPTIONS="--max-old-space-size=4096"
node play_version2_controller.js
```

**Check worker logs:**
```bash
# Run worker manually to see errors
node play_version2_worker_integrated_Version5.js
```

**Check system limits:**
```bash
# Check open file limits
ulimit -n

# Increase if needed
ulimit -n 4096
```

### Worker Crashes

**Symptoms:**
```
[BATCH] Worker crashed (code=-1, signal=SIGSEGV)
```

**Causes:**
1. Browser crash
2. Out of memory
3. Segmentation fault

**Solutions:**

**Add error handling:**
```javascript
// In worker
process.on('uncaughtException', (error) => {
  console.error('[WORKER] Uncaught exception:', error);
  process.exit(1);
});

process.on('unhandledRejection', (reason) => {
  console.error('[WORKER] Unhandled rejection:', reason);
  process.exit(1);
});
```

**Enable core dumps:**
```bash
ulimit -c unlimited
node play_version2_controller.js
```

---

## Logging Issues

### No Logs Generated

**Symptoms:**
```
logs/ directory empty or missing files
```

**Causes:**
1. Insufficient permissions
2. Incorrect log path
3. Logging disabled

**Solutions:**

**Check permissions:**
```bash
ls -la logs/
chmod -R 755 logs/
```

**Verify log directory:**
```javascript
// In config.js
console.log('Log directory:', path.join(process.cwd(), 'logs'));
```

**Enable logging:**
```javascript
logging: {
  enableStructuredLogging: true,
  logLevel: 'info'
}
```

### Logs Not Being Written

**Symptoms:**
```
Console output but no JSONL files
```

**Causes:**
1. File write errors
2. Disk full
3. Wrong path

**Solutions:**

**Check disk space:**
```bash
df -h
```

**Test file writing:**
```javascript
const fs = require('fs');
fs.writeFileSync('logs/test.txt', 'test', 'utf8');
console.log('Write successful');
```

**Check errors:**
```bash
# Run with debug
node play_version2_controller.js 2>&1 | tee debug.log
```

### Large Log Files

**Symptoms:**
```
logs/*.jsonl files are gigabytes in size
```

**Solutions:**

**Rotate logs:**
```bash
# Archive old logs
tar -czf logs-$(date +%Y%m%d).tar.gz logs/
rm -rf logs/*/*.jsonl

# Or use logrotate
```

**Reduce logging:**
```javascript
logging: {
  logLevel: 'warn'  // Only warnings and errors
}
```

**Implement log rotation:**
```javascript
// Add to logger.js
if (fileSize > 100 * 1024 * 1024) {  // 100MB
  rotateLogFile();
}
```

---

## Target Site Issues

### Site Blocks All Attempts

**Symptoms:**
```
[RESULTS] Blocked: 100%
```

**Causes:**
1. IP-based rate limiting
2. Browser fingerprinting detection
3. Proxy provider blocked

**Solutions:**

**Slow down requests:**
```javascript
batch: {
  pauseBetweenBatchMin: 10000,   // 10 seconds
  pauseBetweenBatchMax: 30000    // 30 seconds
}
```

**Use better proxies:**
```
Residential proxies (harder to detect) vs datacenter proxies
```

**Reduce parallel workers:**
```javascript
batch: {
  maxParallelWorkers: 1  // Sequential only
}
```

**Add stealth plugins:**
```bash
npm install puppeteer-extra-plugin-stealth
```

### CAPTCHA on Every Attempt

**Symptoms:**
```
[RESULTS] CAPTCHA Detected: 80%+
```

**Causes:**
1. Aggressive rate limiting
2. Bot detection
3. Bad proxy reputation

**Solutions:**

**Increase delays:**
```javascript
batch: {
  pauseBetweenBatchMin: 15000,
  pauseBetweenBatchMax: 45000
},
form: {
  typeDelayMin: 10,
  typeDelayMax: 30
}
```

**Use residential proxies:**
```
Switch from datacenter to residential proxy provider
```

**Rotate proxies more:**
```javascript
batch: {
  credentialsPerProxy: 1  // New proxy every credential
}
```

**Future: Implement CAPTCHA solving:**
```javascript
// Coming soon
captcha: {
  solver: '2captcha',
  apiKey: 'YOUR_API_KEY'
}
```

### Site Returns Errors

**Symptoms:**
```
HTTP 500 Internal Server Error
HTTP 503 Service Unavailable
```

**Causes:**
1. Target site is down
2. Overloading target site
3. Proxy issues

**Solutions:**

**Check site status:**
```bash
curl -I https://login.supercard.ch/
```

**Add retry logic:**
```javascript
// Already implemented in errorRecovery.js
retryWithBackoff(() => page.goto(url), { maxRetries: 5 });
```

**Slow down:**
```javascript
batch: {
  maxParallelWorkers: 1,
  pauseBetweenBatchMin: 30000
}
```

---

## Debug Mode

### Enable Full Debug Output

```javascript
// config.js
logging: {
  logLevel: 'debug'
}
```

```bash
# Run with debug
DEBUG=* node play_version2_controller.js
```

### Capture Screenshots

```javascript
// After each credential test
await page.screenshot({
  path: `logs/screenshots/${username}_${Date.now()}.png`,
  fullPage: true
});
```

### Enable Browser DevTools

```javascript
browser: {
  headless: false,
  dumpio: true,
  devtools: true  // Opens DevTools automatically
}
```

### Log Network Traffic

```javascript
page.on('request', req => {
  console.log('→', req.method(), req.url());
});

page.on('response', res => {
  console.log('←', res.status(), res.url());
});
```

---

## Getting Help

### Collect Debug Information

```bash
# System info
uname -a
node --version
npm --version

# Check logs
tail -100 logs/errors/*.jsonl

# Check config
cat config.js

# Test browser
node -e "require('patchright').chromium.launch().then(b => b.close())"
```

### Report Issues

When reporting issues, include:

1. **System info**: OS, Node.js version
2. **Error message**: Full error output
3. **Configuration**: Relevant config.js sections
4. **Logs**: Last 50 lines from logs
5. **Steps to reproduce**: What you did before error

### Useful Commands

```bash
# Check running processes
ps aux | grep node

# Kill all workers
pkill -f play_version2_worker

# Clear all state
rm -rf logs/* bad_proxies.txt

# Test single credential
node -e "
const config = require('./config');
console.log(JSON.stringify(config, null, 2));
"
```

---

**Next:** [Configuration Guide](CONFIGURATION.md) | [Architecture](ARCHITECTURE.md)
