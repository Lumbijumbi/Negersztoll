# Python Combo Extractor

A standalone Python application for extracting User:Password or Email:Password combos from large text files with various formats.

## Features

- **Multiple Format Support**: Handles various input formats including:
  - Standard format: `email@domain.com:password`
  - URL format: `app.exeedme.com/:--.user@domain.com:password`
  - Full URL format: `https://app.exeedme.com/csgo:username:password`
  - Metadata format: Lines with tabs and additional data

- **Extraction Modes**:
  - **Email:Password**: Extracts only combos where the username is a valid email address
  - **User:Password**: Extracts all user:password combos (including non-email usernames)

- **Deduplication**: Optional removal of duplicate combos while maintaining order

- **Easy-to-use GUI**: Simple graphical interface built with tkinter

- **Progress Tracking**: Real-time progress bar for large file processing

- **CLI Support**: Command-line interface for automation and batch processing

## Installation

### Prerequisites

- Python 3.6 or higher
- tkinter (usually included with Python)

### Setup

1. No additional packages required! The application uses only Python standard library modules.

2. Ensure you have Python 3 installed:
```bash
python3 --version
```

### Quick Test

Test the extractor with the provided sample files:

```bash
# Test with sample input (located in examples/ directory)
python3 extractor_core.py examples/sample_combos_input.txt output.txt email:password true

# View the results
cat output.txt
```

## Usage

### GUI Mode (Recommended)

Launch the graphical interface:

```bash
python3 combo_extractor.py
```

**Steps:**
1. Click "Browse..." next to "Input File" to select your source file
2. Click "Browse..." next to "Output File" to choose where to save results (or use auto-suggested filename)
3. Select extraction mode:
   - **Email:Password**: Only extracts combos with valid email addresses
   - **User:Password**: Extracts all user:password combos
4. Check "Remove duplicates (dedupe)" to eliminate duplicate entries
5. Click "Extract Combos" to start processing

The progress bar will show real-time progress, and you'll see a success message when complete.

### Command-Line Mode

For automation or batch processing:

```bash
python3 extractor_core.py <input_file> <output_file> [mode] [dedupe]
```

**Arguments:**
- `input_file`: Path to input text file
- `output_file`: Path to output file (will be created)
- `mode` (optional): `email:password` or `user:password` (default: `email:password`)
- `dedupe` (optional): `true` or `false` (default: `true`)

**Examples:**

Extract emails with deduplication:
```bash
python3 extractor_core.py combos.txt output.txt email:password true
```

Extract all users without deduplication:
```bash
python3 extractor_core.py combos.txt output.txt user:password false
```

## Supported Input Formats

The extractor recognizes and processes these formats:

### Format 1: Standard
```
user@email.com:password123
username:mypassword
```

### Format 2: URL:Login:Password
```
app.exeedme.com/:--.user@neuf.fr:_eDaH@$_$Z7
domain.com:admin@site.com:AdminPass456
```

### Format 3: Full URL:User:Pass
```
https://app.exeedme.com/csgo:hanabi:Groaz526
http://service.com:john:SecurePass123
```

### Format 4: With Metadata (tab-separated)
```
user@email.com:password	2026-01-08T13:48:22.959Z	no_indicators	batch: 2
```

The extractor automatically detects the format and extracts the user:password combo from each line.

## Output

The output file will contain one combo per line in the format:
```
username:password
```

- Duplicates are removed if deduplication is enabled
- Empty lines and invalid entries are skipped
- Output is UTF-8 encoded

## Performance

- **Large Files**: Efficiently processes files with millions of lines
- **Progress Updates**: Updates every 1,000 lines to avoid performance overhead
- **Memory Efficient**: Processes files line-by-line to handle very large files

## Examples

### Sample Files

The repository includes sample files in the `examples/` directory:
- `sample_combos_input.txt` - Example input with various formats and comments
- `sample_combos_output_email.txt` - Output using email:password mode with dedupe
- `sample_combos_output_user.txt` - Output using user:password mode with dedupe

### Example 1: Extract email combos from a breach file

Input (`breach.txt`):
```
app.example.com:john@email.com:Pass123
https://site.com/path:user@domain.org:Secret456
normaluser@test.com:MyPass789
username:password
```

Command:
```bash
python3 extractor_core.py breach.txt clean_emails.txt email:password true
```

Output (`clean_emails.txt`):
```
john@email.com:Pass123
user@domain.org:Secret456
normaluser@test.com:MyPass789
```

Note: `username:password` was skipped because "username" is not a valid email.

### Example 2: Extract all user combos

Using the same input with `user:password` mode:

Command:
```bash
python3 extractor_core.py breach.txt all_users.txt user:password true
```

Output (`all_users.txt`):
```
john@email.com:Pass123
user@domain.org:Secret456
normaluser@test.com:MyPass789
username:password
```

All combos are extracted, including non-email usernames.

## Troubleshooting

### GUI doesn't launch

**Issue**: `ModuleNotFoundError: No module named 'tkinter'`

**Solution**: Install tkinter for your Python version:
- **Ubuntu/Debian**: `sudo apt-get install python3-tk`
- **Fedora**: `sudo dnf install python3-tkinter`
- **macOS**: tkinter is included with Python from python.org
- **Windows**: tkinter is included with standard Python installation

### No combos extracted

**Possible causes:**
1. Input file format doesn't match expected patterns
2. Using `email:password` mode but file contains only non-email usernames
   - Solution: Try `user:password` mode instead

### Incorrect extractions

If the extraction doesn't match your expectations:
1. Check your input file format
2. Verify you're using the correct extraction mode
3. Look at the first few lines of your input and output to understand the pattern

## Integration with SuPerrMurrer

This combo extractor is a standalone utility that complements the SuPerrMurrer credential testing system:

1. Use the extractor to clean and format combo lists
2. Use the dedupe feature to reduce unnecessary tests
3. Feed the cleaned output into SuPerrMurrer's test.txt for credential testing

## License

This tool is part of the SuPerrMurrer project and is provided for educational purposes.

## Contributing

Contributions are welcome! Please ensure:
- Code follows Python PEP 8 style guidelines
- New formats are documented in this README
- Test with various input formats before submitting

## Future Enhancements

Potential future features:
- Additional output formats (JSON, CSV)
- Custom regex patterns for extraction
- Bulk file processing
- Statistics and reporting
- Format validation and cleaning
