# Project Tracking Quick Start Guide

This guide helps you get started with tracking the SuPerrMurrer v3.0 development plan.

## 📋 Overview

The project tracking system consists of:
- **PROJECT_STATUS.md** - Main tracking document
- **utils/projectTracker.js** - CLI utility for granular updates
- **utils/workflowManager.js** - High-level workflow automation (NEW!)

## 🔥 New: Workflow Manager

The Workflow Manager provides automated workflows for common tasks:

```bash
# View available workflows
node utils/workflowManager.js --help

# Start stakeholder review process
node utils/workflowManager.js initiate-review

# Bulk approve all stakeholders
node utils/workflowManager.js approve-all

# Set up Phase 1 resources and environment
node utils/workflowManager.js setup-phase1

# Generate weekly status report
node utils/workflowManager.js weekly-update
```

See [Automated Workflows](#-automated-workflows) section below for details.

## 🚀 Quick Start

### 1. View Current Status

```bash
node utils/projectTracker.js status
```

This displays:
- Current phase
- Pending stakeholder approvals
- Resources to assign
- Environment setup items pending

### 2. Update Stakeholder Approvals

When a stakeholder approves the plan:

```bash
node utils/projectTracker.js update-approval "Project Owner" "✅ Approved"
```

Available statuses:
- ✅ Approved
- ⏳ Pending
- 🔄 In Review
- ❌ Rejected
- 🔴 Blocked

### 3. Assign Team Members

Assign a developer to Phase 1:

```bash
node utils/projectTracker.js assign-resource 1 "Lead Developer" "Alice Smith" "2026-02-01" "2026-03-15"
```

Format: `assign-resource <phase> <role> <name> [startDate] [endDate]`

### 4. Track Milestones

Mark a milestone as complete:

```bash
node utils/projectTracker.js complete-milestone "M1" "2026-03-15"
```

### 5. Record Meeting Notes

Add notes from review meetings:

```bash
node utils/projectTracker.js add-meeting-note "Kickoff Meeting" "Approved" "Present plan;Discuss timeline;Address questions"
```

### 6. Update Environment Setup

Check off environment setup items:

```bash
node utils/projectTracker.js update-setup "Node.js Environment" true
```

## 📖 Common Workflows

### Workflow 1: Plan Approval Process

1. Technical team reviews plan
   ```bash
   node utils/projectTracker.js update-approval "Technical Lead" "🔄 In Review"
   ```

2. After review, mark as approved
   ```bash
   node utils/projectTracker.js update-approval "Technical Lead" "✅ Approved"
   ```

3. Repeat for all stakeholders

### Workflow 2: Phase 1 Setup

1. Assign all Phase 1 team members
   ```bash
   node utils/projectTracker.js assign-resource 1 "Lead Developer" "Alice Smith" "2026-02-01"
   node utils/projectTracker.js assign-resource 1 "UX Developer" "Bob Jones" "2026-02-01"
   node utils/projectTracker.js assign-resource 1 "QA Engineer" "Carol White" "2026-02-01"
   ```

2. Complete environment setup items
   ```bash
   node utils/projectTracker.js update-setup "Node.js Environment" true
   node utils/projectTracker.js update-setup "Repository Setup" true
   node utils/projectTracker.js update-setup "IDE Configuration" true
   ```

3. Record kickoff meeting
   ```bash
   node utils/projectTracker.js add-meeting-note "Kickoff Meeting" "Success" "Team aligned;Sprint 1 planned;Questions addressed"
   ```

### Workflow 3: Phase Completion

1. Mark milestone as complete
   ```bash
   node utils/projectTracker.js complete-milestone "M1" "2026-03-15"
   ```

2. Check overall status
   ```bash
   node utils/projectTracker.js status
   ```

3. Manually update PROJECT_STATUS.md for:
   - Sprint retrospectives
   - Detailed task completion
   - Phase review notes
   - Lessons learned

## 📝 Manual Updates

Some sections require manual editing of PROJECT_STATUS.md:

### Sprint Tracking
- Update Sprint Backlog tables with actual hours
- Add sprint retrospective notes
- Update burndown charts (if maintained)

### Risk Management
- Update risk probability and mitigation status
- Add new risks as they emerge

### Metrics
- Update KPIs and metrics sections
- Add actual vs. estimated comparisons

### Change Log
- Document significant changes to the plan
- Record scope adjustments
- Note timeline modifications

## 🎯 Best Practices

1. **Update Regularly**: Update status at least weekly
2. **Be Specific**: Use clear, descriptive notes in meetings
3. **Track Changes**: Always update the Change Log for significant modifications
4. **Timestamp Updates**: The utility automatically updates timestamps
5. **Commit Changes**: Commit PROJECT_STATUS.md after updates
   ```bash
   git add PROJECT_STATUS.md
   git commit -m "Update project status: [description]"
   git push
   ```

## 🔍 Viewing Status

### In Terminal
```bash
node utils/projectTracker.js status
```

### In Browser/Editor
Open PROJECT_STATUS.md in:
- GitHub web interface (with rendered markdown)
- VS Code with Markdown Preview
- Any markdown viewer

### Generate Reports
You can grep PROJECT_STATUS.md for specific information:

```bash
# View all pending approvals
grep "⏳ Pending" PROJECT_STATUS.md

# View all assigned resources
grep -v "TBD" PROJECT_STATUS.md | grep "Lead Developer"

# Count completed setup items
grep -c "\[x\]" PROJECT_STATUS.md
```

## 🆘 Troubleshooting

### Command Not Working
- Check you're in the project root directory
- Verify Node.js is installed: `node --version`
- Ensure utils/projectTracker.js exists

### Changes Not Reflected
- Check PROJECT_STATUS.md was updated
- Verify the command completed successfully
- Look for error messages in output

### Incorrect Update
- Manually edit PROJECT_STATUS.md to fix
- Or restore from git: `git checkout PROJECT_STATUS.md`
- Then re-run the correct command

## 🔥 Automated Workflows

The **Workflow Manager** (`utils/workflowManager.js`) provides high-level automation for common project management workflows.

### Available Workflows

#### 1. Initiate Review
Start the stakeholder review process:
```bash
node utils/workflowManager.js initiate-review
```
This marks all stakeholders as "In Review" automatically.

#### 2. Approve All
Bulk approve all stakeholders after reviews complete:
```bash
node utils/workflowManager.js approve-all
```
This saves time versus approving each stakeholder individually.

#### 3. Setup Phase 1
Complete Phase 1 resource allocation and environment setup:
```bash
node utils/workflowManager.js setup-phase1
```
This assigns the default Phase 1 team and marks key environment items as complete.

#### 4. Start Sprint
Initialize a new sprint:
```bash
node utils/workflowManager.js start-sprint 1 2026-02-03 2026-02-14
```
This displays a checklist of manual steps to complete sprint setup.

#### 5. Complete Sprint
Mark sprint as complete:
```bash
node utils/workflowManager.js complete-sprint 1 "Menu system;Navigation;Icons"
```
This displays a completion checklist and documents accomplishments.

#### 6. Weekly Update
Generate weekly status report:
```bash
node utils/workflowManager.js weekly-update
```
This creates a formatted report in the `reports/` directory showing:
- Approval progress
- Resource allocation status
- Environment setup progress
- Overall percentages

### Typical Workflow Sequence

```bash
# 1. Start stakeholder reviews
node utils/workflowManager.js initiate-review

# 2. After reviews complete, approve all
node utils/workflowManager.js approve-all

# 3. Set up Phase 1 resources and environment
node utils/workflowManager.js setup-phase1

# 4. Begin first sprint
node utils/workflowManager.js start-sprint 1 2026-02-03 2026-02-14

# 5. Generate weekly reports
node utils/workflowManager.js weekly-update

# 6. Complete sprint
node utils/workflowManager.js complete-sprint 1

# 7. Start next sprint
node utils/workflowManager.js start-sprint 2 2026-02-17 2026-02-28
```

### When to Use Workflow Manager vs. Project Tracker

**Use Workflow Manager** when:
- Performing common, multi-step workflows
- Need to update multiple items at once
- Want automated reports
- Following the standard development process

**Use Project Tracker** when:
- Need fine-grained control
- Updating a single specific item
- Handling edge cases or exceptions
- Custom updates not covered by workflows

## 📞 Getting Help

```bash
# View all available commands
node utils/projectTracker.js --help

# View examples for each command
node utils/projectTracker.js --help | grep -A 2 "Examples:"
```

For more information:
- See [PROJECT_STATUS.md](../PROJECT_STATUS.md) - Full tracking document
- See [DEVELOPMENT_PLAN.md](../DEVELOPMENT_PLAN.md) - Complete development plan
- See [DEVELOPMENT_PLAN_SUMMARY.md](../DEVELOPMENT_PLAN_SUMMARY.md) - Executive summary

---

**Quick Reference Card**

| Command | Description |
|---------|-------------|
| `status` | Display summary |
| `update-approval <role> <status>` | Update approval status |
| `assign-resource <phase> <role> <name>` | Assign team member |
| `complete-milestone <name>` | Mark milestone done |
| `add-meeting-note <meeting> <outcome> <actions>` | Record meeting |
| `update-setup <item> <checked>` | Update checklist |
| `--help` | Show all commands |

---

*Last updated: January 2026*
