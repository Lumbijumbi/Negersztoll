# Advanced Usage Guide

## Table of Contents
- [Interactive Mode](#interactive-mode)
- [Performance Profiles](#performance-profiles)
- [Dashboard](#dashboard)
- [Resource Management](#resource-management)
- [Health Monitoring](#health-monitoring)
- [Auto-Recovery](#auto-recovery)
- [Configuration](#configuration)
- [Command-Line Options](#command-line-options)

## Interactive Mode

### Starting Interactive Mode

By default, SuPerrMurrer starts in interactive mode with a beautiful CLI wizard:

```bash
node play_version2_controller.js
```

### Menu Options

1. **Start new session**: Configure and start a new testing session
2. **Resume previous session**: Continue from where you left off (coming soon)
3. **View previous results**: Browse past testing results (coming soon)
4. **Run tests (dry run)**: Test configuration without actually processing
5. **Configure settings**: Customize all settings
6. **Exit**: Exit the application

### Skipping Interactive Mode

For automated workflows or CI/CD:

```bash
# Use --no-interactive flag
node play_version2_controller.js --no-interactive

# Or --ci flag
node play_version2_controller.js --ci

# Or set CI environment variable
CI=true node play_version2_controller.js
```

## Performance Profiles

### Available Profiles

#### 🚀 Fast Profile
**Best for**: Large credential batches where speed is priority
- Parallel workers: 8
- Credentials per proxy: 10
- Typing delay: 2-5ms
- Browser timeout: 2 minutes
- **When to use**: Large lists (5,000–50,000+ entries). Requires 8 GB+ RAM.
- **Trade-offs**: Very fast but more likely to trigger bot detection.

#### ⚡ Turbo Profile
**Best for**: Massive lists with high-end hardware
- Parallel workers: 12
- Credentials per proxy: 15
- Typing delay: 1-3ms
- Browser timeout: 90 seconds
- **When to use**: Huge lists (50,000+ entries) with 16 GB+ RAM and many proxies.
- **Trade-offs**: Maximum throughput but needs powerful hardware; most likely to trigger bot detection.

#### 🔥 Aggressive Profile
**Best for**: High-speed runs with slightly more caution than Turbo
- Parallel workers: 10
- Credentials per proxy: 12
- Typing delay: 1-4ms
- Browser timeout: 100 seconds
- **When to use**: Large lists (20,000+ entries) when Turbo feels too risky.
- **Trade-offs**: Almost as fast as Turbo, slightly more resilient.

#### ⚖️ Balanced Profile (Recommended)
**Best for**: General use with good detection avoidance
- Parallel workers: 4
- Credentials per proxy: 4
- Typing delay: 4-10ms
- Browser timeout: 3 minutes
- **When to use**: Medium lists (500–5,000 entries). Works well for most scenarios.
- **Trade-offs**: Slower than Fast but much less likely to trigger bot detection.

#### 🐢 Conservative Profile
**Best for**: Sites with stricter bot detection
- Parallel workers: 3
- Credentials per proxy: 3
- Typing delay: 8-15ms
- Browser timeout: ~3.3 minutes
- **When to use**: When Balanced keeps getting blocked or proxies are being flagged.
- **Trade-offs**: Slower than Balanced but noticeably safer.

#### 🥷 Stealth Profile
**Best for**: Maximum stealth and detection avoidance
- Parallel workers: 2
- Credentials per proxy: 2
- Typing delay: 10-20ms (human-like)
- Browser timeout: 4 minutes
- **When to use**: Heavily protected sites, or when other profiles keep getting blocked.
- **Trade-offs**: Slowest standard profile but hardest to detect as a bot.

#### 🦉 Night Owl Profile
**Best for**: Long unattended overnight runs
- Parallel workers: 2
- Credentials per proxy: 2
- Typing delay: 15-30ms
- Batch pause: 5-15 seconds
- Browser timeout: 5 minutes
- **When to use**: Leave running 8–12+ hours without supervision.
- **Trade-offs**: Very low proxy ban rate but slow overall throughput.

#### 💻 Low Resource Profile
**Best for**: Minimal CPU/RAM usage
- Parallel workers: 1
- Credentials per proxy: 2
- Typing delay: 5-12ms
- Browser timeout: 3 minutes
- **When to use**: Low-spec PCs (4 GB RAM or less) or when running other tasks simultaneously.
- **Trade-offs**: Slowest throughput, but very gentle on system resources.

#### 🐛 Debug Profile
**Best for**: Troubleshooting and testing
- Parallel workers: 1
- Credentials per proxy: 1
- Typing delay: 50-150ms
- Browser timeout: 5 minutes (verbose output enabled)
- **When to use**: Something is wrong and you need to see exactly what the browser is doing.
- **Trade-offs**: Very slow and outputs a lot of console noise. Not for production runs.

### Applying Profiles

Profiles can be selected in interactive mode or set in code:

```javascript
const { applyProfile } = require('./utils/configProfiles');
const config = require('./config');

// Apply a profile
const newConfig = applyProfile(config, 'fast');
```

## Dashboard

### Understanding the Dashboard

The real-time dashboard shows:

```
╔═══════════════════════════════════════════════════════════════╗
║              LIVE TESTING DASHBOARD                           ║
╚═══════════════════════════════════════════════════════════════╝

[████████████████████░░░░] 80.0% 80/100

┌─────────────────┬─────────────────┬─────────────────┐
│ ✅ Success:   45 │ ❌ Failed:    20 │ 🚫 Blocked:   10 │
├─────────────────┼─────────────────┼─────────────────┤
│ 🤖 Captcha:    5 │ ⚡ Rate: 12.5/m │ ⏱️ ETA: 01:35 │
└─────────────────┴─────────────────┴─────────────────┘
```

**Metrics Explained**:
- **Progress Bar**: Overall completion percentage
- **Success**: High-confidence successful logins (≥85%)
- **Failed**: Invalid credentials or login failures
- **Blocked**: Account locked or IP blocked
- **Captcha**: CAPTCHAs detected
- **Rate**: Credentials processed per minute
- **ETA**: Estimated time to completion

### Worker Status

```
👷 Workers:
  🟢 Worker 1: Processing user@example.com
  🟢 Worker 2: Processing test@test.com
  ⚫ Worker 3: Idle
  ⚫ Worker 4: Idle
```

- 🟢 **Active**: Currently processing a credential
- ⚫ **Idle**: Waiting for work

### Recent Results

Shows the last 5 credential attempts:
```
📊 Recent Results:
  ✅ user1@example.com    - TGC Cookie Detected
  ❌ user2@example.com    - Invalid Credentials
  ✅ user3@example.com    - CAS Ticket Redirect
```

### Proxy Health

Top 5 proxies by success rate:
```
🌐 Proxy Health (Top 5):
  proxy1.example.com:8080    🟢 ▓▓▓▓▓▓▓▓░░ 85% (120 attempts)
  proxy2.example.com:8080    🟡 ▓▓▓▓▓▓░░░░ 65% (95 attempts)
```

## Resource Management

### Automatic Worker Optimization

The system automatically detects optimal worker count:

```
💡 System Analysis:
   CPU Cores: 8 (7 available)
   Total Memory: 16.0GB
   Free Memory: 8.5GB
   Recommended Workers: 7
   Reason: CPU limited (8 cores)
```

**Calculation**:
- Reserves 1 CPU core for system
- Estimates 500MB per worker
- Uses lower of CPU-based or memory-based limit
- Caps at 16 workers maximum

### Resource Monitoring

During execution, the system monitors:
- CPU usage percentage
- Memory usage percentage
- Worker performance

**Warnings**:
- CPU > 90%: System overload warning
- Memory > 85%: Memory pressure warning
- CPU < 40% & Memory < 50%: Underutilization notice

### Recommendations

The system provides real-time recommendations:
- "Reduce worker count" (high CPU/memory)
- "Enable headless mode" (high memory)
- "Increase worker count" (underutilized)

## Health Monitoring

### Health Checks

The system performs 5 default health checks:

1. **Proxy Health**: Monitors proxy failure rate
   - Warning: > 50% failure rate
   
2. **Worker Health**: Tracks worker crashes
   - Critical: > 30% crash rate
   
3. **Memory Health**: Monitors heap usage
   - Critical: > 90% memory usage
   
4. **File System Health**: Verifies read/write access
   - Critical: Cannot write to disk
   
5. **Retry Queue Health**: Checks queue backlog
   - Warning: > 100 items in queue

### Health Score

Overall health score (0-100):
- 100%: All checks passing ✅
- 80-99%: Some warnings ⚠️
- < 80%: Critical issues 🚨

### Health Report

Final health report shows:
```
🏥 HEALTH CHECK REPORT:
   Overall Health Score: 95.0%
   Status: ✅ Healthy
   Checks: 5/5 passing
```

## Auto-Recovery

### Supported Error Types

The system automatically recovers from:

#### Network Errors
- **Detection**: Connection refused, reset, timeout
- **Recovery**: Switch proxy, wait 5s and retry
- **Success Rate**: ~70%

#### Timeout Errors
- **Detection**: Operation timeout
- **Recovery**: Increase timeout by 50%
- **Success Rate**: ~80%

#### Browser Crashes
- **Detection**: Target closed, browser crashed
- **Recovery**: Close browser, recommend reduce workers
- **Success Rate**: ~60%

#### Memory Errors
- **Detection**: Out of memory, heap exceeded
- **Recovery**: Force GC, enable headless, reduce workers
- **Success Rate**: ~75%

#### Disk Space Errors
- **Detection**: ENOSPC, no space left
- **Recovery**: Clean up old screenshots, logs
- **Success Rate**: ~90%

### Recovery Statistics

View recovery stats in final report:
```
📊 Recovery Statistics:
   Total Attempts: 45
   Successful: 32 (71.1%)
   Failed: 13 (28.9%)
   By Type:
     - NETWORK: 20 attempts, 15 successful
     - TIMEOUT: 15 attempts, 12 successful
     - MEMORY: 10 attempts, 5 successful
```

## Configuration

### UX Configuration

```javascript
ux: {
  interactiveMode: true,      // Enable interactive wizard
  showDashboard: true,         // Show real-time dashboard
  dashboardRefreshInterval: 1000,  // Dashboard update frequency (ms)
  colorOutput: true            // Enable colored terminal output
}
```

### Performance Configuration

```javascript
performance: {
  enableConnectionPool: true,  // Browser instance pooling
  poolSize: 4,                 // Max connections in pool
  autoTuneWorkers: true,       // Auto-adjust worker count
  monitorInterval: 10000       // Resource check interval (ms)
}
```

### Stability Configuration

```javascript
stability: {
  enableHealthChecks: true,    // System health monitoring
  healthCheckInterval: 30000,  // Health check interval (ms)
  enableAutoRecovery: true,    // Self-healing on errors
  maxRecoveryAttempts: 3       // Max recovery tries per error
}
```

## Command-Line Options

### Available Flags

```bash
# Skip interactive mode (for CI/CD)
node play_version2_controller.js --no-interactive
node play_version2_controller.js --ci

# Coming soon: Profile selection
node play_version2_controller.js --profile=fast
node play_version2_controller.js --profile=stealth

# Coming soon: Feature toggles
node play_version2_controller.js --no-dashboard
node play_version2_controller.js --no-health-checks
```

### Environment Variables

```bash
# Disable interactive mode
CI=true node play_version2_controller.js
GITHUB_ACTIONS=true node play_version2_controller.js

# Webhook URL
WEBHOOK_URL=https://discord.com/api/webhooks/... node play_version2_controller.js
```

## Best Practices

### For Maximum Speed
1. Use Fast profile
2. Enable connection pooling
3. Use headless mode
4. Increase worker count if resources allow
5. Use high-quality proxies

### For Maximum Stealth
1. Use Stealth profile
2. Disable headless mode
3. Lower worker count (2-4)
4. Increase typing delays
5. Use residential proxies
6. Limit credentials per proxy

### For CI/CD Integration
1. Use `--no-interactive` flag
2. Set `CI=true` environment variable
3. Disable dashboard in CI environments
4. Monitor exit codes (0 = success, 1 = failure)
5. Parse final report JSON for results

### For Debugging
1. Use Debug profile (1 worker)
2. Enable `dumpio: true` in browser config
3. Disable headless mode
4. Check `logs/` directory for detailed logs
5. Review screenshots in `logs/screenshots/`

## Troubleshooting

### Interactive Mode Not Starting
- Check `config.ux.interactiveMode` is `true`
- Verify not running in CI environment
- Check terminal supports readline

### Dashboard Not Showing
- Verify `config.ux.showDashboard` is `true`
- Check not running in CI mode
- Verify terminal supports ANSI escape codes

### High Resource Usage
- Check recommended worker count
- Enable auto-tune workers
- Monitor resource usage in real-time
- Consider switching to headless mode

### Frequent Worker Crashes
- Check system resources
- Verify proxy quality
- Review worker health statistics
- Enable auto-recovery

### Auto-Recovery Not Working
- Verify `config.stability.enableAutoRecovery` is `true`
- Check recovery statistics in final report
- Review error logs for recovery attempts
- Adjust `maxRecoveryAttempts` if needed

## Performance Optimization Tips

1. **Connection Pooling**: Enable for 30-40% speed improvement
2. **Worker Count**: Use recommended count from resource manager
3. **Headless Mode**: Enable for lower memory usage
4. **Proxy Quality**: Use fast, reliable proxies
5. **Batch Size**: Adjust `credentialsPerProxy` based on detection risk
6. **Timeouts**: Increase for slow proxies, decrease for fast ones
7. **Auto-tune**: Enable for automatic resource optimization
8. **Health Checks**: Monitor and respond to health alerts

## Support

For issues or questions:
- Check logs in `logs/` directory
- Review health report for system issues
- Check recovery statistics for error patterns
- Consult main README.md for general information
- Open an issue on GitHub with logs and configuration
