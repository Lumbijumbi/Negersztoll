# Docker Deployment Guide

This guide explains how to deploy SuPerrMurrer using Docker and Docker Compose.

## Prerequisites

- Docker 20.10+ installed
- Docker Compose 2.0+ installed
- At least 4GB of available RAM
- 10GB of free disk space

## Quick Start

### 1. Prepare Your Files

Ensure you have your credential and proxy files:

```bash
# These files are required
test.txt              # Your credentials (username:password)
Lightning_Proxies.txt # Your proxies
```

### 2. Configure Environment

Copy the example environment file and customize:

```bash
cp .env.example .env
nano .env  # Edit as needed
```

### 3. Build and Run

```bash
# Build the Docker image
docker-compose build

# Start the application
docker-compose up -d

# View logs
docker-compose logs -f superrmurrer
```

### 4. Access the GUI

Open your browser and navigate to:
```
http://localhost:3773
```

## Configuration Options

### Environment Variables

Key environment variables you can set in `.env` or `docker-compose.yml`:

```bash
NODE_ENV=production       # Environment mode
LOG_LEVEL=info           # Logging verbosity
BROWSER_HEADLESS=true    # Run browsers headless
MAX_WORKERS=4            # Number of parallel workers
GUI_PORT=3773            # Web interface port
```

### Volume Mounts

The docker-compose.yml mounts several directories:

- `./test.txt` → Credential file (read-only)
- `./Lightning_Proxies.txt` → Proxy list (read-only)
- `./logs` → Application logs (persistent)
- `./sessions` → Session data (persistent)
- `./screenshots` → Screenshot output (persistent)

## Advanced Usage

### Running with Monitoring Stack

To run with Prometheus and Grafana monitoring:

```bash
docker-compose --profile monitoring up -d
```

This will start:
- SuPerrMurrer on port 3773
- Prometheus on port 9091
- Grafana on port 3000 (admin/admin)

### Custom Configuration

#### Option 1: Environment Variables
```bash
# Override in docker-compose.yml
environment:
  - MAX_WORKERS=8
  - BROWSER_HEADLESS=true
```

#### Option 2: Config File Volume Mount
```bash
# In docker-compose.yml
volumes:
  - ./my-config.js:/app/config.js:ro
```

### Resource Limits

Add resource limits to prevent overconsumption:

```yaml
services:
  superrmurrer:
    # ... other config
    deploy:
      resources:
        limits:
          cpus: '4.0'
          memory: 8G
        reservations:
          cpus: '2.0'
          memory: 4G
```

## Common Commands

### Start Services
```bash
docker-compose up -d
```

### Stop Services
```bash
docker-compose down
```

### View Logs
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f superrmurrer

# Last 100 lines
docker-compose logs --tail=100 superrmurrer
```

### Restart Services
```bash
docker-compose restart superrmurrer
```

### Update Application
```bash
# Pull latest code
git pull origin main

# Rebuild and restart
docker-compose up -d --build
```

### Execute Commands Inside Container
```bash
# Open shell
docker-compose exec superrmurrer sh

# Run CLI command
docker-compose exec superrmurrer node cli.js status
```

## Troubleshooting

### Container Won't Start

**Check logs:**
```bash
docker-compose logs superrmurrer
```

**Common issues:**
- Missing credential files
- Port already in use
- Insufficient memory

### Performance Issues

**Check resource usage:**
```bash
docker stats superrmurrer
```

**Solutions:**
- Increase MAX_WORKERS
- Allocate more memory
- Use faster storage (SSD)

### Permission Issues

**Fix file permissions:**
```bash
# Make sure files are readable
chmod 644 test.txt Lightning_Proxies.txt

# Create directories with correct permissions
mkdir -p logs sessions screenshots
chmod 755 logs sessions screenshots
```

### Browser Issues in Container

**Enable verbose logging:**
```yaml
environment:
  - DEBUG=true
  - LOG_LEVEL=debug
  - BROWSER_DUMPIO=true
```

**Check Chromium:**
```bash
docker-compose exec superrmurrer chromium-browser --version
```

## Production Deployment

### Security Recommendations

1. **Use secrets management:**
```bash
# Use Docker secrets instead of environment variables
docker secret create credentials test.txt
```

2. **Run as non-root user:**
The Dockerfile already configures a non-root user (`appuser`)

3. **Enable authentication:**
Once implemented, set JWT_SECRET:
```bash
JWT_SECRET=$(openssl rand -base64 32)
```

4. **Use HTTPS:**
Put a reverse proxy (nginx/traefik) in front:
```yaml
services:
  nginx:
    image: nginx:alpine
    ports:
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
      - ./ssl:/etc/ssl:ro
```

### Scaling

#### Horizontal Scaling (Multiple Containers)

```bash
# Scale to 3 instances
docker-compose up -d --scale superrmurrer=3
```

**Note:** Requires load balancer configuration

#### Vertical Scaling (More Resources)

```yaml
deploy:
  resources:
    limits:
      cpus: '8.0'
      memory: 16G
```

### Health Checks

The container includes automatic health checks:

```yaml
healthcheck:
  test: ["CMD", "node", "-e", "require('http').get(...)"]
  interval: 30s
  timeout: 10s
  retries: 3
```

**Check health status:**
```bash
docker-compose ps
```

### Backup and Restore

#### Backup Data
```bash
# Backup logs and sessions
tar -czf backup-$(date +%Y%m%d).tar.gz logs/ sessions/ screenshots/ combo_history.jsonl
```

#### Restore Data
```bash
# Extract backup
tar -xzf backup-20260218.tar.gz
```

## Monitoring

### View Metrics (when implemented)

```bash
# Prometheus metrics
curl http://localhost:9090/metrics

# Application health
curl http://localhost:3773/health
```

### Grafana Dashboards

1. Access Grafana: http://localhost:3000
2. Login: admin/admin
3. Import dashboard from monitoring/grafana/dashboards/

## Cleanup

### Remove Everything
```bash
# Stop and remove containers
docker-compose down

# Remove volumes (WARNING: deletes data)
docker-compose down -v

# Remove images
docker rmi superrmurrer:latest
```

### Remove Only Containers
```bash
docker-compose down
```

## Multi-Environment Setup

### Development
```bash
docker-compose -f docker-compose.yml -f docker-compose.dev.yml up
```

### Production
```bash
docker-compose -f docker-compose.yml -f docker-compose.prod.yml up -d
```

Create environment-specific override files:

**docker-compose.dev.yml:**
```yaml
version: '3.8'
services:
  superrmurrer:
    environment:
      - NODE_ENV=development
      - LOG_LEVEL=debug
      - BROWSER_HEADLESS=false
    volumes:
      - .:/app
      - /app/node_modules
```

**docker-compose.prod.yml:**
```yaml
version: '3.8'
services:
  superrmurrer:
    environment:
      - NODE_ENV=production
      - LOG_LEVEL=info
      - BROWSER_HEADLESS=true
    restart: always
    deploy:
      resources:
        limits:
          cpus: '4.0'
          memory: 8G
```

## Kubernetes Deployment (Advanced)

For Kubernetes deployment, see `k8s/` directory (to be created) for:
- Deployment manifests
- Service definitions
- ConfigMaps
- Secrets management

## Support

For issues or questions:
- Check logs: `docker-compose logs -f`
- GitHub Issues: https://github.com/Lumbijumbi/SuPerrMurrer/issues
- Documentation: `docs/` directory

## Next Steps

1. Review and customize `docker-compose.yml`
2. Set up monitoring (optional)
3. Configure authentication (when implemented)
4. Set up automated backups
5. Configure CI/CD pipeline

---

**Last Updated:** February 18, 2026  
**Version:** 2.0.0
