---
name: Documentation Issue
about: Report missing, unclear, or incorrect documentation
title: '[DOCS] '
labels: documentation
assignees: ''
---

## Documentation Issue

Describe what documentation is missing, unclear, or incorrect.

## Location

Where is this documentation located (or where should it be)?

- [ ] README.md
- [ ] /docs/ files (specify which)
- [ ] Code comments
- [ ] API documentation
- [ ] Examples
- [ ] Other: ___________

## Current State

What does the documentation currently say (if anything)?

## Suggested Improvement

What should the documentation say instead? (Be specific if possible)

## Additional Context

- Who is the target audience? (beginners, advanced users, developers)
- Are there related documentation areas that should also be updated?
- Do you have examples or references from other projects?

## Checklist

- [ ] I have checked if this documentation exists elsewhere
- [ ] I have provided specific suggestions for improvement
- [ ] I am willing to submit a PR to fix this (optional)
