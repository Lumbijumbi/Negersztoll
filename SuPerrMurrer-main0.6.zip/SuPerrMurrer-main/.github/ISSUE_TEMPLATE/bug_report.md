---
name: Bug Report
about: Report a bug or issue
title: '[BUG] '
labels: bug
assignees: ''
---

## Bug Description

A clear and concise description of what the bug is.

## To Reproduce

Steps to reproduce the behavior:

1. Go to '...'
2. Run command '....'
3. See error

## Expected Behavior

A clear and concise description of what you expected to happen.

## Actual Behavior

What actually happened instead.

## Environment

- **OS**: [e.g., Ubuntu 22.04, Windows 11, macOS 13]
- **Node.js Version**: [e.g., v18.17.0]
- **SuPerrMurrer Version**: [e.g., 2.0.0]
- **Browser**: [e.g., Chrome 120]
- **Installation Method**: [e.g., npm install, git clone]

## Configuration

<details>
<summary>Relevant config.js settings (remove sensitive data)</summary>

```javascript
// Paste relevant configuration here
```

</details>

## Logs

<details>
<summary>Error logs or output</summary>

```
Paste error logs here
```

</details>

## Screenshots

If applicable, add screenshots to help explain your problem.

## Additional Context

Add any other context about the problem here:
- Does it happen consistently or intermittently?
- Did it work in a previous version?
- Any recent changes to your setup?

## Checklist

- [ ] I have searched existing issues to ensure this is not a duplicate
- [ ] I have included all relevant information above
- [ ] I have removed any sensitive data (credentials, API keys, etc.)
- [ ] I am using this tool for authorized testing only
