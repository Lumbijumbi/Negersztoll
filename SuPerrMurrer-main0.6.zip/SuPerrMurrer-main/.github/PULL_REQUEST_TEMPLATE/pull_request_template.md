## Description

<!-- Provide a clear and concise description of what this PR does -->

## Type of Change

<!-- Check all that apply -->

- [ ] Bug fix (non-breaking change that fixes an issue)
- [ ] New feature (non-breaking change that adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] Documentation update
- [ ] Code refactoring (no functional changes)
- [ ] Performance improvement
- [ ] Test additions/improvements
- [ ] Build/CI changes

## Related Issues

<!-- Link related issues here -->

Closes #(issue number)

## Changes Made

<!-- Provide a detailed list of changes -->

- Change 1
- Change 2
- Change 3

## Testing

<!-- Describe how you tested these changes -->

### Manual Testing

- [ ] Tested with sample credentials
- [ ] Tested with valid proxies
- [ ] Verified log output
- [ ] Checked for memory leaks
- [ ] Tested error handling

### Automated Testing

- [ ] All existing tests pass
- [ ] Added new tests for new functionality
- [ ] Test coverage maintained or improved

### Test Environment

- **OS**:
- **Node.js Version**:
- **Browser**:

## Screenshots

<!-- If applicable, add screenshots -->

## Checklist

### Code Quality

- [ ] My code follows the project's coding standards
- [ ] I have performed a self-review of my own code
- [ ] I have commented my code, particularly in hard-to-understand areas
- [ ] My changes generate no new warnings
- [ ] I have removed any debug code or console.logs

### Documentation

- [ ] I have updated the README.md (if needed)
- [ ] I have updated relevant documentation in /docs/
- [ ] I have updated CHANGELOG.md
- [ ] I have added JSDoc comments for new functions

### Testing

- [ ] I have added tests that prove my fix is effective or that my feature works
- [ ] New and existing unit tests pass locally with my changes
- [ ] I have tested edge cases and error conditions

### Security & Ethics

- [ ] My changes don't introduce security vulnerabilities
- [ ] I have reviewed the SECURITY.md policy
- [ ] My changes maintain the educational purpose of the tool
- [ ] I haven't removed or disabled security warnings

### Dependencies

- [ ] I have not added unnecessary dependencies
- [ ] If I added dependencies, I have justified why they're needed
- [ ] All dependencies are from trusted sources
- [ ] I have run `npm audit` to check for vulnerabilities

## Breaking Changes

<!-- If this PR introduces breaking changes, describe them and migration steps -->

None / Describe here

## Performance Impact

<!-- Describe any performance implications -->

- [ ] No performance impact
- [ ] Performance improved
- [ ] Performance degraded (explain why acceptable)

## Additional Notes

<!-- Any additional information reviewers should know -->

## For Maintainers

<!-- To be filled by maintainers -->

- [ ] Code review completed
- [ ] Tests pass in CI
- [ ] Documentation reviewed
- [ ] Ready to merge
