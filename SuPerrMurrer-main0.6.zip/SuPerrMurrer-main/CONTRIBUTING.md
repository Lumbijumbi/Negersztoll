# Contributing to SuPerrMurrer

Thank you for your interest in contributing to SuPerrMurrer! This document provides guidelines and instructions for contributing.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Setup](#development-setup)
- [How to Contribute](#how-to-contribute)
- [Coding Standards](#coding-standards)
- [Testing](#testing)
- [Documentation](#documentation)
- [Submitting Changes](#submitting-changes)

## Code of Conduct

### Our Pledge

We are committed to providing a welcoming and inclusive environment for all contributors, regardless of experience level, background, or identity.

### Expected Behavior

- Be respectful and constructive
- Accept constructive criticism gracefully
- Focus on what is best for the community
- Show empathy towards others

### Unacceptable Behavior

- Harassment or discriminatory language
- Trolling or insulting comments
- Publishing others' private information
- Other unprofessional conduct

## Getting Started

### Prerequisites

- Node.js v14 or higher
- Git
- Google Chrome browser
- Basic understanding of JavaScript and async/await
- Familiarity with Playwright/Puppeteer

### Fork and Clone

1. Fork the repository on GitHub
2. Clone your fork:
```bash
git clone https://github.com/YOUR_USERNAME/SuPerrMurrer.git
cd SuPerrMurrer
```

3. Add upstream remote:
```bash
git remote add upstream https://github.com/Lumbijumbi/SuPerrMurrer.git
```

## Development Setup

### Install Dependencies

```bash
npm install patchright proxy-chain
```

### Create Test Files

```bash
# Create test credentials (use dummy data)
echo "test@example.com:testpass123" > test.txt

# Create test proxies
echo "http://proxy.example.com:8080" > Lightning_Proxies.txt
```

### Verify Installation

```bash
node play_version2_controller.js
```

## How to Contribute

### Types of Contributions

We welcome:

1. **Bug Fixes** - Fix issues identified in GitHub Issues
2. **New Features** - Add functionality (discuss first in an issue)
3. **Documentation** - Improve docs, add examples
4. **Performance** - Optimize speed, reduce memory usage
5. **Tests** - Add test coverage
6. **Refactoring** - Improve code quality

### Before You Start

1. **Check existing issues** - Someone may already be working on it
2. **Open an issue** - Discuss major changes before implementing
3. **Get feedback** - Ensure your approach aligns with project goals

## Coding Standards

### JavaScript Style

We follow modern JavaScript best practices:

```javascript
// ✅ Good: Use const/let, not var
const config = require('./config');
let counter = 0;

// ✅ Good: Use async/await
async function fetchData() {
  const result = await api.get('/data');
  return result;
}

// ✅ Good: Descriptive names
function calculateBackoffDelay(attempt) {
  return Math.pow(2, attempt) * 1000;
}

// ❌ Bad: Var, callbacks, unclear names
var x = 10;
api.get('/data', function(err, data) {
  cb(data);
});
```

### Code Organization

- **One responsibility per function** - Functions should do one thing well
- **Keep functions small** - Aim for <50 lines
- **Use meaningful names** - Avoid abbreviations unless standard
- **Comment complex logic** - Explain "why", not "what"

### Error Handling

```javascript
// ✅ Good: Specific error handling
try {
  await operation();
} catch (error) {
  if (error.message.includes('timeout')) {
    logger.warn('[OP]', 'Operation timed out, retrying...');
    await retry(operation);
  } else {
    logger.error('[OP]', 'Operation failed', { error: error.message });
    throw error;
  }
}

// ❌ Bad: Silent failures
try {
  await operation();
} catch (error) {
  // Ignore
}
```

### Configuration

- All magic numbers go in `config.js`
- Use descriptive config keys
- Provide sensible defaults
- Document each config option

### Logging

```javascript
// ✅ Good: Structured logging with context
logger.info('[MODULE]', 'Operation completed', { 
  duration: 1234, 
  itemsProcessed: 10 
});

// ✅ Good: Appropriate log levels
logger.debug('[DB]', 'Query executed', { query });
logger.info('[API]', 'Request received');
logger.warn('[CACHE]', 'Cache miss', { key });
logger.error('[AUTH]', 'Authentication failed', { username });

// ❌ Bad: Console.log everywhere
console.log('done');
console.log(data);
```

## Testing

### Manual Testing

Before submitting:

1. Test with dummy credentials
2. Verify no crashes with invalid input
3. Check log output is correct
4. Ensure no memory leaks (run for 5+ minutes)

### Test Checklist

- [ ] Code runs without errors
- [ ] Handles invalid input gracefully
- [ ] Produces correct log output
- [ ] Doesn't break existing functionality
- [ ] Works with both headless and non-headless modes
- [ ] Memory usage is reasonable

### Testing Tips

```bash
# Test with debug output
node play_version2_controller.js 2>&1 | tee test.log

# Monitor memory usage
watch -n 1 'ps aux | grep node'

# Test error handling
echo "invalid" > test.txt
node play_version2_controller.js
```

## Documentation

### Documentation Requirements

All contributions should include:

1. **Code comments** - Explain complex logic
2. **Function documentation** - JSDoc style for public APIs
3. **README updates** - If adding features
4. **Configuration docs** - If adding config options

### JSDoc Format

```javascript
/**
 * Retry async function with exponential backoff
 * 
 * @param {Function} fn - Async function to retry
 * @param {Object} options - Retry options
 * @param {number} options.maxRetries - Maximum retry attempts (default: 3)
 * @param {Function} options.shouldRetry - Determine if should retry
 * @returns {Promise<*>} Function result
 * @throws {Error} Last error if all retries fail
 * 
 * @example
 * const result = await retryWithBackoff(
 *   () => fetchData(),
 *   { maxRetries: 5 }
 * );
 */
async function retryWithBackoff(fn, options = {}) {
  // Implementation...
}
```

### README Updates

If adding a feature:

1. Add to feature list in README.md
2. Update relevant sections (Usage, Configuration, etc.)
3. Add examples if applicable
4. Update Table of Contents if needed

## Submitting Changes

### Commit Messages

Use clear, descriptive commit messages:

```bash
# ✅ Good: Clear and specific
git commit -m "Add retry mechanism for proxy connections"
git commit -m "Fix memory leak in browser cleanup"
git commit -m "Update config documentation for new timeout option"

# ❌ Bad: Vague or unclear
git commit -m "Fix bug"
git commit -m "Update code"
git commit -m "WIP"
```

### Commit Message Format

```
<type>: <subject>

<body>

<footer>
```

**Types:**
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style changes (formatting)
- `refactor`: Code refactoring
- `perf`: Performance improvements
- `test`: Test additions/changes
- `chore`: Build/tooling changes

**Example:**
```
feat: Add support for SOCKS5 proxies

Adds SOCKS5 proxy support via proxy-chain library.
Updated configuration to accept socks5:// URLs.
Added validation for proxy URL format.

Closes #123
```

### Pull Request Process

1. **Update your fork:**
```bash
git fetch upstream
git rebase upstream/main
```

2. **Create a feature branch:**
```bash
git checkout -b feature/my-new-feature
```

3. **Make your changes:**
```bash
# Edit files
git add .
git commit -m "feat: Add my new feature"
```

4. **Push to your fork:**
```bash
git push origin feature/my-new-feature
```

5. **Open a Pull Request:**
   - Go to GitHub
   - Click "New Pull Request"
   - Select your branch
   - Fill in the template

### Pull Request Template

```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Testing
How has this been tested?

## Checklist
- [ ] Code follows project style
- [ ] Self-review completed
- [ ] Comments added for complex logic
- [ ] Documentation updated
- [ ] No new warnings
- [ ] Manual testing completed
```

## Review Process

### What Reviewers Look For

1. **Correctness** - Does it work as intended?
2. **Style** - Follows coding standards?
3. **Performance** - Any performance concerns?
4. **Security** - Any security issues?
5. **Documentation** - Properly documented?
6. **Tests** - Adequate testing?

### Addressing Feedback

- Respond to all comments
- Make requested changes
- Push updates to same branch
- Mark conversations as resolved

### Merging

Once approved:
- Squash commits if requested
- Maintainer will merge
- Delete your feature branch

## Development Workflow

### Typical Workflow

```bash
# 1. Sync with upstream
git fetch upstream
git checkout main
git merge upstream/main

# 2. Create feature branch
git checkout -b fix/proxy-timeout

# 3. Make changes
# ... edit files ...

# 4. Test changes
node play_version2_controller.js

# 5. Commit
git add .
git commit -m "fix: Increase proxy connection timeout"

# 6. Push
git push origin fix/proxy-timeout

# 7. Open PR on GitHub
```

### Keeping PRs Small

- Focus on one thing per PR
- Split large changes into multiple PRs
- Makes review easier and faster

## Areas Needing Contribution

### High Priority

1. **Test Coverage** - Add automated tests
2. **Error Handling** - Improve error messages
3. **Performance** - Optimize slow operations
4. **Documentation** - More examples and guides

### Good First Issues

Look for issues labeled `good first issue`:
- Documentation improvements
- Simple bug fixes
- Adding examples
- Configuration enhancements

### Advanced Contributions

- CAPTCHA solving integration
- Multi-site support
- Headless optimization
- Docker containerization
- Web UI dashboard
- Database integration

## Getting Help

### Questions?

- Open an issue with question label
- Ask in pull request comments
- Review existing documentation

### Resources

- [README.md](../README.md) - Project overview
- [ARCHITECTURE.md](docs/ARCHITECTURE.md) - System design
- [API.md](docs/API.md) - Code reference
- [Playwright Docs](https://playwright.dev/) - Browser automation

## License

By contributing, you agree that your contributions will be licensed under the same license as the project.

## Recognition

Contributors will be:
- Listed in CONTRIBUTORS.md
- Credited in release notes
- Thanked in commit messages

---

**Thank you for contributing to SuPerrMurrer!** 🎉
