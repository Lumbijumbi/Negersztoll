#!/usr/bin/env python3
"""
Core extraction logic for combo extractor.
Handles parsing of various combo formats from text files.
"""

import re
from typing import Set, List, Tuple


class ComboExtractor:
    """Extract user:password or email:password combos from various formats."""
    
    def __init__(self):
        self.email_pattern = re.compile(r'[\w\.-]+@[\w\.-]+\.\w+')
        self.url_pattern = re.compile(r'https?://[^\s:]+')
        
    def extract_combos(self, lines: List[str], mode: str = 'email:password', 
                       dedupe: bool = True) -> List[str]:
        """
        Extract combos from lines based on the specified mode.
        
        Args:
            lines: List of lines to process
            mode: 'email:password' or 'user:password'
            dedupe: Whether to remove duplicates
            
        Returns:
            List of extracted combos
        """
        combos = []
        seen = set() if dedupe else None
        
        for line in lines:
            line = line.strip()
            # Skip empty lines and comments
            if not line or line.startswith('#'):
                continue
                
            extracted = self._extract_from_line(line, mode)
            
            if extracted:
                if dedupe:
                    if extracted not in seen:
                        seen.add(extracted)
                        combos.append(extracted)
                else:
                    combos.append(extracted)
        
        return combos
    
    def _extract_from_line(self, line: str, mode: str) -> str:
        """
        Extract combo from a single line.
        
        Supported formats:
        1. email:password (standard format, password may contain colons)
        2. URL:Login:Password (e.g., app.exeedme.com/:--.siCHociRkus@neuf.fr:_eDaH@$_$Z7)
        3. URL:User:Pass (e.g., https://app.exeedme.com/csgo:hanabi:Groaz526)
        4. Lines with additional metadata (separated by tabs)
        """
        # Handle lines with tabs (metadata format)
        if '\t' in line:
            # Extract only the first part (the actual combo)
            line = line.split('\t')[0].strip()
        
        # Count colons to determine format
        colon_count = line.count(':')
        
        # Format 1: Simple email:password or user:password (1 colon)
        if colon_count == 1:
            parts = line.split(':', 1)
            if len(parts) == 2:
                username, password = parts
                username = username.strip()
                password = password.strip()
                
                if mode == 'email:password':
                    # Check if username is an email
                    if self.email_pattern.match(username):
                        return f"{username}:{password}"
                else:  # user:password
                    return f"{username}:{password}"
        
        # Multiple colons: could be URL format or email:password with colon in password
        elif colon_count >= 2:
            # First, check if it starts with email:password format (email before first colon)
            first_part = line.split(':', 1)[0].strip()
            if self.email_pattern.match(first_part):
                # This looks like email:password where password contains colons
                parts = line.split(':', 1)
                username = parts[0].strip()
                password = parts[1].strip()
                
                if mode == 'email:password':
                    return f"{username}:{password}"
                else:
                    # In user:password mode, also accept email addresses
                    return f"{username}:{password}"
            
            # Not an email in the first part, try URL formats
            # Try to detect URL at the beginning
            if line.startswith('http://') or line.startswith('https://'):
                # Remove URL protocol and find next colon
                line_without_protocol = line.replace('https://', '').replace('http://', '')
                parts = line_without_protocol.split(':', 2)
                
                if len(parts) >= 3:
                    # parts[0] is domain, parts[1] is user, parts[2] is password
                    username = parts[1].strip()
                    password = parts[2].strip()
                    
                    if mode == 'email:password':
                        if self.email_pattern.match(username):
                            return f"{username}:{password}"
                    else:
                        return f"{username}:{password}"
            else:
                # Format: domain:login:password (no protocol)
                parts = line.split(':', 2)
                if len(parts) >= 3:
                    username = parts[1].strip()
                    password = parts[2].strip()
                    
                    # Clean up username if it has special characters at start/end
                    username = username.strip('/-.')
                    
                    if mode == 'email:password':
                        if self.email_pattern.match(username):
                            return f"{username}:{password}"
                    else:
                        return f"{username}:{password}"
        
        return ""
    
    def process_file(self, input_file: str, output_file: str, mode: str = 'email:password',
                     dedupe: bool = True, progress_callback=None) -> Tuple[int, int]:
        """
        Process a file and extract combos.
        
        Args:
            input_file: Path to input file
            output_file: Path to output file
            mode: 'email:password' or 'user:password'
            dedupe: Whether to remove duplicates
            progress_callback: Optional callback function(current, total) for progress
            
        Returns:
            Tuple of (total_lines_processed, combos_extracted)
        """
        # First pass: count lines for progress
        with open(input_file, 'r', encoding='utf-8', errors='ignore') as f:
            total_lines = sum(1 for _ in f)
        
        # Second pass: process lines
        combos = []
        seen = set() if dedupe else None
        
        with open(input_file, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f, 1):
                line = line.strip()
                # Skip empty lines and comments
                if line and not line.startswith('#'):
                    extracted = self._extract_from_line(line, mode)
                    if extracted:
                        if dedupe:
                            if extracted not in seen:
                                seen.add(extracted)
                                combos.append(extracted)
                        else:
                            combos.append(extracted)
                
                # Update progress every 1000 lines
                if progress_callback and i % 1000 == 0:
                    progress_callback(i, total_lines)
        
        # Final progress update
        if progress_callback:
            progress_callback(total_lines, total_lines)
        
        # Write results
        with open(output_file, 'w', encoding='utf-8') as f:
            for combo in combos:
                f.write(combo + '\n')
        
        return total_lines, len(combos)


if __name__ == '__main__':
    # Simple CLI test
    import sys
    
    if len(sys.argv) < 3:
        print("Usage: python extractor_core.py <input_file> <output_file> [mode] [dedupe]")
        print("  mode: 'email:password' or 'user:password' (default: email:password)")
        print("  dedupe: 'true' or 'false' (default: true)")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    mode = sys.argv[3] if len(sys.argv) > 3 else 'email:password'
    dedupe = sys.argv[4].lower() != 'false' if len(sys.argv) > 4 else True
    
    extractor = ComboExtractor()
    
    def progress(current, total):
        percent = (current / total) * 100
        print(f"\rProcessing: {current}/{total} ({percent:.1f}%)", end='', flush=True)
    
    total, extracted = extractor.process_file(input_file, output_file, mode, dedupe, progress)
    print(f"\n\nProcessed {total} lines, extracted {extracted} combos")
    print(f"Output saved to: {output_file}")
