#!/usr/bin/env node
/**
 * ============================================================================
 * CLI — Bulk Cookie Generator
 * ============================================================================
 *
 * Usage:
 *   node scripts/generateBulkCookies.js [--amount <n|s|m|l|xl>] [--output <dir>]
 *                                        [--concurrency <1-5>] [--headless]
 *
 * Amount shortcuts:
 *   s  →  100
 *   m  →  500
 *   l  → 1000
 *   xl → 2000
 *
 * Examples:
 *   node scripts/generateBulkCookies.js --amount 100
 *   node scripts/generateBulkCookies.js --amount l --output CookieExports --concurrency 2
 *   node scripts/generateBulkCookies.js --amount xl --headless
 */

'use strict';

const BulkCookieGenerator = require('../utils/bulkCookieGenerator');

// ── CLI argument parsing ──────────────────────────────────────────────────────

const AMOUNT_SHORTCUTS = { s: 100, m: 500, l: 1000, xl: 2000 };

function parseArgs(argv) {
  const args   = argv.slice(2);
  const result = {
    amount:      100,
    output:      'CookieExports',
    concurrency: 1,
    headless:    false
  };

  for (let i = 0; i < args.length; i++) {
    const flag = args[i];
    const next = args[i + 1];

    if (flag === '--amount' && next !== undefined) {
      if (AMOUNT_SHORTCUTS[next] !== undefined) {
        result.amount = AMOUNT_SHORTCUTS[next];
      } else {
        const n = parseInt(next, 10);
        result.amount = isNaN(n) || n < 1 ? 100 : n;
      }
      i++;
    } else if (flag === '--output' && next !== undefined) {
      result.output = next;
      i++;
    } else if (flag === '--concurrency' && next !== undefined) {
      const n = parseInt(next, 10);
      result.concurrency = isNaN(n) || n < 1 ? 1 : Math.min(n, 5);
      i++;
    } else if (flag === '--headless') {
      result.headless = true;
    }
  }

  return result;
}

// ── main ─────────────────────────────────────────────────────────────────────

async function main() {
  const opts = parseArgs(process.argv);

  console.log('[BulkCookieGenerator] Starting...');
  console.log(`  Amount:      ${opts.amount}`);
  console.log(`  Output dir:  ${opts.output}`);
  console.log(`  Concurrency: ${opts.concurrency}`);
  console.log(`  Headless:    ${opts.headless}`);
  console.log('');

  const generator = new BulkCookieGenerator({
    amount:      opts.amount,
    outputDir:   opts.output,
    concurrency: opts.concurrency,
    headless:    opts.headless
  });

  let lastReportedAt = 0;

  generator.on('progress', ({ current, total, successful, failed }) => {
    // Print progress every 10 captures (or on first/last)
    if (current - lastReportedAt >= 10 || current === total) {
      console.log(
        `[Progress] ${current}/${total}  ✓ ${successful}  ✗ ${failed}`
      );
      lastReportedAt = current;
    }
  });

  generator.on('error', err => {
    console.error('[BulkCookieGenerator] Fatal error:', err.message);
  });

  try {
    const { outputPath, totalSets, successful, failed } = await generator.generate();

    console.log('');
    console.log('[BulkCookieGenerator] Done!');
    console.log(`  Output file: ${outputPath}`);
    console.log(`  Total sets:  ${totalSets}`);
    console.log(`  Successful:  ${successful}`);
    console.log(`  Failed:      ${failed}`);

    process.exit(0);
  } catch (err) {
    console.error('[BulkCookieGenerator] Generation failed:', err.message);
    process.exit(1);
  }
}

main();
