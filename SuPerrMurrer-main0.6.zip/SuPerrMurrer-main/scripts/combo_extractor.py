#!/usr/bin/env python3
"""
Combo Extractor - GUI Application
Extract User:Password or Email:Password combos from large text files.
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import os
from extractor_core import ComboExtractor


class ComboExtractorGUI:
    """GUI for the combo extractor application."""
    
    def __init__(self, root):
        self.root = root
        self.root.title("Combo Extractor")
        self.root.geometry("700x500")
        self.root.resizable(False, False)
        
        self.extractor = ComboExtractor()
        self.input_file = None
        self.output_file = None
        self.is_processing = False
        
        self._setup_ui()
        
    def _setup_ui(self):
        """Setup the user interface."""
        # Title
        title_frame = ttk.Frame(self.root, padding="10")
        title_frame.grid(row=0, column=0, sticky=(tk.W, tk.E))
        
        title_label = ttk.Label(
            title_frame,
            text="Combo Extractor",
            font=("Arial", 18, "bold")
        )
        title_label.grid(row=0, column=0)
        
        subtitle_label = ttk.Label(
            title_frame,
            text="Extract User:Password or Email:Password from large text files",
            font=("Arial", 10)
        )
        subtitle_label.grid(row=1, column=0)
        
        # Main frame
        main_frame = ttk.Frame(self.root, padding="20")
        main_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Input file selection
        input_label = ttk.Label(main_frame, text="Input File:", font=("Arial", 10, "bold"))
        input_label.grid(row=0, column=0, sticky=tk.W, pady=(0, 5))
        
        input_frame = ttk.Frame(main_frame)
        input_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=(0, 15))
        
        self.input_entry = ttk.Entry(input_frame, width=50)
        self.input_entry.grid(row=0, column=0, padx=(0, 10))
        
        input_button = ttk.Button(
            input_frame,
            text="Browse...",
            command=self._browse_input
        )
        input_button.grid(row=0, column=1)
        
        # Output file selection
        output_label = ttk.Label(main_frame, text="Output File:", font=("Arial", 10, "bold"))
        output_label.grid(row=2, column=0, sticky=tk.W, pady=(0, 5))
        
        output_frame = ttk.Frame(main_frame)
        output_frame.grid(row=3, column=0, sticky=(tk.W, tk.E), pady=(0, 15))
        
        self.output_entry = ttk.Entry(output_frame, width=50)
        self.output_entry.grid(row=0, column=0, padx=(0, 10))
        
        output_button = ttk.Button(
            output_frame,
            text="Browse...",
            command=self._browse_output
        )
        output_button.grid(row=0, column=1)
        
        # Extraction mode
        mode_label = ttk.Label(main_frame, text="Extraction Mode:", font=("Arial", 10, "bold"))
        mode_label.grid(row=4, column=0, sticky=tk.W, pady=(0, 5))
        
        self.mode_var = tk.StringVar(value="email:password")
        
        mode_frame = ttk.Frame(main_frame)
        mode_frame.grid(row=5, column=0, sticky=tk.W, pady=(0, 15))
        
        email_radio = ttk.Radiobutton(
            mode_frame,
            text="Email:Password",
            variable=self.mode_var,
            value="email:password"
        )
        email_radio.grid(row=0, column=0, padx=(0, 20))
        
        user_radio = ttk.Radiobutton(
            mode_frame,
            text="User:Password",
            variable=self.mode_var,
            value="user:password"
        )
        user_radio.grid(row=0, column=1)
        
        # Options
        options_label = ttk.Label(main_frame, text="Options:", font=("Arial", 10, "bold"))
        options_label.grid(row=6, column=0, sticky=tk.W, pady=(0, 5))
        
        self.dedupe_var = tk.BooleanVar(value=True)
        
        dedupe_check = ttk.Checkbutton(
            main_frame,
            text="Remove duplicates (dedupe)",
            variable=self.dedupe_var
        )
        dedupe_check.grid(row=7, column=0, sticky=tk.W, pady=(0, 15))
        
        # Progress bar
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(
            main_frame,
            length=600,
            mode='determinate',
            variable=self.progress_var
        )
        self.progress_bar.grid(row=8, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # Status label
        self.status_label = ttk.Label(
            main_frame,
            text="Ready to extract combos",
            font=("Arial", 9),
            foreground="gray"
        )
        self.status_label.grid(row=9, column=0, sticky=tk.W, pady=(0, 15))
        
        # Extract button
        self.extract_button = ttk.Button(
            main_frame,
            text="Extract Combos",
            command=self._start_extraction,
            style="Accent.TButton"
        )
        self.extract_button.grid(row=10, column=0, pady=(10, 0))
        
        # Style
        style = ttk.Style()
        style.configure("Accent.TButton", font=("Arial", 11, "bold"))
        
    def _browse_input(self):
        """Browse for input file."""
        filename = filedialog.askopenfilename(
            title="Select Input File",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if filename:
            self.input_file = filename
            self.input_entry.delete(0, tk.END)
            self.input_entry.insert(0, filename)
            
            # Auto-suggest output filename
            if not self.output_file:
                base = os.path.splitext(filename)[0]
                suggested_output = f"{base}_extracted.txt"
                self.output_entry.delete(0, tk.END)
                self.output_entry.insert(0, suggested_output)
    
    def _browse_output(self):
        """Browse for output file."""
        filename = filedialog.asksaveasfilename(
            title="Select Output File",
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if filename:
            self.output_file = filename
            self.output_entry.delete(0, tk.END)
            self.output_entry.insert(0, filename)
    
    def _start_extraction(self):
        """Start the extraction process."""
        if self.is_processing:
            messagebox.showwarning("Warning", "Extraction already in progress!")
            return
        
        # Validate inputs
        input_file = self.input_entry.get().strip()
        output_file = self.output_entry.get().strip()
        
        if not input_file:
            messagebox.showerror("Error", "Please select an input file!")
            return
        
        if not output_file:
            messagebox.showerror("Error", "Please select an output file!")
            return
        
        if not os.path.exists(input_file):
            messagebox.showerror("Error", f"Input file not found: {input_file}")
            return
        
        # Start extraction in a separate thread
        self.is_processing = True
        self.extract_button.config(state="disabled")
        self.progress_var.set(0)
        self.status_label.config(text="Processing...", foreground="blue")
        
        thread = threading.Thread(
            target=self._extract_worker,
            args=(input_file, output_file),
            daemon=True
        )
        thread.start()
    
    def _extract_worker(self, input_file, output_file):
        """Worker thread for extraction."""
        try:
            mode = self.mode_var.get()
            dedupe = self.dedupe_var.get()
            
            def progress_callback(current, total):
                progress = (current / total) * 100
                self.root.after(0, self._update_progress, progress, current, total)
            
            total_lines, extracted_count = self.extractor.process_file(
                input_file,
                output_file,
                mode,
                dedupe,
                progress_callback
            )
            
            # Show success message
            self.root.after(
                0,
                self._extraction_complete,
                total_lines,
                extracted_count,
                output_file
            )
            
        except Exception as e:
            self.root.after(0, self._extraction_error, str(e))
    
    def _update_progress(self, progress, current, total):
        """Update progress bar."""
        self.progress_var.set(progress)
        self.status_label.config(
            text=f"Processing: {current:,} / {total:,} lines ({progress:.1f}%)"
        )
    
    def _extraction_complete(self, total_lines, extracted_count, output_file):
        """Handle extraction completion."""
        self.is_processing = False
        self.extract_button.config(state="normal")
        self.progress_var.set(100)
        self.status_label.config(
            text=f"Complete! Processed {total_lines:,} lines, extracted {extracted_count:,} combos",
            foreground="green"
        )
        
        messagebox.showinfo(
            "Success",
            f"Extraction complete!\n\n"
            f"Processed: {total_lines:,} lines\n"
            f"Extracted: {extracted_count:,} combos\n\n"
            f"Output saved to:\n{output_file}"
        )
    
    def _extraction_error(self, error_msg):
        """Handle extraction error."""
        self.is_processing = False
        self.extract_button.config(state="normal")
        self.progress_var.set(0)
        self.status_label.config(text="Error occurred", foreground="red")
        
        messagebox.showerror("Error", f"Extraction failed:\n\n{error_msg}")


def main():
    """Main entry point."""
    root = tk.Tk()
    app = ComboExtractorGUI(root)
    root.mainloop()


if __name__ == '__main__':
    main()
