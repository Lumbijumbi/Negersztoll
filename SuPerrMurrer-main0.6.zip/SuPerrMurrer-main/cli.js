#!/usr/bin/env node
/**
 * ============================================================================
 * SUPERRMURRER CLI - Main Entry Point
 * ============================================================================
 * 
 * Provides multiple ways to start the application:
 * - Interactive menu (default)
 * - Direct controller execution
 * - Quick start with command-line arguments
 * - Queue management commands
 * - System status and configuration
 */

const InteractiveMenu = require('./utils/interactiveMenu');
const ComboQueue = require('./utils/comboQueue');
const CredentialHistory = require('./utils/credentialHistory');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

// Parse command-line arguments
const args = process.argv.slice(2);
const command = args[0];
const subcommand = args[1];

// Version
const VERSION = '2.0.0';

// Help text
const showHelp = () => {
  console.log(`
═══════════════════════════════════════════════════════════════════════════
  SuPerrMurrer - Automated Credential Testing System v${VERSION}
═══════════════════════════════════════════════════════════════════════════

Usage:
  node cli.js [command] [options]

Commands:
  menu                     Launch interactive menu (default)
  start                    Start credential testing immediately
  queue <subcommand>       Manage combo queue/backlog
  import-logs [dir]        Import all JSONL log files into history
  stats [--history]        Show rich statistics summary
  status                   Show system status
  config                   Print current configuration
  profile <subcommand>     Manage performance profiles
  version, -v, --version   Show version number
  help, -h, --help         Show this help message

Queue Subcommands:
  queue add <filepath> [--priority N]   Add combo file to queue (priority 1-5)
  queue list                            Show queue status and files
  queue shuffle                         Shuffle the queue
  queue clear                           Clear completed items

Profile Commands:
  profile list                    List available profiles with details
  profile show <name>             Show detailed settings for a profile
  profile apply <name> [options]  Apply a profile to config.js
  profile <name>                  Quick apply shortcut (e.g. profile fast)

Profile Apply Options:
  --workers <n>                   Override max parallel workers
  --creds-per-proxy <n>           Override credentials per proxy
  --headless                      Enable headless mode
  --no-headless                   Disable headless mode
  --type-delay-min <ms>           Override min typing delay
  --type-delay-max <ms>           Override max typing delay

Stats Options:
  --history                       Show historical breakdown by date

Examples:
  node cli.js                                  # Launch interactive menu
  node cli.js start                            # Start testing immediately
  node cli.js stats                            # Show statistics summary
  node cli.js stats --history                  # Show historical trends
  node cli.js import-logs                      # Import from default logs/
  node cli.js import-logs /path/to/old/logs    # Import from specific dir
  node cli.js import-logs --replace            # Replace mode
  node cli.js profile list                     # List all profiles
  node cli.js profile show fast                # Show fast profile details
  node cli.js profile fast                     # Quick-apply fast profile
  node cli.js profile apply balanced           # Apply balanced profile
  node cli.js profile apply fast --workers 6   # Apply fast with 6 workers
  node cli.js queue add combos.txt             # Add file to queue
  node cli.js queue add combos.txt --priority 1  # Add with high priority
  node cli.js queue list                       # View queue status
  node cli.js status                           # Show system status
  node cli.js config                           # Print current config
  node cli.js version                          # Show version

For more information, visit: https://github.com/Lumbijumbi/SuPerrMurrer
═══════════════════════════════════════════════════════════════════════════
  `);
  process.exit(0);
};

// Queue management functions
async function handleQueue() {
  const config = require('./config');
  const history = new CredentialHistory(config.history);
  history.load();
  
  const queue = new ComboQueue({
    queueFile: config.queue.queueFile,
    historyInstance: history,
    randomize: config.queue.randomize,
    listDelay: config.queue.listDelay,
    listDelayJitter: config.queue.listDelayJitter,
    autoFeed: config.queue.autoFeed,
    deduplication: config.queue.deduplication,
    defaultPriority: config.queue.defaultPriority,
    maxQueueSize: config.queue.maxQueueSize
  });

  switch (subcommand) {
    case 'add': {
      const filepath = args[2];
      if (!filepath) {
        console.error('❌ Error: Please specify a file path');
        console.log('Usage: node cli.js queue add <filepath> [--priority N]');
        process.exit(1);
      }

      // Parse priority from args
      let priority = config.queue.defaultPriority;
      const priorityIndex = args.indexOf('--priority');
      if (priorityIndex >= 0 && args[priorityIndex + 1]) {
        priority = parseInt(args[priorityIndex + 1], 10);
        if (isNaN(priority) || priority < 1 || priority > 5) {
          console.error('❌ Error: Priority must be between 1 and 5');
          process.exit(1);
        }
      }

      try {
        const stats = queue.addFile(filepath, { priority });
        console.log(`\n✅ Successfully added file: ${path.basename(filepath)}`);
        console.log(`   Total lines: ${stats.added}`);
        console.log(`   Duplicates removed: ${stats.duplicatesRemoved}`);
        console.log(`   Already processed: ${stats.alreadyProcessed}`);
        console.log(`   New combos queued: ${stats.queued}`);
        console.log(`   Priority: ${'★'.repeat(priority)}${'☆'.repeat(5 - priority)}`);
      } catch (error) {
        console.error(`❌ Error: ${error.message}`);
        process.exit(1);
      }
      break;
    }

    case 'list': {
      const stats = queue.getStats();
      const files = queue.getFiles();

      console.log('\n📦 Queue Status:');
      console.log('═══════════════════════════════════════════════════════════════\n');
      
      console.log(`Total Files: ${stats.totalFiles}`);
      console.log(`Total Combos in Queue: ${stats.totalCombos}`);
      console.log(`Pending: ${stats.pending} | Processing: ${stats.processing} | Completed: ${stats.completed}`);
      console.log(`Paused: ${stats.paused ? 'Yes' : 'No'}`);
      console.log('');

      if (files.length === 0) {
        console.log('No files in queue.');
      } else {
        console.log('Files in Queue:');
        console.log('─────────────────────────────────────────────────────────────');
        console.log('# | File                  | Priority  | Status     | Total | Queued | Processed | Added');
        console.log('─────────────────────────────────────────────────────────────');
        
        files.forEach((file, index) => {
          const priorityStars = '★'.repeat(file.priority) + '☆'.repeat(5 - file.priority);
          const filename = file.filename.length > 20 ? file.filename.substring(0, 17) + '...' : file.filename.padEnd(20);
          const status = file.status.padEnd(10);
          const added = new Date(file.addedAt).toLocaleDateString();
          
          console.log(`${(index + 1).toString().padStart(2)} | ${filename} | ${priorityStars} | ${status} | ${file.lineCount.toString().padStart(5)} | ${file.queuedCount.toString().padStart(6)} | ${file.processedCount.toString().padStart(9)} | ${added}`);
        });
      }
      
      console.log('');
      break;
    }

    case 'shuffle': {
      queue.shuffle();
      console.log('✅ Queue shuffled successfully');
      break;
    }

    case 'clear': {
      const cleared = queue.clearCompleted();
      console.log(`✅ Cleared ${cleared} completed file(s) from queue`);
      break;
    }

    default:
      console.error(`❌ Unknown queue subcommand: ${subcommand}`);
      console.log('Usage: node cli.js queue <add|list|shuffle|clear>');
      process.exit(1);
  }
}

// Show system status
function showStatus() {
  console.log('\n🔍 System Status:');
  console.log('═══════════════════════════════════════════════════════════════\n');

  const config = require('./config');
  
  // Check if files exist
  const credentialsFile = path.join(process.cwd(), 'test.txt');
  const proxiesFile = path.join(process.cwd(), 'Lightning_Proxies.txt');
  const historyFile = path.join(process.cwd(), config.history.historyFile);
  const queueFile = path.join(process.cwd(), config.queue.queueFile);

  console.log('Files:');
  console.log(`  Credentials: ${fs.existsSync(credentialsFile) ? '✓ Found' : '✗ Not found'} (${credentialsFile})`);
  console.log(`  Proxies:     ${fs.existsSync(proxiesFile) ? '✓ Found' : '✗ Not found'} (${proxiesFile})`);
  console.log(`  History:     ${fs.existsSync(historyFile) ? '✓ Found' : '✗ Not found'} (${historyFile})`);
  console.log(`  Queue:       ${fs.existsSync(queueFile) ? '✓ Found' : '✗ Not found'} (${queueFile})`);
  
  console.log('\nConfiguration:');
  console.log(`  Browser: ${config.browser.channel} (${config.browser.headless ? 'headless' : 'headed'})`);
  console.log(`  Workers: ${config.batch.maxParallelWorkers} parallel`);
  console.log(`  Credentials per proxy: ${config.batch.credentialsPerProxy}`);
  console.log(`  History enabled: ${config.history.enabled ? 'Yes' : 'No'}`);
  console.log(`  Queue enabled: ${config.queue.enabled ? 'Yes' : 'No'}`);
  
  // Load history stats if available
  if (fs.existsSync(historyFile)) {
    try {
      const history = new CredentialHistory(config.history);
      history.load();
      const breakdown = history._breakdown();
      console.log('\nHistory Statistics:');
      console.log(`  Total entries: ${history.history.size}`);
      console.log(`  Successful: ${breakdown.success} | Failed: ${breakdown.failed} | Blocked: ${breakdown.blocked} | Captcha: ${breakdown.captcha}`);
    } catch (error) {
      console.log('\nHistory Statistics: Error loading');
    }
  }

  // Load queue stats if available
  if (fs.existsSync(queueFile)) {
    try {
      const historyInstance = new CredentialHistory(config.history);
      historyInstance.load();
      const queue = new ComboQueue({
        queueFile: config.queue.queueFile,
        historyInstance: historyInstance,
        ...config.queue
      });
      const stats = queue.getStats();
      console.log('\nQueue Statistics:');
      console.log(`  Total files: ${stats.totalFiles}`);
      console.log(`  Total combos: ${stats.totalCombos}`);
      console.log(`  Pending: ${stats.pending} | Processing: ${stats.processing} | Completed: ${stats.completed}`);
    } catch (error) {
      console.log('\nQueue Statistics: Error loading');
    }
  }

  console.log('');
}

// Show rich statistics
function showStats() {
  const showHistory = args.includes('--history');
  const config = require('./config');
  const historyFile = path.join(process.cwd(), config.history.historyFile);

  console.log('\n╔══════════════════════════════════════════════════════════════╗');
  console.log('║                    📊 STATISTICS SUMMARY                     ║');
  console.log('╚══════════════════════════════════════════════════════════════╝\n');

  if (!fs.existsSync(historyFile)) {
    console.log('  No history file found. Run some credential tests first.\n');
    return;
  }

  try {
    const history = new CredentialHistory(config.history);
    // Suppress console output during load
    const origLog = console.log;
    const origWarn = console.warn;
    console.log = () => {};
    console.warn = () => {};
    history.load();
    console.log = origLog;
    console.warn = origWarn;

    const entries = Array.from(history.history.values());
    const total = entries.length;

    if (total === 0) {
      console.log('  No entries in history.\n');
      return;
    }

    const breakdown = history._breakdown();
    const successRate = total > 0 ? (breakdown.success / total * 100).toFixed(1) : '0.0';

    // Helper to render ASCII progress bar (20 chars wide)
    function bar(count, total) {
      const filled = total > 0 ? Math.round((count / total) * 20) : 0;
      return '█'.repeat(filled) + '░'.repeat(20 - filled);
    }

    // Helper to format number with commas
    function fmt(n) {
      return n.toLocaleString();
    }

    console.log('Overall Performance');
    console.log(`  Total Processed:   ${fmt(total)} combos`);
    console.log(`  Success Rate:      ${successRate}%`);
    console.log('');

    console.log('Results Breakdown');
    console.log(`  ✅ Success:    ${fmt(breakdown.success).padStart(6)} (${(breakdown.success / total * 100).toFixed(1).padStart(5)}%)  ${bar(breakdown.success, total)}`);
    console.log(`  ❌ Failed:     ${fmt(breakdown.failed).padStart(6)} (${(breakdown.failed / total * 100).toFixed(1).padStart(5)}%)  ${bar(breakdown.failed, total)}`);
    console.log(`  🚫 Blocked:    ${fmt(breakdown.blocked).padStart(6)} (${(breakdown.blocked / total * 100).toFixed(1).padStart(5)}%)  ${bar(breakdown.blocked, total)}`);
    console.log(`  ⚠️  Captcha:    ${fmt(breakdown.captcha).padStart(6)} (${(breakdown.captcha / total * 100).toFixed(1).padStart(5)}%)  ${bar(breakdown.captcha, total)}`);
    console.log('');

    // Detection method breakdown
    const methods = {};
    for (const entry of entries) {
      if (entry.s === 'success' && entry.m) {
        methods[entry.m] = (methods[entry.m] || 0) + 1;
      }
    }
    const methodEntries = Object.entries(methods).sort((a, b) => b[1] - a[1]);
    if (methodEntries.length > 0) {
      console.log('Detection Methods');
      for (const [method, count] of methodEntries) {
        const pct = (count / breakdown.success * 100).toFixed(1);
        console.log(`  ${method.padEnd(20)} ${fmt(count).padStart(6)} (${pct}%)`);
      }
      console.log('');
    }

    // Historical breakdown by date
    if (showHistory) {
      const byDate = {};
      for (const entry of entries) {
        const date = entry.t ? entry.t.substring(0, 10) : 'unknown';
        if (!byDate[date]) byDate[date] = { success: 0, failed: 0, blocked: 0, captcha: 0, total: 0 };
        byDate[date].total++;
        if (entry.s === 'success') byDate[date].success++;
        else if (entry.s === 'failed') byDate[date].failed++;
        else if (entry.s === 'blocked') byDate[date].blocked++;
        else if (entry.s === 'captcha') byDate[date].captcha++;
      }
      const dates = Object.keys(byDate).sort().reverse().slice(0, 10);
      if (dates.length > 0) {
        console.log('Historical Breakdown (last 10 days)');
        console.log('  Date         Total   Success  Failed  Blocked  Captcha');
        console.log('  ─────────────────────────────────────────────────────');
        for (const date of dates) {
          const d = byDate[date];
          console.log(`  ${date}  ${fmt(d.total).padStart(6)}  ${fmt(d.success).padStart(7)}  ${fmt(d.failed).padStart(6)}  ${fmt(d.blocked).padStart(7)}  ${fmt(d.captcha).padStart(7)}`);
        }
        console.log('');
      }
    }

    // File stats
    const fileStats = fs.statSync(historyFile);
    const fileSizeKb = (fileStats.size / 1024).toFixed(1);
    console.log(`History File: ${historyFile}`);
    console.log(`File Size:    ${fileSizeKb} KB`);
    console.log('');
  } catch (error) {
    console.error('Error loading statistics:', error.message);
  }
}

// Import credentials from logs/ directory into history
async function handleImportLogs() {
  const config = require('./config');

  // Parse arguments: optional directory path, optional --replace flag
  let logsDir = path.join(process.cwd(), 'logs');
  let mode = 'merge';

  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--replace') {
      mode = 'replace';
    } else if (!args[i].startsWith('--')) {
      logsDir = path.resolve(args[i]);
    }
  }

  if (!fs.existsSync(logsDir)) {
    console.error(`❌ Logs directory not found: ${logsDir}`);
    process.exit(1);
  }

  const history = new CredentialHistory(config.history);
  const origLog = console.log;
  const origWarn = console.warn;
  console.log = () => {};
  console.warn = () => {};
  history.load();
  console.log = origLog;
  console.warn = origWarn;

  const beforeCount = history.history.size;

  console.log('\n╔══════════════════════════════════════════════════════════════╗');
  console.log('║               📂 IMPORT FROM LOGS FOLDER                    ║');
  console.log('╚══════════════════════════════════════════════════════════════╝\n');
  console.log(`  Logs directory: ${logsDir}`);
  console.log(`  Mode:           ${mode.toUpperCase()}`);
  console.log(`  Before import:  ${beforeCount} entries\n`);

  if (mode === 'replace') history.history.clear();

  const dirConfigs = {
    successful: {
      status: 'success',
      extract: e => ({ method: e.method, confidence: e.confidence, pointsBalance: e.pointsBalance, moneyBalance: e.moneyBalance })
    },
    failed: {
      status: 'failed',
      extract: e => ({ reason: e.reason })
    },
    blocked: {
      status: 'blocked',
      extract: e => ({ reason: e.reason })
    },
    captcha: {
      status: 'captcha',
      extract: () => ({})
    },
    errors: {
      status: 'failed',
      extract: e => ({ reason: e.error })
    }
  };

  let totalImported = 0;
  let totalSkipped = 0;
  let totalErrors = 0;
  let filesProcessed = 0;
  const breakdown = {};

  for (const [subdir, cfg] of Object.entries(dirConfigs)) {
    const dirPath = path.join(logsDir, subdir);
    breakdown[subdir] = { files: 0, imported: 0, skipped: 0, errors: 0 };

    if (!fs.existsSync(dirPath)) continue;

    const files = fs.readdirSync(dirPath).filter(f => f.endsWith('.jsonl'));
    breakdown[subdir].files = files.length;
    filesProcessed += files.length;

    for (const file of files) {
      const filePath = path.join(dirPath, file);
      let content;
      try {
        content = fs.readFileSync(filePath, 'utf8');
      } catch (e) {
        breakdown[subdir].errors++;
        totalErrors++;
        continue;
      }

      for (const line of content.split('\n').filter(l => l.trim())) {
        try {
          const entry = JSON.parse(line);
          const username = entry.username || entry.u;
          const password = entry.password || entry.p;
          if (!username || !password) continue;

          const key = history._key(username, password);
          if (mode === 'merge' && history.history.has(key)) {
            breakdown[subdir].skipped++;
            totalSkipped++;
          } else {
            const details = cfg.extract(entry);
            history.record(username, password, cfg.status, details);
            const origTimestamp = entry.timestamp || entry.t;
            if (origTimestamp) {
              const stored = history.history.get(key);
              if (stored) stored.t = origTimestamp;
            }
            breakdown[subdir].imported++;
            totalImported++;
          }
        } catch (e) {
          breakdown[subdir].errors++;
          totalErrors++;
        }
      }
    }
  }

  history.compact();

  console.log('  Results by directory:');
  console.log('  ─────────────────────────────────────────────────────────────');
  for (const [dir, stats] of Object.entries(breakdown)) {
    if (stats.files > 0 || stats.imported > 0) {
      console.log(`  ${dir.padEnd(12)} files: ${stats.files.toString().padStart(3)}  imported: ${stats.imported.toString().padStart(6)}  skipped: ${stats.skipped.toString().padStart(6)}  errors: ${stats.errors}`);
    }
  }
  console.log('');
  console.log(`  Files processed: ${filesProcessed}`);
  console.log(`  Total imported:  ${totalImported}`);
  console.log(`  Total skipped:   ${totalSkipped}`);
  console.log(`  Total errors:    ${totalErrors}`);
  console.log(`  After import:    ${history.history.size} entries`);
  console.log('');
}

// Show current configuration
function showConfig() {
  const config = require('./config');
  console.log('\n⚙️  Current Configuration:\n');
  console.log(JSON.stringify(config, null, 2));
  console.log('');
}

// Show version
function showVersion() {
  console.log(`SuPerrMurrer v${VERSION}`);
}

// Route based on command
async function main() {
  switch (command) {
    case 'help':
    case '--help':
    case '-h':
      showHelp();
      break;

    case 'version':
    case '--version':
    case '-v':
      showVersion();
      break;

    case 'queue':
      await handleQueue();
      break;

    case 'status':
      showStatus();
      break;

    case 'stats':
      showStats();
      break;

    case 'config':
      showConfig();
      break;

    case 'start':
      console.log('🚀 Starting credential testing...\n');
      const controller = spawn('node', ['play_version2_controller.js'], {
        stdio: 'inherit',
        cwd: process.cwd()
      });
      
      controller.on('close', (code) => {
        if (code === 0) {
          console.log('\n✓ Testing completed successfully!');
        } else {
          console.error(`\n✗ Testing exited with code ${code}`);
        }
        process.exit(code);
      });
      break;

    case 'profile':
      const profileCmd = args[1];
      const { PROFILES, getProfileDescriptions, getProfile, applyProfile, getProfileSettings } = require('./utils/configProfiles');
      
      if (profileCmd === 'list') {
        console.log('\n⚡ Available Performance Profiles:\n');
        const descs = getProfileDescriptions();
        Object.entries(descs).forEach(([name, desc]) => {
          const p = getProfile(name);
          console.log(`  ${desc}`);
          console.log(`    Workers: ${p.batch.maxParallelWorkers} | Creds/Proxy: ${p.batch.credentialsPerProxy} | Typing: ${p.form.typeDelayMin}-${p.form.typeDelayMax}ms`);
          console.log('');
        });
      } else if (profileCmd === 'show') {
        const name = args[2];
        const settings = getProfileSettings(name);
        if (!settings) {
          console.error(`Unknown profile: ${name}`);
          process.exit(1);
        }
        console.log(`\n${settings.description}\n`);
        // Print all settings grouped by section
        let currentSection = '';
        for (const s of settings.settings) {
          if (s.section !== currentSection) {
            currentSection = s.section;
            console.log(`\n  ${currentSection}:`);
          }
          console.log(`    ${s.label}: ${s.value}${s.type === 'number' && s.description ? ` (${s.description})` : ''}`);
        }
        console.log('');
      } else if (profileCmd === 'apply') {
        const name = args[2];
        if (!getProfile(name)) {
          console.error(`Unknown profile: ${name}. Available: ${Object.keys(PROFILES).join(', ')}`);
          process.exit(1);
        }
        const config = require('./config');
        const newConfig = applyProfile(config, name);
        newConfig.activeProfile = name;
        
        // Parse CLI overrides with validation
        for (let i = 3; i < args.length; i++) {
          if (args[i] === '--workers' && args[i+1]) { 
            const val = parseInt(args[++i], 10);
            if (isNaN(val) || val < 1 || val > 16) {
              console.error('Invalid --workers value. Must be between 1 and 16.');
              process.exit(1);
            }
            newConfig.batch.maxParallelWorkers = val;
          }
          if (args[i] === '--creds-per-proxy' && args[i+1]) { 
            const val = parseInt(args[++i], 10);
            if (isNaN(val) || val < 1 || val > 20) {
              console.error('Invalid --creds-per-proxy value. Must be between 1 and 20.');
              process.exit(1);
            }
            newConfig.batch.credentialsPerProxy = val;
          }
          if (args[i] === '--headless') { newConfig.browser.headless = true; }
          if (args[i] === '--no-headless') { newConfig.browser.headless = false; }
          if (args[i] === '--type-delay-min' && args[i+1]) { 
            const val = parseInt(args[++i], 10);
            if (isNaN(val) || val < 0) {
              console.error('Invalid --type-delay-min value. Must be >= 0.');
              process.exit(1);
            }
            newConfig.form.typeDelayMin = val;
          }
          if (args[i] === '--type-delay-max' && args[i+1]) { 
            const val = parseInt(args[++i], 10);
            if (isNaN(val) || val < 0) {
              console.error('Invalid --type-delay-max value. Must be >= 0.');
              process.exit(1);
            }
            newConfig.form.typeDelayMax = val;
          }
        }
        
        // Write to config.js
        const configPath = path.join(process.cwd(), 'config.js');
        const backupPath = configPath + '.backup.' + Date.now();
        fs.copyFileSync(configPath, backupPath);
        const { generateConfigFile } = require('./utils/configHelper');
        const configStr = generateConfigFile(newConfig);
        fs.writeFileSync(configPath, configStr, 'utf8');
        
        console.log(`\n✅ Profile "${name}" applied to config.js`);
        console.log(`📋 Backup saved to: ${backupPath}`);
        console.log('');
      } else if (getProfile(profileCmd)) {
        // Quick apply shortcut: node cli.js profile <name>
        const name = profileCmd;
        const config = require('./config');
        const profileConfig = getProfile(name);
        const newConfig = applyProfile(config, name);
        newConfig.activeProfile = name;

        // Show changes summary (current config → new profile settings)
        console.log(`\n✅ Applying profile: ${name}\n`);
        console.log('Changes:');
        console.log(`  batch.maxParallelWorkers:  ${config.batch.maxParallelWorkers} → ${profileConfig.batch.maxParallelWorkers}`);
        console.log(`  batch.credentialsPerProxy: ${config.batch.credentialsPerProxy} → ${profileConfig.batch.credentialsPerProxy}`);
        console.log(`  form.typeDelayMin:          ${config.form.typeDelayMin} → ${profileConfig.form.typeDelayMin}`);
        console.log(`  form.typeDelayMax:          ${config.form.typeDelayMax} → ${profileConfig.form.typeDelayMax}`);

        const configPath = path.join(process.cwd(), 'config.js');
        const backupPath = configPath + '.backup.' + Date.now();
        fs.copyFileSync(configPath, backupPath);
        const { generateConfigFile } = require('./utils/configHelper');
        const configStr = generateConfigFile(newConfig);
        fs.writeFileSync(configPath, configStr, 'utf8');

        console.log(`\nConfiguration saved to config.js`);
        console.log(`📋 Backup saved to: ${backupPath}`);
        console.log('');
      } else {
        console.log('Usage: node cli.js profile <list|show|apply|name> [options]');
        console.log(`Available profiles: ${Object.keys(require('./utils/configProfiles').PROFILES).join(', ')}`);
      }
      break;

    case 'import-logs':
      await handleImportLogs();
      break;

    case 'menu':
    case undefined:
    default:
      // Launch interactive menu
      const menu = new InteractiveMenu();
      await menu.start();
      break;
  }
}

// Handle errors
process.on('unhandledRejection', (error) => {
  console.error('\n❌ Unhandled error:', error.message);
  process.exit(1);
});

process.on('SIGINT', () => {
  console.log('\n\n👋 Goodbye!');
  process.exit(0);
});

// Start
main().catch((error) => {
  console.error('\n❌ Error:', error.message);
  process.exit(1);
});
