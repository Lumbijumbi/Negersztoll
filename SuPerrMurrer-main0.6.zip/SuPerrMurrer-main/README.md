# SuPerrMurrer - Automated Credential Testing System

[![Node.js](https://img.shields.io/badge/node-%3E%3D14.0.0-brightgreen)](https://nodejs.org/)
[![License](https://img.shields.io/badge/license-MIT-blue)](LICENSE)
[![Code of Conduct](https://img.shields.io/badge/code%20of%20conduct-contributor%20covenant-purple)](CODE_OF_CONDUCT.md)
[![Security](https://img.shields.io/badge/security-policy-red)](SECURITY.md)

## Overview

SuPerrMurrer is a sophisticated automated credential testing system built with Node.js and Playwright (Patchright). It's designed to test login credentials against the Supercard.ch authentication system using a distributed worker architecture with advanced detection mechanisms.

## 🚀 Quick Start

**Want to get started quickly?** Check out our [Quick Start Guide](docs/QUICKSTART.md) for a 5-minute setup!

### Interactive Menu (New!)

```bash
# Clone, install, and launch interactive menu in 3 commands
git clone https://github.com/Lumbijumbi/SuPerrMurrer.git
cd SuPerrMurrer && npm install
npm start
```

### Direct Execution

```bash
# Or run controller directly
npm run direct
# Or: node play_version2_controller.js
```

## 🎯 Key Features

### Core Features
- **Multi-Worker Architecture**: Parallel credential testing with configurable worker pools
- **Advanced CAS Detection**: Multi-strategy authentication success detection with confidence scoring
- **TGC Cookie Priority**: Highest confidence (99%) detection using CAS Ticket Granting Cookies
- **Intelligent Form Filling**: Character-by-character typing simulation with multiple fallbacks
- **Proxy Management**: Built-in proxy rotation, health checks, and blacklisting
- **Comprehensive Logging**: Structured logging with categorized results and metrics
- **Error Recovery**: Exponential backoff retry mechanisms with intelligent error classification
- **Real-time Metrics**: Live progress tracking and detailed performance analytics
- **CAPTCHA Detection**: Automatic reCAPTCHA v2 detection and reporting
- **🆕 Retry Queue System**: Automatic retry of failed credentials with configurable max retries; hardened against silent credential loss during worker crashes, shutdowns, and relaunch failures (v2.0.0 — 14 bug fixes)
- **🆕 Session Cookie Reuse**: Skip re-authentication by reusing valid sessions (24h default)
- **🆕 Webhook Notifications**: Real-time Discord/Slack notifications for batch completion and errors
- **🆕 Enhanced Console Output** (Phase 1): Beautiful colored output, enhanced progress bars with ETA, visual grouping with boxes, rich error messages, and ASCII tables
- **🆕 Interactive Main Menu** (Phase 1): User-friendly menu system with navigation, quick actions, system status, and keyboard shortcuts
- **🆕 Python Combo Extractor**: Standalone utility to extract and clean User:Password or Email:Password combos from large text files with GUI support

## 📋 Table of Contents

- [Quick Start](#-quick-start)
- [Python Combo Extractor](#-python-combo-extractor) 🆕
- [Architecture](#-architecture)
- [New Features](#-new-features)
- [Prerequisites](#-prerequisites)
- [Installation](#-installation)
- [Configuration](#-configuration)
- [Usage](#-usage)
- [Detection Methods](#-detection-methods)
- [File Structure](#-file-structure)
- [Output Files](#-output-files)
- [Documentation](#-additional-documentation)
- [Contributing](#-contributing)
- [License & Disclaimer](#-license)

## 🐍 Python Combo Extractor

**NEW!** A standalone Python utility for extracting and cleaning credential combos from large text files.

### Quick Start

```bash
# Launch GUI
python3 scripts/combo_extractor.py

# Or use CLI
python3 scripts/extractor_core.py input.txt output.txt email:password true
```

### Features

- 🎨 **Easy-to-use GUI** - Simple graphical interface for file processing
- 📊 **Progress Tracking** - Real-time progress bar for large files
- 🎯 **Multiple Formats** - Handles various input formats:
  - Standard: `email@domain.com:password`
  - URL format: `app.example.com:user@email.com:password`
  - Full URL: `https://site.com:username:password123`
- 🔄 **Deduplication** - Optional removal of duplicate combos
- ⚡ **Fast Processing** - Efficiently handles files with millions of lines
- 🎛️ **Two Extraction Modes**:
  - **Email:Password** - Only extracts combos with valid email addresses
  - **User:Password** - Extracts all user:password combos

### Documentation

For complete documentation, usage examples, and supported formats, see:
📖 **[Combo Extractor Guide](docs/COMBO_EXTRACTOR.md)**

### Example Usage

Clean your combo list before testing:

```bash
# Extract only email combos and remove duplicates
python3 scripts/extractor_core.py raw_breach.txt clean_combos.txt email:password true

# Use the output with SuPerrMurrer
cp clean_combos.txt test.txt
npm start
```

## 🏗️ Architecture

The system uses a **Controller-Worker** pattern:

```
┌─────────────────────────────────────────────────────────────┐
│                    CONTROLLER PROCESS                        │
│  (play_version2_controller.js)                              │
│                                                              │
│  • Reads credentials from test.txt                          │
│  • Reads proxies from Lightning_Proxies.txt                 │
│  • Distributes batches to workers                           │
│  • Monitors worker health and timeouts                      │
│  • Aggregates results and metrics                           │
└────────────┬────────────────────────────────────────────────┘
             │
             │ Spawns & Manages
             │
    ┌────────┴──────────┬──────────┬──────────┐
    ▼                   ▼          ▼          ▼
┌─────────┐      ┌─────────┐  ┌─────────┐  ┌─────────┐
│ WORKER 1│      │ WORKER 2│  │ WORKER 3│  │ WORKER 4│
└─────────┘      └─────────┘  └─────────┘  └─────────┘

Each Worker:
  • Launches browser with proxy
  • Tests assigned credentials
  • Performs CAS detection
  • Captures screenshots
  • Reports results back
```

### Process Flow

1. **Controller** reads credentials and proxies
2. **Controller** creates batches (default: 4 credentials per batch)
3. **Controller** spawns worker processes (max 4 parallel)
4. **Workers** test credentials using:
   - Browser automation (Playwright/Patchright)
   - Proxy chain for anonymity
   - Character-by-character form filling
   - Multi-strategy success detection
5. **Workers** report results via IPC
6. **Controller** aggregates and exports results

## 🎨 User Experience

### Interactive Mode

When you start SuPerrMurrer, you'll be greeted with an interactive wizard that guides you through configuration:

```
╔═══════════════════════════════════════════════════════════════╗
║              🚀 SuPerrMurrer - Credential Tester 🚀           ║
║                  Production-Ready Edition                     ║
╚═══════════════════════════════════════════════════════════════╝

🎯 What would you like to do?
  1. 🚀 Start new session
  2. ⏸️  Resume previous session
  3. 📊 View previous results
  4. 🧪 Run tests (dry run)
  5. ⚙️  Configure settings
  6. 🚪 Exit
```

### Performance Profiles

Choose from predefined profiles or create your own:

- **🚀 Fast**: 8 workers, 2-5ms typing — Best for large batches
- **⚡ Turbo**: 12 workers, 1-3ms typing — Maximum throughput for huge lists
- **🔥 Aggressive**: 10 workers, 1-4ms typing — High-speed with slightly more caution
- **⚖️ Balanced**: 4 workers, 4-10ms typing — Recommended good-all-rounder
- **🐢 Conservative**: 3 workers, 8-15ms typing — Careful low-risk approach
- **🥷 Stealth**: 2 workers, 10-20ms typing — Best detection avoidance
- **🦉 Night Owl**: 2 workers, 15-30ms typing — Long unattended overnight runs
- **💻 Low Resource**: 1 worker, 5-12ms typing — Minimal CPU/RAM usage
- **🐛 Debug**: 1 worker, verbose output — For testing & troubleshooting
- **🔧 Custom**: Start from any profile and override workers, delays, and other settings via the interactive wizard or config.

### Real-Time Dashboard

During execution, watch a beautiful live dashboard:

```
╔═══════════════════════════════════════════════════════════════╗
║              LIVE TESTING DASHBOARD                           ║
╚═══════════════════════════════════════════════════════════════╝

[████████████████████░░░░] 80.0% 80/100

┌─────────────────┬─────────────────┬─────────────────┐
│ ✅ Success:   45 │ ❌ Failed:    20 │ 🚫 Blocked:   10 │
├─────────────────┼─────────────────┼─────────────────┤
│ 🤖 Captcha:    5 │ ⚡ Rate: 12.5/m │ ⏱️ ETA: 01:35 │
└─────────────────┴─────────────────┴─────────────────┘

👷 Workers:
  🟢 Worker 1: Processing user@example.com
  🟢 Worker 2: Processing test@test.com
  ⚫ Worker 3: Idle
  ⚫ Worker 4: Idle
```

### Automatic Optimization

The system automatically:
- Detects optimal worker count based on your CPU and memory
- Monitors system resources and provides recommendations
- Performs health checks on proxies, workers, and memory
- Auto-recovers from network errors, timeouts, and crashes
- Validates configuration before starting to catch errors early

## 🆕 New Features

### Retry Queue System

Automatically retry failed credentials with intelligent tracking. As of v2.0.0, the retry
system has been hardened with 14 bug fixes to eliminate silent credential loss:

- **Crash Recovery**: Credentials from crashed or timed-out workers are automatically recovered into the retry queue
- **Multi-Pass Retry**: Retry processing runs up to 3 passes so credentials that fail during retry are re-queued
- **Per-Credential Success Tracking**: Individual `credential_result` IPC messages drive success marking (not bulk)
- **Duplicate Guard**: `credentialHistory.hasSucceeded()` prevents re-queuing already-successful credentials
- **Priority Ordering**: `getRetryablePrioritized()` orders credentials by failure-reason priority (proxy/bot blocks first) and, within the same priority, processes lower-attempt credentials first
- **Periodic Auto-Save**: Queue is saved periodically and on `SIGINT`/`SIGTERM`
- **Configurable Max Retries**: Default 3 retries, configurable in `config.js`
- **Failure Tracking**: Records timestamp and reason for each attempt
- **Persistence**: Queue saved to `retry_queue.json` and loaded on restart
- **Statistics**: Detailed stats on total added, retried, succeeded, and exhausted

**Configuration:**
```javascript
retry: {
  enabled: true,
  maxRetries: 3,
  queueFile: 'retry_queue.json',
  retryDelayMin: 5000,
  retryDelayMax: 10000
}
```

**Usage:**
- Retry queue is automatically managed by the controller
- Failed credentials are added by workers via IPC
- After all main batches complete, retry batches are processed
- View retry statistics in the final report

### Session Cookie Reuse

Skip re-authentication by reusing valid session cookies:

- **Session Storage**: Saves cookies after successful login to `sessions/` directory
- **Per-User Sessions**: One file per username for organized storage
- **Session Validation**: Checks expiration and max age before reuse
- **Auto Cleanup**: Expired sessions removed on startup
- **Fast Login**: Bypasses form filling and login for valid sessions

**Configuration:**
```javascript
session: {
  enabled: true,
  directory: 'sessions',
  maxAge: 24 * 60 * 60 * 1000, // 24 hours
  cleanupOnStart: true
}
```

**How It Works:**
1. Worker checks for valid session before login
2. If found, loads session cookies and navigates to account page
3. Verifies session validity by checking for logout/account indicators
4. If valid, skips login and continues to next credential
5. If invalid, deletes session and performs normal login
6. After successful login, saves session for future use

### Webhook Notifications

Real-time notifications to Discord, Slack, or generic webhooks:

- **Multiple Webhook Types**: Discord, Slack, or custom webhook formats
- **Event Types**: batch_complete, all_complete, blocked, error, success (optional)
- **Rate Limiting**: Max 1 message per second to avoid spam
- **Event Batching**: Similar events batched into single notification
- **Rich Formatting**: Emojis, color coding, timestamps, and statistics

**Configuration:**
```javascript
notifications: {
  enabled: false, // Disabled by default
  webhook: {
    url: process.env.WEBHOOK_URL || '',
    type: 'discord', // 'discord', 'slack', 'generic'
    events: ['batch_complete', 'all_complete', 'blocked', 'error'],
    includeSuccesses: false,
    rateLimit: {
      maxPerSecond: 1,
      batchSimilarEvents: true
    }
  }
}
```

**Setup:**
1. Enable notifications in `config.js` or set `enabled: true`
2. Set webhook URL via environment variable:
   ```bash
   export WEBHOOK_URL="https://discord.com/api/webhooks/..."
   ```
3. Or set directly in `config.js`
4. Choose webhook type: `discord`, `slack`, or `generic`
5. Select events to receive notifications for

**Notification Examples:**
- **Batch Complete**: Shows processed count, successes, TGC detections, CAPTCHAs
- **All Complete**: Summary with total stats, success rate, TGC rate, processing time
- **Blocked**: Alerts when account blocking is detected
- **Error**: Critical errors with context information

### Enhanced Console Output (Phase 1)

Beautiful, user-friendly console output with rich visual elements:

- **Standardized Color Coding**: 
  - Success operations: Green (✓)
  - Warnings: Yellow (⚠)
  - Errors: Red (✗)
  - Informational: Blue (ℹ)
  - Progress: Cyan (⏱)
- **Enhanced Progress Bars**: Shows percentage, ETA, processing rate (items/min), and success/failure counts
- **Visual Grouping**: Box-drawing characters create sections and group related information
- **Rich Error Messages**: Errors include cause, suggested remediation steps, error codes, and context
- **ASCII Tables**: Beautiful tabular formatting for results and statistics
- **Consistent Icons**: Visual indicators for common operations throughout the application
- **Typography**: Improved spacing and formatting for better readability

**Features:**
```javascript
const AdvancedLogger = require('./utils/logger');
const logger = new AdvancedLogger({ level: 'info' });

// Enhanced error messages with suggestions
logger.enhancedError({
  message: 'Proxy connection failed',
  cause: 'Proxy server may be offline',
  suggestions: [
    'Check proxy server status',
    'Verify proxy credentials',
    'Try a different proxy'
  ],
  errorCode: 'PROXY_ERROR'
});

// Visual sections with boxes
logger.section('Batch Status', 'Batch #1: 4/4 completed', {
  borderColor: 'green'
});

// ASCII tables for structured data
logger.table(
  ['Username', 'Status', 'Method'],
  [
    ['user1@example.com', '✓ Success', 'TGC Cookie'],
    ['user2@example.com', '✗ Failed', 'Invalid']
  ]
);

// Enhanced progress bars
const progressName = logger.createEnhancedProgressBar('processing', 100);
logger.updateEnhancedProgressBar('processing', 50, {
  successCount: 40,
  failureCount: 10
});
logger.stopEnhancedProgressBar('processing');
```

**Benefits:**
- **Faster debugging**: Rich error messages with actionable suggestions reduce troubleshooting time
- **Better visibility**: Color coding and icons make it easy to spot issues at a glance
- **Professional output**: Box-drawing and tables provide a polished, organized appearance
- **Progress tracking**: Enhanced progress bars show exactly where you are and when you'll finish

### Interactive Main Menu (Phase 1)

User-friendly interactive menu system for easy navigation and quick access to all features:

- **Main Menu Dashboard**: Central hub providing access to all major functions
  - 🚀 Credential Testing
  - ⚙️ Configuration Management
  - 📊 Results & Analysis
  - ⚡ Quick Actions
  - 🔍 System Status
  - 📖 Help & Documentation

- **Intuitive Navigation**: Arrow keys and Enter to select options
- **Quick Actions Menu**: Fast access to frequent operations
  - Quick Start with default settings
  - Retry failed credentials
  - View latest summary
  - Clear old logs
  - Reset retry queue
  - Delete session files

- **Keyboard Shortcuts**: Common operations at your fingertips
  - Ctrl+T - Start Testing
  - Ctrl+R - View Results
  - Ctrl+S - System Status
  - Ctrl+Q - Quick Actions

- **System Status Dashboard**: Real-time view of system health
  - Credentials file status and count
  - Proxies file status and count
  - Configuration validity
  - Log files count
  - Retry queue status
  - Active sessions count

**Launch Interactive Menu:**
```bash
npm start              # Launch interactive menu (default)
npm run menu           # Explicitly launch menu
node cli.js            # Direct CLI access
```

**Quick Commands:**
```bash
npm test               # Start testing immediately (bypass menu)
npm run direct         # Run controller directly
npm run help           # Show CLI help
```

**Features:**
- **No Configuration Required**: Works out of the box with sensible defaults
- **Context-Sensitive Help**: Documentation available at every step
- **Visual Feedback**: Spinners, progress indicators, and status messages
- **Error Prevention**: Confirmations for destructive actions
- **File Previews**: View credentials, proxies, configs, and results without leaving the menu
- **Safe Operations**: All dangerous actions require explicit confirmation

**Benefits:**
- **Reduced Learning Curve**: No need to memorize commands or file locations
- **Faster Workflow**: Navigate to any feature in seconds
- **Less Errors**: Clear options and confirmations prevent mistakes
- **Better Discoverability**: All features visible and accessible from one place
- **Professional Experience**: Polished interface that's pleasant to use

## 📦 Prerequisites

- **Node.js** v14 or higher
- **Chrome Browser** (not Chromium)
- **Patchright** (Playwright fork)
- **proxy-chain** for proxy tunneling

### Required Dependencies

```json
{
  "patchright": "latest",
  "proxy-chain": "latest"
}
```

## 🚀 Installation

1. Clone the repository:
```bash
git clone https://github.com/Lumbijumbi/SuPerrMurrer.git
cd SuPerrMurrer
```

2. Install dependencies:
```bash
npm install patchright proxy-chain
```

3. Install Chrome browser (if not already installed)

4. Prepare input files:
   - Create `test.txt` with credentials (format: `username:password`)
   - Create `Lightning_Proxies.txt` with proxy addresses

## ⚙️ Configuration

All configuration is centralized in `config.js`. Key sections:

### Browser Configuration
```javascript
browser: {
  timeout: 180 * 1000,        // 3 minutes per worker
  headless: false,            // Visible browser
  channel: 'chrome',          // Use Chrome, not Chromium
}
```

### Batch & Worker Configuration
```javascript
batch: {
  credentialsPerProxy: 4,     // Credentials per batch
  maxParallelWorkers: 4,      // Concurrent workers
}
```

### Detection Configuration
```javascript
detection: {
  confidenceThresholds: {
    tgc_cookie: { minConfidence: 0.99, category: 'TGC_COOKIE' },
    cas_ticket: { minConfidence: 0.99, category: 'REDIRECT_302' },
    oidc: { minConfidence: 0.95, category: 'REDIRECT_OIDC' },
    body_token: { minConfidence: 0.90, category: 'BODY_TOKEN' },
    set_cookie: { minConfidence: 0.85, category: 'SET_COOKIE' }
  },
  minimumSuccessConfidence: 0.85
}
```

See [Configuration Guide](docs/CONFIGURATION.md) for detailed options.

## 🎮 Usage

### Basic Usage

1. Add credentials to `test.txt`:
```
user1@example.com:password123
user2@example.com:secretpass
```

2. Add proxies to `Lightning_Proxies.txt`:
```
http://proxy1.example.com:8080
http://username:password@proxy2.example.com:8080
```

3. Run the controller:
```bash
node play_version2_controller.js
```

### Command Line Options

The system runs autonomously once started. Configuration changes should be made in `config.js`.

### Monitoring Progress

The controller displays:
- Real-time progress bar
- Per-batch results
- Success/failure counts
- TGC cookie detection rate
- Processing speed (credentials/minute)

### Example Output

```
[CONTROLLER] ════════════════════════════════════════════════════
[CONTROLLER] PATCHRIGHT CREDENTIAL TESTING CONTROLLER
[CONTROLLER] ════════════════════════════════════════════════════
[STARTUP] Configuration:
[STARTUP]   Total Credentials: 100
[STARTUP]   Total Proxies: 10
[STARTUP]   Credentials per Batch: 4
[STARTUP]   Max Parallel Workers: 4

[Progress] [████████████████████░░░░] 80.0% 80/100

[RESULTS] [Batch #20] Status: OK
[RESULTS]            Processed: 4
[RESULTS]            Success (>= 85%): 3/4
[RESULTS]            ✅ TGC Cookie: 2
[RESULTS]            ✅ Redirect 302: 1
```

## 🔍 Detection Methods

The system uses a **hierarchical detection strategy** with confidence scoring:

### 1. TGC Cookie Detection (99% Confidence) ⭐ PRIMARY
Detects CAS Ticket Granting Cookie - the most reliable success indicator.

```javascript
{
  ok: true,
  type: 'success',
  reason: 'tgc_cookie_detected',
  confidence: 0.99,
  detectionMethod: 'tgc_cookie',
  cookie: { name: 'TGC', domain: '.supercard.ch', secure: true }
}
```

### 2. CAS Ticket Redirect (99% Confidence)
Detects redirect with `ticket=ST-` parameter in URL.

### 3. OIDC Authorization (95% Confidence)
Detects OAuth/OIDC authorization flow redirects.

### 4. Body Token Detection (90% Confidence)
Finds authentication tokens in response body.

### 5. Set-Cookie Headers (85% Confidence)
Detects session/auth cookies in HTTP headers.

### Minimum Confidence Threshold
Only results with **confidence >= 85%** are logged as successful.

## 📁 File Structure

```
SuPerrMurrer/
├── cli.js                                 # 🆕 CLI entry point with interactive menu
├── config.js                              # Centralized configuration
├── package.json                           # 🆕 NPM package configuration
├── play_version2_controller.js            # Main controller process
├── play_version2_worker_integrated_Version5.js  # Worker process
│
├── utils/                                 # Utility modules
│   ├── logger.js                          # Advanced logging system
│   ├── enhancedConsole.js                 # 🆕 Enhanced console output (Phase 1)
│   ├── interactiveMenu.js                 # 🆕 Interactive main menu (Phase 1)
│   ├── casDetection.js                    # CAS/OAuth detection logic
│   ├── formSubmit.js                      # Submit button detection
│   ├── retryQueue.js                      # 🆕 Retry queue management
│   ├── sessionManager.js                  # 🆕 Session cookie reuse
│   └── webhookNotifier.js                 # 🆕 Webhook notifications
├── utils/                             # Utility modules
│   ├── logger.js                      # Advanced logging system
│   ├── casDetection.js                # CAS/OAuth detection logic
│   ├── formSubmit.js                  # Submit button detection
│   ├── retryQueue.js                  # 🆕 Retry queue management
│   ├── sessionManager.js              # 🆕 Session cookie reuse
│   ├── webhookNotifier.js             # 🆕 Webhook notifications
│   ├── projectTracker.js              # 🆕 Project status tracker utility
│   └── workflowManager.js             # 🆕 Workflow automation (NEW!)
│
├── errorRecovery.js                       # Error recovery with backoff
├── metricsCollector.js                    # Real-time metrics
├── formFill.js                            # Form filling utilities
│
├── example_tgc_detection_Version3.js  # Usage examples
│
├── test.txt                           # Input: credentials
├── Lightning_Proxies.txt              # Input: proxies
├── ichfiggdinimueter.txt              # Output: failed credentials
├── retry_queue.json                   # 🆕 Retry queue persistence
│
├── PROJECT_STATUS.md                  # 🆕 Development plan tracking
├── DEVELOPMENT_PLAN.md                # Comprehensive enhancement plan
├── DEVELOPMENT_PLAN_SUMMARY.md        # Executive summary
├── IMPLEMENTATION_SUMMARY.md          # Completed features log
│
├── sessions/                          # 🆕 Session storage (auto-created)
│   └── *.json                         # Per-user session files
│
├── reports/                           # 🆕 Generated reports (auto-created)
│   └── weekly-status-*.txt            # Weekly project status reports
│
└── logs/                              # Output directory
    ├── successful/                    # Success logs (JSONL)
    ├── failed/                        # Failure logs (JSONL)
    ├── blocked/                       # Blocked accounts
    ├── captcha/                       # CAPTCHA detections
    ├── screenshots/                   # Browser screenshots
    └── reports/                       # CSV and JSON reports
```

## 📊 Output Files

### Structured Logs (JSONL)
- `logs/successful/successes_YYYY-MM-DD.jsonl` - Successful logins with confidence scores
- `logs/failed/failures_YYYY-MM-DD.jsonl` - Failed login attempts
- `logs/blocked/blocked_YYYY-MM-DD.jsonl` - Blocked/banned accounts
- `logs/captcha/captchas_YYYY-MM-DD.jsonl` - CAPTCHA encounters

### Reports (CSV)
- `logs/reports/successful_YYYY-MM-DD.csv` - Success report with all details
- `logs/reports/failed_YYYY-MM-DD.csv` - Failure report with reasons

### Reports (JSON)
- `logs/reports/results_TIMESTAMP.json` - Complete results with statistics

### Screenshots
- `logs/screenshots/*.png` - Screenshots organized by status

### 🆕 New Data Files
- `retry_queue.json` - Retry queue state (persisted between runs)
- `sessions/*.json` - Session cookies per username (auto-managed)

### Legacy Files
- `ichfiggdinimueter.txt` - Failed credentials (backward compatibility)

## 📚 API Documentation

### Core Modules

#### `config.js`
Central configuration module exporting all settings.

#### `play_version2_controller.js`
Main controller that orchestrates worker processes.

**Key Functions:**
- `readCredentials(filepath)` - Parse credentials from file
- `readProxies(filepath)` - Parse proxy list
- `launchWorkerForSlice(slice, upstream, batchNum, rawProxies)` - Spawn worker

#### `play_version2_worker_integrated_Version5.js`
Worker process that tests credentials.

**Key Functions:**
- `ensureDirectories()` - Create log directories
- `testProxyTcp(upstream)` - Check proxy health
- `launchBrowserWithProxy(upstream)` - Start browser session
- `processCredentials(browser, slice)` - Test credential batch

#### `casDetection.js`
CAS authentication detection module.

**Exports:**
- `submitAndDetectCasFlow(page, username, password, opts)` - Main detection function

**Returns:**
```javascript
{
  ok: boolean,
  type: 'success' | 'failure' | 'captcha' | 'blocked',
  reason: string,
  confidence: number,  // 0.00 to 1.00
  detectionMethod: string,
  details: string,
  cookie?: object  // For TGC detection
}
```

#### `formFill.js`
Form input utilities with realistic typing.

**Exports:**
- `fastFill(page, selector, text, options)` - Fill single field
- `fillForm(page, fieldMap, options)` - Fill multiple fields

**Features:**
- Character-by-character typing with random delays
- Multiple fallback methods
- Input event triggering

#### `formSubmit.js`
Submit button detection and clicking.

**Exports:**
- `findAndClickSubmitButton(page, logPrefix)` - Find and click submit
- `detectRecaptcha(page)` - Detect CAPTCHA presence

**Strategies:**
1. CSS selectors (multiple patterns)
2. XPath
3. Button text matching
4. Form submission
5. Enter key press

#### `logger.js`
Advanced logging system with colored output.

**Class: AdvancedLogger**

**Methods:**
- `debug(prefix, message, data)` - Debug level
- `info(prefix, message, data)` - Info level
- `warn(prefix, message, data)` - Warning level
- `error(prefix, message, data)` - Error level
- `success(prefix, message, data)` - Success level
- `logSuccess(username, password, method, confidence, duration)` - Log successful login
- `logFailed(username, password, reason, details)` - Log failed login
- `logBlocked(username, password, reason, batchNum)` - Log blocked account
- `logCaptcha(username, password, version, batchNum)` - Log CAPTCHA
- `progressBar(current, total, prefix, barLength)` - Show progress
- `exportResults(format)` - Export to JSON/CSV

#### `errorRecovery.js`
Error handling with exponential backoff.

**Exports:**
- `calculateBackoffDelay(attempt)` - Compute retry delay
- `retryWithBackoff(fn, options)` - Retry with backoff
- `classifyError(error)` - Classify error type

**Error Types:**
- `NETWORK` - Proxy/tunnel errors (recoverable)
- `TIMEOUT` - Timeout errors (recoverable)
- `BLOCKED` - Authentication blocked (not recoverable)
- `NOT_FOUND` - 404 errors (not recoverable)
- `BROWSER_CRASH` - Browser crashes (recoverable)
- `UNKNOWN` - Other errors

#### `metricsCollector.js`
Real-time metrics collection.

**Class: MetricsCollector**

**Events:**
- `login_success` - Successful login
- `login_failed` - Failed login
- `captcha` - CAPTCHA detected
- `blocked` - Account blocked
- `proxy_failure` - Proxy error
- `navigation_error` - Navigation error
- `screenshot_failure` - Screenshot error
- `tunnel_error` - Proxy tunnel error
- `batch_complete` - Batch finished

**Methods:**
- `record(event, data)` - Record an event
- `getMetrics()` - Get current metrics
- `getDetailedMetrics()` - Get detailed breakdown
- `reset()` - Reset all metrics

## 🔒 Security Considerations

1. **Credentials Storage**: Credentials are stored in plain text in `test.txt`. Ensure file permissions are restricted.

2. **Proxy Security**: Use trusted proxy providers. The system supports authenticated proxies.

3. **Rate Limiting**: Configure `pauseBetweenBatchMin` and `pauseBetweenBatchMax` to avoid detection.

4. **Browser Fingerprinting**: The system uses Chrome's stealth mode but may still be detectable.

5. **Logs**: Output logs contain credentials. Secure the `logs/` directory appropriately.

## 🧪 Testing

### Automated Test Suite ✅

The project includes a comprehensive automated test suite with **212 tests** and **~90% code coverage**.

#### Running Tests

```bash
# Run all tests
npm test

# Run tests in watch mode
npm run test:watch

# Run only unit tests
npm run test:unit

# Run only integration tests
npm run test:integration
```

#### Test Coverage

- **Total Tests**: 212 passing
- **Test Suites**: 6 (5 unit, 1 integration)
- **Code Coverage**: ~90% for tested modules
- **Execution Time**: ~30 seconds

**Modules Tested:**
- ✅ CAS Detection (52 tests, 94% coverage)
- ✅ Error Recovery (38 tests, 95% coverage)
- ✅ Retry Queue (72 tests, 95% coverage)
- ✅ Form Fill (52 tests, 73% coverage)
- ✅ Configuration (86 tests, 100% coverage)
- ✅ Integration Workflows (6 tests)

For detailed test documentation, see [tests/README.md](tests/README.md) and [TEST_SUMMARY.md](TEST_SUMMARY.md).

### Manual System Testing

To test the full system end-to-end:

1. Add a few test credentials to `test.txt`
2. Add working proxies to `Lightning_Proxies.txt`
3. Run: `node play_version2_controller.js`
4. Check `logs/` for results

### Debug Mode

Enable detailed logging in `config.js`:
```javascript
logging: {
  logLevel: 'debug',  // Show all debug messages
}
```

## 🐛 Troubleshooting

### Browser Launch Fails
```
Error: Failed to launch browser
```
**Solution**: Install Chrome browser and ensure Patchright is installed.

### Proxy Connection Errors
```
Error: ECONNREFUSED
```
**Solution**: 
- Verify proxy addresses in `Lightning_Proxies.txt`
- Check proxy authentication credentials
- Ensure proxies are online

### TGC Not Detected
**Solution**:
- Credentials may be invalid
- Check if account is blocked
- Verify Supercard.ch is accessible through proxy

### Workers Timing Out
**Solution**:
- Increase `browser.timeout` in `config.js`
- Reduce `batch.maxParallelWorkers`
- Check system resources (CPU, memory)

## 📈 Performance Tuning

### Optimize Proxy Traffic (NEW!)

**Reduce proxy bandwidth by 60-85% without affecting functionality!**

See **[Traffic Optimization Guide](docs/TRAFFIC_OPTIMIZATION.md)** for detailed instructions on:
- Request interception to block images, fonts, and tracking
- Optimized navigation strategies
- Session reuse for repeat credentials
- Traffic monitoring and measurement

**Quick Start - Enable Resource Blocking:**
```javascript
browser: {
  resourceBlocking: {
    enabled: true,
    blockTypes: ['image', 'font', 'media'],  // Safe defaults
    blockThirdParty: true
  }
}
```

### Optimize Throughput

1. **Increase Parallel Workers**:
```javascript
batch: {
  maxParallelWorkers: 8  // More concurrent workers
}
```

2. **Adjust Batch Size**:
```javascript
batch: {
  credentialsPerProxy: 10  // More credentials per batch
}
```

3. **Reduce Type Delays**:
```javascript
form: {
  typeDelayMin: 2,
  typeDelayMax: 5
}
```

### Trade-offs
- More workers = Higher throughput but more resource usage
- Faster typing = Higher speed but higher detection risk
- Larger batches = Better proxy utilization but longer per-batch time
- Resource blocking = 60-85% less traffic but test carefully for compatibility

## 🤝 Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add documentation
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License with an educational use disclaimer. See [LICENSE](LICENSE) for full details.

**TL;DR**: Free to use for educational and authorized security testing. Must comply with laws and obtain permission before testing systems.

## ⚠️ Disclaimer

This tool is designed for authorized security testing and research purposes only. Unauthorized access to computer systems is illegal.

**Key Points**:
- ✅ Use only on systems you own or have explicit permission to test
- ✅ Comply with all applicable laws and regulations
- ✅ For educational, research, and authorized penetration testing only
- ❌ Never use for unauthorized access or illegal activities
- ❌ Authors are not responsible for misuse

See [SECURITY.md](SECURITY.md) for detailed security policy and ethical guidelines.

## 📞 Support

### Getting Help

- 📚 **[Documentation Index](docs/INDEX.md)** - Central documentation hub
- 🐛 **[Issue Tracker](https://github.com/Lumbijumbi/SuPerrMurrer/issues)** - Report bugs or request features
- 🔒 **[Security Policy](SECURITY.md)** - Report security vulnerabilities
- 🤝 **[Contributing](CONTRIBUTING.md)** - Contribute to the project

### Reporting Issues

Use the appropriate template when creating issues:
- **Bug Report**: [.github/ISSUE_TEMPLATE/bug_report.md](.github/ISSUE_TEMPLATE/bug_report.md)
- **Feature Request**: [.github/ISSUE_TEMPLATE/feature_request.md](.github/ISSUE_TEMPLATE/feature_request.md)
- **Documentation**: [.github/ISSUE_TEMPLATE/documentation.md](.github/ISSUE_TEMPLATE/documentation.md)

## 🗺️ Roadmap

### Current Development (v3.0)
See **[Project Status](docs/status/PROJECT_STATUS.md)** for detailed tracking of the comprehensive v3.0 development plan, including:
- 📋 Stakeholder review and approval tracking
- 👥 Resource allocation and team assignments
- 🔧 Environment setup checklists
- 🚀 Phase 1-5 execution tracking (16-22 weeks)
- 📊 Sprint planning and iterative execution framework

For the complete technical plan, see **[Development Plan](docs/status/DEVELOPMENT_PLAN.md)**.

### Future Improvements (v3.x+)
- [ ] Support for multiple target sites
- [ ] Web UI for monitoring
- [ ] Database storage for results
- [ ] Distributed testing across multiple machines
- [ ] CAPTCHA solving integration
- [ ] Headless mode optimization
- [ ] Docker containerization
- [ ] REST API for remote control

## 📖 Documentation

**📑 [Complete Documentation Index](docs/INDEX.md)** - Find all documentation in one place

### Getting Started
- **[Quick Start Guide](docs/QUICKSTART.md)** - Get up and running in 5 minutes
- **[Installation Guide](#-installation)** - Detailed installation instructions
- **[Configuration Guide](docs/CONFIGURATION.md)** - Comprehensive configuration reference

### User Guides
- **[Advanced Usage](docs/ADVANCED_USAGE.md)** - Power user features and tips
- **[Traffic Optimization](docs/TRAFFIC_OPTIMIZATION.md)** - Reduce proxy bandwidth by 60-85%
- **[Docker Deployment](docs/DOCKER_DEPLOYMENT.md)** - Container deployment guide
- **[Troubleshooting](docs/TROUBLESHOOTING.md)** - Common issues and solutions

### Technical Documentation
- **[Architecture](docs/ARCHITECTURE.md)** - System design and internals
- **[API Reference](docs/API.md)** - Complete API documentation
- **[Detection Strategies](docs/DETECTION.md)** - How success detection works
- **[Test Suite](tests/README.md)** - Testing documentation

### Project Status & Planning
- **[Project Status](docs/status/PROJECT_STATUS.md)** - Real-time development tracking
- **[Development Plan](docs/status/DEVELOPMENT_PLAN.md)** - Comprehensive v3.0 roadmap
- **[Features Roadmap](docs/status/FEATURES_ROADMAP.md)** - Feature planning
- **[Project Tracking Guide](docs/PROJECT_TRACKING_QUICKSTART.md)** - Using tracking tools

### Security & Policies
- **[Security Policy](SECURITY.md)** - Vulnerability reporting and best practices
- **[Code of Conduct](CODE_OF_CONDUCT.md)** - Community standards
- **[Contributing Guide](CONTRIBUTING.md)** - How to contribute
- **[License](LICENSE)** - MIT License with educational disclaimer

## 🤝 Contributing

Contributions are welcome! Please:

1. Read our [Contributing Guide](CONTRIBUTING.md)
2. Fork the repository
3. Create a feature branch
4. Make your changes with tests
5. Submit a pull request

See [CONTRIBUTING.md](CONTRIBUTING.md) for detailed guidelines.

## 📄 License

This project is for educational purposes only. Use responsibly and only on systems you own or have permission to test.
