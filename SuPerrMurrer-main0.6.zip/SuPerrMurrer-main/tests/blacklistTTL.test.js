/**
 * Test Suite for Tiered Blacklist TTL
 * Tests different TTLs for different blacklist reasons
 */

const fs = require('fs');
const path = require('path');

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  ✅ ${name}`);
  } catch (e) {
    failed++;
    console.log(`  ❌ ${name}: ${e.message}`);
  }
}

function assert(condition, message) {
  if (!condition) throw new Error(message || 'Assertion failed');
}

// Mock config
const mockConfig = {
  proxy: {
    blacklistTTL: 10 * 60 * 1000, // 10 minutes default
    blacklistTTLs: {
      tcp_unreachable: 5 * 60 * 1000,      // 5 min
      captcha_triggered: 5 * 60 * 1000,    // 5 min (updated per requirement)
      rate_limited: 20 * 60 * 1000,        // 20 min
      ip_banned: 60 * 60 * 1000,           // 1 hour
      proxy_auth_failed: 2 * 60 * 1000,    // 2 min
      default: 10 * 60 * 1000
    }
  },
  output: {
    badProxiesFile: path.join(__dirname, 'test_bad_proxies.txt')
  }
};

// Mock logger
const mockLogger = {
  warn: () => {},
  debug: () => {}
};

// Test implementation of blacklist functions
const blacklist = new Map();

function addToBlacklist(upstream, reason = 'default', config, logger) {
  const ttl = config.proxy.blacklistTTLs?.[reason] || config.proxy.blacklistTTL;
  blacklist.set(upstream, { timestamp: Date.now(), ttl, reason });
  const ts = new Date().toISOString();
  fs.appendFileSync(config.output.badProxiesFile, `${ts}\t${upstream}\t${reason}\n`, 'utf8');
  logger.warn('[PROXY]', `Blacklisted proxy (${reason}, TTL: ${ttl/60000}min): ${upstream}`);
}

function isBlacklisted(upstream, config) {
  const entry = blacklist.get(upstream);
  if (!entry) return false;
  const ttl = typeof entry === 'object' ? entry.ttl : config.proxy.blacklistTTL;
  const timestamp = typeof entry === 'object' ? entry.timestamp : entry;
  if (Date.now() - timestamp > ttl) {
    blacklist.delete(upstream);
    return false;
  }
  return true;
}

function loadBlacklist(config, logger) {
  blacklist.clear();
  try {
    if (!fs.existsSync(config.output.badProxiesFile)) return;
    const lines = fs.readFileSync(config.output.badProxiesFile, 'utf8').split('\n').filter(Boolean);

    for (const ln of lines) {
      const parts = ln.split('\t');
      const ts = Date.parse(parts[0]);
      const upstream = parts.length >= 3 ? parts[1] : parts.slice(1).join('\t');
      const reason = parts.length >= 3 ? parts[2] : 'default';

      if (upstream && !isNaN(ts)) {
        const ttl = config.proxy.blacklistTTLs?.[reason] || config.proxy.blacklistTTL;
        if ((Date.now() - ts) <= ttl) {
          blacklist.set(upstream, { timestamp: ts, ttl, reason });
        }
      }
    }
    logger.debug('[PROXY]', `Loaded ${blacklist.size} blacklisted proxies`);
  } catch (e) {
    logger.warn('[PROXY]', `Failed to load blacklist: ${e && e.message}`);
  }
}

console.log('\n🧪 Testing Tiered Blacklist TTL...\n');

// Clean up test file before starting
if (fs.existsSync(mockConfig.output.badProxiesFile)) {
  fs.unlinkSync(mockConfig.output.badProxiesFile);
}

// Test 1: Different reasons get different TTLs
test('Different reasons get different TTLs', () => {
  addToBlacklist('192.168.1.1:8080', 'tcp_unreachable', mockConfig, mockLogger);
  addToBlacklist('192.168.1.2:8080', 'rate_limited', mockConfig, mockLogger);
  addToBlacklist('192.168.1.3:8080', 'ip_banned', mockConfig, mockLogger);
  
  const entry1 = blacklist.get('192.168.1.1:8080');
  const entry2 = blacklist.get('192.168.1.2:8080');
  const entry3 = blacklist.get('192.168.1.3:8080');
  
  assert(entry1.ttl === 5 * 60 * 1000, 'tcp_unreachable should have 5 min TTL');
  assert(entry2.ttl === 20 * 60 * 1000, 'rate_limited should have 20 min TTL');
  assert(entry3.ttl === 60 * 60 * 1000, 'ip_banned should have 60 min TTL');
});

// Test 2: Unknown reasons get default TTL
test('Unknown reasons get default TTL', () => {
  addToBlacklist('192.168.1.4:8080', 'unknown_reason', mockConfig, mockLogger);
  
  const entry = blacklist.get('192.168.1.4:8080');
  assert(entry.ttl === 10 * 60 * 1000, 'Unknown reason should get default TTL');
});

// Test 3: isBlacklisted() correctly expires entries based on their individual TTL
test('isBlacklisted() expires entries based on individual TTL', () => {
  blacklist.clear();
  
  const now = Date.now();
  
  // Add entry with short TTL that should be expired
  blacklist.set('192.168.1.5:8080', {
    timestamp: now - (6 * 60 * 1000), // 6 minutes ago
    ttl: 5 * 60 * 1000, // 5 min TTL
    reason: 'tcp_unreachable'
  });
  
  // Add entry with long TTL that should still be valid
  blacklist.set('192.168.1.6:8080', {
    timestamp: now - (6 * 60 * 1000), // 6 minutes ago
    ttl: 60 * 60 * 1000, // 1 hour TTL
    reason: 'ip_banned'
  });
  
  assert(!isBlacklisted('192.168.1.5:8080', mockConfig), 'Entry with 5 min TTL should be expired after 6 min');
  assert(isBlacklisted('192.168.1.6:8080', mockConfig), 'Entry with 60 min TTL should still be valid after 6 min');
});

// Test 4: loadBlacklist() handles both old format and new format
test('loadBlacklist() handles both old and new formats', () => {
  // Clean and recreate file with mixed formats
  if (fs.existsSync(mockConfig.output.badProxiesFile)) {
    fs.unlinkSync(mockConfig.output.badProxiesFile);
  }
  
  const now = new Date();
  const recent = new Date(now.getTime() - 1 * 60 * 1000); // 1 min ago
  
  // Old format: timestamp\tupstream
  fs.appendFileSync(mockConfig.output.badProxiesFile, 
    `${recent.toISOString()}\t192.168.1.7:8080\n`, 'utf8');
  
  // New format: timestamp\tupstream\treason
  fs.appendFileSync(mockConfig.output.badProxiesFile, 
    `${recent.toISOString()}\t192.168.1.8:8080\ttcp_unreachable\n`, 'utf8');
  
  blacklist.clear();
  loadBlacklist(mockConfig, mockLogger);
  
  assert(blacklist.has('192.168.1.7:8080'), 'Should load old format entry');
  assert(blacklist.has('192.168.1.8:8080'), 'Should load new format entry');
  
  const entry1 = blacklist.get('192.168.1.7:8080');
  const entry2 = blacklist.get('192.168.1.8:8080');
  
  assert(entry1.reason === 'default', 'Old format should default to "default" reason');
  assert(entry2.reason === 'tcp_unreachable', 'New format should preserve reason');
  assert(entry1.ttl === 10 * 60 * 1000, 'Old format should use default TTL');
  assert(entry2.ttl === 5 * 60 * 1000, 'New format should use reason-specific TTL');
});

// Test 5: addToBlacklist() writes the correct format to file
test('addToBlacklist() writes correct format to file', () => {
  if (fs.existsSync(mockConfig.output.badProxiesFile)) {
    fs.unlinkSync(mockConfig.output.badProxiesFile);
  }
  
  addToBlacklist('192.168.1.9:8080', 'rate_limited', mockConfig, mockLogger);
  addToBlacklist('192.168.1.10:8080', 'captcha_triggered', mockConfig, mockLogger);
  
  const content = fs.readFileSync(mockConfig.output.badProxiesFile, 'utf8');
  const lines = content.trim().split('\n');
  
  assert(lines.length === 2, 'Should have written 2 lines');
  
  const parts1 = lines[0].split('\t');
  const parts2 = lines[1].split('\t');
  
  assert(parts1.length === 3, 'Should have 3 tab-separated parts');
  assert(parts1[1] === '192.168.1.9:8080', 'Should have correct proxy');
  assert(parts1[2] === 'rate_limited', 'Should have correct reason');
  
  assert(parts2[1] === '192.168.1.10:8080', 'Should have correct proxy');
  assert(parts2[2] === 'captcha_triggered', 'Should have correct reason');
});

// Test 6: Expired entries are not loaded
test('loadBlacklist() skips expired entries', () => {
  if (fs.existsSync(mockConfig.output.badProxiesFile)) {
    fs.unlinkSync(mockConfig.output.badProxiesFile);
  }
  
  const oldDate = new Date(Date.now() - 70 * 60 * 1000); // 70 minutes ago
  
  // Write expired entry (70 min old with 60 min TTL)
  fs.appendFileSync(mockConfig.output.badProxiesFile, 
    `${oldDate.toISOString()}\t192.168.1.11:8080\tip_banned\n`, 'utf8');
  
  // Write valid entry
  const recentDate = new Date(Date.now() - 1 * 60 * 1000); // 1 min ago
  fs.appendFileSync(mockConfig.output.badProxiesFile, 
    `${recentDate.toISOString()}\t192.168.1.12:8080\tip_banned\n`, 'utf8');
  
  blacklist.clear();
  loadBlacklist(mockConfig, mockLogger);
  
  assert(!blacklist.has('192.168.1.11:8080'), 'Should not load expired entry');
  assert(blacklist.has('192.168.1.12:8080'), 'Should load valid entry');
});

// Test 7: Reason is stored correctly
test('Blacklist entries store reason correctly', () => {
  blacklist.clear();
  
  addToBlacklist('192.168.1.13:8080', 'proxy_auth_failed', mockConfig, mockLogger);
  
  const entry = blacklist.get('192.168.1.13:8080');
  assert(entry.reason === 'proxy_auth_failed', 'Should store correct reason');
  assert(entry.ttl === 2 * 60 * 1000, 'Should have correct TTL for proxy_auth_failed');
});

// Clean up test file after all tests
if (fs.existsSync(mockConfig.output.badProxiesFile)) {
  fs.unlinkSync(mockConfig.output.badProxiesFile);
}

console.log(`\n📊 Results: ${passed} passed, ${failed} failed\n`);
process.exit(failed > 0 ? 1 : 0);
