/**
 * Test Suite for AdaptiveDetectionTimeout
 * Tests adaptive timeout adjustment based on historical timing data
 */

const AdaptiveDetectionTimeout = require('../utils/adaptiveTimeout');

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  ✅ ${name}`);
  } catch (e) {
    failed++;
    console.log(`  ❌ ${name}: ${e.message}`);
  }
}

function assert(condition, message) {
  if (!condition) throw new Error(message || 'Assertion failed');
}

console.log('\n🧪 Testing AdaptiveDetectionTimeout...\n');

// Test 1: Returns base timeout when fewer than 3 samples
test('Returns base timeout with < 3 samples', () => {
  const timeout = new AdaptiveDetectionTimeout(12000);
  assert(timeout.getTimeout() === 12000, 'Should return base timeout');
  
  timeout.recordSuccess(5000);
  assert(timeout.getTimeout() === 12000, 'Should still return base timeout with 1 sample');
  
  timeout.recordSuccess(6000);
  assert(timeout.getTimeout() === 12000, 'Should still return base timeout with 2 samples');
});

// Test 2: Adapts after 3+ samples based on p95
test('Adapts timeout after 3+ samples', () => {
  const timeout = new AdaptiveDetectionTimeout(12000, { bufferMultiplier: 1.5 });
  
  // Record 5 samples: 2000, 3000, 4000, 5000, 10000
  timeout.recordSuccess(2000);
  timeout.recordSuccess(3000);
  timeout.recordSuccess(4000);
  
  // Now we have 3 samples, should start adapting
  const adaptive1 = timeout.getTimeout();
  assert(adaptive1 < 12000, 'Should adapt below base timeout');
  assert(adaptive1 > 3000, 'Should be above min timeout');
  
  timeout.recordSuccess(5000);
  timeout.recordSuccess(10000);
  
  // p95 of [2000, 3000, 4000, 5000, 10000] is 10000
  // adaptive = ceil(10000 * 1.5) = 15000, but capped at 12000
  const adaptive2 = timeout.getTimeout();
  assert(adaptive2 === 12000, `Should cap at base timeout, got ${adaptive2}`);
});

// Test 3: Respects min timeout floor
test('Respects min timeout floor', () => {
  const timeout = new AdaptiveDetectionTimeout(12000, { 
    minTimeout: 5000,
    bufferMultiplier: 1.5 
  });
  
  // Record very fast samples
  timeout.recordSuccess(100);
  timeout.recordSuccess(200);
  timeout.recordSuccess(300);
  
  const adaptive = timeout.getTimeout();
  assert(adaptive >= 5000, `Should respect min timeout of 5000, got ${adaptive}`);
});

// Test 4: Respects max (base) timeout ceiling
test('Respects max (base) timeout ceiling', () => {
  const timeout = new AdaptiveDetectionTimeout(8000, { 
    bufferMultiplier: 2.0 
  });
  
  // Record slow samples that would exceed base timeout with buffer
  timeout.recordSuccess(5000);
  timeout.recordSuccess(6000);
  timeout.recordSuccess(7000);
  
  const adaptive = timeout.getTimeout();
  assert(adaptive <= 8000, `Should cap at base timeout of 8000, got ${adaptive}`);
});

// Test 5: Handles edge case - all same values
test('Handles all same timing values', () => {
  const timeout = new AdaptiveDetectionTimeout(12000);
  
  timeout.recordSuccess(5000);
  timeout.recordSuccess(5000);
  timeout.recordSuccess(5000);
  timeout.recordSuccess(5000);
  
  const adaptive = timeout.getTimeout();
  // p95 of all 5000s is 5000, with 1.5x buffer = 7500
  assert(adaptive === 7500, `Expected 7500, got ${adaptive}`);
});

// Test 6: Handles single very slow outlier
test('Handles single very slow outlier', () => {
  const timeout = new AdaptiveDetectionTimeout(15000, {
    bufferMultiplier: 1.5
  });
  
  // Most samples are fast, one is very slow
  timeout.recordSuccess(2000);
  timeout.recordSuccess(2100);
  timeout.recordSuccess(2200);
  timeout.recordSuccess(2300);
  timeout.recordSuccess(12000); // Outlier
  
  // p95 should be 12000 (95th percentile of 5 items is index 4)
  // adaptive = ceil(12000 * 1.5) = 18000, capped at 15000
  const adaptive = timeout.getTimeout();
  assert(adaptive === 15000, `Expected 15000 (capped), got ${adaptive}`);
});

// Test 7: getStats() returns correct statistics
test('getStats() returns correct statistics', () => {
  const timeout = new AdaptiveDetectionTimeout(12000);
  
  // No samples yet
  let stats = timeout.getStats();
  assert(stats.samples === 0, 'Should have 0 samples initially');
  assert(stats.currentTimeout === 12000, 'Should return base timeout');
  
  // Add samples
  timeout.recordSuccess(1000);
  timeout.recordSuccess(2000);
  timeout.recordSuccess(3000);
  timeout.recordSuccess(4000);
  timeout.recordSuccess(5000);
  
  stats = timeout.getStats();
  assert(stats.samples === 5, 'Should have 5 samples');
  assert(stats.min === 1000, 'Min should be 1000');
  assert(stats.max === 5000, 'Max should be 5000');
  assert(stats.median === 3000, 'Median should be 3000');
  assert(stats.p95 === 5000, 'p95 should be 5000');
  assert(stats.currentTimeout !== undefined, 'Should have currentTimeout');
});

// Test 8: Buffer multiplier applies correctly
test('Buffer multiplier applies correctly', () => {
  const timeout1 = new AdaptiveDetectionTimeout(20000, { bufferMultiplier: 1.5 });
  const timeout2 = new AdaptiveDetectionTimeout(20000, { bufferMultiplier: 2.0 });
  
  // Same samples to both
  for (let i = 0; i < 5; i++) {
    timeout1.recordSuccess(4000);
    timeout2.recordSuccess(4000);
  }
  
  const adaptive1 = timeout1.getTimeout();
  const adaptive2 = timeout2.getTimeout();
  
  // p95 = 4000, so adaptive1 = 6000, adaptive2 = 8000
  assert(adaptive1 === 6000, `Expected 6000 with 1.5x, got ${adaptive1}`);
  assert(adaptive2 === 8000, `Expected 8000 with 2.0x, got ${adaptive2}`);
});

// Test 9: Max samples limit (sliding window)
test('Maintains max samples limit', () => {
  const timeout = new AdaptiveDetectionTimeout(12000, { maxSamples: 5 });
  
  // Add 10 samples
  for (let i = 1; i <= 10; i++) {
    timeout.recordSuccess(i * 1000);
  }
  
  const stats = timeout.getStats();
  assert(stats.samples === 5, `Should keep only 5 samples, got ${stats.samples}`);
  assert(stats.min === 6000, `Min should be 6000 (oldest removed), got ${stats.min}`);
  assert(stats.max === 10000, `Max should be 10000, got ${stats.max}`);
});

// Test 10: Ignores invalid timing values
test('Ignores invalid timing values', () => {
  const timeout = new AdaptiveDetectionTimeout(12000);
  
  timeout.recordSuccess(5000);
  timeout.recordSuccess(-100); // Negative
  timeout.recordSuccess(null);
  timeout.recordSuccess(undefined);
  timeout.recordSuccess('invalid');
  timeout.recordSuccess(6000);
  
  const stats = timeout.getStats();
  // Should only have recorded the valid values
  assert(stats.samples === 2, `Should have 2 valid samples, got ${stats.samples}`);
});

console.log(`\n📊 Results: ${passed} passed, ${failed} failed\n`);
process.exit(failed > 0 ? 1 : 0);
