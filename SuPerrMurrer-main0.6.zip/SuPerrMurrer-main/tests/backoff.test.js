/**
 * Test Suite for Progressive Backoff
 * Tests exponential backoff with jitter for consecutive blocks
 */

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  ✅ ${name}`);
  } catch (e) {
    failed++;
    console.log(`  ❌ ${name}: ${e.message}`);
  }
}

function assert(condition, message) {
  if (!condition) throw new Error(message || 'Assertion failed');
}

// Mock config
const mockConfig = {
  form: {
    pauseBetweenCredsMin: 100,
    pauseBetweenCredsMax: 350
  }
};

// Test implementation of backoff logic
let consecutiveBlocks = 0;

const rnd = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;

function getBackoffDelay() {
  if (consecutiveBlocks === 0) {
    return rnd(mockConfig.form.pauseBetweenCredsMin, mockConfig.form.pauseBetweenCredsMax);
  }
  const backoff = Math.min(1000 * Math.pow(2, consecutiveBlocks - 1), 30000);
  const jitter = backoff * 0.25 * (Math.random() * 2 - 1);
  return Math.floor(backoff + jitter);
}

console.log('\n🧪 Testing Progressive Backoff...\n');

// Test 1: Returns normal delay when consecutiveBlocks === 0
test('Returns normal delay when consecutiveBlocks === 0', () => {
  consecutiveBlocks = 0;
  const delay = getBackoffDelay();
  assert(delay >= mockConfig.form.pauseBetweenCredsMin, 
    `Delay ${delay} should be >= ${mockConfig.form.pauseBetweenCredsMin}`);
  assert(delay <= mockConfig.form.pauseBetweenCredsMax, 
    `Delay ${delay} should be <= ${mockConfig.form.pauseBetweenCredsMax}`);
});

// Test 2: Exponentially increases with consecutive blocks
test('Exponentially increases with consecutive blocks', () => {
  consecutiveBlocks = 1;
  const delay1 = getBackoffDelay();
  // Base backoff = 1000 * 2^0 = 1000ms
  // With ±25% jitter: 750-1250ms
  assert(delay1 >= 750 && delay1 <= 1250, 
    `Delay ${delay1} should be between 750-1250ms for 1 block`);
  
  consecutiveBlocks = 2;
  const delay2 = getBackoffDelay();
  // Base backoff = 1000 * 2^1 = 2000ms
  // With ±25% jitter: 1500-2500ms
  assert(delay2 >= 1500 && delay2 <= 2500, 
    `Delay ${delay2} should be between 1500-2500ms for 2 blocks`);
  
  consecutiveBlocks = 3;
  const delay3 = getBackoffDelay();
  // Base backoff = 1000 * 2^2 = 4000ms
  // With ±25% jitter: 3000-5000ms
  assert(delay3 >= 3000 && delay3 <= 5000, 
    `Delay ${delay3} should be between 3000-5000ms for 3 blocks`);
  
  consecutiveBlocks = 4;
  const delay4 = getBackoffDelay();
  // Base backoff = 1000 * 2^3 = 8000ms
  // With ±25% jitter: 6000-10000ms
  assert(delay4 >= 6000 && delay4 <= 10000, 
    `Delay ${delay4} should be between 6000-10000ms for 4 blocks`);
});

// Test 3: Caps at 30 seconds maximum
test('Caps at 30 seconds maximum', () => {
  consecutiveBlocks = 10; // Would be 1000 * 2^9 = 512000ms without cap
  const delay = getBackoffDelay();
  // Capped at 30000ms, with ±25% jitter: 22500-37500ms, but Math.floor should keep it reasonable
  assert(delay <= 37500, `Delay ${delay} should not exceed 37500ms (30000 + 25%)`);
  assert(delay >= 22500, `Delay ${delay} should be at least 22500ms (30000 - 25%)`);
});

// Test 4: Adds jitter within ±25% range
test('Adds jitter within ±25% range', () => {
  consecutiveBlocks = 3; // Base = 4000ms
  
  // Run multiple times to check jitter distribution
  const delays = [];
  for (let i = 0; i < 100; i++) {
    delays.push(getBackoffDelay());
  }
  
  const min = Math.min(...delays);
  const max = Math.max(...delays);
  
  // Should have some variation due to jitter
  assert(max - min > 500, 'Should have significant variation from jitter');
  
  // All values should be within ±25% of base (4000ms)
  assert(min >= 3000, `Min delay ${min} should be >= 3000ms (4000 - 25%)`);
  assert(max <= 5000, `Max delay ${max} should be <= 5000ms (4000 + 25%)`);
});

// Test 5: Reset behavior
test('Resets to 0 after success', () => {
  consecutiveBlocks = 5;
  
  // Simulate success
  consecutiveBlocks = 0;
  
  const delay = getBackoffDelay();
  assert(delay >= mockConfig.form.pauseBetweenCredsMin, 
    'Should return to normal delay after reset');
  assert(delay <= mockConfig.form.pauseBetweenCredsMax, 
    'Should return to normal delay after reset');
});

// Test 6: Progressive increase scenario
test('Progressive increase scenario (realistic flow)', () => {
  consecutiveBlocks = 0;
  
  // First block
  consecutiveBlocks++;
  const delay1 = getBackoffDelay();
  assert(delay1 >= 750 && delay1 <= 1250, '1st block: ~1s');
  
  // Second block
  consecutiveBlocks++;
  const delay2 = getBackoffDelay();
  assert(delay2 >= 1500 && delay2 <= 2500, '2nd block: ~2s');
  assert(delay2 > delay1 * 0.75, '2nd delay should be larger');
  
  // Third block
  consecutiveBlocks++;
  const delay3 = getBackoffDelay();
  assert(delay3 >= 3000 && delay3 <= 5000, '3rd block: ~4s');
  assert(delay3 > delay2 * 0.75, '3rd delay should be larger');
  
  // Reset on success
  consecutiveBlocks = 0;
  const delayAfterSuccess = getBackoffDelay();
  assert(delayAfterSuccess < 500, 'Should reset to normal after success');
});

// Test 7: Edge case - very high consecutive blocks
test('Edge case - very high consecutive blocks value', () => {
  consecutiveBlocks = 100; // Extreme value
  const delay = getBackoffDelay();
  
  // Should still be capped and within jitter range
  assert(delay >= 22500, 'Should respect minimum cap with jitter');
  assert(delay <= 37500, 'Should respect maximum cap with jitter');
});

// Test 8: Jitter randomness (statistical test)
test('Jitter provides randomness', () => {
  consecutiveBlocks = 2; // Base = 2000ms
  
  const delays = [];
  for (let i = 0; i < 50; i++) {
    delays.push(getBackoffDelay());
  }
  
  // Calculate standard deviation to verify randomness
  const mean = delays.reduce((a, b) => a + b, 0) / delays.length;
  const squareDiffs = delays.map(value => Math.pow(value - mean, 2));
  const avgSquareDiff = squareDiffs.reduce((a, b) => a + b, 0) / squareDiffs.length;
  const stdDev = Math.sqrt(avgSquareDiff);
  
  // Should have reasonable standard deviation (indicating randomness)
  assert(stdDev > 50, `Standard deviation ${stdDev} should indicate randomness`);
  
  // Mean should be close to base value (2000ms)
  assert(Math.abs(mean - 2000) < 300, `Mean ${mean} should be close to base 2000ms`);
});

// Test 9: Floor function ensures integer values
test('Returns integer values', () => {
  consecutiveBlocks = 3;
  
  for (let i = 0; i < 20; i++) {
    const delay = getBackoffDelay();
    assert(Number.isInteger(delay), `Delay ${delay} should be an integer`);
    assert(delay >= 0, 'Delay should be non-negative');
  }
});

console.log(`\n📊 Results: ${passed} passed, ${failed} failed\n`);
process.exit(failed > 0 ? 1 : 0);
