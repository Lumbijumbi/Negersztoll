/**
 * Test Suite for detectBlockOrCaptcha() improvements
 * Tests differentiated block detection and cached body text
 */

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  ✅ ${name}`);
  } catch (e) {
    failed++;
    console.log(`  ❌ ${name}: ${e.message}`);
  }
}

function assert(condition, message) {
  if (!condition) throw new Error(message || 'Assertion failed');
}

// Mock page object
function createMockPage(bodyText, hasCaptchaFrame = false) {
  return {
    evaluate: async (fn) => {
      if (fn.toString().includes('document.body')) {
        return bodyText;
      }
      if (fn.toString().includes('querySelector')) {
        return hasCaptchaFrame;
      }
      return null;
    }
  };
}

// Mock config
const mockConfig = {
  detection: {
    accountBlockPhrases: [],  // Empty - account lock phrase now treated as invalid credentials
    blockPhrases: ['Der Zugriff ist vorübergehend eingeschränkt'],
    invalidCredentialsPhrase: 'Bitte überprüfen Sie Ihre Eingaben und versuchen Sie es erneut.',
    accountLockPhrase: 'Ihr Konto wurde aufgrund von zu vielen Loginversuchen temporär gesperrt. Zum Freischalten setzen Sie jetzt ihr Passwort zurück'
  }
};

// Mock logger
const mockLogger = {
  warn: () => {}
};

// Create a test version of detectBlockOrCaptcha
async function detectBlockOrCaptcha(page, cachedBodyText = null, config, logger) {
  const INVALID_CREDENTIALS_PHRASE_NORMALIZED = config.detection.invalidCredentialsPhrase
    ? config.detection.invalidCredentialsPhrase.replace(/\s+/g, ' ').trim().toLowerCase()
    : 'bitte überprüfen sie ihre eingaben und versuchen sie es erneut.';
  const ACCOUNT_LOCK_PHRASE_NORMALIZED = config.detection.accountLockPhrase
    ? config.detection.accountLockPhrase.replace(/\s+/g, ' ').trim().toLowerCase()
    : '';
  const SUSPICIOUS_BEHAVIOR_PHRASE_NORMALIZED = 'etwas im verhalten des browsers hat uns stutzig gemacht.';
  // Note: Bot check and CAPTCHA use the same phrase in current config
  const BOT_CHECK_PHRASE_NORMALIZED = 'wir vergewissern uns, dass wir es wirklich mit ihnen zu tun haben, und nicht mit einem roboter.';
  const CAPTCHA_PHRASE_NORMALIZED = BOT_CHECK_PHRASE_NORMALIZED; // Same phrase for now

  try {
    const bodyText = cachedBodyText || await page.evaluate(() =>
      document.body && document.body.innerText ? document.body.innerText : ''
    ).catch(() => '');

    if (!bodyText) return false;
    const normalized = bodyText.replace(/\s+/g, ' ').trim().toLowerCase();

    // ACCOUNT-level blocks
    const accountBlockPhrases = config.detection.accountBlockPhrases || [];
    for (const phrase of accountBlockPhrases) {
      if (normalized.includes(phrase.toLowerCase())) {
        logger.warn('[DETECT]', `Account block detected: ${phrase}`);
        return { type: 'account_blocked', reason: 'account_locked', phrase };
      }
    }

    // IP/PROXY-level blocks
    for (const phrase of config.detection.blockPhrases) {
      if (normalized.includes(phrase.toLowerCase())) {
        logger.warn('[DETECT]', `Proxy/IP block phrase detected: ${phrase}`);
        return { type: 'proxy_blocked', reason: 'ip_rate_limited', phrase };
      }
    }

    // Suspicious behavior (proxy-level)
    if (normalized.includes(SUSPICIOUS_BEHAVIOR_PHRASE_NORMALIZED)) {
      logger.warn('[DETECT]', `Suspicious behavior detected (proxy-level)`);
      return { type: 'suspicious_behavior', reason: 'suspicious_behavior' };
    }

    // Bot verification page (proxy-level) - BEFORE generic CAPTCHA check
    if (normalized.includes(BOT_CHECK_PHRASE_NORMALIZED)) {
      logger.warn('[DETECT]', `Bot verification page detected`);
      return { type: 'bot_check', reason: 'bot_verification_page' };
    }

    // CAPTCHA
    if (normalized.includes(CAPTCHA_PHRASE_NORMALIZED)) {
      logger.warn('[DETECT]', `CAPTCHA detected`);
      return { type: 'captcha', reason: 'captcha_phrase' };
    }

    // Invalid credentials (including account lock due to too many attempts)
    if (normalized.includes(INVALID_CREDENTIALS_PHRASE_NORMALIZED)) {
      logger.warn('[DETECT]', `Invalid credentials phrase detected`);
      return { type: 'invalid_credentials', reason: 'invalid_credentials_phrase' };
    }
    
    if (ACCOUNT_LOCK_PHRASE_NORMALIZED && normalized.includes(ACCOUNT_LOCK_PHRASE_NORMALIZED)) {
      logger.warn('[DETECT]', `Account lock detected (too many login attempts) - treating as invalid credentials`);
      return { type: 'invalid_credentials', reason: 'account_lock_invalid_credentials' };
    }

  } catch (e) {
    logger.warn('[DETECT]', `Detection error: ${e.message}`);
  }

  return false;
}

console.log('\n🧪 Testing detectBlockOrCaptcha() improvements...\n');

// Test 1: Returns invalid_credentials for account lock phrase (too many login attempts)
test('Returns invalid_credentials for account lock phrase', async () => {
  const page = createMockPage('Ihr Konto wurde aufgrund von zu vielen Loginversuchen temporär gesperrt. Zum Freischalten setzen Sie jetzt ihr Passwort zurück.');
  const result = await detectBlockOrCaptcha(page, null, mockConfig, mockLogger);
  assert(result && result.type === 'invalid_credentials', 'Should detect as invalid credentials, not account block');
  assert(result.reason === 'account_lock_invalid_credentials', 'Should have account_lock_invalid_credentials reason');
});

test('Returns invalid_credentials for partial account lock phrase match', async () => {
  const page = createMockPage('Achtung: Ihr Konto wurde aufgrund von zu vielen Loginversuchen temporär gesperrt. Zum Freischalten setzen Sie jetzt ihr Passwort zurück. Bitte kontaktieren Sie uns.');
  const result = await detectBlockOrCaptcha(page, null, mockConfig, mockLogger);
  assert(result && result.type === 'invalid_credentials', 'Should detect as invalid credentials');
});

// Test 2: Returns proxy_blocked for IP/proxy-level phrases
test('Returns proxy_blocked for "Der Zugriff ist vorübergehend eingeschränkt"', async () => {
  const page = createMockPage('Der Zugriff ist vorübergehend eingeschränkt. Bitte versuchen Sie es später erneut.');
  const result = await detectBlockOrCaptcha(page, null, mockConfig, mockLogger);
  assert(result && result.type === 'proxy_blocked', 'Should detect proxy block');
  assert(result.reason === 'ip_rate_limited', 'Should have ip_rate_limited reason');
});

test('Returns suspicious_behavior for suspicious behavior', async () => {
  const page = createMockPage('Etwas im Verhalten des Browsers hat uns stutzig gemacht.');
  const result = await detectBlockOrCaptcha(page, null, mockConfig, mockLogger);
  assert(result && result.type === 'suspicious_behavior', 'Should detect suspicious_behavior');
  assert(result.reason === 'suspicious_behavior', 'Should have suspicious_behavior reason');
});

// Test 3: Returns bot_check for bot verification page
test('Returns bot_check for bot verification page', async () => {
  const page = createMockPage('Wir vergewissern uns, dass wir es wirklich mit Ihnen zu tun haben, und nicht mit einem Roboter.');
  const result = await detectBlockOrCaptcha(page, null, mockConfig, mockLogger);
  assert(result && result.type === 'bot_check', 'Should detect bot check page');
  assert(result.reason === 'bot_verification_page', 'Should have bot_verification_page reason');
});

// Test 4: Bot check takes precedence over CAPTCHA for the same phrase
test('Bot check detection takes precedence over generic CAPTCHA', async () => {
  const page = createMockPage('Wir vergewissern uns, dass wir es wirklich mit Ihnen zu tun haben, und nicht mit einem Roboter.');
  const result = await detectBlockOrCaptcha(page, null, mockConfig, mockLogger);
  assert(result && result.type === 'bot_check', 'Should detect as bot_check (takes precedence)');
  assert(result.reason === 'bot_verification_page', 'Should have bot_verification_page reason');
});

// Test 5: Returns invalid_credentials for invalid credential phrases
test('Returns invalid_credentials for error phrase', async () => {
  const page = createMockPage('Bitte überprüfen Sie Ihre Eingaben und versuchen Sie es erneut.');
  const result = await detectBlockOrCaptcha(page, null, mockConfig, mockLogger);
  assert(result && result.type === 'invalid_credentials', 'Should detect invalid credentials');
  assert(result.reason === 'invalid_credentials_phrase', 'Should have correct reason');
});

// Test 5: Returns false for normal pages
test('Returns false for normal page content', async () => {
  const page = createMockPage('Welcome to our website. Please log in to continue.');
  const result = await detectBlockOrCaptcha(page, null, mockConfig, mockLogger);
  assert(result === false, 'Should return false for normal content');
});

// Test 6: Handles edge cases
test('Handles empty body text', async () => {
  const page = createMockPage('');
  const result = await detectBlockOrCaptcha(page, null, mockConfig, mockLogger);
  assert(result === false, 'Should return false for empty body');
});

test('Handles null body text', async () => {
  const page = createMockPage(null);
  const result = await detectBlockOrCaptcha(page, null, mockConfig, mockLogger);
  assert(result === false, 'Should return false for null body');
});

test('Handles page.evaluate throwing error', async () => {
  const page = {
    evaluate: async () => {
      throw new Error('Page closed');
    }
  };
  const result = await detectBlockOrCaptcha(page, null, mockConfig, mockLogger);
  assert(result === false, 'Should return false on error');
});

// Test 7: Properly normalizes whitespace
test('Normalizes whitespace in phrase matching', async () => {
  const page = createMockPage('Ihr    Konto    wurde\n\n   aufgrund von zu vielen Loginversuchen temporär gesperrt.\n\nZum Freischalten setzen Sie jetzt ihr Passwort zurück.');
  const result = await detectBlockOrCaptcha(page, null, mockConfig, mockLogger);
  assert(result && result.type === 'invalid_credentials', 'Should detect as invalid credentials despite extra whitespace');
});

// Test 8: Accepts and uses cachedBodyText parameter
test('Uses cachedBodyText when provided', async () => {
  let evaluateCalled = false;
  const page = {
    evaluate: async () => {
      evaluateCalled = true;
      return 'This should not be used';
    }
  };
  
  const cachedText = 'Ihr Konto wurde aufgrund von zu vielen Loginversuchen temporär gesperrt. Zum Freischalten setzen Sie jetzt ihr Passwort zurück.';
  const result = await detectBlockOrCaptcha(page, cachedText, mockConfig, mockLogger);
  
  assert(!evaluateCalled, 'Should not call page.evaluate when cachedBodyText is provided');
  assert(result && result.type === 'account_blocked', 'Should detect using cached text');
});

test('Falls back to page.evaluate when cachedBodyText is null', async () => {
  let evaluateCalled = false;
  const page = {
    evaluate: async () => {
      evaluateCalled = true;
      return 'Ihr Konto wurde aufgrund von zu vielen Loginversuchen temporär gesperrt. Zum Freischalten setzen Sie jetzt ihr Passwort zurück.';
    }
  };
  
  const result = await detectBlockOrCaptcha(page, null, mockConfig, mockLogger);
  
  assert(evaluateCalled, 'Should call page.evaluate when no cachedBodyText');
  assert(result && result.type === 'invalid_credentials', 'Should detect as invalid credentials');
});

// Test 9: Priority order (invalid credentials checked after proxy blocks and CAPTCHA)
test('Account lock phrase returns invalid_credentials', async () => {
  const page = createMockPage('Der Zugriff ist vorübergehend eingeschränkt. Ihr Konto wurde aufgrund von zu vielen Loginversuchen temporär gesperrt.');
  const result = await detectBlockOrCaptcha(page, null, mockConfig, mockLogger);
  // Proxy block phrase should be detected first (it's checked before invalid credentials)
  assert(result && result.type === 'proxy_blocked', 'Proxy block should be detected first');
});

console.log(`\n📊 Results: ${passed} passed, ${failed} failed\n`);
process.exit(failed > 0 ? 1 : 0);
