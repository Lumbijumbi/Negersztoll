/**
 * Integration Tests for Balance Parsing and CAS Detection
 * Tests that verify the complete workflow works correctly
 */

const path = require('path');
const fs = require('fs');
const config = require('../../config');
const { CASDetector, submitAndDetectCasFlow } = require('../../utils/casDetection');

describe('Integration Tests', () => {
  describe('Balance Parsing Workflow', () => {
    it('should have all required configuration for balance parsing', () => {
      expect(config.account).toBeDefined();
      expect(config.account.url).toBeDefined();
      expect(config.account.balanceSelectors).toBeDefined();
      expect(config.account.balanceSelectors.points).toBe('span.myPointBalance-value');
      expect(config.account.balanceSelectors.money).toBe('span.myMoneyBalance-value');
      expect(config.account.balanceSelectors.timeout).toBe(3000);
    });

    it('should have cookie popup dismissal configured', () => {
      expect(config.account.cookiePopupSelectors).toBeDefined();
      expect(Array.isArray(config.account.cookiePopupSelectors)).toBe(true);
      expect(config.account.cookiePopupSelectors.length).toBeGreaterThan(0);
      expect(config.account.cookiePopupSelectors).toContain('#onetrust-accept-btn-handler');
    });

    it('should support N/A values for missing balances', () => {
      const sanitize = (s = '') => {
        if (!s) return 'unknown';
        return s.replace(/[\/\\\?\%\*\|"<>\n\r\t:  ]/g, '_').substring(0, 100);
      };

      const points = 'N/A';
      const money = 'N/A';

      expect(sanitize(points)).toBe('N_A');
      expect(sanitize(money)).toBe('N_A');
    });
  });

  describe('CAS Detection Integration', () => {
    let detector;

    beforeEach(() => {
      detector = new CASDetector();
    });

    it('should detect CAS ticket redirect as primary method', () => {
      const url = 'https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?ticket=ST-123456-ABCDEF';
      const result = detector.detectCASTicketRedirect(url);

      expect(result).not.toBeNull();
      expect(result.type).toBe('cas_ticket_redirect');
      expect(result.priority).toBe('secondary');
      expect(result.ticket).toBe('ST-123456-ABCDEF');
    });

    it('should detect TGC cookie as secondary method', () => {
      const cookieString = 'sessionid=abc; CASTGC=TGT-123-XYZ; other=value';
      const result = detector.detectTGCCookie(cookieString);

      expect(result).not.toBeNull();
      expect(result.type).toBe('cas_tgc_cookie');
      expect(result.priority).toBe('fallback');
    });

    it('should prioritize ticket over cookie in main detect method', () => {
      const context = {
        url: 'https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?ticket=ST-999',
        cookies: 'CASTGC=TGT-123'
      };

      const result = detector.detect(context);

      expect(result).not.toBeNull();
      expect(result.type).toBe('cas_ticket_redirect');
      expect(result.priority).toBe('secondary');
    });

    it('should validate ticket format', () => {
      expect(detector.isValidTicketFormat('ST-123456-ABCDEF')).toBe(true);
      expect(detector.isValidTicketFormat('ST-999')).toBe(true);
      expect(detector.isValidTicketFormat('INVALID')).toBe(false);
      expect(detector.isValidTicketFormat('TGC-123')).toBe(false);
    });

    it('should have correct CAS detection configuration', () => {
      expect(config.detection.cas).toBeDefined();
      expect(config.detection.cas.loginPath).toBe('/cas/login');
      expect(config.detection.cas.callbackPath).toBe('callbackAuthorize');
      expect(config.detection.cas.ticketPattern).toBeDefined();
      expect(config.detection.cas.timeout).toBe(12000);
    });

    it('should have confidence thresholds properly configured', () => {
      expect(config.detection.confidenceThresholds).toBeDefined();
      expect(config.detection.confidenceThresholds.tgc_cookie.minConfidence).toBe(0.99);
      expect(config.detection.confidenceThresholds.cas_ticket.minConfidence).toBe(0.99);
      expect(config.detection.minimumSuccessConfidence).toBe(0.85);
    });
  });

  describe('Logging Integration', () => {
    it('should support balance parameters in success logging', () => {
      const AdvancedLogger = require('../../utils/logger');
      const logger = new AdvancedLogger();

      // Test that logSuccess accepts balance parameters without errors
      expect(() => {
        logger.logSuccess('test@example.com', 'password', 'tgc_cookie', 0.99, 1000, '6666', '33');
      }).not.toThrow();

      // Verify the logged entry includes balance values
      const lastSuccess = logger.results.successful[logger.results.successful.length - 1];
      expect(lastSuccess).toBeDefined();
      expect(lastSuccess.pointsBalance).toBe('6666');
      expect(lastSuccess.moneyBalance).toBe('33');
    });

    it('should support backward compatibility for success logging without balances', () => {
      const AdvancedLogger = require('../../utils/logger');
      const logger = new AdvancedLogger();

      // Test that logSuccess works without balance parameters
      expect(() => {
        logger.logSuccess('test@example.com', 'password', 'cas_ticket_redirect', 0.99, 1500);
      }).not.toThrow();

      // Verify the logged entry doesn't have balance values
      const lastSuccess = logger.results.successful[logger.results.successful.length - 1];
      expect(lastSuccess).toBeDefined();
      expect(lastSuccess.pointsBalance).toBeUndefined();
      expect(lastSuccess.moneyBalance).toBeUndefined();
    });
  });

  describe('Complete Workflow Validation', () => {
    it('should have all components properly configured for the complete workflow', () => {
      // 1. Balance parsing configuration
      expect(config.account.balanceSelectors).toBeDefined();
      expect(config.account.balanceSelectors.points).toBeDefined();
      expect(config.account.balanceSelectors.money).toBeDefined();

      // 2. Cookie popup dismissal
      expect(config.account.cookiePopupSelectors).toBeDefined();
      expect(config.account.cookiePopupSelectors.length).toBeGreaterThan(0);

      // 3. CAS detection
      expect(config.detection.cas).toBeDefined();
      expect(config.casDetection.tgcCookieNames).toBeDefined();

      // 4. Logging
      expect(config.logging).toBeDefined();
      expect(config.logging.enableStructuredLogging).toBe(true);
    });

    it('should process workflow in correct order', () => {
      // The expected workflow order:
      const expectedWorkflow = [
        'Login to CAS',
        'Detect authentication (ticket or TGC)',
        'Navigate to account page',
        'Dismiss cookie popup',
        'Parse balance values',
        'Logout',
        'Log success with balance values'
      ];

      expect(expectedWorkflow.length).toBe(7);
      expect(expectedWorkflow[0]).toBe('Login to CAS');
      expect(expectedWorkflow[6]).toBe('Log success with balance values');
    });
  });
});
