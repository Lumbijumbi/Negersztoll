/**
 * Integration Tests
 * Tests for integrated workflows and module interactions
 */

const { CASDetector, submitAndDetectCasFlow } = require('../../utils/casDetection');
const { retryWithBackoff, classifyError } = require('../../errorRecovery');
const RetryQueue = require('../../utils/retryQueue');

describe('Integration Tests', () => {
  describe('CAS Detection with Error Recovery', () => {
    it('should retry CAS detection on transient errors', async () => {
      const mockPage = {
        url: jest.fn(),
        cookies: jest.fn()
      };

      let attemptCount = 0;
      mockPage.url.mockImplementation(() => {
        attemptCount++;
        if (attemptCount < 2) {
          throw new Error('timeout occurred');
        }
        return Promise.resolve('https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?ticket=ST-123');
      });
      mockPage.cookies.mockResolvedValue([]);

      const detectionWithRetry = async () => {
        return await submitAndDetectCasFlow(mockPage, 'test@example.com', 'pass', {
          timeoutMs: 1000,
          verbose: false
        });
      };

      const result = await retryWithBackoff(detectionWithRetry, {
        maxRetries: 3,
        verbose: false
      });

      expect(result.ok).toBe(true);
      expect(result.confidence).toBe(0.95);
      expect(attemptCount).toBe(2);
    });
  });

  describe('Retry Queue with Error Classification', () => {
    let queue;

    beforeEach(() => {
      queue = new RetryQueue({
        maxRetries: 2,
        queueFile: `integration_test_${Date.now()}.json`
      });
    });

    afterEach(() => {
      const fs = require('fs');
      const path = require('path');
      const queuePath = path.join(process.cwd(), queue.queueFile);
      if (fs.existsSync(queuePath)) {
        fs.unlinkSync(queuePath);
      }
    });

    it('should only queue recoverable errors', () => {
      const credential = {
        username: 'test@example.com',
        password: 'password123'
      };

      // Test various error types
      const errors = [
        new Error('timeout occurred'),
        new Error('blocked account'),
        new Error('tunnel connection failed')
      ];

      errors.forEach(error => {
        const classification = classifyError(error);
        
        if (classification.recoverable) {
          queue.add(credential, error.message);
        }
      });

      // Should have added 2 recoverable errors (timeout and tunnel)
      // Should NOT have added blocked error (non-recoverable)
      expect(queue.size()).toBe(1); // Same credential, so size is 1
      
      const entry = queue.toArray()[0];
      expect(entry.attempts.length).toBe(2); // 2 recoverable errors
      
      // Verify reasons
      const reasons = entry.attempts.map(a => a.reason);
      expect(reasons).toContain('timeout occurred');
      expect(reasons).toContain('tunnel connection failed');
      expect(reasons).not.toContain('blocked account');
    });

    it('should track retry attempts across queue operations', () => {
      const credential = {
        username: 'user@test.com',
        password: 'pass'
      };

      // Add credential multiple times
      queue.add(credential, 'first failure');
      expect(queue.getRetryable()).toHaveLength(1);

      queue.add(credential, 'second failure');
      expect(queue.getRetryable()).toHaveLength(1);

      queue.add(credential, 'third failure');
      expect(queue.getRetryable()).toHaveLength(0); // Exceeded max retries

      // Save and reload
      queue.save();
      
      const newQueue = new RetryQueue({
        maxRetries: 2,
        queueFile: queue.queueFile
      });
      newQueue.load();

      expect(newQueue.size()).toBe(1);
      expect(newQueue.getRetryable()).toHaveLength(0);
      
      const entry = newQueue.toArray()[0];
      expect(entry.retryCount).toBe(2);
      expect(entry.attempts).toHaveLength(3);
    });
  });

  describe('Form Fill with Retry Logic', () => {
    it('should retry form filling on transient failures', async () => {
      const { fastFill } = require('../../formFill');
      
      const mockPage = {
        focus: jest.fn().mockResolvedValue(undefined),
        evaluate: jest.fn().mockResolvedValue(undefined),
        type: jest.fn(),
        inputValue: jest.fn(),
        fill: jest.fn().mockResolvedValue(undefined)
      };

      jest.spyOn(console, 'log').mockImplementation(() => {});
      jest.spyOn(console, 'warn').mockImplementation(() => {});
      jest.spyOn(console, 'error').mockImplementation(() => {});

      let attemptCount = 0;
      mockPage.inputValue.mockImplementation(() => {
        attemptCount++;
        if (attemptCount < 3) {
          return Promise.resolve('wrong_value');
        }
        return Promise.resolve('test@example.com');
      });

      const fillWithRetry = async () => {
        const result = await fastFill(mockPage, '#email', 'test@example.com');
        if (!result) {
          throw new Error('Fill failed');
        }
        return result;
      };

      const result = await retryWithBackoff(fillWithRetry, {
        maxRetries: 3,
        verbose: false
      });

      expect(result).toBe(true);
      expect(attemptCount).toBeGreaterThan(1);

      console.log.mockRestore();
      console.warn.mockRestore();
      console.error.mockRestore();
    });
  });

  describe('Configuration Validation Integration', () => {
    const config = require('../../config');

    it('should have consistent configuration across modules', () => {
      // Verify retry configuration matches between modules
      expect(config.retry.maxRetries).toBe(config.errorRecovery.maxRetries);
      
      // Verify detection confidence thresholds are consistent
      expect(config.detection.minimumSuccessConfidence).toBeLessThanOrEqual(
        config.detection.confidenceThresholds.tgc_cookie.minConfidence
      );

      // Verify form delays are within browser timeout
      const maxFormDelay = config.form.typeDelayMax * 100; // Assume max 100 chars
      expect(maxFormDelay).toBeLessThan(config.browser.timeout);

      // Verify navigation timeout is less than browser timeout
      expect(config.navigation.timeout).toBeLessThan(config.browser.timeout);
    });

    it('should have valid CAS detection configuration', () => {
      const detector = new CASDetector();
      
      // Verify TGC cookie names from config work with detector
      config.casDetection.tgcCookieNames.forEach(cookieName => {
        const testCookie = `${cookieName}=test-value`;
        const result = detector.detectTGCCookie(testCookie);
        // Should detect or be null, but not throw
        expect(result === null || result.type === 'cas_tgc_cookie').toBe(true);
      });
    });
  });
});
