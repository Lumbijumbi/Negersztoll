/**
 * Unit Tests for Form Submit Module
 * Tests form submission strategies, button detection, Enter key submission, 
 * wait conditions, error handling, and various form types
 */

const {
  findAndClickSubmitButton,
  detectRecaptcha,
  waitForRecaptchaCompletion,
  findAndClickLogoutButton
} = require('../../utils/formSubmit');

// Mock config
jest.mock('../../config', () => ({
  login: {
    submitMethod: 'css',
    submitSelectors: [
      'button[type="submit"]',
      '#btnSubmit',
      '.login-button'
    ],
    submitXPath: '//button[contains(text(), "Submit")]',
    passwordSelector: '#password',
    recaptcha: {
      selectors: [
        '.g-recaptcha',
        '#recaptcha',
        'iframe[src*="recaptcha"]'
      ],
      callbackFunction: 'onRecaptchaSuccess'
    }
  },
  account: {
    logoutSelectors: [
      '#logout',
      '.logout-button',
      'a[href*="logout"]'
    ],
    logoutPhrases: ['Logout', 'Sign Out', 'Abmelden'],
    logoutRetryAttempts: 3,
    logoutRetryDelay: 1000,
    logoutPostDelay: 2000
  },
  logging: {
    logLevel: 'error'
  }
}));

describe('Form Submit Module', () => {
  let mockPage;
  let mockLocator;

  beforeEach(() => {
    mockLocator = {
      isVisible: jest.fn().mockResolvedValue(false),
      click: jest.fn().mockResolvedValue(undefined)
    };

    mockPage = {
      $: jest.fn().mockResolvedValue(null),
      $$: jest.fn().mockResolvedValue([]),
      evaluate: jest.fn().mockResolvedValue(undefined),
      press: jest.fn().mockResolvedValue(undefined),
      getByText: jest.fn().mockReturnValue(mockLocator),
      getByRole: jest.fn().mockReturnValue(mockLocator)
    };

    // Suppress console output in tests
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'warn').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('findAndClickSubmitButton', () => {
    describe('CSS Selector Strategy (Method 1)', () => {
      it('should successfully click submit button via CSS selector', async () => {
        const mockButton = {
          click: jest.fn().mockResolvedValue(undefined),
          isVisible: jest.fn().mockResolvedValue(true),
          isEnabled: jest.fn().mockResolvedValue(true)
        };

        mockPage.$.mockResolvedValueOnce(mockButton);

        const result = await findAndClickSubmitButton(mockPage);

        expect(result.success).toBe(true);
        expect(result.method).toBe('css_selector');
        expect(result.selector).toBe('button[type="submit"]');
        expect(mockButton.click).toHaveBeenCalled();
      });

      it('should skip invisible buttons and try next selector', async () => {
        const mockButton1 = {
          click: jest.fn(),
          isVisible: jest.fn().mockResolvedValue(false),
          isEnabled: jest.fn().mockResolvedValue(true)
        };
        const mockButton2 = {
          click: jest.fn().mockResolvedValue(undefined),
          isVisible: jest.fn().mockResolvedValue(true),
          isEnabled: jest.fn().mockResolvedValue(true)
        };

        mockPage.$
          .mockResolvedValueOnce(mockButton1)  // First selector found
          .mockResolvedValueOnce(mockButton2); // Second selector found

        const result = await findAndClickSubmitButton(mockPage);

        expect(result.success).toBe(true);
        expect(result.selector).toBe('#btnSubmit');
        expect(mockButton1.click).not.toHaveBeenCalled();
        expect(mockButton2.click).toHaveBeenCalled();
      });

      it('should skip disabled buttons', async () => {
        const mockButton1 = {
          click: jest.fn(),
          isVisible: jest.fn().mockResolvedValue(true),
          isEnabled: jest.fn().mockResolvedValue(false)
        };
        const mockButton2 = {
          click: jest.fn().mockResolvedValue(undefined),
          isVisible: jest.fn().mockResolvedValue(true),
          isEnabled: jest.fn().mockResolvedValue(true)
        };

        mockPage.$
          .mockResolvedValueOnce(mockButton1)
          .mockResolvedValueOnce(mockButton2);

        const result = await findAndClickSubmitButton(mockPage);

        expect(result.success).toBe(true);
        expect(mockButton1.click).not.toHaveBeenCalled();
        expect(mockButton2.click).toHaveBeenCalled();
      });

      it('should move to next selector if click fails', async () => {
        const mockButton1 = {
          click: jest.fn().mockRejectedValue(new Error('Click failed')),
          isVisible: jest.fn().mockResolvedValue(true),
          isEnabled: jest.fn().mockResolvedValue(true)
        };
        const mockButton2 = {
          click: jest.fn().mockResolvedValue(undefined),
          isVisible: jest.fn().mockResolvedValue(true),
          isEnabled: jest.fn().mockResolvedValue(true)
        };

        mockPage.$
          .mockResolvedValueOnce(mockButton1)
          .mockResolvedValueOnce(mockButton2);

        const result = await findAndClickSubmitButton(mockPage);

        expect(result.success).toBe(true);
        expect(result.method).toBe('css_selector');
        expect(result.selector).toBe('#btnSubmit');
        expect(mockButton1.click).toHaveBeenCalled();
        expect(mockButton2.click).toHaveBeenCalled();
      });

      it('should skip selector when element not found', async () => {
        mockPage.$
          .mockResolvedValueOnce(null)  // First selector not found
          .mockResolvedValueOnce(null)  // Second selector not found
          .mockResolvedValueOnce(null); // Third selector not found

        // Should continue to next method
        const result = await findAndClickSubmitButton(mockPage);

        expect(mockPage.$).toHaveBeenCalledTimes(3);
      });

      it('should handle isVisible errors gracefully', async () => {
        const mockButton1 = {
          click: jest.fn(),
          isVisible: jest.fn().mockRejectedValue(new Error('Visibility check failed')),
          isEnabled: jest.fn().mockResolvedValue(true)
        };
        const mockButton2 = {
          click: jest.fn().mockResolvedValue(undefined),
          isVisible: jest.fn().mockResolvedValue(true),
          isEnabled: jest.fn().mockResolvedValue(true)
        };

        mockPage.$
          .mockResolvedValueOnce(mockButton1)
          .mockResolvedValueOnce(mockButton2);

        const result = await findAndClickSubmitButton(mockPage);

        expect(result.success).toBe(true);
        expect(mockButton2.click).toHaveBeenCalled();
      });

      it('should use custom log prefix', async () => {
        // Restore console.log temporarily to capture actual calls
        console.log.mockRestore();
        const logSpy = jest.spyOn(console, 'log').mockImplementation(() => {});

        const mockButton = {
          click: jest.fn().mockResolvedValue(undefined),
          isVisible: jest.fn().mockResolvedValue(true),
          isEnabled: jest.fn().mockResolvedValue(true)
        };

        mockPage.$.mockResolvedValueOnce(mockButton);

        await findAndClickSubmitButton(mockPage, '[CustomPrefix]');

        // Since logging is set to 'error' level, we won't see the prefix
        // Just verify the function completed successfully
        expect(mockButton.click).toHaveBeenCalled();
      });
    });

    describe('XPath Strategy (Method 2)', () => {
      it('should successfully click submit button via XPath', async () => {
        // All CSS selectors fail
        mockPage.$.mockResolvedValue(null);

        const mockButton = {
          click: jest.fn().mockResolvedValue(undefined)
        };
        mockPage.$$.mockResolvedValueOnce([mockButton]);

        const result = await findAndClickSubmitButton(mockPage);

        expect(result.success).toBe(true);
        expect(result.method).toBe('xpath');
        expect(result.xpath).toBe('//button[contains(text(), "Submit")]');
        expect(mockButton.click).toHaveBeenCalled();
      });

      it('should fall through to Enter key if XPath click fails', async () => {
        mockPage.$.mockResolvedValue(null);

        const mockButton = {
          click: jest.fn().mockRejectedValue(new Error('Click failed'))
        };
        mockPage.$$.mockResolvedValueOnce([mockButton]);

        const result = await findAndClickSubmitButton(mockPage);

        // XPath click fails -> falls through to keyboard_enter
        expect(result.success).toBe(true);
        expect(result.method).toBe('keyboard_enter');
        expect(mockButton.click).toHaveBeenCalled();
      });

      it('should skip XPath if no buttons found', async () => {
        mockPage.$.mockResolvedValue(null);
        mockPage.$$.mockResolvedValueOnce([]);

        // Should continue to next method
        const result = await findAndClickSubmitButton(mockPage);

        expect(result.method).not.toBe('xpath');
      });

      it('should handle XPath query errors', async () => {
        mockPage.$.mockResolvedValue(null);
        mockPage.$$.mockRejectedValueOnce(new Error('XPath error'));

        // Should continue to next method
        const result = await findAndClickSubmitButton(mockPage);

        expect(result.method).not.toBe('xpath');
      });
    });

    describe('Keyboard Enter Strategy (Method 3)', () => {
      it('should submit form by pressing Enter on password field', async () => {
        mockPage.$.mockResolvedValue(null);
        mockPage.$$.mockResolvedValue([]);
        mockPage.press.mockResolvedValue(undefined);

        const result = await findAndClickSubmitButton(mockPage);

        expect(result.success).toBe(true);
        expect(result.method).toBe('keyboard_enter');
        expect(result.selector).toBe('#password');
        expect(mockPage.press).toHaveBeenCalledWith('#password', 'Enter');
      });

      it('should succeed even if press throws (catch handles it)', async () => {
        mockPage.$.mockResolvedValue(null);
        mockPage.$$.mockResolvedValue([]);
        mockPage.press.mockRejectedValue(new Error('Press failed'));

        // The catch(() => {}) swallows the error, so it returns success
        const result = await findAndClickSubmitButton(mockPage);

        expect(result.success).toBe(true);
        expect(result.method).toBe('keyboard_enter');
      });

      it('should always succeed with keyboard_enter method', async () => {
        mockPage.$.mockResolvedValue(null);
        mockPage.$$.mockResolvedValue([]);
        mockPage.press.mockResolvedValue(undefined);

        const result = await findAndClickSubmitButton(mockPage);

        expect(result.success).toBe(true);
        expect(result.method).toBe('keyboard_enter');
      });
    });

    describe('All Methods Failed', () => {
      it('should return failure when all methods fail', async () => {
        mockPage.$.mockResolvedValue(null);
        mockPage.$$.mockResolvedValue([]);
        mockPage.press.mockImplementation(() => {
          throw new Error('Press failed');
        });

        const result = await findAndClickSubmitButton(mockPage);

        expect(result.success).toBe(false);
        expect(result.method).toBe('none');
        expect(result.details).toContain('All submission methods failed');
      });
    });
  });

  describe('detectRecaptcha', () => {
    it('should detect reCAPTCHA v2', async () => {
      const mockElement = {};
      mockPage.$.mockResolvedValueOnce(mockElement);
      mockPage.evaluate.mockResolvedValueOnce('v2');

      const result = await detectRecaptcha(mockPage);

      expect(result.detected).toBe(true);
      expect(result.version).toBe('v2');
      expect(result.selector).toBe('.g-recaptcha');
      expect(result.callback).toBe('onRecaptchaSuccess');
    });

    it('should detect reCAPTCHA v3', async () => {
      const mockElement = {};
      mockPage.$.mockResolvedValueOnce(mockElement);
      mockPage.evaluate.mockResolvedValueOnce('v3');

      const result = await detectRecaptcha(mockPage);

      expect(result.detected).toBe(true);
      expect(result.version).toBe('v3');
    });

    it('should detect reCAPTCHA enterprise', async () => {
      const mockElement = {};
      mockPage.$.mockResolvedValueOnce(mockElement);
      mockPage.evaluate.mockResolvedValueOnce('enterprise');

      const result = await detectRecaptcha(mockPage);

      expect(result.detected).toBe(true);
      expect(result.version).toBe('enterprise');
    });

    it('should return unknown version if detection fails', async () => {
      const mockElement = {};
      mockPage.$.mockResolvedValueOnce(mockElement);
      mockPage.evaluate.mockResolvedValueOnce('unknown');

      const result = await detectRecaptcha(mockPage);

      expect(result.detected).toBe(true);
      expect(result.version).toBe('unknown');
    });

    it('should check multiple selectors', async () => {
      mockPage.$
        .mockResolvedValueOnce(null)  // First selector not found
        .mockResolvedValueOnce(null)  // Second selector not found
        .mockResolvedValueOnce({});   // Third selector found

      mockPage.evaluate.mockResolvedValueOnce('v2');

      const result = await detectRecaptcha(mockPage);

      expect(result.detected).toBe(true);
      expect(result.selector).toBe('iframe[src*="recaptcha"]');
    });

    it('should return not detected if no reCAPTCHA found', async () => {
      mockPage.$.mockResolvedValue(null);

      const result = await detectRecaptcha(mockPage);

      expect(result.detected).toBe(false);
      expect(result.version).toBeNull();
      expect(result.details).toContain('No reCAPTCHA found');
    });

    it('should handle detection errors gracefully', async () => {
      // Mock to throw after checking selectors
      let callCount = 0;
      mockPage.$.mockImplementation(() => {
        callCount++;
        if (callCount > 3) {
          throw new Error('Detection error');
        }
        return Promise.resolve(null);
      });

      const result = await detectRecaptcha(mockPage);

      // The error is caught by catch(() => null), so it returns no detection
      expect(result.detected).toBe(false);
      expect(result.details).toBe('No reCAPTCHA found');
    });

    it('should handle evaluate errors during version detection', async () => {
      const mockElement = {};
      mockPage.$.mockResolvedValueOnce(mockElement);
      mockPage.evaluate.mockRejectedValueOnce(new Error('Evaluate error'));

      const result = await detectRecaptcha(mockPage);

      expect(result.detected).toBe(true);
      expect(result.version).toBe('v2'); // Default fallback
    });
  });

  describe('waitForRecaptchaCompletion', () => {
    it('should return true if no reCAPTCHA detected', async () => {
      mockPage.$.mockResolvedValue(null);

      const result = await waitForRecaptchaCompletion(mockPage, 30000);

      expect(result).toBe(true);
    });

    it('should wait for reCAPTCHA callback', async () => {
      const mockElement = {};
      mockPage.$.mockResolvedValueOnce(mockElement);
      mockPage.evaluate
        .mockResolvedValueOnce('v2')  // Version detection
        .mockResolvedValueOnce(true); // Callback executed

      const result = await waitForRecaptchaCompletion(mockPage, 30000);

      expect(result).toBe(true);
    });

    it('should timeout if reCAPTCHA not completed', async () => {
      const mockElement = {};
      mockPage.$.mockResolvedValueOnce(mockElement);
      mockPage.evaluate
        .mockResolvedValueOnce('v2')
        .mockResolvedValueOnce(false); // Timeout

      const result = await waitForRecaptchaCompletion(mockPage, 100);

      expect(result).toBe(false);
    });

    it('should detect token in response field', async () => {
      const mockElement = {};
      mockPage.$.mockResolvedValueOnce(mockElement);
      mockPage.evaluate
        .mockResolvedValueOnce('v2')
        .mockResolvedValueOnce(true); // Token found

      const result = await waitForRecaptchaCompletion(mockPage, 30000);

      expect(result).toBe(true);
    });

    it('should handle completion check errors', async () => {
      const mockElement = {};
      mockPage.$.mockResolvedValueOnce(mockElement);
      mockPage.evaluate
        .mockResolvedValueOnce('v2')
        .mockRejectedValueOnce(new Error('Check error'));

      const result = await waitForRecaptchaCompletion(mockPage, 30000);

      expect(result).toBe(false);
    });

    it('should use custom timeout', async () => {
      const mockElement = {};
      mockPage.$.mockResolvedValueOnce(mockElement);
      mockPage.evaluate
        .mockResolvedValueOnce('v2')
        .mockResolvedValueOnce(false);

      const result = await waitForRecaptchaCompletion(mockPage, 1000);

      expect(result).toBe(false);
    });
  });

  describe('findAndClickLogoutButton', () => {
    describe('CSS Selector Strategy', () => {
      it('should successfully click logout button via CSS selector', async () => {
        const mockButton = {
          click: jest.fn().mockResolvedValue(undefined),
          isVisible: jest.fn().mockResolvedValue(true)
        };

        mockPage.$.mockResolvedValueOnce(mockButton);

        const result = await findAndClickLogoutButton(mockPage);

        expect(result.success).toBe(true);
        expect(result.method).toBe('css_selector');
        expect(result.selector).toBe('#logout');
        expect(result.attempt).toBe(1);
        expect(mockButton.click).toHaveBeenCalled();
      });

      it('should skip invisible logout buttons', async () => {
        const mockButton1 = {
          click: jest.fn(),
          isVisible: jest.fn().mockResolvedValue(false)
        };
        const mockButton2 = {
          click: jest.fn().mockResolvedValue(undefined),
          isVisible: jest.fn().mockResolvedValue(true)
        };

        mockPage.$
          .mockResolvedValueOnce(mockButton1)
          .mockResolvedValueOnce(mockButton2);

        const result = await findAndClickLogoutButton(mockPage);

        expect(result.success).toBe(true);
        expect(result.selector).toBe('.logout-button');
        expect(mockButton1.click).not.toHaveBeenCalled();
        expect(mockButton2.click).toHaveBeenCalled();
      });

      it('should try next selector if click fails', async () => {
        const mockButton1 = {
          click: jest.fn().mockRejectedValue(new Error('Click failed')),
          isVisible: jest.fn().mockResolvedValue(true)
        };
        const mockButton2 = {
          click: jest.fn().mockResolvedValue(undefined),
          isVisible: jest.fn().mockResolvedValue(true)
        };

        mockPage.$
          .mockResolvedValueOnce(mockButton1)
          .mockResolvedValueOnce(mockButton2);

        const result = await findAndClickLogoutButton(mockPage);

        expect(result.success).toBe(true);
        expect(mockButton1.click).toHaveBeenCalled();
        expect(mockButton2.click).toHaveBeenCalled();
      });

      it('should wait for logout to complete', async () => {
        const mockButton = {
          click: jest.fn().mockResolvedValue(undefined),
          isVisible: jest.fn().mockResolvedValue(true)
        };

        mockPage.$.mockResolvedValueOnce(mockButton);

        const result = await findAndClickLogoutButton(mockPage);

        expect(result.success).toBe(true);
        expect(mockButton.click).toHaveBeenCalled();
      });
    });

    describe('Text Content Strategy', () => {
      it('should find logout button via text content', async () => {
        mockPage.$.mockResolvedValue(null); // No CSS selectors match

        const mockTextLocator = {
          isVisible: jest.fn().mockResolvedValue(true),
          click: jest.fn().mockResolvedValue(undefined)
        };
        mockPage.getByRole.mockReturnValue(mockTextLocator);

        const result = await findAndClickLogoutButton(mockPage);

        expect(result.success).toBe(true);
        expect(result.method).toBe('text_search');
        expect(result.details).toContain('via text');
      }, 10000);

      it('should match "Logout" phrase via link role', async () => {
        mockPage.$.mockResolvedValue(null);

        const mockTextLocator = {
          isVisible: jest.fn().mockResolvedValue(true),
          click: jest.fn().mockResolvedValue(undefined)
        };
        mockPage.getByRole.mockReturnValue(mockTextLocator);

        const result = await findAndClickLogoutButton(mockPage);

        expect(result.success).toBe(true);
        expect(result.method).toBe('text_search');
        expect(mockPage.getByRole).toHaveBeenCalledWith('link', expect.objectContaining({ name: expect.any(String) }));
      }, 10000);

      it('should match "Sign Out" phrase', async () => {
        mockPage.$.mockResolvedValue(null);

        // For each phrase: getByRole('link',...) then getByRole('button',...)
        // First phrase (Logout): link invisible, button invisible = 2 calls
        // Second phrase (Sign Out): link visible → click = 3rd call
        let callCount = 0;
        mockPage.getByRole.mockImplementation(() => {
          callCount++;
          if (callCount <= 2) {
            return {
              isVisible: jest.fn().mockResolvedValue(false),
              click: jest.fn().mockResolvedValue(undefined)
            };
          }
          return {
            isVisible: jest.fn().mockResolvedValue(true),
            click: jest.fn().mockResolvedValue(undefined)
          };
        });

        const result = await findAndClickLogoutButton(mockPage);

        expect(result.method).toBe('text_search');
        expect(result.details).toContain('Sign Out');
      }, 10000);

      it('should match "Abmelden" phrase', async () => {
        mockPage.$.mockResolvedValue(null);

        // For each phrase: getByRole('link',...) then getByRole('button',...)
        // First 2 phrases (Logout, Sign Out) × 2 roles = 4 invisible calls
        // Third phrase (Abmelden) link = visible → click
        let callCount = 0;
        mockPage.getByRole.mockImplementation(() => {
          callCount++;
          if (callCount <= 4) {
            return {
              isVisible: jest.fn().mockResolvedValue(false),
              click: jest.fn().mockResolvedValue(undefined)
            };
          }
          return {
            isVisible: jest.fn().mockResolvedValue(true),
            click: jest.fn().mockResolvedValue(undefined)
          };
        });

        const result = await findAndClickLogoutButton(mockPage);

        expect(result.method).toBe('text_search');
        expect(result.details).toContain('Abmelden');
      }, 10000);

      it('should handle text search errors and retry', async () => {
        mockPage.$.mockResolvedValue(null);
        let callCount = 0;
        mockPage.getByRole.mockImplementation(() => {
          callCount++;
          if (callCount === 1) {
            throw new Error('Search error');
          }
          return {
            isVisible: jest.fn().mockResolvedValue(true),
            click: jest.fn().mockResolvedValue(undefined)
          };
        });

        const result = await findAndClickLogoutButton(mockPage);

        expect(result.success).toBe(true);
        expect(callCount).toBeGreaterThan(1);
      }, 10000);
    });

    describe('Retry Logic', () => {
      it('should retry up to maxAttempts times', async () => {
        mockPage.$.mockResolvedValue(null);
        let getByRoleCallCount = 0;
        mockPage.getByRole.mockImplementation(() => {
          getByRoleCallCount++;
          // 3 phrases x 2 roles x 2 failed attempts = 12 invisible calls, then succeed
          if (getByRoleCallCount <= 12) {
            return {
              isVisible: jest.fn().mockResolvedValue(false),
              click: jest.fn().mockResolvedValue(undefined)
            };
          }
          return {
            isVisible: jest.fn().mockResolvedValue(true),
            click: jest.fn().mockResolvedValue(undefined)
          };
        });

        const result = await findAndClickLogoutButton(mockPage);

        expect(result.success).toBe(true);
        expect(result.attempt).toBe(3);
        expect(getByRoleCallCount).toBeGreaterThanOrEqual(13);
      }, 10000);

      it('should return failure after all attempts exhausted', async () => {
        mockPage.$.mockResolvedValue(null);
        mockPage.getByRole.mockReturnValue({
          isVisible: jest.fn().mockResolvedValue(false),
          click: jest.fn().mockResolvedValue(undefined)
        });

        const result = await findAndClickLogoutButton(mockPage);

        expect(result.success).toBe(false);
        expect(result.method).toBe('none');
        expect(result.attempts).toBe(3);
      }, 10000);

      it('should wait retry delay between attempts', async () => {
        mockPage.$.mockResolvedValue(null);
        let getByRoleCallCount = 0;
        mockPage.getByRole.mockImplementation(() => {
          getByRoleCallCount++;
          // 3 phrases x 2 roles x 1 failed attempt = 6, then succeed on 7th
          if (getByRoleCallCount <= 6) {
            return {
              isVisible: jest.fn().mockResolvedValue(false),
              click: jest.fn().mockResolvedValue(undefined)
            };
          }
          return {
            isVisible: jest.fn().mockResolvedValue(true),
            click: jest.fn().mockResolvedValue(undefined)
          };
        });

        const result = await findAndClickLogoutButton(mockPage);

        expect(result.success).toBe(true);
        expect(result.attempt).toBe(2);
      }, 10000);

      it('should handle errors during retry', async () => {
        let dollarCallCount = 0;
        mockPage.$.mockImplementation(() => {
          dollarCallCount++;
          if (dollarCallCount === 1) {
            throw new Error('Attempt 1 error');
          }
          return Promise.resolve(null);
        });

        const mockTextLocator = {
          isVisible: jest.fn().mockResolvedValue(true),
          click: jest.fn().mockResolvedValue(undefined)
        };
        mockPage.getByRole.mockReturnValue(mockTextLocator);

        const result = await findAndClickLogoutButton(mockPage);

        expect(result.success).toBe(true);
        expect(dollarCallCount).toBeGreaterThan(1);
      }, 10000);
    });

    describe('Custom Log Prefix', () => {
      it('should use custom log prefix', async () => {
        const mockButton = {
          click: jest.fn().mockResolvedValue(undefined),
          isVisible: jest.fn().mockResolvedValue(true)
        };

        mockPage.$.mockResolvedValueOnce(mockButton);

        const result = await findAndClickLogoutButton(mockPage, '[CustomLogout]');

        // Since logging is at 'error' level, we won't see the prefix
        // Just verify the function completed successfully
        expect(result.success).toBe(true);
        expect(mockButton.click).toHaveBeenCalled();
      }, 10000);
    });
  });

  describe('integration scenarios', () => {
    it('should handle complex form submission workflow', async () => {
      // Simulate first method failing, second succeeding
      mockPage.$.mockResolvedValue(null);
      
      const mockButton = { click: jest.fn().mockResolvedValue(undefined) };
      mockPage.$$.mockResolvedValueOnce([mockButton]);

      const result = await findAndClickSubmitButton(mockPage);

      expect(result.success).toBe(true);
      expect(result.method).toBe('xpath');
    });

    it('should handle form with reCAPTCHA detection', async () => {
      const mockElement = {};
      mockPage.$.mockResolvedValueOnce(mockElement);
      mockPage.evaluate.mockResolvedValueOnce('v2');

      const captchaResult = await detectRecaptcha(mockPage);

      expect(captchaResult.detected).toBe(true);
      
      mockPage.evaluate
        .mockResolvedValueOnce('v2')
        .mockResolvedValueOnce(true);

      const waitResult = await waitForRecaptchaCompletion(mockPage);
      
      expect(waitResult).toBe(true);
    });

    it('should handle complete login-logout cycle', async () => {
      // Login
      const mockLoginButton = {
        click: jest.fn().mockResolvedValue(undefined),
        isVisible: jest.fn().mockResolvedValue(true),
        isEnabled: jest.fn().mockResolvedValue(true)
      };
      mockPage.$.mockResolvedValueOnce(mockLoginButton);

      const loginResult = await findAndClickSubmitButton(mockPage);
      expect(loginResult.success).toBe(true);

      // Logout
      const mockLogoutButton = {
        click: jest.fn().mockResolvedValue(undefined),
        isVisible: jest.fn().mockResolvedValue(true)
      };
      mockPage.$.mockResolvedValueOnce(mockLogoutButton);

      const logoutResult = await findAndClickLogoutButton(mockPage);
      expect(logoutResult.success).toBe(true);
    }, 10000);

    it('should handle page errors across multiple methods', async () => {
      mockPage.$.mockRejectedValue(new Error('Page closed'));
      mockPage.$$.mockRejectedValue(new Error('Page closed'));
      mockPage.press.mockImplementation(() => {
        throw new Error('Page closed');
      });

      const result = await findAndClickSubmitButton(mockPage);

      expect(result.success).toBe(false);
      expect(result.method).toBe('none');
    });

    it('should test all form types with different selectors', async () => {
      // Test with first selector
      const mockButton1 = {
        click: jest.fn().mockResolvedValue(undefined),
        isVisible: jest.fn().mockResolvedValue(true),
        isEnabled: jest.fn().mockResolvedValue(true)
      };
      mockPage.$.mockResolvedValueOnce(mockButton1);

      const result1 = await findAndClickSubmitButton(mockPage);
      expect(result1.success).toBe(true);

      // Test with second selector (first not found)
      const mockButton2 = {
        click: jest.fn().mockResolvedValue(undefined),
        isVisible: jest.fn().mockResolvedValue(true),
        isEnabled: jest.fn().mockResolvedValue(true)
      };
      mockPage.$.mockResolvedValueOnce(null).mockResolvedValueOnce(mockButton2);

      const result2 = await findAndClickSubmitButton(mockPage);
      expect(result2.success).toBe(true);

      // Test with third selector (first two not found)
      const mockButton3 = {
        click: jest.fn().mockResolvedValue(undefined),
        isVisible: jest.fn().mockResolvedValue(true),
        isEnabled: jest.fn().mockResolvedValue(true)
      };
      mockPage.$.mockResolvedValueOnce(null).mockResolvedValueOnce(null).mockResolvedValueOnce(mockButton3);

      const result3 = await findAndClickSubmitButton(mockPage);
      expect(result3.success).toBe(true);
    });
  });
});
