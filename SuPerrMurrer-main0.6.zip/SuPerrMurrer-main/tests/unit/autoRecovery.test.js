'use strict';

const AutoRecovery = require('../../utils/autoRecovery');

describe('AutoRecovery', () => {
  let recovery;

  beforeEach(() => {
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'warn').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
    recovery = new AutoRecovery();
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('constructor', () => {
    it('should initialize with defaults', () => {
      expect(recovery.config).toEqual({});
      expect(recovery.proxyManager).toBeNull();
      expect(recovery.history).toEqual([]);
      expect(recovery.stats.total).toBe(0);
    });

    it('should accept custom options', () => {
      const pm = { getNextProxy: jest.fn() };
      const r = new AutoRecovery({ config: { x: 1 }, proxyManager: pm });
      expect(r.config).toEqual({ x: 1 });
      expect(r.proxyManager).toBe(pm);
    });

    it('should register default strategies', () => {
      expect(recovery.strategies.has('NETWORK')).toBe(true);
      expect(recovery.strategies.has('TIMEOUT')).toBe(true);
      expect(recovery.strategies.has('BROWSER_CRASH')).toBe(true);
      expect(recovery.strategies.has('MEMORY')).toBe(true);
      expect(recovery.strategies.has('DISK')).toBe(true);
    });
  });

  describe('classifyError', () => {
    it('should return UNKNOWN for null/undefined', () => {
      expect(recovery.classifyError(null)).toBe('UNKNOWN');
      expect(recovery.classifyError(undefined)).toBe('UNKNOWN');
    });

    it('should classify ECONNREFUSED as NETWORK', () => {
      expect(recovery.classifyError(new Error('ECONNREFUSED'))).toBe('NETWORK');
    });

    it('should classify ECONNRESET as NETWORK', () => {
      expect(recovery.classifyError(new Error('ECONNRESET'))).toBe('NETWORK');
    });

    it('should classify ETIMEDOUT as NETWORK', () => {
      expect(recovery.classifyError(new Error('ETIMEDOUT'))).toBe('NETWORK');
    });

    it('should classify net:: errors as NETWORK', () => {
      expect(recovery.classifyError(new Error('net::ERR_CONNECTION_REFUSED'))).toBe('NETWORK');
    });

    it('should classify by error code', () => {
      const err = new Error('some error');
      err.code = 'ECONNREFUSED';
      expect(recovery.classifyError(err)).toBe('NETWORK');
    });

    it('should classify timeout errors', () => {
      expect(recovery.classifyError(new Error('Operation timeout'))).toBe('TIMEOUT');
      expect(recovery.classifyError(new Error('Timeout exceeded'))).toBe('TIMEOUT');
      expect(recovery.classifyError(new Error('TIMEOUT'))).toBe('TIMEOUT');
    });

    it('should classify browser crash errors', () => {
      expect(recovery.classifyError(new Error('Target closed'))).toBe('BROWSER_CRASH');
      expect(recovery.classifyError(new Error('Browser closed'))).toBe('BROWSER_CRASH');
      expect(recovery.classifyError(new Error('Connection closed'))).toBe('BROWSER_CRASH');
      expect(recovery.classifyError(new Error('browser crashed'))).toBe('BROWSER_CRASH');
    });

    it('should classify memory errors', () => {
      expect(recovery.classifyError(new Error('out of memory'))).toBe('MEMORY');
      expect(recovery.classifyError(new Error('OOM error'))).toBe('MEMORY');
      expect(recovery.classifyError(new Error('heap out of memory'))).toBe('MEMORY');
    });

    it('should classify disk errors', () => {
      expect(recovery.classifyError(new Error('ENOSPC'))).toBe('DISK');
      expect(recovery.classifyError(new Error('no space left'))).toBe('DISK');
      const err = new Error('write error');
      err.code = 'ENOSPC';
      expect(recovery.classifyError(err)).toBe('DISK');
    });

    it('should return UNKNOWN for unknown errors', () => {
      expect(recovery.classifyError(new Error('something random'))).toBe('UNKNOWN');
    });
  });

  describe('recover', () => {
    it('should return no strategy result for UNKNOWN type', async () => {
      const result = await recovery.recover(new Error('random error'));
      expect(result.recovered).toBe(false);
      expect(result.action).toBe('No strategy available');
      expect(result.errorType).toBe('UNKNOWN');
    });

    it('should increment stats on each call', async () => {
      await recovery.recover(new Error('random'));
      await recovery.recover(new Error('random'));
      expect(recovery.stats.total).toBe(2);
    });

    it('should track byType stats', async () => {
      await recovery.recover(new Error('random'));
      expect(recovery.stats.byType['UNKNOWN']).toBeDefined();
      expect(recovery.stats.byType['UNKNOWN'].total).toBe(1);
    });

    it('should count successful recoveries', async () => {
      recovery.register('NETWORK', async () => ({ recovered: true, action: 'ok' }));
      await recovery.recover(new Error('ECONNREFUSED'));
      expect(recovery.stats.successful).toBe(1);
    });

    it('should count failed recoveries', async () => {
      recovery.register('NETWORK', async () => ({ recovered: false, action: 'fail' }));
      await recovery.recover(new Error('ECONNREFUSED'));
      expect(recovery.stats.failed).toBe(1);
    });

    it('should handle strategy that throws', async () => {
      recovery.register('NETWORK', async () => { throw new Error('strategy crashed'); });
      const result = await recovery.recover(new Error('ECONNREFUSED'));
      expect(result.recovered).toBe(false);
      expect(result.action).toContain('Recovery failed');
    });
  });

  describe('default NETWORK strategy', () => {
    it('should switch proxy if proxyManager available', async () => {
      const pm = { getNextProxy: jest.fn().mockReturnValue('new-proxy') };
      const r = new AutoRecovery({ proxyManager: pm });
      const result = await r.recover(new Error('ECONNREFUSED'), { proxy: 'old-proxy' });
      expect(result.recovered).toBe(true);
      expect(result.action).toContain('Switched proxy');
    });

    it('should wait and retry if no proxy switch possible', async () => {
      jest.useFakeTimers();
      const p = recovery.recover(new Error('ECONNREFUSED'), {});
      jest.runAllTimers();
      const result = await p;
      expect(result.recovered).toBe(true);
      expect(result.action).toContain('Waited');
      jest.useRealTimers();
    });

    it('should not switch to same proxy', async () => {
      const pm = { getNextProxy: jest.fn().mockReturnValue('same-proxy') };
      const r = new AutoRecovery({ proxyManager: pm });
      jest.useFakeTimers();
      const p = r.recover(new Error('ECONNREFUSED'), { proxy: 'same-proxy' });
      jest.runAllTimers();
      const result = await p;
      expect(result.recovered).toBe(true);
      expect(result.action).toContain('Waited');
      jest.useRealTimers();
    });
  });

  describe('default TIMEOUT strategy', () => {
    it('should increase timeout', async () => {
      const context = { config: { browser: { timeout: 10000 } } };
      const result = await recovery.recover(new Error('timeout'), context);
      expect(result.recovered).toBe(true);
      expect(context.config.browser.timeout).toBe(15000);
    });

    it('should use default timeout if not in context', async () => {
      const result = await recovery.recover(new Error('timeout'), {});
      expect(result.recovered).toBe(true);
      expect(result.action).toContain('180000ms');
    });
  });

  describe('default BROWSER_CRASH strategy', () => {
    it('should close browser if provided', async () => {
      const browser = { close: jest.fn().mockResolvedValue(undefined) };
      const result = await recovery.recover(new Error('Target closed'), { browser });
      expect(result.recovered).toBe(true);
      expect(browser.close).toHaveBeenCalled();
    });

    it('should handle browser.close throwing', async () => {
      const browser = { close: jest.fn().mockRejectedValue(new Error('already closed')) };
      const result = await recovery.recover(new Error('Target closed'), { browser });
      expect(result.recovered).toBe(true);
    });

    it('should work without browser in context', async () => {
      const result = await recovery.recover(new Error('Target closed'), {});
      expect(result.recovered).toBe(true);
    });
  });

  describe('default MEMORY strategy', () => {
    it('should enable headless if not already', async () => {
      const context = { config: { browser: { headless: false } } };
      const result = await recovery.recover(new Error('out of memory'), context);
      expect(result.recovered).toBe(true);
      expect(context.config.browser.headless).toBe(true);
    });

    it('should call global.gc if available', async () => {
      global.gc = jest.fn();
      const result = await recovery.recover(new Error('out of memory'), {});
      expect(result.recovered).toBe(true);
      expect(global.gc).toHaveBeenCalled();
      delete global.gc;
    });

    it('should work when no browser config in context', async () => {
      const result = await recovery.recover(new Error('out of memory'), {});
      expect(result.recovered).toBe(true);
    });
  });

  describe('default DISK strategy', () => {
    it('should return recovered false with no cleanup available', async () => {
      const result = await recovery.recover(new Error('ENOSPC'), {});
      expect(result.recovered).toBe(false);
      expect(result.details.filesRemoved).toBe(0);
    });
  });

  describe('recordRecovery', () => {
    it('should add entry to history', () => {
      recovery.recordRecovery('NETWORK', true, 'ok');
      expect(recovery.history.length).toBe(1);
      expect(recovery.history[0].errorType).toBe('NETWORK');
    });

    it('should trim history to 100 entries', () => {
      for (let i = 0; i < 110; i++) {
        recovery.recordRecovery('NETWORK', true, 'ok');
      }
      expect(recovery.history.length).toBe(100);
    });
  });

  describe('getStats', () => {
    it('should return zero success rate when no recoveries', () => {
      const stats = recovery.getStats();
      expect(stats.total).toBe(0);
      expect(stats.successRate).toBe('0%');
    });

    it('should calculate correct success rate', async () => {
      recovery.register('NETWORK', async () => ({ recovered: true, action: 'ok' }));
      await recovery.recover(new Error('ECONNREFUSED'));
      const stats = recovery.getStats();
      expect(stats.successRate).toBe('100.0%');
    });
  });

  describe('getHistory', () => {
    it('should return empty array initially', () => {
      expect(recovery.getHistory()).toEqual([]);
    });

    it('should respect limit parameter', () => {
      for (let i = 0; i < 30; i++) recovery.recordRecovery('UNKNOWN', false, 'x');
      expect(recovery.getHistory(5).length).toBe(5);
    });
  });

  describe('exportReport', () => {
    it('should return stats and history', () => {
      const report = recovery.exportReport();
      expect(report).toHaveProperty('stats');
      expect(report).toHaveProperty('recentHistory');
      expect(report).toHaveProperty('timestamp');
    });
  });

  describe('register', () => {
    it('should register a custom strategy', async () => {
      recovery.register('CUSTOM', async () => ({ recovered: true, action: 'custom' }));
      recovery.register('TEST_TYPE', async (err, ctx) => ({ recovered: true, action: 'test', details: ctx }));
      expect(recovery.strategies.has('CUSTOM')).toBe(true);
    });
  });
});
