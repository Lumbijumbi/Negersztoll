/**
 * Unit Tests for ConfigProfiles Module
 * Tests profile system with fast/turbo/aggressive/balanced/conservative/stealth/nightowl/lowresource/debug profiles
 */

const {
  PROFILES,
  applyProfile,
  getProfileList,
  getProfile,
  getProfileDescriptions,
  getProfileDetailedDescriptions
} = require('../../utils/configProfiles');

describe('ConfigProfiles', () => {
  describe('PROFILES structure', () => {
    it('should have all nine profiles defined', () => {
      expect(PROFILES).toHaveProperty('fast');
      expect(PROFILES).toHaveProperty('turbo');
      expect(PROFILES).toHaveProperty('aggressive');
      expect(PROFILES).toHaveProperty('balanced');
      expect(PROFILES).toHaveProperty('conservative');
      expect(PROFILES).toHaveProperty('stealth');
      expect(PROFILES).toHaveProperty('nightowl');
      expect(PROFILES).toHaveProperty('lowresource');
      expect(PROFILES).toHaveProperty('debug');
    });

    it('should have valid structure for fast profile', () => {
      const { fast } = PROFILES;
      
      expect(fast.browser).toBeDefined();
      expect(fast.batch).toBeDefined();
      expect(fast.form).toBeDefined();
      expect(fast.navigation).toBeDefined();
      
      expect(fast.batch.maxParallelWorkers).toBe(8);
    });

    it('should not have headless on any profile', () => {
      Object.keys(PROFILES).forEach(profileName => {
        expect(PROFILES[profileName].browser).not.toHaveProperty('headless');
      });
    });

    it('should have valid structure for turbo profile', () => {
      const { turbo } = PROFILES;
      
      expect(turbo.browser).toBeDefined();
      expect(turbo.batch).toBeDefined();
      expect(turbo.form).toBeDefined();
      expect(turbo.navigation).toBeDefined();
      
      expect(turbo.batch.maxParallelWorkers).toBe(12);
    });

    it('should have valid structure for aggressive profile', () => {
      const { aggressive } = PROFILES;
      
      expect(aggressive.browser).toBeDefined();
      expect(aggressive.batch).toBeDefined();
      expect(aggressive.form).toBeDefined();
      expect(aggressive.navigation).toBeDefined();
      
      expect(aggressive.batch.maxParallelWorkers).toBe(10);
    });

    it('should have valid structure for balanced profile', () => {
      const { balanced } = PROFILES;
      
      expect(balanced.browser).toBeDefined();
      expect(balanced.batch).toBeDefined();
      expect(balanced.form).toBeDefined();
      expect(balanced.navigation).toBeDefined();
      
      expect(balanced.batch.maxParallelWorkers).toBe(4);
    });

    it('should have valid structure for conservative profile', () => {
      const { conservative } = PROFILES;
      
      expect(conservative.browser).toBeDefined();
      expect(conservative.batch).toBeDefined();
      expect(conservative.form).toBeDefined();
      expect(conservative.navigation).toBeDefined();
      
      expect(conservative.batch.maxParallelWorkers).toBe(3);
    });

    it('should have valid structure for stealth profile', () => {
      const { stealth } = PROFILES;
      
      expect(stealth.browser).toBeDefined();
      expect(stealth.batch).toBeDefined();
      expect(stealth.form).toBeDefined();
      expect(stealth.navigation).toBeDefined();
      
      expect(stealth.batch.maxParallelWorkers).toBe(2);
    });

    it('should have valid structure for nightowl profile', () => {
      const { nightowl } = PROFILES;
      
      expect(nightowl.browser).toBeDefined();
      expect(nightowl.batch).toBeDefined();
      expect(nightowl.form).toBeDefined();
      expect(nightowl.navigation).toBeDefined();
      
      expect(nightowl.batch.maxParallelWorkers).toBe(2);
    });

    it('should have valid structure for lowresource profile', () => {
      const { lowresource } = PROFILES;
      
      expect(lowresource.browser).toBeDefined();
      expect(lowresource.batch).toBeDefined();
      expect(lowresource.form).toBeDefined();
      expect(lowresource.navigation).toBeDefined();
      
      expect(lowresource.batch.maxParallelWorkers).toBe(1);
    });

    it('should have valid structure for debug profile', () => {
      const { debug } = PROFILES;
      
      expect(debug.browser).toBeDefined();
      expect(debug.batch).toBeDefined();
      expect(debug.form).toBeDefined();
      expect(debug.navigation).toBeDefined();
      
      expect(debug.batch.maxParallelWorkers).toBe(1);
      expect(debug.browser.dumpio).toBe(true);
    });
  });

  describe('Profile performance characteristics', () => {
    it('should have turbo profile with more workers than fast', () => {
      expect(PROFILES.turbo.batch.maxParallelWorkers).toBeGreaterThan(
        PROFILES.fast.batch.maxParallelWorkers
      );
    });

    it('should have fast profile with more workers than stealth', () => {
      expect(PROFILES.fast.batch.maxParallelWorkers).toBeGreaterThan(
        PROFILES.stealth.batch.maxParallelWorkers
      );
    });

    it('should have fast profile with shorter delays than stealth', () => {
      expect(PROFILES.fast.form.typeDelayMin).toBeLessThan(
        PROFILES.stealth.form.typeDelayMin
      );
      expect(PROFILES.fast.form.typeDelayMax).toBeLessThan(
        PROFILES.stealth.form.typeDelayMax
      );
    });

    it('should have balanced profile between fast and stealth in workers', () => {
      expect(PROFILES.balanced.batch.maxParallelWorkers).toBeGreaterThan(
        PROFILES.stealth.batch.maxParallelWorkers
      );
      expect(PROFILES.balanced.batch.maxParallelWorkers).toBeLessThan(
        PROFILES.fast.batch.maxParallelWorkers
      );
    });

    it('should have stealth profile with longer timeouts than fast', () => {
      expect(PROFILES.stealth.browser.timeout).toBeGreaterThan(
        PROFILES.fast.browser.timeout
      );
    });

    it('should have debug profile with single worker', () => {
      expect(PROFILES.debug.batch.maxParallelWorkers).toBe(1);
      expect(PROFILES.debug.batch.credentialsPerProxy).toBe(1);
    });

    it('should have debug profile with longest timeout', () => {
      expect(PROFILES.debug.browser.timeout).toBeGreaterThanOrEqual(
        PROFILES.stealth.browser.timeout
      );
      expect(PROFILES.debug.browser.timeout).toBeGreaterThanOrEqual(
        PROFILES.balanced.browser.timeout
      );
      expect(PROFILES.debug.browser.timeout).toBeGreaterThanOrEqual(
        PROFILES.fast.browser.timeout
      );
    });

    it('should have nightowl with longer typing delays than balanced', () => {
      expect(PROFILES.nightowl.form.typeDelayMin).toBeGreaterThan(
        PROFILES.balanced.form.typeDelayMin
      );
    });

    it('should have lowresource with single worker', () => {
      expect(PROFILES.lowresource.batch.maxParallelWorkers).toBe(1);
    });
  });

  describe('applyProfile()', () => {
    it('should merge profile into config correctly', () => {
      const baseConfig = {
        browser: {
          headless: false,
          timeout: 60000,
          channel: 'chrome'
        },
        batch: {
          maxParallelWorkers: 10,
          credentialsPerProxy: 15
        },
        form: {
          typeDelayMin: 100,
          typeDelayMax: 200
        },
        navigation: {
          timeout: 5000,
          domWaitUntil: 'load'
        },
        extra: {
          keepThis: true
        }
      };

      const result = applyProfile(baseConfig, 'fast');

      // Should apply fast profile values
      expect(result.browser.timeout).toBe(120000);
      expect(result.batch.maxParallelWorkers).toBe(8);
      
      // Should keep values not in profile
      expect(result.browser.channel).toBe('chrome');
      expect(result.extra.keepThis).toBe(true);
    });

    it('should throw error for unknown profile', () => {
      const config = { browser: {}, batch: {} };

      expect(() => {
        applyProfile(config, 'unknown');
      }).toThrow('Unknown profile: unknown');
    });

    it('should not mutate original config', () => {
      const originalConfig = {
        browser: { headless: false, timeout: 60000 },
        batch: { maxParallelWorkers: 10 }
      };

      const originalWorkers = originalConfig.batch.maxParallelWorkers;

      applyProfile(originalConfig, 'fast');

      // Original should be unchanged
      expect(originalConfig.batch.maxParallelWorkers).toBe(originalWorkers);
    });

    it('should apply balanced profile correctly', () => {
      const config = {
        browser: {},
        batch: {},
        form: {},
        navigation: {}
      };

      const result = applyProfile(config, 'balanced');

      expect(result.batch.maxParallelWorkers).toBe(4);
    });

    it('should apply stealth profile correctly', () => {
      const config = {
        browser: {},
        batch: {},
        form: {},
        navigation: {}
      };

      const result = applyProfile(config, 'stealth');

      expect(result.batch.maxParallelWorkers).toBe(2);
      expect(result.batch.credentialsPerProxy).toBe(2);
      expect(result.form.typeDelayMin).toBeGreaterThanOrEqual(10);
    });

    it('should apply debug profile correctly', () => {
      const config = {
        browser: {},
        batch: {},
        form: {},
        navigation: {}
      };

      const result = applyProfile(config, 'debug');

      expect(result.batch.maxParallelWorkers).toBe(1);
      expect(result.browser.dumpio).toBe(true);
    });

    it('should apply turbo profile correctly', () => {
      const config = {
        browser: {},
        batch: {},
        form: {},
        navigation: {}
      };

      const result = applyProfile(config, 'turbo');

      expect(result.batch.maxParallelWorkers).toBe(12);
      expect(result.batch.credentialsPerProxy).toBe(15);
    });

    it('should apply nightowl profile correctly', () => {
      const config = {
        browser: {},
        batch: {},
        form: {},
        navigation: {}
      };

      const result = applyProfile(config, 'nightowl');

      expect(result.batch.maxParallelWorkers).toBe(2);
      expect(result.form.typeDelayMin).toBe(15);
    });

    it('should apply lowresource profile correctly', () => {
      const config = {
        browser: {},
        batch: {},
        form: {},
        navigation: {}
      };

      const result = applyProfile(config, 'lowresource');

      expect(result.batch.maxParallelWorkers).toBe(1);
    });

    it('should handle partial config objects', () => {
      const config = {
        browser: { channel: 'chrome' },
        batch: {}
      };

      const result = applyProfile(config, 'fast');

      expect(result.browser.timeout).toBe(120000);
      expect(result.browser.channel).toBe('chrome');
    });

    it('should merge nested objects properly', () => {
      const config = {
        browser: {
          headless: false,
          channel: 'chrome',
          args: ['--no-sandbox']
        },
        batch: {
          maxParallelWorkers: 10,
          customOption: 'keep-me'
        }
      };

      const result = applyProfile(config, 'fast');

      // Profile values should override
      expect(result.batch.maxParallelWorkers).toBe(8);
      
      // Non-profile values should remain
      expect(result.browser.channel).toBe('chrome');
      expect(result.browser.args).toEqual(['--no-sandbox']);
      expect(result.batch.customOption).toBe('keep-me');
    });
  });

  describe('getProfileList()', () => {
    it('should return array of profile names', () => {
      const list = getProfileList();

      expect(Array.isArray(list)).toBe(true);
      expect(list).toContain('fast');
      expect(list).toContain('turbo');
      expect(list).toContain('aggressive');
      expect(list).toContain('balanced');
      expect(list).toContain('conservative');
      expect(list).toContain('stealth');
      expect(list).toContain('nightowl');
      expect(list).toContain('lowresource');
      expect(list).toContain('debug');
    });

    it('should return exactly 9 profiles', () => {
      const list = getProfileList();

      expect(list.length).toBe(9);
    });
  });

  describe('getProfile()', () => {
    it('should return profile object for valid name', () => {
      const fast = getProfile('fast');

      expect(fast).toBeDefined();
      expect(fast.browser).toBeDefined();
      expect(fast.batch).toBeDefined();
    });

    it('should return null for invalid profile name', () => {
      const result = getProfile('nonexistent');

      expect(result).toBeNull();
    });

    it('should return different objects for different profiles', () => {
      const fast = getProfile('fast');
      const stealth = getProfile('stealth');

      expect(fast).not.toEqual(stealth);
      expect(fast.batch.maxParallelWorkers).not.toBe(stealth.batch.maxParallelWorkers);
    });
  });

  describe('getProfileDescriptions()', () => {
    it('should return descriptions for all nine profiles', () => {
      const descriptions = getProfileDescriptions();

      expect(descriptions).toHaveProperty('fast');
      expect(descriptions).toHaveProperty('turbo');
      expect(descriptions).toHaveProperty('aggressive');
      expect(descriptions).toHaveProperty('balanced');
      expect(descriptions).toHaveProperty('conservative');
      expect(descriptions).toHaveProperty('stealth');
      expect(descriptions).toHaveProperty('nightowl');
      expect(descriptions).toHaveProperty('lowresource');
      expect(descriptions).toHaveProperty('debug');
    });

    it('should have non-empty descriptions', () => {
      const descriptions = getProfileDescriptions();

      Object.keys(descriptions).forEach(key => {
        expect(descriptions[key].length).toBeGreaterThan(0);
      });
    });

    it('should include emojis in descriptions', () => {
      const descriptions = getProfileDescriptions();

      expect(descriptions.fast).toContain('🚀');
      expect(descriptions.turbo).toContain('⚡');
      expect(descriptions.aggressive).toContain('🔥');
      expect(descriptions.balanced).toContain('⚖️');
      expect(descriptions.conservative).toContain('🐢');
      expect(descriptions.stealth).toContain('🥷');
      expect(descriptions.nightowl).toContain('🦉');
      expect(descriptions.lowresource).toContain('💻');
      expect(descriptions.debug).toContain('🐛');
    });

    it('should not mention headless in any description', () => {
      const descriptions = getProfileDescriptions();

      Object.values(descriptions).forEach(desc => {
        expect(desc.toLowerCase()).not.toContain('headless');
      });
    });
  });

  describe('getProfileDetailedDescriptions()', () => {
    it('should return detailed descriptions for all nine profiles', () => {
      const details = getProfileDetailedDescriptions();

      ['fast', 'turbo', 'aggressive', 'balanced', 'conservative', 'stealth', 'nightowl', 'lowresource', 'debug'].forEach(name => {
        expect(details).toHaveProperty(name);
        expect(details[name].tagline).toBeDefined();
        expect(details[name].whatItDoes.length).toBeGreaterThan(10);
        expect(details[name].whenToUse.length).toBeGreaterThan(10);
        expect(details[name].tradeoffs.length).toBeGreaterThan(10);
        expect(details[name].recommendedFor.length).toBeGreaterThan(10);
      });
    });
  });

  describe('Profile value ranges', () => {
    it('should have reasonable timeout values', () => {
      Object.keys(PROFILES).forEach(profileName => {
        const profile = PROFILES[profileName];
        
        expect(profile.browser.timeout).toBeGreaterThan(0);
        expect(profile.browser.timeout).toBeLessThanOrEqual(600000); // Max 10 minutes
      });
    });

    it('should have reasonable worker counts', () => {
      Object.keys(PROFILES).forEach(profileName => {
        const profile = PROFILES[profileName];
        
        expect(profile.batch.maxParallelWorkers).toBeGreaterThan(0);
        expect(profile.batch.maxParallelWorkers).toBeLessThanOrEqual(16);
      });
    });

    it('should have reasonable delay values', () => {
      Object.keys(PROFILES).forEach(profileName => {
        const profile = PROFILES[profileName];
        
        expect(profile.form.typeDelayMin).toBeGreaterThanOrEqual(0);
        expect(profile.form.typeDelayMax).toBeGreaterThan(profile.form.typeDelayMin);
      });
    });

    it('should have credentialsPerProxy within reasonable range', () => {
      Object.keys(PROFILES).forEach(profileName => {
        const profile = PROFILES[profileName];
        
        expect(profile.batch.credentialsPerProxy).toBeGreaterThan(0);
        expect(profile.batch.credentialsPerProxy).toBeLessThanOrEqual(20);
      });
    });
  });

  describe('Profile consistency', () => {
    it('should have all profiles with same top-level section keys', () => {
      const baseKeys = Object.keys(PROFILES.balanced).sort();

      Object.keys(PROFILES).forEach(profileName => {
        // debug has an extra dumpio key in browser, so only check top-level sections
        const keys = Object.keys(PROFILES[profileName]).sort();
        expect(keys).toEqual(baseKeys);
      });
    });

    it('should have browser section in all profiles', () => {
      Object.keys(PROFILES).forEach(profileName => {
        expect(PROFILES[profileName].browser).toBeDefined();
        expect(PROFILES[profileName].browser.timeout).toBeDefined();
      });
    });

    it('should have batch section in all profiles', () => {
      Object.keys(PROFILES).forEach(profileName => {
        expect(PROFILES[profileName].batch).toBeDefined();
        expect(PROFILES[profileName].batch.maxParallelWorkers).toBeDefined();
      });
    });

    it('should have form section in all profiles', () => {
      Object.keys(PROFILES).forEach(profileName => {
        expect(PROFILES[profileName].form).toBeDefined();
        expect(PROFILES[profileName].form.typeDelayMin).toBeDefined();
        expect(PROFILES[profileName].form.typeDelayMax).toBeDefined();
      });
    });

    it('should have navigation section in all profiles', () => {
      Object.keys(PROFILES).forEach(profileName => {
        expect(PROFILES[profileName].navigation).toBeDefined();
        expect(PROFILES[profileName].navigation.timeout).toBeDefined();
      });
    });
  });
});
