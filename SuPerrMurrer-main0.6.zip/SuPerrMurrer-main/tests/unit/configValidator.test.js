/**
 * Unit Tests for ConfigValidator Module
 * Tests configuration validation for all sections
 */

const ConfigValidator = require('../../utils/configValidator');

describe('ConfigValidator', () => {
  let validator;

  beforeEach(() => {
    validator = new ConfigValidator();
  });

  describe('Constructor', () => {
    it('should initialize with empty errors and warnings', () => {
      expect(validator.errors).toEqual([]);
      expect(validator.warnings).toEqual([]);
    });
  });

  describe('addError() and addWarning()', () => {
    it('should add error to errors array', () => {
      validator.addError('test', 'test error');
      
      expect(validator.errors.length).toBe(1);
      expect(validator.errors[0]).toEqual({ section: 'test', message: 'test error' });
    });

    it('should add warning to warnings array', () => {
      validator.addWarning('test', 'test warning');
      
      expect(validator.warnings.length).toBe(1);
      expect(validator.warnings[0]).toEqual({ section: 'test', message: 'test warning' });
    });
  });

  describe('validate() with complete valid config', () => {
    it('should pass validation for complete valid config', () => {
      const validConfig = {
        browser: {
          timeout: 120000,
          headless: true,
          channel: 'chrome'
        },
        proxy: {
          blacklistTTL: 300000,
          tcpTimeout: 5000
        },
        batch: {
          maxParallelWorkers: 4,
          credentialsPerProxy: 5
        },
        form: {
          typeDelayMin: 50,
          typeDelayMax: 150
        },
        navigation: {
          timeout: 10000,
          domWaitUntil: 'load'
        },
        login: {
          url: 'https://example.com/login',
          usernameSelector: '#username',
          passwordSelector: '#password',
          submitSelectors: ['button[type="submit"]']
        },
        retry: {
          enabled: true,
          maxRetries: 3
        },
        session: {
          enabled: true,
          maxAge: 3600000
        },
        notifications: {
          enabled: false
        }
      };

      const result = validator.validate(validConfig);

      expect(result).toBe(true);
      expect(validator.errors.length).toBe(0);
    });
  });

  describe('validate() with null config', () => {
    it('should add error for null config', () => {
      const result = validator.validate(null);

      expect(result).toBe(false);
      expect(validator.errors.length).toBe(1);
      expect(validator.errors[0].message).toContain('null or undefined');
    });
  });

  describe('validateBrowser()', () => {
    it('should add error when browser section is missing', () => {
      validator.validateBrowser(null);

      expect(validator.errors.length).toBe(1);
      expect(validator.errors[0].section).toBe('browser');
    });

    it('should add error when timeout is not a number', () => {
      validator.validateBrowser({ timeout: '120000' });

      expect(validator.errors.some(e => e.message.includes('must be a number'))).toBe(true);
    });

    it('should add error when timeout is too low', () => {
      validator.validateBrowser({ timeout: 5000 });

      expect(validator.errors.some(e => e.message.includes('at least 10 seconds'))).toBe(true);
    });

    it('should add warning when timeout is too high', () => {
      validator.validateBrowser({ timeout: 700000 });

      expect(validator.warnings.some(w => w.message.includes('10 minutes'))).toBe(true);
    });

    it('should add error for invalid channel', () => {
      validator.validateBrowser({ timeout: 120000, channel: 'firefox' });

      expect(validator.errors.some(e => e.message.includes('channel must be one of'))).toBe(true);
    });

    it('should accept valid channels', () => {
      ['chrome', 'msedge', 'chromium'].forEach(channel => {
        validator = new ConfigValidator();
        validator.validateBrowser({ timeout: 120000, channel });
        
        expect(validator.errors.filter(e => e.message.includes('channel')).length).toBe(0);
      });
    });

    it('should add warning when headless is false', () => {
      validator.validateBrowser({ timeout: 120000, headless: false });

      expect(validator.warnings.some(w => w.message.includes('resource usage'))).toBe(true);
    });
  });

  describe('validateProxy()', () => {
    it('should add warning when proxy section is missing', () => {
      validator.validateProxy(null);

      expect(validator.warnings.length).toBe(1);
      expect(validator.warnings[0].section).toBe('proxy');
    });

    it('should add error when blacklistTTL is negative', () => {
      validator.validateProxy({ blacklistTTL: -1000 });

      expect(validator.errors.some(e => e.message.includes('cannot be negative'))).toBe(true);
    });

    it('should add warning when tcpTimeout is too low', () => {
      validator.validateProxy({ tcpTimeout: 500 });

      expect(validator.warnings.some(w => w.message.includes('may cause false negatives'))).toBe(true);
    });
  });

  describe('validateBatch()', () => {
    it('should add error when batch section is missing', () => {
      validator.validateBatch(null);

      expect(validator.errors.length).toBe(1);
      expect(validator.errors[0].section).toBe('batch');
    });

    it('should add error when maxParallelWorkers is not a number', () => {
      validator.validateBatch({ maxParallelWorkers: '4' });

      expect(validator.errors.some(e => e.message.includes('must be a number'))).toBe(true);
    });

    it('should add error when maxParallelWorkers is less than 1', () => {
      validator.validateBatch({ maxParallelWorkers: 0 });

      expect(validator.errors.some(e => e.message.includes('at least 1'))).toBe(true);
    });

    it('should add warning when maxParallelWorkers is too high', () => {
      validator.validateBatch({ maxParallelWorkers: 20 });

      expect(validator.warnings.some(w => w.message.includes('overload system'))).toBe(true);
    });

    it('should add error when credentialsPerProxy is less than 1', () => {
      validator.validateBatch({ maxParallelWorkers: 4, credentialsPerProxy: 0 });

      expect(validator.errors.some(e => e.message.includes('at least 1'))).toBe(true);
    });

    it('should add warning when credentialsPerProxy is too high', () => {
      validator.validateBatch({ maxParallelWorkers: 4, credentialsPerProxy: 25 });

      expect(validator.warnings.some(w => w.message.includes('detection risk'))).toBe(true);
    });
  });

  describe('validateForm()', () => {
    it('should add warning when form section is missing', () => {
      validator.validateForm(null);

      expect(validator.warnings.length).toBe(1);
      expect(validator.warnings[0].section).toBe('form');
    });

    it('should add error when typeDelayMin > typeDelayMax', () => {
      validator.validateForm({ typeDelayMin: 200, typeDelayMax: 100 });

      expect(validator.errors.some(e => e.message.includes('cannot be greater than'))).toBe(true);
    });

    it('should add error when typeDelayMin is negative', () => {
      validator.validateForm({ typeDelayMin: -10, typeDelayMax: 100 });

      expect(validator.errors.some(e => e.message.includes('cannot be negative'))).toBe(true);
    });
  });

  describe('validateNavigation()', () => {
    it('should add warning when navigation section is missing', () => {
      validator.validateNavigation(null);

      expect(validator.warnings.length).toBe(1);
      expect(validator.warnings[0].section).toBe('navigation');
    });

    it('should add warning when timeout is too low', () => {
      validator.validateNavigation({ timeout: 3000 });

      expect(validator.warnings.some(w => w.message.includes('may cause failures'))).toBe(true);
    });

    it('should add warning for invalid domWaitUntil', () => {
      validator.validateNavigation({ timeout: 10000, domWaitUntil: 'invalid' });

      expect(validator.warnings.some(w => w.message.includes('should be one of'))).toBe(true);
    });

    it('should accept valid domWaitUntil values', () => {
      ['load', 'domcontentloaded', 'networkidle'].forEach(waitUntil => {
        validator = new ConfigValidator();
        validator.validateNavigation({ timeout: 10000, domWaitUntil: waitUntil });
        
        expect(validator.warnings.filter(w => w.message.includes('should be one of')).length).toBe(0);
      });
    });
  });

  describe('validateLogin()', () => {
    it('should add error when login section is missing', () => {
      validator.validateLogin(null);

      expect(validator.errors.length).toBe(1);
      expect(validator.errors[0].section).toBe('login');
    });

    it('should add error when url is missing', () => {
      validator.validateLogin({ usernameSelector: '#user', passwordSelector: '#pass' });

      expect(validator.errors.some(e => e.message.includes('url is required'))).toBe(true);
    });

    it('should add warning when url does not start with https', () => {
      validator.validateLogin({ 
        url: 'http://example.com',
        usernameSelector: '#user',
        passwordSelector: '#pass',
        submitSelectors: ['button']
      });

      expect(validator.warnings.some(w => w.message.includes('should start with https'))).toBe(true);
    });

    it('should add error when usernameSelector is missing', () => {
      validator.validateLogin({ url: 'https://example.com', passwordSelector: '#pass' });

      expect(validator.errors.some(e => e.message.includes('usernameSelector is required'))).toBe(true);
    });

    it('should add error when passwordSelector is missing', () => {
      validator.validateLogin({ url: 'https://example.com', usernameSelector: '#user' });

      expect(validator.errors.some(e => e.message.includes('passwordSelector is required'))).toBe(true);
    });

    it('should add warning when submitSelectors is empty', () => {
      validator.validateLogin({ 
        url: 'https://example.com',
        usernameSelector: '#user',
        passwordSelector: '#pass',
        submitSelectors: []
      });

      expect(validator.warnings.some(w => w.message.includes('at least one entry'))).toBe(true);
    });
  });

  describe('validateRetry()', () => {
    it('should not add errors when retry is missing', () => {
      validator.validateRetry(null);

      expect(validator.errors.length).toBe(0);
    });

    it('should add error when retry is enabled and maxRetries < 1', () => {
      validator.validateRetry({ enabled: true, maxRetries: 0 });

      expect(validator.errors.some(e => e.message.includes('at least 1'))).toBe(true);
    });

    it('should add warning when maxRetries is too high', () => {
      validator.validateRetry({ enabled: true, maxRetries: 15 });

      expect(validator.warnings.some(w => w.message.includes('long delays'))).toBe(true);
    });
  });

  describe('validateSession()', () => {
    it('should not add errors when session is missing', () => {
      validator.validateSession(null);

      expect(validator.errors.length).toBe(0);
    });

    it('should add warning when maxAge is too low', () => {
      validator.validateSession({ enabled: true, maxAge: 30000 });

      expect(validator.warnings.some(w => w.message.includes('may not be useful'))).toBe(true);
    });
  });

  describe('validateNotifications()', () => {
    it('should not add errors when notifications is missing', () => {
      validator.validateNotifications(null);

      expect(validator.errors.length).toBe(0);
    });

    it('should add warning when enabled but webhook URL is missing', () => {
      validator.validateNotifications({ enabled: true, webhook: {} });

      expect(validator.warnings.some(w => w.message.includes('URL is missing'))).toBe(true);
    });

    it('should add warning for invalid webhook type', () => {
      validator.validateNotifications({ 
        enabled: true, 
        webhook: { url: 'https://example.com', type: 'invalid' }
      });

      expect(validator.warnings.some(w => w.message.includes('should be one of'))).toBe(true);
    });

    it('should accept valid webhook types', () => {
      ['discord', 'slack', 'generic'].forEach(type => {
        validator = new ConfigValidator();
        validator.validateNotifications({ 
          enabled: true, 
          webhook: { url: 'https://example.com', type }
        });
        
        expect(validator.warnings.filter(w => w.message.includes('should be one of')).length).toBe(0);
      });
    });
  });

  describe('getSummary()', () => {
    it('should return correct summary', () => {
      validator.addError('test', 'error1');
      validator.addError('test', 'error2');
      validator.addWarning('test', 'warning1');

      const summary = validator.getSummary();

      expect(summary.valid).toBe(false);
      expect(summary.errorCount).toBe(2);
      expect(summary.warningCount).toBe(1);
      expect(summary.errors.length).toBe(2);
      expect(summary.warnings.length).toBe(1);
    });

    it('should return valid=true when no errors', () => {
      validator.addWarning('test', 'warning1');

      const summary = validator.getSummary();

      expect(summary.valid).toBe(true);
      expect(summary.errorCount).toBe(0);
      expect(summary.warningCount).toBe(1);
    });
  });

  describe('printReport()', () => {
    let consoleLogSpy;

    beforeEach(() => {
      consoleLogSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
    });

    afterEach(() => {
      consoleLogSpy.mockRestore();
    });

    it('should print success message when no errors or warnings', () => {
      validator.printReport();

      expect(consoleLogSpy).toHaveBeenCalledWith(expect.stringContaining('✅'));
    });

    it('should print errors when present', () => {
      validator.addError('test', 'test error');
      validator.printReport();

      const calls = consoleLogSpy.mock.calls.map(call => call[0]).join(' ');
      expect(calls).toContain('❌ ERRORS');
      expect(calls).toContain('test error');
    });

    it('should print warnings when present', () => {
      validator.addWarning('test', 'test warning');
      validator.printReport();

      const calls = consoleLogSpy.mock.calls.map(call => call[0]).join(' ');
      expect(calls).toContain('⚠️');
      expect(calls).toContain('test warning');
    });

    it('should return false when errors exist', () => {
      validator.addError('test', 'error');
      const result = validator.printReport();

      expect(result).toBe(false);
    });

    it('should return true when only warnings exist', () => {
      validator.addWarning('test', 'warning');
      const result = validator.printReport();

      expect(result).toBe(true);
    });

    it('should emit plain-text [CONFIG] lines for errors', () => {
      validator.addError('browser', 'timeout must be at least 10 seconds');
      validator.printReport();

      const calls = consoleLogSpy.mock.calls.map(call => call[0]).join('\n');
      expect(calls).toContain('[CONFIG] VALIDATION ERROR [browser]: timeout must be at least 10 seconds');
      expect(calls).toContain('[CONFIG] Validation failed with 1 error(s) and 0 warning(s)');
    });

    it('should emit plain-text [CONFIG] lines for warnings', () => {
      validator.addWarning('proxy', 'tcpTimeout < 1s may cause false negatives');
      validator.printReport();

      const calls = consoleLogSpy.mock.calls.map(call => call[0]).join('\n');
      expect(calls).toContain('[CONFIG] VALIDATION WARNING [proxy]: tcpTimeout < 1s may cause false negatives');
      expect(calls).toContain('[CONFIG] Validation passed with 1 warning(s)');
    });
  });

  describe('getReport()', () => {
    it('should return valid:true and empty arrays when no errors or warnings', () => {
      const report = validator.getReport();

      expect(report.valid).toBe(true);
      expect(report.errors).toEqual([]);
      expect(report.warnings).toEqual([]);
      expect(typeof report.summary).toBe('string');
    });

    it('should return valid:false with errors array when validation fails', () => {
      validator.addError('browser', 'timeout must be at least 10 seconds');
      validator.addWarning('proxy', 'tcpTimeout may cause issues');

      const report = validator.getReport();

      expect(report.valid).toBe(false);
      expect(report.errors).toHaveLength(1);
      expect(report.errors[0]).toEqual({ section: 'browser', message: 'timeout must be at least 10 seconds' });
      expect(report.warnings).toHaveLength(1);
      expect(report.summary).toContain('1 error(s)');
      expect(report.summary).toContain('1 warning(s)');
    });

    it('should return valid:true with warnings when only warnings present', () => {
      validator.addWarning('proxy', 'some warning');

      const report = validator.getReport();

      expect(report.valid).toBe(true);
      expect(report.errors).toHaveLength(0);
      expect(report.warnings).toHaveLength(1);
      expect(report.summary).toContain('1 warning(s)');
    });
  });
});
