/**
 * Unit Tests for Retry Queue Module
 * Tests credential retry management, persistence, and statistics
 */

const fs = require('fs');
const path = require('path');
const RetryQueue = require('../../utils/retryQueue');

describe('RetryQueue', () => {
  let queue;
  let testQueueFile;

  beforeEach(() => {
    testQueueFile = `test_retry_queue_${Date.now()}.json`;
    queue = new RetryQueue({
      maxRetries: 3,
      queueFile: testQueueFile
    });
  });

  afterEach(() => {
    // Cleanup test files
    const queuePath = path.join(process.cwd(), testQueueFile);
    if (fs.existsSync(queuePath)) {
      fs.unlinkSync(queuePath);
    }
    // Clean up temp files
    const tempPath = `${queuePath}.tmp`;
    if (fs.existsSync(tempPath)) {
      fs.unlinkSync(tempPath);
    }
    // Clean up corrupted backups
    const files = fs.readdirSync(process.cwd());
    files.forEach(file => {
      if (file.startsWith(testQueueFile) && file.includes('corrupted')) {
        fs.unlinkSync(path.join(process.cwd(), file));
      }
    });
  });

  describe('constructor', () => {
    it('should initialize with default options', () => {
      const defaultQueue = new RetryQueue();
      expect(defaultQueue.maxRetries).toBe(3);
      expect(defaultQueue.queueFile).toBe('retry_queue.json');
    });

    it('should initialize with custom options', () => {
      const customQueue = new RetryQueue({
        maxRetries: 5,
        queueFile: 'custom_queue.json'
      });
      expect(customQueue.maxRetries).toBe(5);
      expect(customQueue.queueFile).toBe('custom_queue.json');
    });

    it('should initialize empty queue and stats', () => {
      expect(queue.size()).toBe(0);
      expect(queue.stats.totalAdded).toBe(0);
      expect(queue.stats.totalRetried).toBe(0);
      expect(queue.stats.totalExhausted).toBe(0);
      expect(queue.stats.totalSucceeded).toBe(0);
    });
  });

  describe('add', () => {
    it('should add new credential to queue', () => {
      const credential = {
        username: 'test@example.com',
        password: 'password123'
      };
      
      queue.add(credential, 'timeout');
      
      expect(queue.size()).toBe(1);
      expect(queue.stats.totalAdded).toBe(1);
    });

    it('should increment retry count for existing credential', () => {
      const credential = {
        username: 'test@example.com',
        password: 'password123'
      };
      
      queue.add(credential, 'timeout');
      queue.add(credential, 'network error');
      
      expect(queue.size()).toBe(1);
      expect(queue.stats.totalAdded).toBe(1);
      
      const entry = Array.from(queue.queue.values())[0];
      expect(entry.retryCount).toBe(1);
      expect(entry.attempts).toHaveLength(2);
    });

    it('should record failure reasons', () => {
      const credential = {
        username: 'test@example.com',
        password: 'password123'
      };
      
      queue.add(credential, 'timeout');
      queue.add(credential, 'network error');
      
      const entry = Array.from(queue.queue.values())[0];
      expect(entry.attempts[0].reason).toBe('timeout');
      expect(entry.attempts[1].reason).toBe('network error');
    });

    it('should throw error for invalid credential', () => {
      expect(() => queue.add(null, 'reason')).toThrow('Invalid credential');
      expect(() => queue.add({}, 'reason')).toThrow('Invalid credential');
      expect(() => queue.add({ username: 'test' }, 'reason')).toThrow('Invalid credential');
      expect(() => queue.add({ password: 'pass' }, 'reason')).toThrow('Invalid credential');
    });

    it('should use "unknown" as default reason', () => {
      const credential = {
        username: 'test@example.com',
        password: 'password123'
      };
      
      queue.add(credential);
      
      const entry = Array.from(queue.queue.values())[0];
      expect(entry.attempts[0].reason).toBe('unknown');
    });

    it('should record timestamps for each attempt', () => {
      const credential = {
        username: 'test@example.com',
        password: 'password123'
      };
      
      const beforeAdd = Date.now();
      queue.add(credential, 'reason1');
      const afterAdd = Date.now();
      
      const entry = Array.from(queue.queue.values())[0];
      expect(entry.addedAt).toBeDefined();
      const addedTimestamp = new Date(entry.addedAt).getTime();
      expect(addedTimestamp).toBeGreaterThanOrEqual(beforeAdd);
      expect(addedTimestamp).toBeLessThanOrEqual(afterAdd);
      expect(entry.attempts[0].timestamp).toBeDefined();
    });

    it('should store maxRetries in entry', () => {
      const credential = {
        username: 'test@example.com',
        password: 'password123'
      };
      
      queue.add(credential, 'reason');
      
      const entry = Array.from(queue.queue.values())[0];
      expect(entry.maxRetries).toBe(3);
    });
  });

  describe('getRetryable', () => {
    it('should return empty array for empty queue', () => {
      const retryable = queue.getRetryable();
      expect(retryable).toEqual([]);
    });

    it('should return credentials that haven\'t exceeded max retries', () => {
      queue.add({ username: 'user1@test.com', password: 'pass1' }, 'reason1');
      queue.add({ username: 'user2@test.com', password: 'pass2' }, 'reason2');
      
      const retryable = queue.getRetryable();
      
      expect(retryable).toHaveLength(2);
      expect(retryable[0].username).toBe('user1@test.com');
      expect(retryable[1].username).toBe('user2@test.com');
    });

    it('should exclude credentials that exceeded max retries', () => {
      const credential = { username: 'test@example.com', password: 'password123' };
      
      // Add 4 times (initial + 3 retries = maxRetries)
      for (let i = 0; i < 4; i++) {
        queue.add(credential, `reason${i}`);
      }
      
      const retryable = queue.getRetryable();
      expect(retryable).toHaveLength(0);
    });

    it('should include retryCount in returned credentials', () => {
      const credential = { username: 'test@example.com', password: 'password123' };
      queue.add(credential, 'reason1');
      queue.add(credential, 'reason2');
      
      const retryable = queue.getRetryable();
      expect(retryable[0].retryCount).toBe(1);
    });

    it('should include lastReason in returned credentials', () => {
      const credential = { username: 'test@example.com', password: 'password123' };
      queue.add(credential, 'reason1');
      queue.add(credential, 'reason2');
      
      const retryable = queue.getRetryable();
      expect(retryable[0].lastReason).toBe('reason2');
    });

    it('should not mutate totalRetried stat', () => {
      queue.add({ username: 'user1@test.com', password: 'pass1' }, 'reason1');
      queue.getRetryable();
      queue.getRetryable();
      expect(queue.stats.totalRetried).toBe(0);
    });
  });

  describe('markRetried', () => {
    it('should increment totalRetried by the given count', () => {
      queue.markRetried(5);
      expect(queue.stats.totalRetried).toBe(5);
      queue.markRetried(3);
      expect(queue.stats.totalRetried).toBe(8);
    });

    it('should handle zero and undefined gracefully', () => {
      queue.markRetried(0);
      expect(queue.stats.totalRetried).toBe(0);
      queue.markRetried(undefined);
      expect(queue.stats.totalRetried).toBe(0);
    });
  });

  describe('getRetryablePrioritized', () => {
    it('should return empty array for empty queue', () => {
      expect(queue.getRetryablePrioritized()).toEqual([]);
    });

    it('should order high-priority reasons before low-priority', () => {
      queue.add({ username: 'a@test.com', password: 'pass' }, 'submit_failed');       // priority 4
      queue.add({ username: 'b@test.com', password: 'pass' }, 'proxy_blocked');       // priority 1
      queue.add({ username: 'c@test.com', password: 'pass' }, 'timeout_retry');       // priority 2

      const result = queue.getRetryablePrioritized();
      expect(result[0].username).toBe('b@test.com'); // priority 1
      expect(result[1].username).toBe('c@test.com'); // priority 2
      expect(result[2].username).toBe('a@test.com'); // priority 4
    });

    it('should use retryCount as tie-breaker within same priority', () => {
      queue.add({ username: 'a@test.com', password: 'pass' }, 'timeout_retry'); // retryCount 0
      const credB = { username: 'b@test.com', password: 'pass' };
      queue.add(credB, 'timeout_retry');
      queue.add(credB, 'timeout_retry'); // retryCount 1

      const result = queue.getRetryablePrioritized();
      // Both are 'timeout_retry' (priority 2); lower retryCount first
      expect(result[0].username).toBe('a@test.com'); // retryCount 0
      expect(result[1].username).toBe('b@test.com'); // retryCount 1
    });

    it('should assign default priority 5 to unknown reasons', () => {
      queue.add({ username: 'a@test.com', password: 'pass' }, 'some_unknown_reason');
      queue.add({ username: 'b@test.com', password: 'pass' }, 'tunnel_failed'); // priority 3

      const result = queue.getRetryablePrioritized();
      expect(result[0].username).toBe('b@test.com'); // priority 3 < default 5
      expect(result[1].username).toBe('a@test.com'); // default priority 5
    });

    it('should exclude exhausted credentials', () => {
      const cred = { username: 'test@test.com', password: 'pass' };
      for (let i = 0; i <= queue.maxRetries; i++) {
        queue.add(cred, 'proxy_blocked');
      }
      expect(queue.getRetryablePrioritized()).toHaveLength(0);
    });
  });

  describe('isMaxRetriesReached', () => {
    it('should return false for credential not in queue', () => {
      const result = queue.isMaxRetriesReached({ username: 'unknown@test.com' });
      expect(result).toBe(false);
    });

    it('should return false for credential below max retries', () => {
      const credential = { username: 'test@example.com', password: 'password123' };
      queue.add(credential, 'reason');
      
      const result = queue.isMaxRetriesReached(credential);
      expect(result).toBe(false);
    });

    it('should return true for credential at max retries', () => {
      const credential = { username: 'test@example.com', password: 'password123' };
      
      for (let i = 0; i <= queue.maxRetries; i++) {
        queue.add(credential, `reason${i}`);
      }
      
      const result = queue.isMaxRetriesReached(credential);
      expect(result).toBe(true);
    });

    it('should handle invalid input', () => {
      expect(queue.isMaxRetriesReached(null)).toBe(false);
      expect(queue.isMaxRetriesReached({})).toBe(false);
      expect(queue.isMaxRetriesReached({ password: 'pass' })).toBe(false);
    });
  });

  describe('markSuccess', () => {
    it('should remove credential from queue on success', () => {
      const credential = { username: 'test@example.com', password: 'password123' };
      queue.add(credential, 'reason');
      
      expect(queue.size()).toBe(1);
      
      queue.markSuccess(credential);
      
      expect(queue.size()).toBe(0);
      expect(queue.stats.totalSucceeded).toBe(1);
    });

    it('should handle marking non-existent credential as success', () => {
      const credential = { username: 'unknown@test.com' };
      queue.markSuccess(credential);
      
      expect(queue.stats.totalSucceeded).toBe(0);
    });

    it('should handle invalid input', () => {
      expect(() => queue.markSuccess(null)).not.toThrow();
      expect(() => queue.markSuccess({})).not.toThrow();
    });
  });

  describe('cleanExhausted', () => {
    it('should remove credentials that exceeded max retries', () => {
      const credential1 = { username: 'user1@test.com', password: 'pass1' };
      const credential2 = { username: 'user2@test.com', password: 'pass2' };
      
      // Add credential1 beyond max retries
      for (let i = 0; i <= queue.maxRetries; i++) {
        queue.add(credential1, 'reason');
      }
      
      // Add credential2 below max retries
      queue.add(credential2, 'reason');
      
      expect(queue.size()).toBe(2);
      
      const removed = queue.cleanExhausted();
      
      expect(removed).toBe(1);
      expect(queue.size()).toBe(1);
      expect(queue.stats.totalExhausted).toBe(1);
    });

    it('should return 0 when no credentials are exhausted', () => {
      queue.add({ username: 'user1@test.com', password: 'pass1' }, 'reason');
      queue.add({ username: 'user2@test.com', password: 'pass2' }, 'reason');
      
      const removed = queue.cleanExhausted();
      
      expect(removed).toBe(0);
      expect(queue.size()).toBe(2);
    });
  });

  describe('size', () => {
    it('should return 0 for empty queue', () => {
      expect(queue.size()).toBe(0);
    });

    it('should return correct size after additions', () => {
      queue.add({ username: 'user1@test.com', password: 'pass1' }, 'reason');
      expect(queue.size()).toBe(1);
      
      queue.add({ username: 'user2@test.com', password: 'pass2' }, 'reason');
      expect(queue.size()).toBe(2);
    });

    it('should return correct size after removals', () => {
      const credential = { username: 'user1@test.com', password: 'pass1' };
      queue.add(credential, 'reason');
      queue.add({ username: 'user2@test.com', password: 'pass2' }, 'reason');
      
      queue.markSuccess(credential);
      
      expect(queue.size()).toBe(1);
    });
  });

  describe('getStats', () => {
    it('should return correct statistics', () => {
      const credential1 = { username: 'user1@test.com', password: 'pass1' };
      const credential2 = { username: 'user2@test.com', password: 'pass2' };
      
      queue.add(credential1, 'reason');
      queue.add(credential2, 'reason');
      
      const stats = queue.getStats();
      
      expect(stats.totalAdded).toBe(2);
      expect(stats.currentQueueSize).toBe(2);
      expect(stats.retryableCredentials).toBe(2);
      expect(stats.exhaustedCredentials).toBe(0);
    });

    it('should count exhausted credentials correctly', () => {
      const credential = { username: 'test@example.com', password: 'password123' };
      
      for (let i = 0; i <= queue.maxRetries; i++) {
        queue.add(credential, 'reason');
      }
      
      const stats = queue.getStats();
      
      expect(stats.retryableCredentials).toBe(0);
      expect(stats.exhaustedCredentials).toBe(1);
    });
  });

  describe('save and load', () => {
    it('should save queue to disk', () => {
      queue.add({ username: 'user1@test.com', password: 'pass1' }, 'reason1');
      queue.add({ username: 'user2@test.com', password: 'pass2' }, 'reason2');
      
      const result = queue.save();
      
      expect(result).toBe(true);
      expect(fs.existsSync(path.join(process.cwd(), testQueueFile))).toBe(true);
    });

    it('should load queue from disk', () => {
      queue.add({ username: 'user1@test.com', password: 'pass1' }, 'reason1');
      queue.add({ username: 'user2@test.com', password: 'pass2' }, 'reason2');
      queue.save();
      
      // Create new queue instance and load
      const newQueue = new RetryQueue({
        maxRetries: 3,
        queueFile: testQueueFile
      });
      
      const result = newQueue.load();
      
      expect(result).toBe(true);
      expect(newQueue.size()).toBe(2);
    });

    it('should preserve retry counts when loading', () => {
      const credential = { username: 'test@example.com', password: 'password123' };
      queue.add(credential, 'reason1');
      queue.add(credential, 'reason2');
      queue.save();
      
      const newQueue = new RetryQueue({
        maxRetries: 3,
        queueFile: testQueueFile
      });
      newQueue.load();
      
      const entries = newQueue.toArray();
      expect(entries[0].retryCount).toBe(1);
      expect(entries[0].attempts).toHaveLength(2);
    });

    it('should handle loading non-existent file', () => {
      const newQueue = new RetryQueue({
        queueFile: 'non_existent_queue.json'
      });
      
      const result = newQueue.load();
      
      expect(result).toBe(false);
      expect(newQueue.size()).toBe(0);
    });

    it('should handle corrupted queue file', () => {
      const queuePath = path.join(process.cwd(), testQueueFile);
      fs.writeFileSync(queuePath, 'invalid json{]', 'utf8');
      
      const result = queue.load();
      
      expect(result).toBe(false);
      expect(queue.size()).toBe(0);
      
      // Check that corrupted file was backed up
      const files = fs.readdirSync(process.cwd());
      const backupFile = files.find(f => f.startsWith(testQueueFile) && f.includes('corrupted'));
      expect(backupFile).toBeDefined();
    });

    it('should save and load stats correctly', () => {
      queue.add({ username: 'user1@test.com', password: 'pass1' }, 'reason');
      queue.markSuccess({ username: 'user1@test.com' });
      queue.save();
      
      const newQueue = new RetryQueue({
        maxRetries: 3,
        queueFile: testQueueFile
      });
      newQueue.load();
      
      expect(newQueue.stats.totalAdded).toBe(1);
      expect(newQueue.stats.totalSucceeded).toBe(1);
    });
  });

  describe('clear', () => {
    it('should clear all entries and reset stats', () => {
      queue.add({ username: 'user1@test.com', password: 'pass1' }, 'reason');
      queue.add({ username: 'user2@test.com', password: 'pass2' }, 'reason');
      
      queue.clear();
      
      expect(queue.size()).toBe(0);
      expect(queue.stats.totalAdded).toBe(0);
      expect(queue.stats.totalRetried).toBe(0);
      expect(queue.stats.totalExhausted).toBe(0);
      expect(queue.stats.totalSucceeded).toBe(0);
    });
  });

  describe('toArray', () => {
    it('should return empty array for empty queue', () => {
      const arr = queue.toArray();
      expect(arr).toEqual([]);
    });

    it('should return all entries as array', () => {
      queue.add({ username: 'user1@test.com', password: 'pass1' }, 'reason1');
      queue.add({ username: 'user2@test.com', password: 'pass2' }, 'reason2');
      
      const arr = queue.toArray();
      
      expect(arr).toHaveLength(2);
      expect(arr[0].username).toBe('user1@test.com');
      expect(arr[1].username).toBe('user2@test.com');
    });

    it('should return array with all entry details', () => {
      queue.add({ username: 'test@example.com', password: 'password123' }, 'reason');
      
      const arr = queue.toArray();
      
      expect(arr[0]).toHaveProperty('username');
      expect(arr[0]).toHaveProperty('password');
      expect(arr[0]).toHaveProperty('retryCount');
      expect(arr[0]).toHaveProperty('maxRetries');
      expect(arr[0]).toHaveProperty('attempts');
      expect(arr[0]).toHaveProperty('addedAt');
      expect(arr[0]).toHaveProperty('lastAttempt');
    });
  });

  describe('edge cases', () => {
    it('should handle rapid additions of same credential', () => {
      const credential = { username: 'test@example.com', password: 'password123' };
      
      for (let i = 0; i < 10; i++) {
        queue.add(credential, `reason${i}`);
      }
      
      expect(queue.size()).toBe(1);
      const entry = queue.toArray()[0];
      expect(entry.attempts).toHaveLength(10);
      expect(entry.retryCount).toBe(9);
    });

    it('should handle many different credentials', () => {
      for (let i = 0; i < 100; i++) {
        queue.add({ 
          username: `user${i}@test.com`, 
          password: `pass${i}` 
        }, 'reason');
      }
      
      expect(queue.size()).toBe(100);
      expect(queue.stats.totalAdded).toBe(100);
    });

    it('should maintain queue integrity after multiple operations', () => {
      const cred1 = { username: 'user1@test.com', password: 'pass1' };
      const cred2 = { username: 'user2@test.com', password: 'pass2' };
      
      queue.add(cred1, 'reason');
      queue.add(cred2, 'reason');
      queue.markSuccess(cred1);
      queue.add(cred2, 'reason');
      queue.save();
      queue.clear();
      queue.load();
      
      expect(queue.size()).toBe(1);
      expect(queue.toArray()[0].username).toBe('user2@test.com');
    });
  });
});
