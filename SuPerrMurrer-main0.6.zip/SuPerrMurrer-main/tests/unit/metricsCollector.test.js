/**
 * Unit Tests for MetricsCollector Module
 * Tests metric recording, statistics calculation, and reporting functionality
 */

const MetricsCollector = require('../../metricsCollector');

describe('MetricsCollector', () => {
  let collector;

  beforeEach(() => {
    jest.clearAllMocks();
    jest.clearAllTimers();
    jest.useFakeTimers();
  });

  afterEach(() => {
    if (collector) {
      collector.destroy();
    }
    jest.useRealTimers();
  });

  describe('Constructor', () => {
    it('should initialize with default options', () => {
      collector = new MetricsCollector();

      expect(collector.metricsInterval).toBe(30000);
      expect(collector.enableConsoleOutput).toBe(true);
      expect(collector.metrics.totalAttempts).toBe(0);
      expect(collector.metrics.successfulLogins).toBe(0);
      expect(collector.metrics.failedLogins).toBe(0);
    });

    it('should initialize with custom metricsInterval', () => {
      collector = new MetricsCollector({ metricsInterval: 60000 });

      expect(collector.metricsInterval).toBe(60000);
    });

    it('should initialize with console output disabled', () => {
      collector = new MetricsCollector({ enableConsoleOutput: false });

      expect(collector.enableConsoleOutput).toBe(false);
    });

    it('should initialize all metric counters to zero', () => {
      collector = new MetricsCollector();

      expect(collector.metrics.totalAttempts).toBe(0);
      expect(collector.metrics.successfulLogins).toBe(0);
      expect(collector.metrics.failedLogins).toBe(0);
      expect(collector.metrics.captchasDetected).toBe(0);
      expect(collector.metrics.blocksDetected).toBe(0);
      expect(collector.metrics.proxyFailures).toBe(0);
      expect(collector.metrics.navigationErrors).toBe(0);
      expect(collector.metrics.screenshotFailures).toBe(0);
      expect(collector.metrics.tunnelErrors).toBe(0);
      expect(collector.metrics.totalResponseTime).toBe(0);
      expect(collector.metrics.avgResponseTime).toBe(0);
    });

    it('should initialize detailed metrics structures', () => {
      collector = new MetricsCollector();

      expect(collector.detailedMetrics.byReason).toEqual({});
      expect(collector.detailedMetrics.byProxy).toEqual({});
      expect(collector.detailedMetrics.byBatch).toEqual({});
      expect(collector.detailedMetrics.timeline).toEqual([]);
    });

    it('should set timeStarted timestamp', () => {
      const before = Date.now();
      collector = new MetricsCollector();
      const after = Date.now();

      expect(collector.metrics.timeStarted).toBeGreaterThanOrEqual(before);
      expect(collector.metrics.timeStarted).toBeLessThanOrEqual(after);
    });

    it('should start metrics interval', () => {
      collector = new MetricsCollector();

      expect(collector.metricsIntervalHandle).toBeDefined();
    });
  });

  describe('record() - Counter Metrics', () => {
    beforeEach(() => {
      collector = new MetricsCollector({ enableConsoleOutput: false });
    });

    describe('login_success event', () => {
      it('should increment successfulLogins counter', () => {
        collector.record('login_success');

        expect(collector.metrics.successfulLogins).toBe(1);
      });

      it('should increment totalAttempts counter', () => {
        collector.record('login_success');

        expect(collector.metrics.totalAttempts).toBe(1);
      });

      it('should record duration in totalResponseTime', () => {
        collector.record('login_success', { duration: 2500 });

        expect(collector.metrics.totalResponseTime).toBe(2500);
      });

      it('should handle multiple successful logins', () => {
        collector.record('login_success', { duration: 1000 });
        collector.record('login_success', { duration: 2000 });
        collector.record('login_success', { duration: 3000 });

        expect(collector.metrics.successfulLogins).toBe(3);
        expect(collector.metrics.totalAttempts).toBe(3);
        expect(collector.metrics.totalResponseTime).toBe(6000);
      });

      it('should handle login success without duration', () => {
        collector.record('login_success');

        expect(collector.metrics.totalResponseTime).toBe(0);
      });
    });

    describe('login_failed event', () => {
      it('should increment failedLogins counter', () => {
        collector.record('login_failed');

        expect(collector.metrics.failedLogins).toBe(1);
      });

      it('should increment totalAttempts counter', () => {
        collector.record('login_failed');

        expect(collector.metrics.totalAttempts).toBe(1);
      });

      it('should record failure reason', () => {
        collector.record('login_failed', { reason: 'invalid_credentials' });

        expect(collector.detailedMetrics.byReason.invalid_credentials).toBe(1);
      });

      it('should use "unknown" as default reason', () => {
        collector.record('login_failed');

        expect(collector.detailedMetrics.byReason.unknown).toBe(1);
      });

      it('should track multiple failures by reason', () => {
        collector.record('login_failed', { reason: 'timeout' });
        collector.record('login_failed', { reason: 'timeout' });
        collector.record('login_failed', { reason: 'blocked' });

        expect(collector.detailedMetrics.byReason.timeout).toBe(2);
        expect(collector.detailedMetrics.byReason.blocked).toBe(1);
      });
    });

    describe('captcha event', () => {
      it('should increment captchasDetected counter', () => {
        collector.record('captcha');

        expect(collector.metrics.captchasDetected).toBe(1);
      });

      it('should record captcha in byReason', () => {
        collector.record('captcha');

        expect(collector.detailedMetrics.byReason.captcha).toBe(1);
      });

      it('should track multiple captchas', () => {
        collector.record('captcha');
        collector.record('captcha');
        collector.record('captcha');

        expect(collector.metrics.captchasDetected).toBe(3);
        expect(collector.detailedMetrics.byReason.captcha).toBe(3);
      });
    });

    describe('blocked event', () => {
      it('should increment blocksDetected counter', () => {
        collector.record('blocked');

        expect(collector.metrics.blocksDetected).toBe(1);
      });

      it('should record block reason', () => {
        collector.record('blocked', { reason: 'ip_blocked' });

        expect(collector.detailedMetrics.byReason.ip_blocked).toBe(1);
      });

      it('should use "blocked" as default reason', () => {
        collector.record('blocked');

        expect(collector.detailedMetrics.byReason.blocked).toBe(1);
      });
    });

    describe('proxy_failure event', () => {
      it('should increment proxyFailures counter', () => {
        collector.record('proxy_failure', { proxy: '127.0.0.1:8080' });

        expect(collector.metrics.proxyFailures).toBe(1);
      });

      it('should track proxy performance', () => {
        collector.record('proxy_failure', { proxy: '127.0.0.1:8080' });

        expect(collector.detailedMetrics.byProxy['127.0.0.1:8080']).toEqual({
          success: 0,
          failure: 1
        });
      });

      it('should record proxy failure reason', () => {
        collector.record('proxy_failure', { 
          proxy: '127.0.0.1:8080',
          reason: 'connection_timeout'
        });

        expect(collector.detailedMetrics.byReason.connection_timeout).toBe(1);
      });

      it('should use "proxy_failure" as default reason', () => {
        collector.record('proxy_failure', { proxy: '127.0.0.1:8080' });

        expect(collector.detailedMetrics.byReason.proxy_failure).toBe(1);
      });

      it('should track multiple proxy failures', () => {
        collector.record('proxy_failure', { proxy: 'proxy1:8080' });
        collector.record('proxy_failure', { proxy: 'proxy1:8080' });
        collector.record('proxy_failure', { proxy: 'proxy2:8080' });

        expect(collector.detailedMetrics.byProxy['proxy1:8080'].failure).toBe(2);
        expect(collector.detailedMetrics.byProxy['proxy2:8080'].failure).toBe(1);
      });
    });

    describe('navigation_error event', () => {
      it('should increment navigationErrors counter', () => {
        collector.record('navigation_error');

        expect(collector.metrics.navigationErrors).toBe(1);
      });

      it('should record navigation error reason', () => {
        collector.record('navigation_error', { reason: 'page_load_timeout' });

        expect(collector.detailedMetrics.byReason.page_load_timeout).toBe(1);
      });

      it('should use "navigation" as default reason', () => {
        collector.record('navigation_error');

        expect(collector.detailedMetrics.byReason.navigation).toBe(1);
      });
    });

    describe('screenshot_failure event', () => {
      it('should increment screenshotFailures counter', () => {
        collector.record('screenshot_failure');

        expect(collector.metrics.screenshotFailures).toBe(1);
      });

      it('should track multiple screenshot failures', () => {
        collector.record('screenshot_failure');
        collector.record('screenshot_failure');

        expect(collector.metrics.screenshotFailures).toBe(2);
      });
    });

    describe('tunnel_error event', () => {
      it('should increment tunnelErrors counter', () => {
        collector.record('tunnel_error');

        expect(collector.metrics.tunnelErrors).toBe(1);
      });

      it('should record tunnel error in byReason', () => {
        collector.record('tunnel_error');

        expect(collector.detailedMetrics.byReason.tunnel_error).toBe(1);
      });
    });

    describe('batch_complete event', () => {
      it('should record batch data', () => {
        collector.record('batch_complete', {
          batchNum: 1,
          processed: 50,
          duration: 30000,
          status: 'completed'
        });

        expect(collector.detailedMetrics.byBatch[1]).toEqual({
          processed: 50,
          duration: 30000,
          status: 'completed'
        });
      });

      it('should track multiple batches', () => {
        collector.record('batch_complete', {
          batchNum: 1,
          processed: 50,
          duration: 30000,
          status: 'completed'
        });
        collector.record('batch_complete', {
          batchNum: 2,
          processed: 45,
          duration: 28000,
          status: 'completed'
        });

        expect(collector.detailedMetrics.byBatch[1]).toBeDefined();
        expect(collector.detailedMetrics.byBatch[2]).toBeDefined();
        expect(collector.detailedMetrics.byBatch[1].processed).toBe(50);
        expect(collector.detailedMetrics.byBatch[2].processed).toBe(45);
      });
    });
  });

  describe('record() - Timeline Recording', () => {
    beforeEach(() => {
      collector = new MetricsCollector({ enableConsoleOutput: false });
    });

    it('should add event to timeline', () => {
      collector.record('login_success', { duration: 1500 });

      expect(collector.detailedMetrics.timeline.length).toBe(1);
      expect(collector.detailedMetrics.timeline[0].event).toBe('login_success');
    });

    it('should record timestamp for each event', () => {
      const before = Date.now();
      collector.record('login_success');
      const after = Date.now();

      expect(collector.detailedMetrics.timeline[0].timestamp).toBeGreaterThanOrEqual(before);
      expect(collector.detailedMetrics.timeline[0].timestamp).toBeLessThanOrEqual(after);
    });

    it('should record event data in timeline', () => {
      const data = { duration: 2500, user: 'test@example.com' };
      collector.record('login_success', data);

      expect(collector.detailedMetrics.timeline[0].data).toEqual(data);
    });

    it('should maintain chronological order in timeline', () => {
      collector.record('login_success', { duration: 1000 });
      jest.advanceTimersByTime(100);
      collector.record('login_failed', { reason: 'timeout' });
      jest.advanceTimersByTime(100);
      collector.record('captcha');

      expect(collector.detailedMetrics.timeline.length).toBe(3);
      expect(collector.detailedMetrics.timeline[0].event).toBe('login_success');
      expect(collector.detailedMetrics.timeline[1].event).toBe('login_failed');
      expect(collector.detailedMetrics.timeline[2].event).toBe('captcha');
    });
  });

  describe('record() - Event Emission', () => {
    beforeEach(() => {
      collector = new MetricsCollector({ enableConsoleOutput: false });
    });

    it('should emit metric event on record', () => {
      const listener = jest.fn();
      collector.on('metric', listener);

      collector.record('login_success', { duration: 1500 });

      expect(listener).toHaveBeenCalledTimes(1);
    });

    it('should emit event with correct structure', () => {
      const listener = jest.fn();
      collector.on('metric', listener);

      collector.record('login_success', { duration: 1500 });

      expect(listener).toHaveBeenCalledWith(
        expect.objectContaining({
          event: 'login_success',
          timestamp: expect.any(Number),
          data: { duration: 1500 },
          metrics: expect.any(Object)
        })
      );
    });

    it('should include current metrics in emitted event', () => {
      const listener = jest.fn();
      collector.on('metric', listener);

      collector.record('login_success', { duration: 1500 });

      const emittedData = listener.mock.calls[0][0];
      expect(emittedData.metrics.successfulLogins).toBe(1);
      expect(emittedData.metrics.totalAttempts).toBe(1);
    });
  });

  describe('recordByReason()', () => {
    beforeEach(() => {
      collector = new MetricsCollector({ enableConsoleOutput: false });
    });

    it('should initialize new reason to 1', () => {
      collector.recordByReason('timeout');

      expect(collector.detailedMetrics.byReason.timeout).toBe(1);
    });

    it('should increment existing reason', () => {
      collector.recordByReason('timeout');
      collector.recordByReason('timeout');

      expect(collector.detailedMetrics.byReason.timeout).toBe(2);
    });

    it('should track multiple different reasons', () => {
      collector.recordByReason('timeout');
      collector.recordByReason('blocked');
      collector.recordByReason('timeout');

      expect(collector.detailedMetrics.byReason.timeout).toBe(2);
      expect(collector.detailedMetrics.byReason.blocked).toBe(1);
    });
  });

  describe('recordByProxy()', () => {
    beforeEach(() => {
      collector = new MetricsCollector({ enableConsoleOutput: false });
    });

    it('should initialize new proxy with success and failure counters', () => {
      collector.recordByProxy('proxy1:8080', 'failure');

      expect(collector.detailedMetrics.byProxy['proxy1:8080']).toEqual({
        success: 0,
        failure: 1
      });
    });

    it('should increment proxy failure count', () => {
      collector.recordByProxy('proxy1:8080', 'failure');
      collector.recordByProxy('proxy1:8080', 'failure');

      expect(collector.detailedMetrics.byProxy['proxy1:8080'].failure).toBe(2);
    });

    it('should increment proxy success count', () => {
      collector.recordByProxy('proxy1:8080', 'success');
      collector.recordByProxy('proxy1:8080', 'success');

      expect(collector.detailedMetrics.byProxy['proxy1:8080'].success).toBe(2);
    });

    it('should track multiple proxies independently', () => {
      collector.recordByProxy('proxy1:8080', 'success');
      collector.recordByProxy('proxy2:8080', 'failure');

      expect(collector.detailedMetrics.byProxy['proxy1:8080'].success).toBe(1);
      expect(collector.detailedMetrics.byProxy['proxy2:8080'].failure).toBe(1);
    });
  });

  describe('recordByBatch()', () => {
    beforeEach(() => {
      collector = new MetricsCollector({ enableConsoleOutput: false });
    });

    it('should record batch data', () => {
      const batchData = { processed: 100, duration: 50000, status: 'complete' };
      collector.recordByBatch(1, batchData);

      expect(collector.detailedMetrics.byBatch[1]).toEqual(batchData);
    });

    it('should overwrite existing batch data', () => {
      collector.recordByBatch(1, { processed: 50, duration: 25000, status: 'partial' });
      collector.recordByBatch(1, { processed: 100, duration: 50000, status: 'complete' });

      expect(collector.detailedMetrics.byBatch[1]).toEqual({
        processed: 100,
        duration: 50000,
        status: 'complete'
      });
    });
  });

  describe('getMetrics() - Statistics Calculation', () => {
    beforeEach(() => {
      collector = new MetricsCollector({ enableConsoleOutput: false });
    });

    it('should calculate avgResponseTime correctly', () => {
      collector.record('login_success', { duration: 1000 });
      collector.record('login_success', { duration: 2000 });
      collector.record('login_success', { duration: 3000 });

      const metrics = collector.getMetrics();

      expect(metrics.avgResponseTime).toBe('2000.00');
    });

    it('should return 0 avgResponseTime when no attempts', () => {
      const metrics = collector.getMetrics();

      expect(metrics.avgResponseTime).toBe(0);
    });

    it('should calculate successRate correctly', () => {
      collector.record('login_success', { duration: 1000 });
      collector.record('login_success', { duration: 2000 });
      collector.record('login_failed', { reason: 'timeout' });
      collector.record('login_failed', { reason: 'blocked' });

      const metrics = collector.getMetrics();

      expect(metrics.successRate).toBe('50.00');
    });

    it('should return 0 successRate when no attempts', () => {
      const metrics = collector.getMetrics();

      expect(metrics.successRate).toBe(0);
    });

    it('should calculate 100% successRate', () => {
      collector.record('login_success', { duration: 1000 });
      collector.record('login_success', { duration: 2000 });

      const metrics = collector.getMetrics();

      expect(metrics.successRate).toBe('100.00');
    });

    it('should calculate 0% successRate', () => {
      collector.record('login_failed', { reason: 'timeout' });
      collector.record('login_failed', { reason: 'blocked' });

      const metrics = collector.getMetrics();

      expect(metrics.successRate).toBe('0.00');
    });

    it('should calculate credentialsPerMinute', () => {
      collector.record('login_success', { duration: 1000 });
      collector.record('login_failed', { reason: 'timeout' });
      
      jest.advanceTimersByTime(60000);

      const metrics = collector.getMetrics();

      expect(parseFloat(metrics.credentialsPerMinute)).toBeGreaterThan(0);
    });

    it('should return 0 credentialsPerMinute when no time elapsed', () => {
      const metrics = collector.getMetrics();

      expect(metrics.credentialsPerMinute).toBe(0);
    });

    it('should calculate elapsedSeconds', () => {
      jest.advanceTimersByTime(5000);

      const metrics = collector.getMetrics();

      expect(parseFloat(metrics.elapsedSeconds)).toBeCloseTo(5.0, 0);
    });

    it('should include errorBreakdown', () => {
      collector.record('login_failed', { reason: 'timeout' });
      collector.record('login_failed', { reason: 'blocked' });
      collector.record('login_failed', { reason: 'timeout' });

      const metrics = collector.getMetrics();

      expect(metrics.errorBreakdown).toEqual({
        timeout: 2,
        blocked: 1
      });
    });

    it('should include proxyPerformance', () => {
      collector.record('proxy_failure', { proxy: 'proxy1:8080' });

      const metrics = collector.getMetrics();

      expect(metrics.proxyPerformance).toEqual({
        'proxy1:8080': { success: 0, failure: 1 }
      });
    });

    it('should include all base metrics', () => {
      const metrics = collector.getMetrics();

      expect(metrics).toHaveProperty('totalAttempts');
      expect(metrics).toHaveProperty('successfulLogins');
      expect(metrics).toHaveProperty('failedLogins');
      expect(metrics).toHaveProperty('captchasDetected');
      expect(metrics).toHaveProperty('blocksDetected');
      expect(metrics).toHaveProperty('proxyFailures');
      expect(metrics).toHaveProperty('navigationErrors');
      expect(metrics).toHaveProperty('screenshotFailures');
      expect(metrics).toHaveProperty('tunnelErrors');
      expect(metrics).toHaveProperty('timeStarted');
      expect(metrics).toHaveProperty('timeLastMetric');
      expect(metrics).toHaveProperty('totalResponseTime');
    });
  });

  describe('getReport()', () => {
    beforeEach(() => {
      collector = new MetricsCollector({ enableConsoleOutput: false });
    });

    it('should return formatted report string', () => {
      const report = collector.getReport();

      expect(typeof report).toBe('string');
      expect(report).toContain('METRICS REPORT');
    });

    it('should include totalAttempts in report', () => {
      collector.record('login_success');
      const report = collector.getReport();

      expect(report).toContain('Total Attempts:');
      expect(report).toContain('1');
    });

    it('should include successfulLogins in report', () => {
      collector.record('login_success');
      const report = collector.getReport();

      expect(report).toContain('Successful:');
      expect(report).toContain('1');
    });

    it('should include failedLogins in report', () => {
      collector.record('login_failed');
      const report = collector.getReport();

      expect(report).toContain('Failed:');
      expect(report).toContain('1');
    });

    it('should include successRate in report', () => {
      collector.record('login_success');
      const report = collector.getReport();

      expect(report).toContain('Success Rate:');
      expect(report).toContain('%');
    });

    it('should include captchasDetected in report', () => {
      collector.record('captcha');
      const report = collector.getReport();

      expect(report).toContain('CAPTCHAs Detected:');
    });

    it('should include blocksDetected in report', () => {
      collector.record('blocked');
      const report = collector.getReport();

      expect(report).toContain('Blocks Detected:');
    });

    it('should include tunnelErrors in report', () => {
      collector.record('tunnel_error');
      const report = collector.getReport();

      expect(report).toContain('Tunnel Errors:');
    });

    it('should include proxyFailures in report', () => {
      collector.record('proxy_failure', { proxy: 'proxy1:8080' });
      const report = collector.getReport();

      expect(report).toContain('Proxy Failures:');
    });

    it('should include credentialsPerMinute in report', () => {
      const report = collector.getReport();

      expect(report).toContain('Credentials/Minute:');
    });

    it('should include avgResponseTime in report', () => {
      const report = collector.getReport();

      expect(report).toContain('Avg Response Time:');
      expect(report).toContain('ms');
    });

    it('should include elapsedTime in report', () => {
      const report = collector.getReport();

      expect(report).toContain('Elapsed Time:');
      expect(report).toContain('s');
    });

    it('should format report with box drawing characters', () => {
      const report = collector.getReport();

      expect(report).toContain('╔');
      expect(report).toContain('╠');
      expect(report).toContain('╚');
      expect(report).toContain('║');
      expect(report).toContain('═');
    });
  });

  describe('padRight()', () => {
    beforeEach(() => {
      collector = new MetricsCollector({ enableConsoleOutput: false });
    });

    it('should pad string to specified width', () => {
      const padded = collector.padRight('test', 10);

      expect(padded.length).toBe(8);
    });

    it('should handle numbers by converting to string', () => {
      const padded = collector.padRight(123, 10);

      expect(typeof padded).toBe('string');
      expect(padded).toContain('123');
    });

    it('should pad with spaces', () => {
      const padded = collector.padRight('a', 6);

      expect(padded).toBe('a   ');
    });
  });

  describe('startMetricsInterval()', () => {
    it('should emit periodic_report event at specified interval', () => {
      collector = new MetricsCollector({ 
        metricsInterval: 5000,
        enableConsoleOutput: false 
      });

      const listener = jest.fn();
      collector.on('periodic_report', listener);

      jest.advanceTimersByTime(5000);
      expect(listener).toHaveBeenCalledTimes(1);

      jest.advanceTimersByTime(5000);
      expect(listener).toHaveBeenCalledTimes(2);
    });

    it('should include metrics in periodic_report event', () => {
      collector = new MetricsCollector({ 
        metricsInterval: 5000,
        enableConsoleOutput: false 
      });

      const listener = jest.fn();
      collector.on('periodic_report', listener);
      
      collector.record('login_success');

      jest.advanceTimersByTime(5000);

      expect(listener).toHaveBeenCalledWith(
        expect.objectContaining({
          totalAttempts: 1,
          successfulLogins: 1
        })
      );
    });

    it('should log report to console when enabled', () => {
      const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();
      
      collector = new MetricsCollector({ 
        metricsInterval: 5000,
        enableConsoleOutput: true 
      });

      jest.advanceTimersByTime(5000);

      expect(consoleLogSpy).toHaveBeenCalled();
      
      consoleLogSpy.mockRestore();
    });

    it('should not log report to console when disabled', () => {
      const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();
      
      collector = new MetricsCollector({ 
        metricsInterval: 5000,
        enableConsoleOutput: false 
      });

      jest.advanceTimersByTime(5000);

      expect(consoleLogSpy).not.toHaveBeenCalled();
      
      consoleLogSpy.mockRestore();
    });
  });

  describe('stopMetricsInterval()', () => {
    it('should stop periodic metric emission', () => {
      collector = new MetricsCollector({ 
        metricsInterval: 5000,
        enableConsoleOutput: false 
      });

      const listener = jest.fn();
      collector.on('periodic_report', listener);

      jest.advanceTimersByTime(5000);
      expect(listener).toHaveBeenCalledTimes(1);

      collector.stopMetricsInterval();

      jest.advanceTimersByTime(10000);
      expect(listener).toHaveBeenCalledTimes(1);
    });

    it('should clear interval handle', () => {
      collector = new MetricsCollector({ enableConsoleOutput: false });
      
      const handle = collector.metricsIntervalHandle;
      collector.stopMetricsInterval();

      expect(collector.metricsIntervalHandle).toBeDefined();
    });
  });

  describe('reset()', () => {
    beforeEach(() => {
      collector = new MetricsCollector({ enableConsoleOutput: false });
    });

    it('should reset all counters to zero', () => {
      collector.record('login_success', { duration: 1000 });
      collector.record('login_failed', { reason: 'timeout' });
      collector.record('captcha');

      collector.reset();

      expect(collector.metrics.totalAttempts).toBe(0);
      expect(collector.metrics.successfulLogins).toBe(0);
      expect(collector.metrics.failedLogins).toBe(0);
      expect(collector.metrics.captchasDetected).toBe(0);
    });

    it('should reset totalResponseTime', () => {
      collector.record('login_success', { duration: 5000 });

      collector.reset();

      expect(collector.metrics.totalResponseTime).toBe(0);
    });

    it('should reset avgResponseTime', () => {
      collector.record('login_success', { duration: 5000 });

      collector.reset();

      expect(collector.metrics.avgResponseTime).toBe(0);
    });

    it('should reset all error counters', () => {
      collector.record('blocked');
      collector.record('proxy_failure', { proxy: 'proxy1:8080' });
      collector.record('navigation_error');
      collector.record('screenshot_failure');
      collector.record('tunnel_error');

      collector.reset();

      expect(collector.metrics.blocksDetected).toBe(0);
      expect(collector.metrics.proxyFailures).toBe(0);
      expect(collector.metrics.navigationErrors).toBe(0);
      expect(collector.metrics.screenshotFailures).toBe(0);
      expect(collector.metrics.tunnelErrors).toBe(0);
    });

    it('should update timeStarted', () => {
      const originalTime = collector.metrics.timeStarted;
      
      jest.advanceTimersByTime(5000);
      collector.reset();

      expect(collector.metrics.timeStarted).toBeGreaterThan(originalTime);
    });

    it('should not reset detailed metrics', () => {
      collector.record('login_failed', { reason: 'timeout' });
      collector.record('proxy_failure', { proxy: 'proxy1:8080' });

      collector.reset();

      expect(collector.detailedMetrics.byReason.timeout).toBe(1);
      expect(collector.detailedMetrics.byProxy['proxy1:8080']).toBeDefined();
    });
  });

  describe('destroy()', () => {
    beforeEach(() => {
      collector = new MetricsCollector({ enableConsoleOutput: false });
    });

    it('should stop metrics interval', () => {
      const stopSpy = jest.spyOn(collector, 'stopMetricsInterval');
      
      collector.destroy();

      expect(stopSpy).toHaveBeenCalled();
    });

    it('should remove all event listeners', () => {
      const listener1 = jest.fn();
      const listener2 = jest.fn();
      
      collector.on('metric', listener1);
      collector.on('periodic_report', listener2);

      collector.destroy();

      collector.record('login_success');
      jest.advanceTimersByTime(collector.metricsInterval);

      expect(listener1).not.toHaveBeenCalled();
      expect(listener2).not.toHaveBeenCalled();
    });

    it('should prevent further event emission', () => {
      const listener = jest.fn();
      collector.on('metric', listener);

      collector.destroy();
      collector.record('login_success');

      expect(listener).not.toHaveBeenCalled();
    });
  });

  describe('Integration Scenarios', () => {
    beforeEach(() => {
      collector = new MetricsCollector({ enableConsoleOutput: false });
    });

    it('should handle mixed success and failure events', () => {
      collector.record('login_success', { duration: 1000 });
      collector.record('login_failed', { reason: 'timeout' });
      collector.record('login_success', { duration: 2000 });
      collector.record('login_failed', { reason: 'blocked' });

      const metrics = collector.getMetrics();

      expect(metrics.totalAttempts).toBe(4);
      expect(metrics.successfulLogins).toBe(2);
      expect(metrics.failedLogins).toBe(2);
      expect(metrics.successRate).toBe('50.00');
      expect(metrics.avgResponseTime).toBe('750.00');
    });

    it('should track complete workflow metrics', () => {
      collector.record('login_success', { duration: 1500 });
      collector.record('captcha');
      collector.record('blocked', { reason: 'ip_blocked' });
      collector.record('proxy_failure', { proxy: 'proxy1:8080' });
      collector.record('tunnel_error');

      const metrics = collector.getMetrics();

      expect(metrics.captchasDetected).toBe(1);
      expect(metrics.blocksDetected).toBe(1);
      expect(metrics.proxyFailures).toBe(1);
      expect(metrics.tunnelErrors).toBe(1);
      expect(metrics.errorBreakdown).toHaveProperty('captcha');
      expect(metrics.errorBreakdown).toHaveProperty('ip_blocked');
    });

    it('should handle batch processing metrics', () => {
      for (let i = 1; i <= 3; i++) {
        collector.record('batch_complete', {
          batchNum: i,
          processed: i * 10,
          duration: i * 5000,
          status: 'completed'
        });
      }

      expect(Object.keys(collector.detailedMetrics.byBatch).length).toBe(3);
      expect(collector.detailedMetrics.byBatch[1].processed).toBe(10);
      expect(collector.detailedMetrics.byBatch[2].processed).toBe(20);
      expect(collector.detailedMetrics.byBatch[3].processed).toBe(30);
    });

    it('should calculate accurate rates with realistic data', () => {
      for (let i = 0; i < 80; i++) {
        collector.record('login_success', { duration: 1000 + Math.random() * 2000 });
      }
      for (let i = 0; i < 20; i++) {
        collector.record('login_failed', { reason: 'timeout' });
      }

      const metrics = collector.getMetrics();

      expect(metrics.totalAttempts).toBe(100);
      expect(metrics.successfulLogins).toBe(80);
      expect(metrics.failedLogins).toBe(20);
      expect(parseFloat(metrics.successRate)).toBe(80.00);
    });

    it('should maintain timeline accuracy with multiple events', () => {
      const events = ['login_success', 'login_failed', 'captcha', 'blocked', 'tunnel_error'];
      
      events.forEach((event, index) => {
        jest.advanceTimersByTime(100);
        collector.record(event, { index });
      });

      expect(collector.detailedMetrics.timeline.length).toBe(5);
      
      for (let i = 0; i < events.length; i++) {
        expect(collector.detailedMetrics.timeline[i].event).toBe(events[i]);
        expect(collector.detailedMetrics.timeline[i].data.index).toBe(i);
      }
    });

    it('should handle proxy performance across multiple events', () => {
      const proxy1 = 'proxy1:8080';
      const proxy2 = 'proxy2:8080';

      collector.recordByProxy(proxy1, 'success');
      collector.recordByProxy(proxy1, 'success');
      collector.recordByProxy(proxy1, 'failure');
      collector.recordByProxy(proxy2, 'success');
      collector.recordByProxy(proxy2, 'failure');
      collector.recordByProxy(proxy2, 'failure');

      const metrics = collector.getMetrics();

      expect(metrics.proxyPerformance[proxy1]).toEqual({ success: 2, failure: 1 });
      expect(metrics.proxyPerformance[proxy2]).toEqual({ success: 1, failure: 2 });
    });

    it('should preserve data after multiple resets', () => {
      collector.record('login_success', { duration: 1000 });
      collector.reset();
      collector.record('login_success', { duration: 2000 });
      collector.reset();
      collector.record('login_success', { duration: 3000 });

      const metrics = collector.getMetrics();

      expect(metrics.totalAttempts).toBe(1);
      expect(metrics.successfulLogins).toBe(1);
      expect(metrics.avgResponseTime).toBe('3000.00');
    });
  });

  describe('Edge Cases', () => {
    beforeEach(() => {
      collector = new MetricsCollector({ enableConsoleOutput: false });
    });

    it('should handle recording events with empty data', () => {
      collector.record('login_success', {});

      expect(collector.metrics.successfulLogins).toBe(1);
      expect(collector.metrics.totalResponseTime).toBe(0);
    });

    it('should handle recording events with missing data object', () => {
      collector.record('login_failed');

      expect(collector.metrics.failedLogins).toBe(1);
      expect(collector.detailedMetrics.byReason.unknown).toBe(1);
    });

    it('should handle recording events with undefined data', () => {
      collector.record('captcha', undefined);

      expect(collector.metrics.captchasDetected).toBe(1);
    });

    it('should handle very large duration values', () => {
      collector.record('login_success', { duration: Number.MAX_SAFE_INTEGER });

      const metrics = collector.getMetrics();

      expect(metrics.totalResponseTime).toBe(Number.MAX_SAFE_INTEGER);
    });

    it('should handle zero duration', () => {
      collector.record('login_success', { duration: 0 });

      const metrics = collector.getMetrics();

      expect(metrics.totalResponseTime).toBe(0);
      expect(metrics.avgResponseTime).toBe('0.00');
    });

    it('should handle negative duration values', () => {
      collector.record('login_success', { duration: -1000 });

      expect(collector.metrics.totalResponseTime).toBe(-1000);
    });

    it('should format avgResponseTime to 2 decimal places', () => {
      collector.record('login_success', { duration: 1234 });
      collector.record('login_success', { duration: 5678 });

      const metrics = collector.getMetrics();

      expect(metrics.avgResponseTime).toMatch(/^\d+\.\d{2}$/);
    });

    it('should format successRate to 2 decimal places', () => {
      collector.record('login_success');
      collector.record('login_success');
      collector.record('login_failed');

      const metrics = collector.getMetrics();

      expect(metrics.successRate).toMatch(/^\d+\.\d{2}$/);
    });

    it('should handle very long proxy names', () => {
      const longProxy = 'a'.repeat(1000) + ':8080';
      
      collector.recordByProxy(longProxy, 'failure');

      expect(collector.detailedMetrics.byProxy[longProxy]).toBeDefined();
    });

    it('should handle special characters in reason', () => {
      const specialReason = 'timeout!@#$%^&*()_+-=[]{}|;:,.<>?';
      
      collector.recordByReason(specialReason);

      expect(collector.detailedMetrics.byReason[specialReason]).toBe(1);
    });

    it('should handle unknown event types gracefully', () => {
      collector.record('unknown_event_type', { data: 'test' });

      expect(collector.detailedMetrics.timeline.length).toBe(1);
      expect(collector.detailedMetrics.timeline[0].event).toBe('unknown_event_type');
    });
  });
});
