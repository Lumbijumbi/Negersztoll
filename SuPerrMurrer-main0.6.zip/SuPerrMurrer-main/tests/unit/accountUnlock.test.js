/**
 * Unit Tests for Account Unlock Module
 * Tests password-reset unlock flow including link selection, email fill,
 * submit detection, confirmation polling, and unlock_requested logging.
 */

'use strict';

const fs = require('fs');
const path = require('path');
const { EventEmitter } = require('events');

// ─── Mock http/https for solver tests ────────────────────────────────────────
jest.mock('http');
jest.mock('https');

// Mock config to avoid loading real config
jest.mock('../../config', () => ({
  form: { typeDelayMin: 4, typeDelayMax: 10 },
  login: { forgotPasswordLink: "a[href*='forgot']" },
  passwordReset: {
    enabled: true,
    resetLinkSelectors: ["a[href*='forgot']"],
    resetLinkPhrases: ['Passwort vergessen'],
    emailSelector: '#email',
    submitSelectors: ["button[type='submit']"],
    submitPhrases: ['Absenden'],
    confirmationPhrases: ['E-Mail wurde gesendet'],
    navigationTimeout: 500,
    confirmationTimeout: 500,
    formLoadDelay: 10
  },
  output: { unlockRequestedFile: '/tmp/test_unlock_requested.txt' }
}));

// Mock formFill to control fastFill behaviour
jest.mock('../../formFill', () => ({
  fastFill: jest.fn().mockResolvedValue(true)
}));

const { fastFill } = require('../../formFill');
const {
  unlockAccountViaPasswordReset,
  _dismissConsentOverlay,
  _detectAndHandleCaptcha,
  _handleCaptchaStrategy,
  _classifyCaptchaType,
  _takeCaptchaScreenshot,
  _attemptCaptchaSolve,
  _httpRequest
} = require('../../utils/accountUnlock');

// Pull in the mocked http/https so we can set up implementations per test
const http = require('http');
const https = require('https');

// ─── helpers ────────────────────────────────────────────────────────────────

function makeLogger() {
  return {
    info: jest.fn(),
    warn: jest.fn(),
    success: jest.fn(),
    error: jest.fn()
  };
}

/**
 * Build a minimal mock Playwright page.
 * @param {Object} overrides - override specific methods
 */
function makePage(overrides = {}) {
  const page = {
    isVisible: jest.fn().mockResolvedValue(false),
    click: jest.fn().mockResolvedValue(undefined),
    evaluate: jest.fn().mockResolvedValue(''),
    getByText: jest.fn().mockReturnValue({
      count: jest.fn().mockResolvedValue(0),
      first: jest.fn().mockReturnValue({ click: jest.fn().mockResolvedValue(undefined) })
    }),
    getByRole: jest.fn().mockReturnValue({
      count: jest.fn().mockResolvedValue(0),
      first: jest.fn().mockReturnValue({ click: jest.fn().mockResolvedValue(undefined) })
    }),
    ...overrides
  };
  return page;
}

function makeConfig(overrides = {}) {
  return {
    login: { forgotPasswordLink: "a[href*='forgot']" },
    passwordReset: {
      enabled: true,
      resetLinkSelectors: ["a[href*='forgot']"],
      resetLinkPhrases: ['Passwort vergessen'],
      emailSelector: '#email',
      submitSelectors: ["button[type='submit']"],
      submitPhrases: ['Absenden'],
      confirmationPhrases: ['E-Mail wurde gesendet'],
      navigationTimeout: 500,
      confirmationTimeout: 500,
      formLoadDelay: 10
    },
    output: { unlockRequestedFile: '/tmp/test_unlock_requested.txt' },
    ...overrides
  };
}

// ─── clean up temp file before/after each test ──────────────────────────────
beforeEach(() => {
  jest.clearAllMocks();
  try { fs.unlinkSync('/tmp/test_unlock_requested.txt'); } catch (_) {}
});
afterEach(() => {
  try { fs.unlinkSync('/tmp/test_unlock_requested.txt'); } catch (_) {}
});

// ─── Tests ───────────────────────────────────────────────────────────────────

describe('unlockAccountViaPasswordReset', () => {

  describe('Reset link detection', () => {
    it('should succeed using config.login.forgotPasswordLink selector', async () => {
      const page = makePage({
        isVisible: jest.fn()
          .mockResolvedValueOnce(true)  // forgotPasswordLink visible
          .mockResolvedValueOnce(true)  // email field visible
          .mockResolvedValueOnce(true), // submit visible
        evaluate: jest.fn().mockResolvedValue('E-Mail wurde gesendet')
      });
      const logger = makeLogger();
      const config = makeConfig();

      const result = await unlockAccountViaPasswordReset(page, 'user@example.com', config, logger);

      expect(result.success).toBe(true);
      expect(page.click).toHaveBeenCalledWith(
        "a[href*='forgot']",
        expect.objectContaining({ timeout: 500 })
      );
    });

    it('should fall through to resetLinkSelectors when forgotPasswordLink is invisible', async () => {
      let clickCount = 0;
      const page = makePage({
        isVisible: jest.fn().mockImplementation((sel) => {
          if (sel === "a[href*='reset']") return Promise.resolve(true);
          if (sel === '#email') return Promise.resolve(true);
          if (sel === "button[type='submit']") return Promise.resolve(true);
          return Promise.resolve(false);
        }),
        evaluate: jest.fn().mockResolvedValue('E-Mail wurde gesendet')
      });
      const logger = makeLogger();
      const config = makeConfig({
        login: { forgotPasswordLink: "a[href*='forgot']" },
        passwordReset: {
          ...makeConfig().passwordReset,
          resetLinkSelectors: ["a[href*='forgot']", "a[href*='reset']"]
        }
      });

      const result = await unlockAccountViaPasswordReset(page, 'user@example.com', config, logger);

      expect(result.success).toBe(true);
      // Verify primary selector was tried first, then the fallback
      const clickCalls = page.click.mock.calls.map(c => c[0]);
      const forgotIdx = clickCalls.indexOf("a[href*='forgot']");
      const resetIdx = clickCalls.indexOf("a[href*='reset']");
      // forgotPasswordLink was attempted (invisible) before the fallback selector
      expect(forgotIdx).toBe(-1); // click should not have been called for invisible selector
      expect(page.click).toHaveBeenCalledWith(
        "a[href*='reset']",
        expect.objectContaining({ timeout: expect.any(Number) })
      );
    });

    it('should return failure and write log entry when reset link not found', async () => {
      const page = makePage({
        isVisible: jest.fn().mockResolvedValue(false)
      });
      const logger = makeLogger();
      const config = makeConfig();

      const result = await unlockAccountViaPasswordReset(page, 'user@example.com', config, logger);

      expect(result.success).toBe(false);
      expect(result.details).toBe('password_reset_link_not_found');

      // Entry must be written even on failure
      const written = fs.readFileSync('/tmp/test_unlock_requested.txt', 'utf8');
      expect(written).toContain('user@example.com');
      expect(written).toContain('failed:link_not_found');
    });
  });

  describe('Email field filling', () => {
    it('should try each comma-separated selector in order', async () => {
      // First selector invisible, second visible
      const page = makePage({
        isVisible: jest.fn().mockImplementation((sel) => {
          if (sel === "a[href*='forgot']") return Promise.resolve(true); // link
          if (sel === '#email') return Promise.resolve(false);
          if (sel === 'input[type=\'email\']') return Promise.resolve(true);
          if (sel === "button[type='submit']") return Promise.resolve(true);
          return Promise.resolve(false);
        }),
        evaluate: jest.fn().mockResolvedValue('E-Mail wurde gesendet')
      });
      const logger = makeLogger();
      const config = makeConfig({
        passwordReset: {
          ...makeConfig().passwordReset,
          emailSelector: "#email, input[type='email']"
        }
      });
      fastFill.mockResolvedValue(true);

      const result = await unlockAccountViaPasswordReset(page, 'user@example.com', config, logger);

      expect(result.success).toBe(true);
      expect(fastFill).toHaveBeenCalledWith(
        page,
        "input[type='email']",
        'user@example.com',
        expect.objectContaining({ logPrefix: '[UNLOCK]' })
      );
    });

    it('should return failure and write log entry when no email field is found', async () => {
      const page = makePage({
        isVisible: jest.fn().mockImplementation((sel) => {
          return Promise.resolve(sel === "a[href*='forgot']");
        })
      });
      const logger = makeLogger();
      const config = makeConfig();
      fastFill.mockResolvedValue(false);

      const result = await unlockAccountViaPasswordReset(page, 'user@example.com', config, logger);

      expect(result.success).toBe(false);
      expect(result.details).toBe('email_field_not_found');

      const written = fs.readFileSync('/tmp/test_unlock_requested.txt', 'utf8');
      expect(written).toContain('user@example.com');
      expect(written).toContain('failed:email_field_not_found');
    });
  });

  describe('Submit button detection', () => {
    it('should click configured CSS submit selector', async () => {
      const page = makePage({
        isVisible: jest.fn().mockImplementation((sel) => {
          return Promise.resolve(
            sel === "a[href*='forgot']" ||
            sel === '#email' ||
            sel === "button[type='submit']"
          );
        }),
        evaluate: jest.fn().mockResolvedValue('E-Mail wurde gesendet')
      });
      const logger = makeLogger();
      const config = makeConfig();
      fastFill.mockResolvedValue(true);

      const result = await unlockAccountViaPasswordReset(page, 'user@example.com', config, logger);

      expect(result.success).toBe(true);
      expect(page.click).toHaveBeenCalledWith(
        "button[type='submit']",
        expect.objectContaining({ timeout: expect.any(Number) })
      );
    });

    it('should fall back to text-based button search when CSS selectors invisible', async () => {
      const submitLocatorClick = jest.fn().mockResolvedValue(undefined);
      const page = makePage({
        isVisible: jest.fn().mockImplementation((sel) => {
          return Promise.resolve(
            sel === "a[href*='forgot']" || sel === '#email'
          );
        }),
        getByRole: jest.fn().mockReturnValue({
          count: jest.fn().mockResolvedValue(1),
          first: jest.fn().mockReturnValue({ click: submitLocatorClick })
        }),
        evaluate: jest.fn().mockResolvedValue('E-Mail wurde gesendet')
      });
      const logger = makeLogger();
      const config = makeConfig();
      fastFill.mockResolvedValue(true);

      const result = await unlockAccountViaPasswordReset(page, 'user@example.com', config, logger);

      expect(result.success).toBe(true);
      expect(submitLocatorClick).toHaveBeenCalled();
    });

    it('should return failure and write log entry when submit not found', async () => {
      const page = makePage({
        isVisible: jest.fn().mockImplementation((sel) => {
          return Promise.resolve(
            sel === "a[href*='forgot']" || sel === '#email'
          );
        }),
        getByRole: jest.fn().mockReturnValue({
          count: jest.fn().mockResolvedValue(0),
          first: jest.fn().mockReturnValue({ click: jest.fn() })
        })
      });
      const logger = makeLogger();
      const config = makeConfig();
      fastFill.mockResolvedValue(true);

      const result = await unlockAccountViaPasswordReset(page, 'user@example.com', config, logger);

      expect(result.success).toBe(false);
      expect(result.details).toBe('submit_button_not_found');

      const written = fs.readFileSync('/tmp/test_unlock_requested.txt', 'utf8');
      expect(written).toContain('user@example.com');
      expect(written).toContain('failed:submit_button_not_found');
    });
  });

  describe('Confirmation polling', () => {
    it('should return success with reset_email_sent when confirmation phrase found', async () => {
      const page = makePage({
        isVisible: jest.fn().mockImplementation((sel) => {
          return Promise.resolve(
            sel === "a[href*='forgot']" ||
            sel === '#email' ||
            sel === "button[type='submit']"
          );
        }),
        evaluate: jest.fn().mockResolvedValue('E-Mail wurde gesendet')
      });
      const logger = makeLogger();
      const config = makeConfig();
      fastFill.mockResolvedValue(true);

      const result = await unlockAccountViaPasswordReset(page, 'user@example.com', config, logger);

      expect(result.success).toBe(true);
      expect(result.details).toBe('reset_email_sent');
      expect(logger.success).toHaveBeenCalled();
    });

    it('should return reset_submitted_unconfirmed when no confirmation phrase is found within timeout', async () => {
      const page = makePage({
        isVisible: jest.fn().mockImplementation((sel) => {
          return Promise.resolve(
            sel === "a[href*='forgot']" ||
            sel === '#email' ||
            sel === "button[type='submit']"
          );
        }),
        evaluate: jest.fn().mockResolvedValue('some other text')
      });
      const logger = makeLogger();
      const config = makeConfig({
        passwordReset: {
          ...makeConfig().passwordReset,
          confirmationTimeout: 50  // very short so test finishes fast
        }
      });
      fastFill.mockResolvedValue(true);

      const result = await unlockAccountViaPasswordReset(page, 'user@example.com', config, logger);

      expect(result.success).toBe(true);
      expect(result.details).toBe('reset_submitted_unconfirmed');
    });
  });

  describe('unlock_requested.txt logging', () => {
    it('should write status column to unlock_requested.txt on success', async () => {
      const page = makePage({
        isVisible: jest.fn().mockImplementation((sel) => {
          return Promise.resolve(
            sel === "a[href*='forgot']" ||
            sel === '#email' ||
            sel === "button[type='submit']"
          );
        }),
        evaluate: jest.fn().mockResolvedValue('E-Mail wurde gesendet')
      });
      const logger = makeLogger();
      const config = makeConfig();
      fastFill.mockResolvedValue(true);

      await unlockAccountViaPasswordReset(page, 'user@example.com', config, logger);

      const written = fs.readFileSync('/tmp/test_unlock_requested.txt', 'utf8');
      expect(written).toContain('user@example.com');
      expect(written).toContain('reset_email_sent');
      // Should contain a full ISO 8601 timestamp (e.g. 2024-03-23T10:15:30.123Z)
      expect(written).toMatch(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z/);
    });

    it('should append multiple entries without overwriting', async () => {
      const makeSuccessPage = () => makePage({
        isVisible: jest.fn().mockImplementation((sel) => {
          return Promise.resolve(
            sel === "a[href*='forgot']" ||
            sel === '#email' ||
            sel === "button[type='submit']"
          );
        }),
        evaluate: jest.fn().mockResolvedValue('E-Mail wurde gesendet')
      });
      const config = makeConfig();
      fastFill.mockResolvedValue(true);

      await unlockAccountViaPasswordReset(makeSuccessPage(), 'user1@example.com', config, makeLogger());
      await unlockAccountViaPasswordReset(makeSuccessPage(), 'user2@example.com', config, makeLogger());

      const written = fs.readFileSync('/tmp/test_unlock_requested.txt', 'utf8');
      expect(written).toContain('user1@example.com');
      expect(written).toContain('user2@example.com');
    });

    it('should not throw when output file path is not writable (graceful fail)', async () => {
      const page = makePage({
        isVisible: jest.fn().mockImplementation((sel) => {
          return Promise.resolve(
            sel === "a[href*='forgot']" ||
            sel === '#email' ||
            sel === "button[type='submit']"
          );
        }),
        evaluate: jest.fn().mockResolvedValue('E-Mail wurde gesendet')
      });
      const logger = makeLogger();
      const config = makeConfig({
        output: { unlockRequestedFile: '/nonexistent_dir/unlock.txt' }
      });
      fastFill.mockResolvedValue(true);

      // Should not throw
      await expect(
        unlockAccountViaPasswordReset(page, 'user@example.com', config, logger)
      ).resolves.toBeDefined();

      expect(logger.warn).toHaveBeenCalledWith(
        '[UNLOCK]',
        expect.stringContaining('Could not write to unlock_requested file')
      );
    });
  });

  describe('Error handling', () => {
    it('should handle non-Error throw values safely in the top-level catch', async () => {
      const page = makePage({
        isVisible: jest.fn().mockRejectedValue('string_error')
      });
      const logger = makeLogger();
      const config = makeConfig();

      const result = await unlockAccountViaPasswordReset(page, 'user@example.com', config, logger);

      // Should still return a structured result, not throw
      expect(result).toHaveProperty('success');
      expect(result).toHaveProperty('details');
    });

    it('should use err?.message || String(err) in top-level catch for non-Error throws', async () => {
      // Simulate a non-Error throw at a deep level
      const page = makePage({
        isVisible: jest.fn().mockImplementation(() => { throw 'oops'; })
      });
      const logger = makeLogger();
      const config = makeConfig();

      const result = await unlockAccountViaPasswordReset(page, 'user@example.com', config, logger);

      expect(result.success).toBe(false);
      expect(typeof result.details).toBe('string');
    });
  });
});

// ─── CAPTCHA helpers ──────────────────────────────────────────────────────────

describe('_classifyCaptchaType', () => {
  it('should classify DataDome selector', () => {
    expect(_classifyCaptchaType("iframe[src*='captcha-delivery.com']")).toBe('datadome');
  });
  it('should classify reCAPTCHA selector', () => {
    expect(_classifyCaptchaType("iframe[src*='recaptcha']")).toBe('recaptcha');
    expect(_classifyCaptchaType('.g-recaptcha')).toBe('recaptcha');
    expect(_classifyCaptchaType('div[data-sitekey]')).toBe('recaptcha');
  });
  it('should classify hCaptcha selector', () => {
    expect(_classifyCaptchaType("iframe[src*='hcaptcha']")).toBe('hcaptcha');
    expect(_classifyCaptchaType('.h-captcha')).toBe('hcaptcha');
  });
  it('should classify unknown selectors', () => {
    expect(_classifyCaptchaType('#recaptcha')).toBe('recaptcha');
    expect(_classifyCaptchaType('.some-other-captcha')).toBe('unknown');
  });
});

describe('_dismissConsentOverlay', () => {
  it('should return false when no consent selector is visible', async () => {
    const page = makePage({ isVisible: jest.fn().mockResolvedValue(false) });
    const logger = makeLogger();
    const config = makeConfig({ passwordReset: { ...makeConfig().passwordReset, captchaHandling: { enabled: true } } });
    const result = await _dismissConsentOverlay(page, config, logger);
    expect(result).toBe(false);
    expect(logger.info).not.toHaveBeenCalledWith('[UNLOCK]', expect.stringContaining('Consent overlay dismissed'));
  });

  it('should click the first visible consent selector and log it', async () => {
    const page = makePage({
      isVisible: jest.fn().mockImplementation(sel => {
        return Promise.resolve(sel === '#onetrust-accept-btn-handler');
      }),
      click: jest.fn().mockResolvedValue(undefined)
    });
    const logger = makeLogger();
    const config = makeConfig({
      passwordReset: {
        ...makeConfig().passwordReset,
        captchaHandling: {
          enabled: true,
          consentSelectors: ["button:has-text('Alle akzeptieren')", '#onetrust-accept-btn-handler']
        }
      }
    });
    const result = await _dismissConsentOverlay(page, config, logger);
    expect(result).toBe(true);
    expect(logger.info).toHaveBeenCalledWith('[UNLOCK]', expect.stringContaining('Consent overlay dismissed'));
  });

  it('should not throw when click fails', async () => {
    const page = makePage({
      isVisible: jest.fn().mockResolvedValue(true),
      click: jest.fn().mockRejectedValue(new Error('click failed'))
    });
    const logger = makeLogger();
    const config = makeConfig({ passwordReset: { ...makeConfig().passwordReset, captchaHandling: { enabled: true } } });
    await expect(_dismissConsentOverlay(page, config, logger)).resolves.toBe(false);
  });
});

describe('_detectAndHandleCaptcha', () => {
  it('should return detected:false when no CAPTCHA selectors are visible', async () => {
    const page = makePage({ isVisible: jest.fn().mockResolvedValue(false) });
    const logger = makeLogger();
    const config = makeConfig({ passwordReset: { ...makeConfig().passwordReset, captchaHandling: { enabled: true } } });
    const result = await _detectAndHandleCaptcha(page, config, logger);
    expect(result.detected).toBe(false);
  });

  it('should return detected:false when captchaHandling.enabled is false', async () => {
    const page = makePage({ isVisible: jest.fn().mockResolvedValue(true) });
    const logger = makeLogger();
    const config = makeConfig({ passwordReset: { ...makeConfig().passwordReset, captchaHandling: { enabled: false } } });
    const result = await _detectAndHandleCaptcha(page, config, logger);
    expect(result.detected).toBe(false);
    expect(page.isVisible).not.toHaveBeenCalled();
  });

  it('should detect reCAPTCHA when g-recaptcha selector is visible', async () => {
    const page = makePage({
      isVisible: jest.fn().mockImplementation(sel => {
        return Promise.resolve(sel === '.g-recaptcha');
      })
    });
    const logger = makeLogger();
    const config = makeConfig({
      passwordReset: {
        ...makeConfig().passwordReset,
        captchaHandling: {
          enabled: true,
          captchaSelectors: ["iframe[src*='captcha-delivery.com']", '.g-recaptcha']
        }
      }
    });
    const result = await _detectAndHandleCaptcha(page, config, logger);
    expect(result.detected).toBe(true);
    expect(result.type).toBe('recaptcha');
    expect(result.selector).toBe('.g-recaptcha');
    expect(logger.warn).toHaveBeenCalledWith('[UNLOCK]', expect.stringContaining('CAPTCHA detected'));
  });

  it('should detect DataDome CAPTCHA', async () => {
    const page = makePage({
      isVisible: jest.fn().mockImplementation(sel => {
        return Promise.resolve(sel === "iframe[src*='captcha-delivery.com']");
      })
    });
    const logger = makeLogger();
    const config = makeConfig({
      passwordReset: {
        ...makeConfig().passwordReset,
        captchaHandling: { enabled: true }
      }
    });
    const result = await _detectAndHandleCaptcha(page, config, logger);
    expect(result.detected).toBe(true);
    expect(result.type).toBe('datadome');
  });

  it('should return detected:false when isVisible throws', async () => {
    const page = makePage({ isVisible: jest.fn().mockRejectedValue(new Error('frame closed')) });
    const logger = makeLogger();
    const config = makeConfig({ passwordReset: { ...makeConfig().passwordReset, captchaHandling: { enabled: true } } });
    const result = await _detectAndHandleCaptcha(page, config, logger);
    expect(result.detected).toBe(false);
  });
});

describe('_handleCaptchaStrategy', () => {
  const captchaResult = { detected: true, type: 'recaptcha', selector: '.g-recaptcha' };

  it('skip strategy should return continueFlow:false with captcha_detected details', async () => {
    const page = makePage();
    const logger = makeLogger();
    const config = makeConfig({
      passwordReset: {
        ...makeConfig().passwordReset,
        captchaHandling: { enabled: true, strategy: 'skip', screenshotOnCaptcha: false }
      }
    });
    const result = await _handleCaptchaStrategy(page, 'user@example.com', config, logger, captchaResult);
    expect(result.continueFlow).toBe(false);
    expect(result.details).toContain('captcha_detected');
    expect(logger.warn).toHaveBeenCalledWith('[UNLOCK]', expect.stringContaining('Skipping'));
  });

  it('screenshot strategy should take screenshot and return continueFlow:false', async () => {
    const screenshotMock = jest.fn().mockResolvedValue(undefined);
    const page = makePage({ screenshot: screenshotMock });
    const logger = makeLogger();
    const config = makeConfig({
      passwordReset: {
        ...makeConfig().passwordReset,
        captchaHandling: {
          enabled: true,
          strategy: 'screenshot',
          screenshotDir: '/tmp/test_captcha_screenshots'
        }
      }
    });
    const result = await _handleCaptchaStrategy(page, 'user@example.com', config, logger, captchaResult);
    expect(result.continueFlow).toBe(false);
    expect(result.details).toContain('captcha_detected');
    expect(screenshotMock).toHaveBeenCalled();
  });

  it('pause strategy should return continueFlow:true when CAPTCHA disappears after pause', async () => {
    const page = makePage({
      isVisible: jest.fn().mockResolvedValue(false) // CAPTCHA gone after pause
    });
    const logger = makeLogger();
    const config = makeConfig({
      passwordReset: {
        ...makeConfig().passwordReset,
        captchaHandling: { enabled: true, strategy: 'pause', pauseTimeout: 10 }
      }
    });
    const result = await _handleCaptchaStrategy(page, 'user@example.com', config, logger, captchaResult);
    expect(result.continueFlow).toBe(true);
    expect(result.details).toContain('resolved');
  });

  it('pause strategy should return continueFlow:false when CAPTCHA still present after pause', async () => {
    const page = makePage({
      isVisible: jest.fn().mockResolvedValue(true) // CAPTCHA still visible
    });
    const logger = makeLogger();
    const config = makeConfig({
      passwordReset: {
        ...makeConfig().passwordReset,
        captchaHandling: { enabled: true, strategy: 'pause', pauseTimeout: 10 }
      }
    });
    const result = await _handleCaptchaStrategy(page, 'user@example.com', config, logger, captchaResult);
    expect(result.continueFlow).toBe(false);
    expect(result.details).toContain('captcha_not_resolved');
  });

  it('solve strategy without solverService/apiKey returns continueFlow:false', async () => {
    const page = makePage();
    const logger = makeLogger();
    const config = makeConfig({
      passwordReset: {
        ...makeConfig().passwordReset,
        captchaHandling: { enabled: true, strategy: 'solve', solverService: null, solverApiKey: '' }
      }
    });
    const result = await _handleCaptchaStrategy(page, 'user@example.com', config, logger, captchaResult);
    expect(result.continueFlow).toBe(false);
    expect(result.details).toContain('captcha_solve_failed');
  });
});

describe('unlockAccountViaPasswordReset with CAPTCHA handling enabled', () => {
  it('should detect CAPTCHA and return failed when strategy is skip', async () => {
    const page = makePage({
      isVisible: jest.fn().mockImplementation(sel => {
        // forgotPasswordLink and email field are visible
        if (sel === "a[href*='forgot']" || sel === '#email') return Promise.resolve(true);
        // CAPTCHA selector visible
        if (sel === '.g-recaptcha') return Promise.resolve(true);
        return Promise.resolve(false);
      }),
      evaluate: jest.fn().mockResolvedValue('')
    });
    const logger = makeLogger();
    const config = makeConfig({
      passwordReset: {
        ...makeConfig().passwordReset,
        captchaHandling: {
          enabled: true,
          strategy: 'skip',
          screenshotOnCaptcha: false,
          captchaSelectors: ['.g-recaptcha'],
          consentSelectors: []
        }
      }
    });
    fastFill.mockResolvedValue(true);

    const result = await unlockAccountViaPasswordReset(page, 'user@example.com', config, logger);

    expect(result.success).toBe(false);
    expect(result.method).toBe('email_filled');
    expect(result.details).toContain('captcha_detected');

    const written = fs.readFileSync('/tmp/test_unlock_requested.txt', 'utf8');
    expect(written).toContain('failed:captcha_detected');
  });

  it('should continue flow when no CAPTCHA detected', async () => {
    const page = makePage({
      isVisible: jest.fn().mockImplementation(sel => {
        return Promise.resolve(
          sel === "a[href*='forgot']" ||
          sel === '#email' ||
          sel === "button[type='submit']"
        );
      }),
      evaluate: jest.fn().mockResolvedValue('E-Mail wurde gesendet')
    });
    const logger = makeLogger();
    const config = makeConfig({
      passwordReset: {
        ...makeConfig().passwordReset,
        captchaHandling: {
          enabled: true,
          strategy: 'skip',
          screenshotOnCaptcha: false,
          captchaSelectors: ['.g-recaptcha'],
          consentSelectors: []
        }
      }
    });
    fastFill.mockResolvedValue(true);

    const result = await unlockAccountViaPasswordReset(page, 'user@example.com', config, logger);

    expect(result.success).toBe(true);
    expect(result.details).toBe('reset_email_sent');
  });

  it('should skip CAPTCHA detection when captchaHandling.enabled is omitted', async () => {
    // No captchaHandling in config — existing tests not impacted
    const page = makePage({
      isVisible: jest.fn()
        .mockResolvedValueOnce(true)  // forgotPasswordLink
        .mockResolvedValueOnce(true)  // email
        .mockResolvedValueOnce(true), // submit
      evaluate: jest.fn().mockResolvedValue('E-Mail wurde gesendet')
    });
    const logger = makeLogger();
    const config = makeConfig(); // no captchaHandling block
    fastFill.mockResolvedValue(true);

    const result = await unlockAccountViaPasswordReset(page, 'user@example.com', config, logger);

    expect(result.success).toBe(true);
  });
});

// ─── HTTP request helper ──────────────────────────────────────────────────────

/**
 * Create a mock http/https .request() implementation that resolves with a
 * given response body on `req.end()`, or emits an error if `errorMsg` is set.
 */
function makeHttpRequestMock(responseBody, { errorMsg = null, reqTimeout = false } = {}) {
  return jest.fn((options, callback) => {
    const mockReq = new EventEmitter();
    mockReq.write = jest.fn();
    mockReq.destroy = jest.fn((err) => {
      // surface destroy as an error so the promise rejects
      if (!reqTimeout) mockReq.emit('error', err || new Error('destroyed'));
    });
    mockReq.end = jest.fn(() => {
      if (reqTimeout) return; // never respond — timeout fires
      if (errorMsg) {
        process.nextTick(() => mockReq.emit('error', new Error(errorMsg)));
        return;
      }
      process.nextTick(() => {
        const mockRes = new EventEmitter();
        mockRes.destroy = jest.fn();
        callback(mockRes);
        process.nextTick(() => {
          mockRes.emit('data', responseBody);
          mockRes.emit('end');
        });
      });
    });
    return mockReq;
  });
}

// ─── _httpRequest ─────────────────────────────────────────────────────────────

describe('_httpRequest', () => {
  afterEach(() => jest.useRealTimers());

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should resolve with response body on success (GET)', async () => {
    https.request.mockImplementation(makeHttpRequestMock('{"status":1}'));
    const result = await _httpRequest('https://example.com/api', null, 5000);
    expect(result).toBe('{"status":1}');
    expect(https.request).toHaveBeenCalled();
  });

  it('should resolve with response body on success (POST)', async () => {
    https.request.mockImplementation(makeHttpRequestMock('{"taskId":123}'));
    const result = await _httpRequest('https://example.com/api', { key: 'val' }, 5000);
    expect(result).toBe('{"taskId":123}');
    const callArgs = https.request.mock.calls[0][0];
    expect(callArgs.method).toBe('POST');
  });

  it('should reject with timeout error and call req.destroy()', async () => {
    jest.useFakeTimers();
    https.request.mockImplementation(makeHttpRequestMock(null, { reqTimeout: true }));

    // Attach .catch immediately to prevent unhandled rejection before our assertion
    const rejection = _httpRequest('https://example.com/api', null, 1000).catch(e => e);
    jest.advanceTimersByTime(1001);

    const error = await rejection;
    expect(error).toBeInstanceOf(Error);
    expect(error.message).toContain('HTTP request timed out');

    const mockReq = https.request.mock.results[0].value;
    expect(mockReq.destroy).toHaveBeenCalled();
  });

  it('should reject when request emits an error', async () => {
    https.request.mockImplementation(makeHttpRequestMock(null, { errorMsg: 'ECONNREFUSED' }));
    await expect(_httpRequest('https://example.com/api', null, 5000)).rejects.toThrow('ECONNREFUSED');
  });
});

// ─── _attemptCaptchaSolve ─────────────────────────────────────────────────────

describe('_attemptCaptchaSolve', () => {
  function makeSolvePage(overrides = {}) {
    return {
      url: jest.fn().mockReturnValue('https://example.com/login'),
      evaluate: jest.fn().mockResolvedValue('test-site-key'),
      $: jest.fn().mockResolvedValue(null),
      ...overrides
    };
  }

  function makeSolverConfig(solverService, captchaType = 'recaptcha') {
    return {
      login: {},
      passwordReset: {
        captchaHandling: {
          enabled: true,
          strategy: 'solve',
          solverService,
          solverApiKey: solverService === 'deathbycaptcha' ? 'user:pass' : 'test-api-key',
          maxSolveAttempts: 1,
          solveTimeout: 30000
        }
      }
    };
  }

  // Use fake timers for all solver tests so that _sleep() calls inside solvers
  // do not cause tests to hang. process.nextTick is NOT faked so HTTP mock
  // responses delivered via process.nextTick still arrive automatically.
  beforeEach(() => {
    jest.clearAllMocks();
    jest.useFakeTimers({ doNotFake: ['nextTick'] });
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  describe('2Captcha solver', () => {
    it('should use method=userrecaptcha and googlekey for reCAPTCHA', async () => {
      https.request
        .mockImplementationOnce(makeHttpRequestMock(JSON.stringify({ status: 1, request: 'cap123' })))
        .mockImplementationOnce(makeHttpRequestMock(JSON.stringify({ status: 1, request: 'solved-token' })));

      const page = makeSolvePage();
      const logger = makeLogger();
      const captchaResult = { detected: true, type: 'recaptcha', selector: '.g-recaptcha' };

      const promise = _attemptCaptchaSolve(page, makeSolverConfig('2captcha'), logger, captchaResult);
      await jest.runAllTimersAsync();
      const result = await promise;

      expect(result).toBe(true);
      const submitOptions = https.request.mock.calls[0][0];
      expect(submitOptions.path).toContain('method=userrecaptcha');
      expect(submitOptions.path).toContain('googlekey=');
    });

    it('should use method=hcaptcha and sitekey for hCaptcha', async () => {
      https.request
        .mockImplementationOnce(makeHttpRequestMock(JSON.stringify({ status: 1, request: 'cap456' })))
        .mockImplementationOnce(makeHttpRequestMock(JSON.stringify({ status: 1, request: 'hcap-token' })));

      const page = makeSolvePage();
      const logger = makeLogger();
      const captchaResult = { detected: true, type: 'hcaptcha', selector: '.h-captcha' };

      const promise = _attemptCaptchaSolve(page, makeSolverConfig('2captcha', 'hcaptcha'), logger, captchaResult);
      await jest.runAllTimersAsync();
      const result = await promise;

      expect(result).toBe(true);
      const submitOptions = https.request.mock.calls[0][0];
      expect(submitOptions.path).toContain('method=hcaptcha');
      expect(submitOptions.path).toContain('sitekey=');
    });

    it('should return false when 2Captcha returns error status', async () => {
      https.request.mockImplementationOnce(
        makeHttpRequestMock(JSON.stringify({ status: 0, request: 'ERROR_WRONG_USER_KEY' }))
      );

      const page = makeSolvePage();
      const logger = makeLogger();
      const captchaResult = { detected: true, type: 'recaptcha', selector: '.g-recaptcha' };

      const promise = _attemptCaptchaSolve(page, makeSolverConfig('2captcha'), logger, captchaResult);
      await jest.runAllTimersAsync();
      const result = await promise;

      expect(result).toBe(false);
      expect(logger.warn).toHaveBeenCalledWith('[UNLOCK]', expect.stringContaining('2Captcha submit error'));
    });

    it('should return false when 2Captcha poll returns a fatal error (not CAPCHA_NOT_READY)', async () => {
      https.request
        .mockImplementationOnce(makeHttpRequestMock(JSON.stringify({ status: 1, request: 'cap789' })))
        .mockImplementationOnce(makeHttpRequestMock(JSON.stringify({ status: 0, request: 'ERROR_CAPTCHA_UNSOLVABLE' })));

      const page = makeSolvePage();
      const logger = makeLogger();
      const captchaResult = { detected: true, type: 'recaptcha', selector: '.g-recaptcha' };

      const promise = _attemptCaptchaSolve(page, makeSolverConfig('2captcha'), logger, captchaResult);
      await jest.runAllTimersAsync();
      const result = await promise;

      expect(result).toBe(false);
      expect(logger.warn).toHaveBeenCalledWith('[UNLOCK]', expect.stringContaining('2Captcha poll error'));
    });

    it('should return false when HTTPS request throws', async () => {
      https.request.mockImplementationOnce(makeHttpRequestMock(null, { errorMsg: 'ECONNREFUSED' }));

      const page = makeSolvePage();
      const logger = makeLogger();
      const captchaResult = { detected: true, type: 'recaptcha', selector: '.g-recaptcha' };

      const promise = _attemptCaptchaSolve(page, makeSolverConfig('2captcha'), logger, captchaResult);
      await jest.runAllTimersAsync();
      const result = await promise;

      expect(result).toBe(false);
    });
  });

  describe('AntiCaptcha solver', () => {
    it('should use NoCaptchaTaskProxyless for reCAPTCHA', async () => {
      https.request
        .mockImplementationOnce(makeHttpRequestMock(JSON.stringify({ errorId: 0, taskId: 999 })))
        .mockImplementationOnce(makeHttpRequestMock(JSON.stringify({ errorId: 0, status: 'ready', solution: { gRecaptchaResponse: 'ac-token' } })));

      const page = makeSolvePage();
      const logger = makeLogger();
      const captchaResult = { detected: true, type: 'recaptcha', selector: '.g-recaptcha' };

      const promise = _attemptCaptchaSolve(page, makeSolverConfig('anticaptcha'), logger, captchaResult);
      await jest.runAllTimersAsync();
      const result = await promise;

      expect(result).toBe(true);
      // POST body is written via req.write — first https.request's mock req
      const createReqMock = https.request.mock.results[0].value;
      const createBody = JSON.parse(createReqMock.write.mock.calls[0][0]);
      expect(createBody.task.type).toBe('NoCaptchaTaskProxyless');
    });

    it('should use HCaptchaTaskProxyless for hCaptcha', async () => {
      https.request
        .mockImplementationOnce(makeHttpRequestMock(JSON.stringify({ errorId: 0, taskId: 888 })))
        .mockImplementationOnce(makeHttpRequestMock(JSON.stringify({ errorId: 0, status: 'ready', solution: { gRecaptchaResponse: 'hac-token' } })));

      const page = makeSolvePage();
      const logger = makeLogger();
      const captchaResult = { detected: true, type: 'hcaptcha', selector: '.h-captcha' };

      const promise = _attemptCaptchaSolve(page, makeSolverConfig('anticaptcha', 'hcaptcha'), logger, captchaResult);
      await jest.runAllTimersAsync();
      const result = await promise;

      expect(result).toBe(true);
      const createReqMock = https.request.mock.results[0].value;
      const createBody = JSON.parse(createReqMock.write.mock.calls[0][0]);
      expect(createBody.task.type).toBe('HCaptchaTaskProxyless');
    });

    it('should return false when AntiCaptcha create task returns errorId != 0', async () => {
      https.request.mockImplementationOnce(
        makeHttpRequestMock(JSON.stringify({ errorId: 1, errorDescription: 'ERROR_KEY_DOES_NOT_EXIST' }))
      );

      const page = makeSolvePage();
      const logger = makeLogger();
      const captchaResult = { detected: true, type: 'recaptcha', selector: '.g-recaptcha' };

      const promise = _attemptCaptchaSolve(page, makeSolverConfig('anticaptcha'), logger, captchaResult);
      await jest.runAllTimersAsync();
      const result = await promise;

      expect(result).toBe(false);
      expect(logger.warn).toHaveBeenCalledWith('[UNLOCK]', expect.stringContaining('AntiCaptcha create error'));
    });
  });

  describe('DeathByCaptcha solver', () => {
    it('should use type=4 for reCAPTCHA and googlekey param', async () => {
      http.request
        .mockImplementationOnce(makeHttpRequestMock('status=1&captcha=dbc123&text='))
        .mockImplementationOnce(makeHttpRequestMock('status=1&captcha=dbc123&text=solved-dbc-token'));

      const page = makeSolvePage();
      const logger = makeLogger();
      const captchaResult = { detected: true, type: 'recaptcha', selector: '.g-recaptcha' };

      const promise = _attemptCaptchaSolve(page, makeSolverConfig('deathbycaptcha'), logger, captchaResult);
      await jest.runAllTimersAsync();
      const result = await promise;

      expect(result).toBe(true);
      const submitReqMock = http.request.mock.results[0].value;
      const writtenBody = submitReqMock.write.mock.calls[0][0];
      expect(writtenBody).toContain('type=4');
      expect(writtenBody).toContain('googlekey');
    });

    it('should use type=7 for hCaptcha and sitekey param', async () => {
      http.request
        .mockImplementationOnce(makeHttpRequestMock('status=1&captcha=dbc456&text='))
        .mockImplementationOnce(makeHttpRequestMock('status=1&captcha=dbc456&text=solved-hcap-token'));

      const page = makeSolvePage();
      const logger = makeLogger();
      const captchaResult = { detected: true, type: 'hcaptcha', selector: '.h-captcha' };

      const promise = _attemptCaptchaSolve(page, makeSolverConfig('deathbycaptcha', 'hcaptcha'), logger, captchaResult);
      await jest.runAllTimersAsync();
      const result = await promise;

      expect(result).toBe(true);
      const submitReqMock = http.request.mock.results[0].value;
      const writtenBody = submitReqMock.write.mock.calls[0][0];
      expect(writtenBody).toContain('type=7');
      expect(writtenBody).toContain('sitekey');
    });

    it('should return false when DBC credentials are malformed', async () => {
      const page = makeSolvePage();
      const logger = makeLogger();
      const captchaResult = { detected: true, type: 'recaptcha', selector: '.g-recaptcha' };
      const config = {
        login: {},
        passwordReset: {
          captchaHandling: {
            enabled: true, strategy: 'solve',
            solverService: 'deathbycaptcha',
            solverApiKey: 'no-colon-here',
            maxSolveAttempts: 1, solveTimeout: 5000
          }
        }
      };

      const promise = _attemptCaptchaSolve(page, config, logger, captchaResult);
      await jest.runAllTimersAsync();
      const result = await promise;

      expect(result).toBe(false);
      expect(logger.warn).toHaveBeenCalledWith('[UNLOCK]', expect.stringContaining('username:password'));
    });

    it('should return false when DBC submit request times out', async () => {
      http.request.mockImplementationOnce(makeHttpRequestMock(null, { reqTimeout: true }));

      const page = makeSolvePage();
      const logger = makeLogger();
      const captchaResult = { detected: true, type: 'recaptcha', selector: '.g-recaptcha' };

      const promise = _attemptCaptchaSolve(page, makeSolverConfig('deathbycaptcha'), logger, captchaResult);
      await jest.advanceTimersByTimeAsync(20000); // past 15s DBC submit timeout
      const result = await promise;

      expect(result).toBe(false);
      expect(logger.warn).toHaveBeenCalledWith('[UNLOCK]', expect.stringContaining('DeathByCaptcha submit failed'));
    });
  });

  describe('unknown solver', () => {
    it('should return false for an unrecognised solverService', async () => {
      const page = makeSolvePage();
      const logger = makeLogger();
      const captchaResult = { detected: true, type: 'recaptcha', selector: '.g-recaptcha' };
      const config = {
        login: {},
        passwordReset: {
          captchaHandling: {
            enabled: true, strategy: 'solve',
            solverService: 'unknownservice',
            solverApiKey: 'key',
            maxSolveAttempts: 1, solveTimeout: 5000
          }
        }
      };

      const promise = _attemptCaptchaSolve(page, config, logger, captchaResult);
      await jest.runAllTimersAsync();
      const result = await promise;

      expect(result).toBe(false);
      expect(logger.warn).toHaveBeenCalledWith('[UNLOCK]', expect.stringContaining('Unknown solver service'));
    });
  });
});
