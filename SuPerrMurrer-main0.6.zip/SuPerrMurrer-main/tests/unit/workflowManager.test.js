'use strict';

jest.mock('fs');
jest.mock('../../utils/projectTracker', () => ({
  updateApproval: jest.fn(),
  assignResource: jest.fn(),
  updateSetupItem: jest.fn(),
  readProjectStatus: jest.fn().mockReturnValue(`
**Phase**: Pre-Phase 1 - Planning & Preparation

| **Project Owner** | ✅ Approved |
| **Technical Lead** | 🔄 In Review |
| **UX Lead** | ⏳ Pending |

| **Lead Developer** | Alex Chen |
| **UX Developer** | TBD |

- [x] Node.js Environment
- [ ] Repository Setup
  `)
}), { virtual: false });

const fs = require('fs');
const projectTracker = require('../../utils/projectTracker');

describe('workflowManager', () => {
  let workflow;

  beforeEach(() => {
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
    jest.spyOn(process, 'exit').mockImplementation(() => {});

    fs.existsSync = jest.fn().mockReturnValue(true);
    fs.mkdirSync = jest.fn();
    fs.writeFileSync = jest.fn();
    fs.readFileSync = jest.fn().mockReturnValue('# Status\n**Phase**: Testing\n');

    jest.clearAllMocks();
    jest.resetModules();
    jest.mock('../../utils/projectTracker', () => ({
      updateApproval: jest.fn(),
      assignResource: jest.fn(),
      updateSetupItem: jest.fn(),
      readProjectStatus: jest.fn().mockReturnValue(`
**Phase**: Pre-Phase 1 - Planning & Preparation
| **Project Owner** | ✅ Approved |
| **Technical Lead** | 🔄 In Review |
| **UX Lead** | ⏳ Pending |
| **Lead Developer** | Alex Chen |
| **UX Developer** | TBD |
- [x] Node.js Environment
- [ ] Repository Setup
      `)
    }), { virtual: false });

    workflow = require('../../utils/workflowManager');
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('initiateReview', () => {
    it('should call updateApproval for each stakeholder', () => {
      const pt = require('../../utils/projectTracker');
      workflow.initiateReview();
      expect(pt.updateApproval).toHaveBeenCalled();
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Initiating'));
    });

    it('should handle errors from updateApproval gracefully', () => {
      const pt = require('../../utils/projectTracker');
      pt.updateApproval.mockImplementationOnce(() => { throw new Error('update failed'); });
      expect(() => workflow.initiateReview()).not.toThrow();
      expect(console.error).toHaveBeenCalled();
    });
  });

  describe('approveAll', () => {
    it('should call updateApproval for each stakeholder', () => {
      const pt = require('../../utils/projectTracker');
      workflow.approveAll();
      expect(pt.updateApproval).toHaveBeenCalled();
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Approving'));
    });

    it('should handle errors from updateApproval gracefully', () => {
      const pt = require('../../utils/projectTracker');
      pt.updateApproval.mockImplementationOnce(() => { throw new Error('approval failed'); });
      expect(() => workflow.approveAll()).not.toThrow();
    });
  });

  describe('setupPhase1', () => {
    it('should assign team members and update setup items', () => {
      const pt = require('../../utils/projectTracker');
      workflow.setupPhase1();
      expect(pt.assignResource).toHaveBeenCalled();
      expect(pt.updateSetupItem).toHaveBeenCalled();
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Setting Up Phase 1'));
    });

    it('should handle errors from assignResource gracefully', () => {
      const pt = require('../../utils/projectTracker');
      pt.assignResource.mockImplementationOnce(() => { throw new Error('assign failed'); });
      expect(() => workflow.setupPhase1()).not.toThrow();
    });
  });

  describe('startSprint', () => {
    it('should log sprint info when args provided', () => {
      workflow.startSprint('1', '2026-02-03', '2026-02-14');
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Sprint #1'));
    });

    it('should call process.exit when args missing', () => {
      workflow.startSprint(null, null, null);
      expect(process.exit).toHaveBeenCalledWith(1);
    });
  });

  describe('completeSprint', () => {
    it('should log completion info', () => {
      workflow.completeSprint('1', 'Menu;Navigation');
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Completing Sprint #1'));
    });

    it('should log accomplishments', () => {
      workflow.completeSprint('2', 'Feature A;Feature B');
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Accomplishments'));
    });

    it('should work without accomplishments', () => {
      workflow.completeSprint('1', null);
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Completing Sprint #1'));
    });

    it('should call process.exit when sprintNumber missing', () => {
      workflow.completeSprint(null, null);
      expect(process.exit).toHaveBeenCalledWith(1);
    });
  });

  describe('weeklyUpdate', () => {
    it('should generate and display a report', () => {
      const mockFs = require('fs');
      mockFs.existsSync.mockReturnValue(false);
      workflow.weeklyUpdate();
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('WEEKLY PROJECT STATUS REPORT'));
    });

    it('should create reports dir if it does not exist', () => {
      const mockFs = require('fs');
      mockFs.existsSync.mockReturnValue(false);
      workflow.weeklyUpdate();
      expect(mockFs.mkdirSync).toHaveBeenCalled();
    });

    it('should handle readProjectStatus failure', () => {
      const pt = require('../../utils/projectTracker');
      pt.readProjectStatus.mockImplementationOnce(() => { throw new Error('file not found'); });
      workflow.weeklyUpdate();
      expect(console.error).toHaveBeenCalledWith('❌ Error generating report:', 'file not found');
      expect(process.exit).toHaveBeenCalledWith(1);
    });
  });

  describe('module exports', () => {
    it('should export all workflow functions', () => {
      expect(typeof workflow.initiateReview).toBe('function');
      expect(typeof workflow.approveAll).toBe('function');
      expect(typeof workflow.setupPhase1).toBe('function');
      expect(typeof workflow.startSprint).toBe('function');
      expect(typeof workflow.completeSprint).toBe('function');
      expect(typeof workflow.weeklyUpdate).toBe('function');
    });
  });
});
