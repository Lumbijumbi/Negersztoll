/**
 * Unit Tests for CredentialHistory Module
 * Tests persistent history management with JSONL storage, deduplication, and skip logic
 */

const CredentialHistory = require('../../utils/credentialHistory');
const fs = require('fs');
const path = require('path');

// Mock fs module
jest.mock('fs');

describe('CredentialHistory', () => {
  let history;
  const testHistoryFile = '/test/combo_history.jsonl';

  beforeEach(() => {
    jest.clearAllMocks();
    
    // Mock fs.existsSync to return false by default (no existing history file)
    fs.existsSync.mockReturnValue(false);
    
    // Mock fs.readFileSync
    fs.readFileSync.mockReturnValue('');
    
    // Mock fs.appendFileSync
    fs.appendFileSync.mockImplementation(() => {});

    // Mock fs.createWriteStream with a writable mock stream
    const mockStream = {
      write: jest.fn(),
      end: jest.fn((cb) => { if (cb) cb(); }),
      destroy: jest.fn(),
      destroyed: false,
      on: jest.fn().mockReturnThis()
    };
    fs.createWriteStream = jest.fn().mockReturnValue(mockStream);
    
    // Mock fs.writeFileSync
    fs.writeFileSync.mockImplementation(() => {});
    
    // Mock fs.renameSync
    fs.renameSync.mockImplementation(() => {});
    
    // Mock fs.statSync
    fs.statSync.mockReturnValue({ size: 1024 });
    
    // Spy on console methods
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'warn').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    console.log.mockRestore();
    console.warn.mockRestore();
    console.error.mockRestore();
  });

  describe('Constructor & Initialization', () => {
    it('should initialize with default options', () => {
      history = new CredentialHistory({ historyFile: testHistoryFile });
      
      expect(history.enabled).toBe(true);
      expect(history.historyFile).toBe(testHistoryFile);
      expect(history.skipSuccessful).toBe(true);
      expect(history.skipFailed).toBe(true);
      expect(history.skipBlocked).toBe(true);
      expect(history.failedRetestAfterDays).toBe(0);
      expect(history.blockedRetestAfterDays).toBe(0);
      expect(history.history).toBeInstanceOf(Map);
      expect(history.history.size).toBe(0);
    });

    it('should initialize with custom options', () => {
      history = new CredentialHistory({
        historyFile: testHistoryFile,
        enabled: false,
        skipSuccessful: false,
        skipFailed: false,
        skipBlocked: false,
        failedRetestAfterDays: 7,
        blockedRetestAfterDays: 14
      });
      
      expect(history.enabled).toBe(false);
      expect(history.skipSuccessful).toBe(false);
      expect(history.skipFailed).toBe(false);
      expect(history.skipBlocked).toBe(false);
      expect(history.failedRetestAfterDays).toBe(7);
      expect(history.blockedRetestAfterDays).toBe(14);
    });

    it('should convert relative paths to absolute', () => {
      history = new CredentialHistory({ historyFile: 'relative_history.jsonl' });
      
      expect(path.isAbsolute(history.historyFile)).toBe(true);
      expect(history.historyFile).toContain('relative_history.jsonl');
    });

    it('should use default filename if not specified', () => {
      history = new CredentialHistory();
      
      expect(history.historyFile).toContain('combo_history.jsonl');
    });
  });

  describe('Key Generation (_key)', () => {
    beforeEach(() => {
      history = new CredentialHistory({ historyFile: testHistoryFile });
    });

    it('should generate tab-separated key', () => {
      const key = history._key('user1', 'pass1');
      
      expect(key).toBe('user1\tpass1');
    });

    it('should be case-sensitive', () => {
      const key1 = history._key('User1', 'Pass1');
      const key2 = history._key('user1', 'pass1');
      
      expect(key1).toBe('User1\tPass1');
      expect(key2).toBe('user1\tpass1');
      expect(key1).not.toBe(key2);
    });

    it('should handle special characters', () => {
      const key = history._key('user@email.com', 'p@ss:w0rd!');
      
      expect(key).toContain('user@email.com');
      expect(key).toContain('p@ss:w0rd!');
    });
  });

  describe('Loading History (load)', () => {
    beforeEach(() => {
      history = new CredentialHistory({ historyFile: testHistoryFile });
    });

    it('should handle missing history file gracefully', () => {
      fs.existsSync.mockReturnValue(false);
      
      expect(() => history.load()).not.toThrow();
      
      expect(history.history.size).toBe(0);
      expect(console.log).toHaveBeenCalledWith(
        expect.stringContaining('No existing history file')
      );
    });

    it('should load valid JSONL entries', () => {
      const mockContent = 
        '{"u":"user1","p":"pass1","s":"success","t":"2024-01-01T00:00:00.000Z"}\n' +
        '{"u":"user2","p":"pass2","s":"failed","t":"2024-01-02T00:00:00.000Z"}\n' +
        '{"u":"user3","p":"pass3","s":"blocked","t":"2024-01-03T00:00:00.000Z"}\n';
      
      fs.existsSync.mockReturnValue(true);
      fs.readFileSync.mockReturnValue(mockContent);
      
      history.load();
      
      expect(history.history.size).toBe(3);
      expect(history.history.has('user1\tpass1')).toBe(true);
      expect(history.history.has('user2\tpass2')).toBe(true);
      expect(history.history.has('user3\tpass3')).toBe(true);
    });

    it('should deduplicate entries on load (latest wins)', () => {
      const mockContent = 
        '{"u":"user1","p":"pass1","s":"failed","t":"2024-01-01T00:00:00.000Z"}\n' +
        '{"u":"user1","p":"pass1","s":"success","t":"2024-01-02T00:00:00.000Z"}\n';
      
      fs.existsSync.mockReturnValue(true);
      fs.readFileSync.mockReturnValue(mockContent);
      
      history.load();
      
      expect(history.history.size).toBe(1);
      const entry = history.history.get('user1\tpass1');
      expect(entry.s).toBe('success');
      expect(entry.t).toBe('2024-01-02T00:00:00.000Z');
    });

    it('should skip entries without username or password', () => {
      const mockContent = 
        '{"u":"user1","s":"success","t":"2024-01-01T00:00:00.000Z"}\n' +
        '{"p":"pass2","s":"failed","t":"2024-01-02T00:00:00.000Z"}\n' +
        '{"u":"user3","p":"pass3","s":"success","t":"2024-01-03T00:00:00.000Z"}\n';
      
      fs.existsSync.mockReturnValue(true);
      fs.readFileSync.mockReturnValue(mockContent);
      
      history.load();
      
      expect(history.history.size).toBe(1);
      expect(history.history.has('user3\tpass3')).toBe(true);
    });

    it('should handle corrupted JSON lines gracefully', () => {
      const mockContent = 
        '{"u":"user1","p":"pass1","s":"success","t":"2024-01-01T00:00:00.000Z"}\n' +
        '{invalid json}\n' +
        '{"u":"user2","p":"pass2","s":"failed","t":"2024-01-02T00:00:00.000Z"}\n';
      
      fs.existsSync.mockReturnValue(true);
      fs.readFileSync.mockReturnValue(mockContent);
      
      history.load();
      
      expect(history.history.size).toBe(2);
      expect(console.warn).toHaveBeenCalledWith(
        expect.stringContaining('Failed to parse line'),
        expect.any(String)
      );
    });

    it('should skip empty lines', () => {
      const mockContent = 
        '{"u":"user1","p":"pass1","s":"success","t":"2024-01-01T00:00:00.000Z"}\n' +
        '\n' +
        '   \n' +
        '{"u":"user2","p":"pass2","s":"failed","t":"2024-01-02T00:00:00.000Z"}\n';
      
      fs.existsSync.mockReturnValue(true);
      fs.readFileSync.mockReturnValue(mockContent);
      
      history.load();
      
      expect(history.history.size).toBe(2);
    });

    it('should log statistics after loading', () => {
      const mockContent = 
        '{"u":"user1","p":"pass1","s":"success","t":"2024-01-01T00:00:00.000Z"}\n' +
        '{"u":"user2","p":"pass2","s":"failed","t":"2024-01-02T00:00:00.000Z"}\n' +
        '{"u":"user3","p":"pass3","s":"blocked","t":"2024-01-03T00:00:00.000Z"}\n' +
        '{"u":"user4","p":"pass4","s":"captcha","t":"2024-01-04T00:00:00.000Z"}\n';
      
      fs.existsSync.mockReturnValue(true);
      fs.readFileSync.mockReturnValue(mockContent);
      
      history.load();
      
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Loaded history'));
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Total entries: 4'));
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Successful: 1'));
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Failed: 1'));
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Blocked: 1'));
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Captcha: 1'));
    });

    it('should handle read errors gracefully', () => {
      fs.existsSync.mockReturnValue(true);
      fs.readFileSync.mockImplementation(() => {
        throw new Error('Read error');
      });
      
      expect(() => history.load()).not.toThrow();
      
      // With fileHelper, errors are logged with [FileHelper] prefix
      expect(console.warn).toHaveBeenCalledWith(
        expect.stringContaining('[FileHelper]')
      );
    });

    it('should do nothing when disabled', () => {
      history = new CredentialHistory({ 
        historyFile: testHistoryFile,
        enabled: false 
      });
      
      fs.existsSync.mockReturnValue(true);
      fs.readFileSync.mockReturnValue('{"u":"user1","p":"pass1","s":"success","t":"2024-01-01T00:00:00.000Z"}');
      
      history.load();
      
      expect(history.history.size).toBe(0);
      expect(fs.readFileSync).not.toHaveBeenCalled();
    });
  });

  describe('Recording Entries (record)', () => {
    beforeEach(() => {
      history = new CredentialHistory({ historyFile: testHistoryFile });
    });

    it('should record basic entry', () => {
      history.record('user1', 'pass1', 'success');
      
      expect(history.history.size).toBe(1);
      const entry = history.history.get('user1\tpass1');
      expect(entry.u).toBe('user1');
      expect(entry.p).toBe('pass1');
      expect(entry.s).toBe('success');
      expect(entry.t).toBeDefined();
    });

    it('should append entry to file', () => {
      history.record('user1', 'pass1', 'success');
      
      const stream = fs.createWriteStream.mock.results[0].value;
      expect(stream.write).toHaveBeenCalledWith(
        expect.stringContaining('"u":"user1"'),
        'utf8',
        expect.any(Function)
      );
      expect(stream.write).toHaveBeenCalledWith(
        expect.stringContaining('"p":"pass1"'),
        'utf8',
        expect.any(Function)
      );
      expect(stream.write).toHaveBeenCalledWith(
        expect.stringContaining('"s":"success"'),
        'utf8',
        expect.any(Function)
      );
    });

    it('should include optional details', () => {
      history.record('user1', 'pass1', 'success', {
        method: 'api',
        confidence: 0.95,
        reason: 'balance_check',
        pointsBalance: 100,
        moneyBalance: 50.5
      });
      
      const entry = history.history.get('user1\tpass1');
      expect(entry.m).toBe('api');
      expect(entry.c).toBe(0.95);
      expect(entry.r).toBe('balance_check');
      expect(entry.pts).toBe(100);
      expect(entry.chf).toBe(50.5);
    });

    it('should overwrite existing entry in memory', () => {
      history.record('user1', 'pass1', 'failed');
      history.record('user1', 'pass1', 'success');
      
      expect(history.history.size).toBe(1);
      const entry = history.history.get('user1\tpass1');
      expect(entry.s).toBe('success');
    });

    it('should handle file write errors gracefully', () => {
      const mockStream = {
        write: jest.fn(() => { throw new Error('Write error'); }),
        end: jest.fn(),
        destroy: jest.fn(),
        destroyed: false,
        on: jest.fn().mockReturnThis()
      };
      fs.createWriteStream.mockReturnValue(mockStream);
      // reset any cached stream
      history._writeStream = null;

      expect(() => history.record('user1', 'pass1', 'success')).not.toThrow();
      
      expect(console.error).toHaveBeenCalledWith(
        expect.stringContaining('Failed to append to file'),
        'Write error'
      );
    });

    it('should do nothing when disabled', () => {
      history = new CredentialHistory({ 
        historyFile: testHistoryFile,
        enabled: false 
      });
      
      history.record('user1', 'pass1', 'success');
      
      expect(history.history.size).toBe(0);
      expect(fs.createWriteStream).not.toHaveBeenCalled();
    });
  });

  describe('Recording Specific Statuses', () => {
    beforeEach(() => {
      history = new CredentialHistory({ historyFile: testHistoryFile });
    });

    it('should record success with details', () => {
      history.recordSuccess('user1', 'pass1', 'api', 0.95, 100, 50.5);
      
      const entry = history.history.get('user1\tpass1');
      expect(entry.s).toBe('success');
      expect(entry.m).toBe('api');
      expect(entry.c).toBe(0.95);
      expect(entry.pts).toBe(100);
      expect(entry.chf).toBe(50.5);
    });

    it('should record success without balances', () => {
      history.recordSuccess('user1', 'pass1', 'api', 0.95);
      
      const entry = history.history.get('user1\tpass1');
      expect(entry.s).toBe('success');
      expect(entry.pts).toBeUndefined();
      expect(entry.chf).toBeUndefined();
    });

    it('should record failed with reason', () => {
      history.recordFailed('user1', 'pass1', 'invalid_credentials');
      
      const entry = history.history.get('user1\tpass1');
      expect(entry.s).toBe('failed');
      expect(entry.r).toBe('invalid_credentials');
    });

    it('should record blocked with reason', () => {
      history.recordBlocked('user1', 'pass1', 'too_many_attempts');
      
      const entry = history.history.get('user1\tpass1');
      expect(entry.s).toBe('blocked');
      expect(entry.r).toBe('too_many_attempts');
    });

    it('should record captcha', () => {
      history.recordCaptcha('user1', 'pass1');
      
      const entry = history.history.get('user1\tpass1');
      expect(entry.s).toBe('captcha');
    });
  });

  describe('Skip Logic (shouldSkip)', () => {
    beforeEach(() => {
      history = new CredentialHistory({ historyFile: testHistoryFile });
    });

    it('should not skip new credentials', () => {
      const result = history.shouldSkip('user1', 'pass1');
      
      expect(result.skip).toBe(false);
      expect(result.reason).toBe('');
    });

    it('should skip successful credentials', () => {
      history.record('user1', 'pass1', 'success');
      
      const result = history.shouldSkip('user1', 'pass1');
      
      expect(result.skip).toBe(true);
      expect(result.reason).toBe('already_successful');
    });

    it('should not skip successful when skipSuccessful is false', () => {
      history = new CredentialHistory({ 
        historyFile: testHistoryFile,
        skipSuccessful: false 
      });
      history.record('user1', 'pass1', 'success');
      
      const result = history.shouldSkip('user1', 'pass1');
      
      expect(result.skip).toBe(false);
    });

    it('should skip failed credentials', () => {
      history.record('user1', 'pass1', 'failed');
      
      const result = history.shouldSkip('user1', 'pass1');
      
      expect(result.skip).toBe(true);
      expect(result.reason).toBe('already_failed');
    });

    it('should not skip failed when skipFailed is false', () => {
      history = new CredentialHistory({ 
        historyFile: testHistoryFile,
        skipFailed: false 
      });
      history.record('user1', 'pass1', 'failed');
      
      const result = history.shouldSkip('user1', 'pass1');
      
      expect(result.skip).toBe(false);
    });

    it('should skip blocked credentials', () => {
      history.record('user1', 'pass1', 'blocked');
      
      const result = history.shouldSkip('user1', 'pass1');
      
      expect(result.skip).toBe(true);
      expect(result.reason).toBe('already_blocked');
    });

    it('should not skip blocked when skipBlocked is false', () => {
      history = new CredentialHistory({ 
        historyFile: testHistoryFile,
        skipBlocked: false 
      });
      history.record('user1', 'pass1', 'blocked');
      
      const result = history.shouldSkip('user1', 'pass1');
      
      expect(result.skip).toBe(false);
    });

    it('should never skip captcha results', () => {
      history.record('user1', 'pass1', 'captcha');
      
      const result = history.shouldSkip('user1', 'pass1');
      
      expect(result.skip).toBe(false);
      expect(result.reason).toBe('');
    });

    it('should retest failed after specified days', () => {
      history = new CredentialHistory({ 
        historyFile: testHistoryFile,
        failedRetestAfterDays: 7 
      });
      
      // Create old failed entry (8 days ago)
      const oldDate = new Date();
      oldDate.setDate(oldDate.getDate() - 8);
      history.history.set('user1\tpass1', {
        u: 'user1',
        p: 'pass1',
        s: 'failed',
        t: oldDate.toISOString()
      });
      
      const result = history.shouldSkip('user1', 'pass1');
      
      expect(result.skip).toBe(false);
    });

    it('should skip recent failed within retry window', () => {
      history = new CredentialHistory({ 
        historyFile: testHistoryFile,
        failedRetestAfterDays: 7 
      });
      
      // Create recent failed entry (3 days ago)
      const recentDate = new Date();
      recentDate.setDate(recentDate.getDate() - 3);
      history.history.set('user1\tpass1', {
        u: 'user1',
        p: 'pass1',
        s: 'failed',
        t: recentDate.toISOString()
      });
      
      const result = history.shouldSkip('user1', 'pass1');
      
      expect(result.skip).toBe(true);
      expect(result.reason).toContain('failed_recently');
      expect(result.reason).toContain('3 days ago');
    });

    it('should retest blocked after specified days', () => {
      history = new CredentialHistory({ 
        historyFile: testHistoryFile,
        blockedRetestAfterDays: 14 
      });
      
      // Create old blocked entry (15 days ago)
      const oldDate = new Date();
      oldDate.setDate(oldDate.getDate() - 15);
      history.history.set('user1\tpass1', {
        u: 'user1',
        p: 'pass1',
        s: 'blocked',
        t: oldDate.toISOString()
      });
      
      const result = history.shouldSkip('user1', 'pass1');
      
      expect(result.skip).toBe(false);
    });

    it('should skip recent blocked within retry window', () => {
      history = new CredentialHistory({ 
        historyFile: testHistoryFile,
        blockedRetestAfterDays: 14 
      });
      
      // Create recent blocked entry (7 days ago)
      const recentDate = new Date();
      recentDate.setDate(recentDate.getDate() - 7);
      history.history.set('user1\tpass1', {
        u: 'user1',
        p: 'pass1',
        s: 'blocked',
        t: recentDate.toISOString()
      });
      
      const result = history.shouldSkip('user1', 'pass1');
      
      expect(result.skip).toBe(true);
      expect(result.reason).toContain('blocked_recently');
      expect(result.reason).toContain('7 days ago');
    });

    it('should return no skip when disabled', () => {
      history = new CredentialHistory({ 
        historyFile: testHistoryFile,
        enabled: false 
      });
      history.record('user1', 'pass1', 'success');
      
      const result = history.shouldSkip('user1', 'pass1');
      
      expect(result.skip).toBe(false);
      expect(result.reason).toBe('');
    });
  });

  describe('Statistics (_breakdown, getStats)', () => {
    beforeEach(() => {
      history = new CredentialHistory({ historyFile: testHistoryFile });
    });

    it('should count entries by status', () => {
      history.record('user1', 'pass1', 'success');
      history.record('user2', 'pass2', 'failed');
      history.record('user3', 'pass3', 'blocked');
      history.record('user4', 'pass4', 'captcha');
      history.record('user5', 'pass5', 'unknown');
      
      const breakdown = history._breakdown();
      
      expect(breakdown.success).toBe(1);
      expect(breakdown.failed).toBe(1);
      expect(breakdown.blocked).toBe(1);
      expect(breakdown.captcha).toBe(1);
      expect(breakdown.other).toBe(1);
    });

    it('should return complete stats', () => {
      fs.existsSync.mockReturnValue(true);
      fs.statSync.mockReturnValue({ size: 2048 });
      
      history.record('user1', 'pass1', 'success');
      history.record('user2', 'pass2', 'failed');
      
      const stats = history.getStats();
      
      expect(stats.total).toBe(2);
      expect(stats.success).toBe(1);
      expect(stats.failed).toBe(1);
      expect(stats.blocked).toBe(0);
      expect(stats.captcha).toBe(0);
      expect(stats.other).toBe(0);
      expect(stats.historyFile).toBe(testHistoryFile);
      expect(stats.fileExists).toBe(true);
      expect(stats.fileSize).toBe(2048);
    });

    it('should handle missing file in stats', () => {
      fs.existsSync.mockReturnValue(false);
      
      const stats = history.getStats();
      
      expect(stats.fileExists).toBe(false);
      expect(stats.fileSize).toBe(0);
    });
  });

  describe('Search (search)', () => {
    beforeEach(() => {
      history = new CredentialHistory({ historyFile: testHistoryFile });
      history.record('admin', 'admin123', 'success', { method: 'api' });
      history.record('user@test.com', 'password', 'failed');
      history.record('testuser', 'TestPass123', 'blocked');
    });

    it('should search by username', () => {
      const results = history.search('admin');
      
      expect(results.length).toBe(1);
      expect(results[0].username).toBe('admin');
    });

    it('should search by password', () => {
      const results = history.search('admin123');
      
      expect(results.length).toBe(1);
      expect(results[0].password).toBe('admin123');
    });

    it('should search by status', () => {
      const results = history.search('failed');
      
      expect(results.length).toBe(1);
      expect(results[0].status).toBe('failed');
    });

    it('should search by method', () => {
      const results = history.search('api');
      
      expect(results.length).toBe(1);
      expect(results[0].method).toBe('api');
    });

    it('should be case-insensitive', () => {
      const results = history.search('TESTUSER');
      
      expect(results.length).toBe(1);
      expect(results[0].username).toBe('testuser');
    });

    it('should match partial strings', () => {
      const results = history.search('test');
      
      expect(results.length).toBeGreaterThan(0);
    });

    it('should return empty array for no matches', () => {
      const results = history.search('nonexistent');
      
      expect(results).toEqual([]);
    });
  });

  describe('Compaction (compact)', () => {
    beforeEach(() => {
      history = new CredentialHistory({ historyFile: testHistoryFile });
    });

    it('should write all entries to temp file and rename', () => {
      history.record('user1', 'pass1', 'success');
      history.record('user2', 'pass2', 'failed');
      
      history.compact();
      
      expect(fs.writeFileSync).toHaveBeenCalledWith(
        testHistoryFile + '.tmp',
        expect.any(String),
        'utf8'
      );
      expect(fs.renameSync).toHaveBeenCalledWith(
        testHistoryFile + '.tmp',
        testHistoryFile
      );
    });

    it('should write valid JSONL format', () => {
      history.record('user1', 'pass1', 'success');
      
      history.compact();
      
      const writtenContent = fs.writeFileSync.mock.calls[0][1];
      const lines = writtenContent.split('\n').filter(line => line.trim());
      
      expect(lines.length).toBe(1);
      expect(() => JSON.parse(lines[0])).not.toThrow();
    });

    it('should handle compaction errors gracefully', () => {
      fs.writeFileSync.mockImplementation(() => {
        throw new Error('Write error');
      });
      
      history.record('user1', 'pass1', 'success');
      
      expect(() => history.compact()).not.toThrow();
      
      expect(console.error).toHaveBeenCalledWith(
        expect.stringContaining('Failed to compact'),
        'Write error'
      );
    });

    it('should do nothing when disabled', () => {
      history = new CredentialHistory({ 
        historyFile: testHistoryFile,
        enabled: false 
      });
      
      history.compact();
      
      expect(fs.writeFileSync).not.toHaveBeenCalled();
      expect(fs.renameSync).not.toHaveBeenCalled();
    });
  });

  describe('Export (getAll, getByStatus)', () => {
    beforeEach(() => {
      history = new CredentialHistory({ historyFile: testHistoryFile });
      
      // Use fixed dates for testing
      jest.spyOn(Date.prototype, 'toISOString').mockReturnValue('2024-01-01T00:00:00.000Z');
      
      history.record('user1', 'pass1', 'success', { 
        method: 'api', 
        confidence: 0.95,
        pointsBalance: 100,
        moneyBalance: 50.5 
      });
      history.record('user2', 'pass2', 'failed', { reason: 'invalid' });
      history.record('user3', 'pass3', 'blocked', { reason: 'rate_limit' });
      
      Date.prototype.toISOString.mockRestore();
    });

    it('should export all entries with expanded fields', () => {
      const entries = history.getAll();
      
      expect(entries.length).toBe(3);
      expect(entries[0]).toHaveProperty('username');
      expect(entries[0]).toHaveProperty('password');
      expect(entries[0]).toHaveProperty('status');
      expect(entries[0]).toHaveProperty('method');
      expect(entries[0]).toHaveProperty('confidence');
      expect(entries[0]).toHaveProperty('reason');
      expect(entries[0]).toHaveProperty('pointsBalance');
      expect(entries[0]).toHaveProperty('moneyBalance');
      expect(entries[0]).toHaveProperty('timestamp');
      expect(entries[0]).toHaveProperty('timeAgo');
    });

    it('should expand abbreviated fields correctly', () => {
      const entries = history.getAll();
      const successEntry = entries.find(e => e.status === 'success');
      
      expect(successEntry.username).toBe('user1');
      expect(successEntry.password).toBe('pass1');
      expect(successEntry.method).toBe('api');
      expect(successEntry.confidence).toBe(0.95);
      expect(successEntry.pointsBalance).toBe(100);
      expect(successEntry.moneyBalance).toBe(50.5);
    });

    it('should handle null optional fields', () => {
      const entries = history.getAll();
      const failedEntry = entries.find(e => e.status === 'failed');
      
      expect(failedEntry.method).toBeNull();
      expect(failedEntry.confidence).toBeNull();
      expect(failedEntry.pointsBalance).toBeNull();
      expect(failedEntry.moneyBalance).toBeNull();
    });

    it('should filter by status', () => {
      const successEntries = history.getByStatus('success');
      
      expect(successEntries.length).toBe(1);
      expect(successEntries[0].status).toBe('success');
    });

    it('should return empty array for non-matching status', () => {
      const entries = history.getByStatus('captcha');
      
      expect(entries).toEqual([]);
    });

    it('should include human-readable time ago', () => {
      const entries = history.getAll();
      
      entries.forEach(entry => {
        expect(entry.timeAgo).toBeDefined();
        expect(typeof entry.timeAgo).toBe('string');
      });
    });
  });

  describe('Time Ago Formatting (_ago)', () => {
    beforeEach(() => {
      history = new CredentialHistory({ historyFile: testHistoryFile });
    });

    it('should format seconds', () => {
      const now = new Date();
      const past = new Date(now - 30 * 1000);
      
      const ago = history._ago(past.toISOString());
      
      expect(ago).toBe('30s ago');
    });

    it('should format minutes', () => {
      const now = new Date();
      const past = new Date(now - 5 * 60 * 1000);
      
      const ago = history._ago(past.toISOString());
      
      expect(ago).toBe('5m ago');
    });

    it('should format hours', () => {
      const now = new Date();
      const past = new Date(now - 3 * 60 * 60 * 1000);
      
      const ago = history._ago(past.toISOString());
      
      expect(ago).toBe('3h ago');
    });

    it('should format days', () => {
      const now = new Date();
      const past = new Date(now - 7 * 24 * 60 * 60 * 1000);
      
      const ago = history._ago(past.toISOString());
      
      expect(ago).toBe('7d ago');
    });
  });

  describe('Delete Entry (deleteEntry)', () => {
    beforeEach(() => {
      history = new CredentialHistory({ historyFile: testHistoryFile });
    });

    it('should delete entry and compact', () => {
      history.record('user1', 'pass1', 'success');
      history.record('user2', 'pass2', 'failed');
      
      const deleted = history.deleteEntry('user1', 'pass1');
      
      expect(deleted).toBe(true);
      expect(history.history.size).toBe(1);
      expect(history.history.has('user1\tpass1')).toBe(false);
      expect(fs.writeFileSync).toHaveBeenCalled(); // Compact called
    });

    it('should return false for non-existent entry', () => {
      const deleted = history.deleteEntry('nonexistent', 'user');
      
      expect(deleted).toBe(false);
    });

    it('should return false when disabled', () => {
      history = new CredentialHistory({ 
        historyFile: testHistoryFile,
        enabled: false 
      });
      
      const deleted = history.deleteEntry('user1', 'pass1');
      
      expect(deleted).toBe(false);
    });
  });

  describe('Filter Credentials (filterCredentials)', () => {
    beforeEach(() => {
      history = new CredentialHistory({ historyFile: testHistoryFile });
    });

    it('should filter out successful credentials', () => {
      history.record('user1', 'pass1', 'success');
      history.record('user2', 'pass2', 'captcha'); // Captcha is never skipped
      
      const credentials = [
        { username: 'user1', password: 'pass1' },
        { username: 'user2', password: 'pass2' },
        { username: 'user3', password: 'pass3' }
      ];
      
      const filtered = history.filterCredentials(credentials);
      
      expect(filtered.length).toBe(2);
      expect(filtered.find(c => c.username === 'user1')).toBeUndefined();
    });

    it('should return all credentials when disabled', () => {
      history = new CredentialHistory({ 
        historyFile: testHistoryFile,
        enabled: false 
      });
      history.record('user1', 'pass1', 'success');
      
      const credentials = [
        { username: 'user1', password: 'pass1' },
        { username: 'user2', password: 'pass2' }
      ];
      
      const filtered = history.filterCredentials(credentials);
      
      expect(filtered.length).toBe(2);
    });

    it('should log filtering summary', () => {
      history.record('user1', 'pass1', 'success');
      history.record('user2', 'pass2', 'failed');
      
      const credentials = [
        { username: 'user1', password: 'pass1' },
        { username: 'user2', password: 'pass2' },
        { username: 'user3', password: 'pass3' }
      ];
      
      history.filterCredentials(credentials);
      
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Total in file: 3'));
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('To test: 1'));
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Skipped: 2'));
    });

    it('should calculate traffic savings percentage', () => {
      history.record('user1', 'pass1', 'success');
      history.record('user2', 'pass2', 'success');
      
      const credentials = [
        { username: 'user1', password: 'pass1' },
        { username: 'user2', password: 'pass2' },
        { username: 'user3', password: 'pass3' },
        { username: 'user4', password: 'pass4' }
      ];
      
      history.filterCredentials(credentials);
      
      expect(console.log).toHaveBeenCalledWith(
        expect.stringContaining('50.0% traffic saved')
      );
    });

    it('should track skip reasons separately', () => {
      history.record('user1', 'pass1', 'success');
      history.record('user2', 'pass2', 'failed');
      history.record('user3', 'pass3', 'blocked');
      
      const credentials = [
        { username: 'user1', password: 'pass1' },
        { username: 'user2', password: 'pass2' },
        { username: 'user3', password: 'pass3' },
        { username: 'user4', password: 'pass4' }
      ];
      
      history.filterCredentials(credentials);
      
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Already successful: 1'));
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Already failed: 1'));
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Already blocked: 1'));
    });
  });

  describe('Integration Tests', () => {
    it('should handle complete workflow', () => {
      // Initialize
      history = new CredentialHistory({ historyFile: testHistoryFile });
      
      // Load empty file
      fs.existsSync.mockReturnValue(false);
      history.load();
      expect(history.history.size).toBe(0);
      
      // Record some entries
      history.recordSuccess('user1', 'pass1', 'api', 0.95);
      history.recordFailed('user2', 'pass2', 'invalid');
      history.recordBlocked('user3', 'pass3', 'rate_limit');
      history.recordCaptcha('user4', 'pass4');
      
      // Check skip logic
      expect(history.shouldSkip('user1', 'pass1').skip).toBe(true);
      expect(history.shouldSkip('user2', 'pass2').skip).toBe(true);
      expect(history.shouldSkip('user3', 'pass3').skip).toBe(true);
      expect(history.shouldSkip('user4', 'pass4').skip).toBe(false); // Captcha never skipped
      expect(history.shouldSkip('user5', 'pass5').skip).toBe(false); // New
      
      // Get stats
      const stats = history.getStats();
      expect(stats.total).toBe(4);
      expect(stats.success).toBe(1);
      expect(stats.failed).toBe(1);
      expect(stats.blocked).toBe(1);
      expect(stats.captcha).toBe(1);
      
      // Compact
      history.compact();
      expect(fs.writeFileSync).toHaveBeenCalled();
      expect(fs.renameSync).toHaveBeenCalled();
    });

    it('should handle load, filter, and record cycle', () => {
      // Setup existing history
      const mockContent = 
        '{"u":"user1","p":"pass1","s":"success","t":"2024-01-01T00:00:00.000Z"}\n' +
        '{"u":"user2","p":"pass2","s":"failed","t":"2024-01-02T00:00:00.000Z"}\n';
      
      fs.existsSync.mockReturnValue(true);
      fs.readFileSync.mockReturnValue(mockContent);
      
      history = new CredentialHistory({ historyFile: testHistoryFile });
      history.load();
      
      expect(history.history.size).toBe(2);
      
      // Filter credentials
      const credentials = [
        { username: 'user1', password: 'pass1' }, // Should be filtered (success)
        { username: 'user2', password: 'pass2' }, // Should be filtered (failed)
        { username: 'user3', password: 'pass3' }  // Should pass through (new)
      ];
      
      const filtered = history.filterCredentials(credentials);
      expect(filtered.length).toBe(1);
      expect(filtered[0].username).toBe('user3');
      
      // Record new result
      history.recordSuccess('user3', 'pass3', 'api', 0.9);
      expect(history.history.size).toBe(3);
    });
  });

  describe('Reload (reload, _updateMtime)', () => {
    beforeEach(() => {
      history = new CredentialHistory({ historyFile: testHistoryFile });
    });

    it('should initialize _lastMtimeMs to 0', () => {
      expect(history._lastMtimeMs).toBe(0);
      expect(history._lastSize).toBe(0);
    });

    it('should update mtime after load', () => {
      fs.existsSync.mockReturnValue(true);
      fs.statSync.mockReturnValue({ size: 1024, mtimeMs: 12345 });
      fs.readFileSync.mockReturnValue('{"u":"a","p":"b","s":"success","t":"2026-01-01T00:00:00Z"}\n');

      history.load();

      expect(history._lastMtimeMs).toBe(12345);
    });

    it('should update mtime and size after record', () => {
      fs.existsSync.mockReturnValue(true);
      fs.statSync.mockReturnValue({ size: 1024, mtimeMs: 99999 });

      history.record('user1', 'pass1', 'success');

      expect(history._lastMtimeMs).toBe(99999);
      expect(history._lastSize).toBe(1024);
    });

    it('should skip reload if file mtime and size have not changed', () => {
      fs.existsSync.mockReturnValue(true);
      fs.statSync.mockReturnValue({ size: 100, mtimeMs: 5000 });
      history._lastMtimeMs = 5000;
      history._lastSize = 100;

      history.reload();

      // readFileSync should NOT have been called because mtime+size are unchanged
      expect(fs.readFileSync).not.toHaveBeenCalled();
    });

    it('should reload when file mtime has changed', () => {
      // First set up initial state
      history.record('old_user', 'old_pass', 'failed');
      expect(history.history.size).toBe(1);
      history._lastMtimeMs = 1000;

      // Mock the file with new content (simulating controller writing new data)
      const newFileContent = [
        '{"u":"user1","p":"pass1","s":"success","t":"2026-01-01T00:00:00Z"}',
        '{"u":"user2","p":"pass2","s":"failed","t":"2026-01-01T00:00:01Z"}'
      ].join('\n');

      fs.existsSync.mockReturnValue(true);
      fs.statSync.mockReturnValue({ size: 200, mtimeMs: 2000 });
      fs.readFileSync.mockReturnValue(newFileContent);

      history.reload();

      expect(history.history.size).toBe(2);
      expect(history._lastMtimeMs).toBe(2000);
      expect(history._lastSize).toBe(200);
      const allEntries = history.getAll();
      expect(allEntries.some(e => e.username === 'user1' && e.status === 'success')).toBe(true);
      expect(allEntries.some(e => e.username === 'user2' && e.status === 'failed')).toBe(true);
      // The old_user entry should be gone because it was not in the file
      expect(allEntries.some(e => e.username === 'old_user')).toBe(false);
    });

    it('should be a no-op when disabled', () => {
      history = new CredentialHistory({ historyFile: testHistoryFile, enabled: false });

      history.reload();

      expect(fs.existsSync).not.toHaveBeenCalled();
    });

    it('should handle non-existent file in reload gracefully', () => {
      fs.existsSync.mockReturnValue(false);

      history.reload();

      expect(history.history.size).toBe(0);
    });

    it('should handle empty file content in reload without advancing mtime', () => {
      history.record('user1', 'pass1', 'success');
      history._lastMtimeMs = 1000;
      history._lastSize = 50;
      fs.existsSync.mockReturnValue(true);
      fs.statSync.mockReturnValue({ size: 0, mtimeMs: 2000 });
      fs.readFileSync.mockReturnValue('');

      history.reload();

      // In-memory data preserved; mtime not advanced so future reload can retry
      expect(history.history.size).toBe(1);
      expect(history._lastMtimeMs).toBe(1000);
      expect(history._lastSize).toBe(50);
    });

    it('should handle stat errors in reload gracefully', () => {
      history.record('user1', 'pass1', 'success');
      fs.existsSync.mockReturnValue(true);
      fs.statSync.mockImplementation(() => { throw new Error('stat error'); });

      // Should not throw, and in-memory data should remain
      history.reload();

      expect(history.history.size).toBe(1);
    });

    it('should preserve in-memory history when file read fails after mtime change', () => {
      // Set up initial state with data
      history.record('user1', 'pass1', 'success');
      expect(history.history.size).toBe(1);
      history._lastMtimeMs = 1000;
      history._lastSize = 50;

      // Simulate file change detected (new mtime) but readFileSync throws
      fs.existsSync.mockReturnValue(true);
      fs.statSync.mockReturnValue({ size: 200, mtimeMs: 2000 });
      fs.readFileSync.mockImplementation(() => { throw new Error('EACCES: permission denied'); });

      history.reload();

      // In-memory history must be preserved
      expect(history.history.size).toBe(1);
      expect(history.getAll()[0].username).toBe('user1');
      // mtime must NOT be advanced so future reload can retry
      expect(history._lastMtimeMs).toBe(1000);
      expect(history._lastSize).toBe(50);
    });

    it('should reload when only file size has changed but mtime is the same', () => {
      history._lastMtimeMs = 5000;
      history._lastSize = 100;

      const newFileContent = '{"u":"user1","p":"pass1","s":"success","t":"2026-01-01T00:00:00Z"}\n';
      fs.existsSync.mockReturnValue(true);
      fs.statSync.mockReturnValue({ size: 200, mtimeMs: 5000 });
      fs.readFileSync.mockReturnValue(newFileContent);

      history.reload();

      expect(history.history.size).toBe(1);
      expect(history._lastSize).toBe(200);
    });
  });

  describe('getFileFingerprint', () => {
    beforeEach(() => {
      history = new CredentialHistory({ historyFile: testHistoryFile });
    });

    it('should return zero fingerprint on fresh instance', () => {
      const fp = history.getFileFingerprint();
      expect(fp).toEqual({ mtimeMs: 0, size: 0 });
    });

    it('should reflect mtime and size after load', () => {
      fs.existsSync.mockReturnValue(true);
      fs.statSync.mockReturnValue({ size: 512, mtimeMs: 77777 });
      fs.readFileSync.mockReturnValue('{"u":"a","p":"b","s":"success","t":"2026-01-01T00:00:00Z"}\n');

      history.load();

      const fp = history.getFileFingerprint();
      expect(fp.mtimeMs).toBe(77777);
      expect(fp.size).toBe(512);
    });

    it('should reflect updated fingerprint after reload picks up a change', () => {
      fs.existsSync.mockReturnValue(true);
      fs.statSync.mockReturnValue({ size: 100, mtimeMs: 1000 });
      fs.readFileSync.mockReturnValue('{"u":"a","p":"b","s":"failed","t":"2026-01-01T00:00:00Z"}\n');
      history.load();

      // Simulate file change (e.g. status updated from failed→success for same user:pass)
      fs.statSync.mockReturnValue({ size: 110, mtimeMs: 2000 });
      fs.readFileSync.mockReturnValue('{"u":"a","p":"b","s":"success","t":"2026-01-02T00:00:00Z"}\n');
      history.reload();

      const fp = history.getFileFingerprint();
      expect(fp.mtimeMs).toBe(2000);
      expect(fp.size).toBe(110);
    });
  });

  describe('hasEntry()', () => {
    beforeEach(() => {
      history = new CredentialHistory({ historyFile: testHistoryFile });
    });

    it('should return false for a credential that has no history entry', () => {
      expect(history.hasEntry('nobody', 'nopass')).toBe(false);
    });

    it('should return true for a credential recorded as success', () => {
      history.record('user1', 'pass1', 'success');
      expect(history.hasEntry('user1', 'pass1')).toBe(true);
    });

    it('should return true for a credential recorded as failed', () => {
      history.record('user2', 'pass2', 'failed', { reason: 'invalid_credentials' });
      expect(history.hasEntry('user2', 'pass2')).toBe(true);
    });

    it('should return true for a credential recorded as blocked', () => {
      history.record('user3', 'pass3', 'blocked', { reason: 'proxy_blocked' });
      expect(history.hasEntry('user3', 'pass3')).toBe(true);
    });

    it('should return true for a credential recorded as captcha', () => {
      history.record('user4', 'pass4', 'captcha');
      expect(history.hasEntry('user4', 'pass4')).toBe(true);
    });

    it('should return false when history is disabled', () => {
      const disabledHistory = new CredentialHistory({
        historyFile: testHistoryFile,
        enabled: false
      });
      disabledHistory.record('user1', 'pass1', 'success');
      expect(disabledHistory.hasEntry('user1', 'pass1')).toBe(false);
    });

    it('should be case-sensitive for username and password', () => {
      history.record('User1', 'Pass1', 'success');
      expect(history.hasEntry('User1', 'Pass1')).toBe(true);
      expect(history.hasEntry('user1', 'Pass1')).toBe(false);
      expect(history.hasEntry('User1', 'pass1')).toBe(false);
    });
  });
});
