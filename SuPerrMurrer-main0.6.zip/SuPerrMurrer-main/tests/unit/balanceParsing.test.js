/**
 * Unit Tests for Balance Parsing Functionality
 * Tests the balance and points parsing logic
 */

const config = require('../../config');

describe('Balance Parsing Configuration', () => {
  describe('balanceSelectors configuration', () => {
    it('should have balanceSelectors defined', () => {
      expect(config.account.balanceSelectors).toBeDefined();
      expect(typeof config.account.balanceSelectors).toBe('object');
    });

    it('should have points selector configured', () => {
      expect(config.account.balanceSelectors.points).toBeDefined();
      expect(typeof config.account.balanceSelectors.points).toBe('string');
      expect(config.account.balanceSelectors.points).toBe('span.myPointBalance-value');
    });

    it('should have money selector configured', () => {
      expect(config.account.balanceSelectors.money).toBeDefined();
      expect(typeof config.account.balanceSelectors.money).toBe('string');
      expect(config.account.balanceSelectors.money).toBe('span.myMoneyBalance-value');
    });

    it('should have timeout configured', () => {
      expect(config.account.balanceSelectors.timeout).toBeDefined();
      expect(typeof config.account.balanceSelectors.timeout).toBe('number');
      expect(config.account.balanceSelectors.timeout).toBe(3000);
    });
  });

  describe('parseAccountBalances function behavior', () => {
    // Mock page object for testing
    const createMockPage = (pointsText = null, moneyText = null) => {
      return {
        waitForSelector: jest.fn((selector, options) => {
          if (selector === 'span.myPointBalance-value' && pointsText !== null) {
            return Promise.resolve({
              textContent: () => Promise.resolve(pointsText),
              isVisible: () => Promise.resolve(true)
            });
          }
          if (selector === 'span.myMoneyBalance-value' && moneyText !== null) {
            return Promise.resolve({
              textContent: () => Promise.resolve(moneyText),
              isVisible: () => Promise.resolve(true)
            });
          }
          return Promise.resolve(null);
        })
      };
    };

    it('should return N/A as default values', async () => {
      // Simulate the function behavior
      const result = {
        pointsBalance: 'N/A',
        moneyBalance: 'N/A'
      };
      
      expect(result.pointsBalance).toBe('N/A');
      expect(result.moneyBalance).toBe('N/A');
    });

    it('should parse both points and money balance', async () => {
      // Simulate successful parsing
      const mockPage = createMockPage('6666', '33');
      
      // Verify mock page can find elements
      const pointsElement = await mockPage.waitForSelector('span.myPointBalance-value', { timeout: 3000 });
      expect(pointsElement).not.toBeNull();
      
      const moneyElement = await mockPage.waitForSelector('span.myMoneyBalance-value', { timeout: 3000 });
      expect(moneyElement).not.toBeNull();
      
      const pointsText = await pointsElement.textContent();
      const moneyText = await moneyElement.textContent();
      
      expect(pointsText).toBe('6666');
      expect(moneyText).toBe('33');
    });

    it('should handle missing elements gracefully', async () => {
      // Simulate elements not found
      const mockPage = createMockPage(null, null);
      
      const pointsElement = await mockPage.waitForSelector('span.myPointBalance-value', { timeout: 3000 });
      const moneyElement = await mockPage.waitForSelector('span.myMoneyBalance-value', { timeout: 3000 });
      
      expect(pointsElement).toBeNull();
      expect(moneyElement).toBeNull();
      
      // Default values should be returned
      const result = {
        pointsBalance: pointsElement ? 'value' : 'N/A',
        moneyBalance: moneyElement ? 'value' : 'N/A'
      };
      
      expect(result.pointsBalance).toBe('N/A');
      expect(result.moneyBalance).toBe('N/A');
    });

    it('should trim whitespace from balance values', () => {
      const rawPoints = '  6666  ';
      const rawMoney = '\n33\n';
      
      const cleanPoints = rawPoints.trim();
      const cleanMoney = rawMoney.trim();
      
      expect(cleanPoints).toBe('6666');
      expect(cleanMoney).toBe('33');
    });

    it('should handle partial success (only points found)', async () => {
      // Simulate only points element found
      const mockPage = createMockPage('1234', null);
      
      const pointsElement = await mockPage.waitForSelector('span.myPointBalance-value', { timeout: 3000 });
      const moneyElement = await mockPage.waitForSelector('span.myMoneyBalance-value', { timeout: 3000 });
      
      expect(pointsElement).not.toBeNull();
      expect(moneyElement).toBeNull();
      
      const result = {
        pointsBalance: pointsElement ? await pointsElement.textContent() : 'N/A',
        moneyBalance: moneyElement ? await moneyElement.textContent() : 'N/A'
      };
      
      expect(result.pointsBalance).toBe('1234');
      expect(result.moneyBalance).toBe('N/A');
    });

    it('should handle partial success (only money found)', async () => {
      // Simulate only money element found
      const mockPage = createMockPage(null, '99');
      
      const pointsElement = await mockPage.waitForSelector('span.myPointBalance-value', { timeout: 3000 });
      const moneyElement = await mockPage.waitForSelector('span.myMoneyBalance-value', { timeout: 3000 });
      
      expect(pointsElement).toBeNull();
      expect(moneyElement).not.toBeNull();
      
      const result = {
        pointsBalance: pointsElement ? await pointsElement.textContent() : 'N/A',
        moneyBalance: moneyElement ? await moneyElement.textContent() : 'N/A'
      };
      
      expect(result.pointsBalance).toBe('N/A');
      expect(result.moneyBalance).toBe('99');
    });
  });
});
