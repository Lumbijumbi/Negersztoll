'use strict';

jest.mock('fs', () => ({
  promises: {
    writeFile: jest.fn(),
    readFile: jest.fn(),
    unlink: jest.fn(),
    access: jest.fn()
  }
}));

const fs = require('fs');
const SessionState = require('../../utils/sessionState');

describe('SessionState', () => {
  let state;

  beforeEach(() => {
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
    state = new SessionState('.test_session_state.json');
    jest.clearAllMocks();
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('constructor', () => {
    it('should use provided stateFile', () => {
      expect(state.stateFile).toBe('.test_session_state.json');
    });

    it('should use default stateFile', () => {
      const defaultState = new SessionState();
      expect(defaultState.stateFile).toBe('.session_state.json');
    });
  });

  describe('save', () => {
    it('should write state to file and return true', async () => {
      fs.promises.writeFile.mockResolvedValue(undefined);
      const result = await state.save({
        total: 100, processed: 50, remaining: 50,
        successful: 30, failed: 10, blocked: 5, captcha: 5,
        retryQueue: [], processedCredentials: [], startTime: Date.now()
      });
      expect(result).toBe(true);
      expect(fs.promises.writeFile).toHaveBeenCalledWith(
        '.test_session_state.json',
        expect.stringContaining('"version"'),
        'utf8'
      );
    });

    it('should return false on write failure', async () => {
      fs.promises.writeFile.mockRejectedValue(new Error('disk full'));
      const result = await state.save({ total: 10, processed: 5 });
      expect(result).toBe(false);
      expect(console.error).toHaveBeenCalled();
    });

    it('should save defaults for missing fields', async () => {
      fs.promises.writeFile.mockResolvedValue(undefined);
      await state.save({});
      const written = fs.promises.writeFile.mock.calls[0][1];
      const data = JSON.parse(written);
      expect(data.credentials.total).toBe(0);
      expect(data.credentials.processed).toBe(0);
    });

    it('should serialize retryQueue and processedCredentials', async () => {
      fs.promises.writeFile.mockResolvedValue(undefined);
      await state.save({ retryQueue: ['a', 'b'], processedCredentials: ['c'] });
      const written = fs.promises.writeFile.mock.calls[0][1];
      const data = JSON.parse(written);
      expect(data.queue).toEqual(['a', 'b']);
      expect(data.processedCredentials).toEqual(['c']);
    });
  });

  describe('load', () => {
    it('should return parsed state for recent data', async () => {
      const stateData = {
        version: '1.0',
        timestamp: Date.now(),
        timestampISO: new Date().toISOString(),
        credentials: { total: 100, processed: 50, remaining: 50 },
        results: { successful: 30, failed: 10, blocked: 5, captcha: 5 },
        queue: [],
        processedCredentials: [],
        startTime: Date.now()
      };
      fs.promises.readFile.mockResolvedValue(JSON.stringify(stateData));
      const result = await state.load();
      expect(result).not.toBeNull();
      expect(result.credentials.total).toBe(100);
    });

    it('should return null for old state (>24h)', async () => {
      const oldTimestamp = Date.now() - (25 * 60 * 60 * 1000);
      const stateData = { timestamp: oldTimestamp, credentials: {}, results: {}, queue: [], processedCredentials: [] };
      fs.promises.readFile.mockResolvedValue(JSON.stringify(stateData));
      const result = await state.load();
      expect(result).toBeNull();
    });

    it('should return null when file does not exist', async () => {
      const err = new Error('File not found');
      err.code = 'ENOENT';
      fs.promises.readFile.mockRejectedValue(err);
      const result = await state.load();
      expect(result).toBeNull();
    });

    it('should return null and log error on non-ENOENT error', async () => {
      const err = new Error('Permission denied');
      err.code = 'EACCES';
      fs.promises.readFile.mockRejectedValue(err);
      const result = await state.load();
      expect(result).toBeNull();
      expect(console.error).toHaveBeenCalled();
    });

    it('should return null on JSON parse error', async () => {
      fs.promises.readFile.mockResolvedValue('invalid json {{{');
      const result = await state.load();
      expect(result).toBeNull();
    });
  });

  describe('clear', () => {
    it('should delete state file and return true', async () => {
      fs.promises.unlink.mockResolvedValue(undefined);
      const result = await state.clear();
      expect(result).toBe(true);
      expect(fs.promises.unlink).toHaveBeenCalledWith('.test_session_state.json');
    });

    it('should return false when file does not exist (ENOENT)', async () => {
      const err = new Error('No such file');
      err.code = 'ENOENT';
      fs.promises.unlink.mockRejectedValue(err);
      const result = await state.clear();
      expect(result).toBe(false);
    });

    it('should return false and log error on other errors', async () => {
      const err = new Error('Permission denied');
      err.code = 'EACCES';
      fs.promises.unlink.mockRejectedValue(err);
      const result = await state.clear();
      expect(result).toBe(false);
      expect(console.error).toHaveBeenCalled();
    });
  });

  describe('exists', () => {
    it('should return true when file is accessible', async () => {
      fs.promises.access.mockResolvedValue(undefined);
      const result = await state.exists();
      expect(result).toBe(true);
    });

    it('should return false when file is not accessible', async () => {
      fs.promises.access.mockRejectedValue(new Error('not found'));
      const result = await state.exists();
      expect(result).toBe(false);
    });
  });

  describe('getInfo', () => {
    it('should return info when file exists', async () => {
      const stateData = {
        timestamp: Date.now() - 3600000,
        timestampISO: new Date().toISOString(),
        credentials: { total: 100, processed: 50, remaining: 50 },
        results: { successful: 30, failed: 10, blocked: 5, captcha: 5 }
      };
      fs.promises.readFile.mockResolvedValue(JSON.stringify(stateData));
      const info = await state.getInfo();
      expect(info.exists).toBe(true);
      expect(info.credentials.total).toBe(100);
      expect(info.ageHours).toBeDefined();
    });

    it('should return exists=false when file not found', async () => {
      fs.promises.readFile.mockRejectedValue(new Error('not found'));
      const info = await state.getInfo();
      expect(info.exists).toBe(false);
    });
  });
});
