/**
 * Unit Tests for Error Recovery Module
 * Tests backoff calculations, retry logic, and error classification
 */

const { calculateBackoffDelay, retryWithBackoff, classifyError } = require('../../errorRecovery');

// Mock config for testing
jest.mock('../../config', () => ({
  errorRecovery: {
    maxRetries: 3,
    retryStrategies: {
      exponentialBackoff: true,
      backoffBase: 2,
      maxBackoffDelay: 30000
    }
  }
}));

describe('Error Recovery Module', () => {
  describe('calculateBackoffDelay', () => {
    it('should calculate exponential backoff for attempt 0', () => {
      const delay = calculateBackoffDelay(0);
      expect(delay).toBe(1000); // 2^0 * 1000 = 1000ms
    });

    it('should calculate exponential backoff for attempt 1', () => {
      const delay = calculateBackoffDelay(1);
      expect(delay).toBe(2000); // 2^1 * 1000 = 2000ms
    });

    it('should calculate exponential backoff for attempt 2', () => {
      const delay = calculateBackoffDelay(2);
      expect(delay).toBe(4000); // 2^2 * 1000 = 4000ms
    });

    it('should calculate exponential backoff for attempt 3', () => {
      const delay = calculateBackoffDelay(3);
      expect(delay).toBe(8000); // 2^3 * 1000 = 8000ms
    });

    it('should cap delay at maxBackoffDelay', () => {
      const delay = calculateBackoffDelay(10);
      expect(delay).toBe(30000); // Should be capped at 30000ms
    });

    it('should handle attempt 0 correctly', () => {
      const delay = calculateBackoffDelay(0);
      expect(delay).toBeGreaterThan(0);
    });

    it('should return positive delays', () => {
      for (let i = 0; i < 10; i++) {
        const delay = calculateBackoffDelay(i);
        expect(delay).toBeGreaterThan(0);
      }
    });
  });

  describe('retryWithBackoff', () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    it('should succeed on first attempt', async () => {
      const mockFn = jest.fn().mockResolvedValue('success');
      
      const result = await retryWithBackoff(mockFn, { verbose: false });
      
      expect(result).toBe('success');
      expect(mockFn).toHaveBeenCalledTimes(1);
    });

    it('should retry on failure and eventually succeed', async () => {
      const mockFn = jest
        .fn()
        .mockRejectedValueOnce(new Error('timeout'))
        .mockResolvedValue('success');
      
      const result = await retryWithBackoff(mockFn, { verbose: false });
      
      expect(result).toBe('success');
      expect(mockFn).toHaveBeenCalledTimes(2);
    });

    it('should exhaust all retries and throw error', async () => {
      const mockFn = jest.fn().mockRejectedValue(new Error('persistent error'));
      
      await expect(retryWithBackoff(mockFn, { maxRetries: 3, verbose: false })).rejects.toThrow('persistent error');
      expect(mockFn).toHaveBeenCalledTimes(3);
    });

    it('should call onRetry callback on each retry', async () => {
      const mockFn = jest
        .fn()
        .mockRejectedValueOnce(new Error('error1'))
        .mockRejectedValueOnce(new Error('error2'))
        .mockResolvedValue('success');
      
      const onRetrySpy = jest.fn();
      
      const result = await retryWithBackoff(mockFn, { 
        onRetry: onRetrySpy, 
        verbose: false 
      });
      
      expect(result).toBe('success');
      expect(onRetrySpy).toHaveBeenCalledTimes(2);
      expect(onRetrySpy).toHaveBeenCalledWith(
        expect.any(Error),
        expect.any(Number),
        expect.any(Number)
      );
    });

    it('should respect shouldRetry predicate', async () => {
      const mockFn = jest.fn().mockRejectedValue(new Error('non-retryable'));
      const shouldRetry = jest.fn().mockReturnValue(false);
      
      await expect(retryWithBackoff(mockFn, { 
        shouldRetry, 
        verbose: false 
      })).rejects.toThrow('non-retryable');
      
      expect(mockFn).toHaveBeenCalledTimes(1);
      expect(shouldRetry).toHaveBeenCalled();
    });

    it('should use custom maxRetries', async () => {
      const mockFn = jest.fn().mockRejectedValue(new Error('error'));
      
      await expect(retryWithBackoff(mockFn, { 
        maxRetries: 5, 
        verbose: false 
      })).rejects.toThrow();
      
      expect(mockFn).toHaveBeenCalledTimes(5);
    }, 20000); // Increase timeout to 20 seconds

    it('should handle transient errors', async () => {
      const mockFn = jest
        .fn()
        .mockRejectedValueOnce(new Error('timeout occurred'))
        .mockResolvedValue('success');
      
      const result = await retryWithBackoff(mockFn, { verbose: false });
      
      expect(result).toBe('success');
      expect(mockFn).toHaveBeenCalledTimes(2);
    });

    it('should work with async functions', async () => {
      let attempts = 0;
      const asyncFn = async () => {
        attempts++;
        if (attempts < 3) {
          throw new Error('not yet');
        }
        return 'done';
      };
      
      const result = await retryWithBackoff(asyncFn, { verbose: false });
      
      expect(result).toBe('done');
      expect(attempts).toBe(3);
    });
  });

  describe('classifyError', () => {
    describe('NETWORK errors', () => {
      it('should classify tunnel errors', () => {
        const error = new Error('tunnel connection failed');
        const classification = classifyError(error);
        
        expect(classification.type).toBe('NETWORK');
        expect(classification.category).toBe('tunnel_or_proxy');
        expect(classification.isTransient).toBe(true);
        expect(classification.recoverable).toBe(true);
      });

      it('should classify proxy errors', () => {
        const error = new Error('proxy connection refused');
        const classification = classifyError(error);
        
        expect(classification.type).toBe('NETWORK');
        expect(classification.isTransient).toBe(true);
      });

      it('should classify ECONNREFUSED errors', () => {
        const error = new Error('ECONNREFUSED: connection refused');
        const classification = classifyError(error);
        
        expect(classification.type).toBe('NETWORK');
        expect(classification.recoverable).toBe(true);
      });
    });

    describe('TIMEOUT errors', () => {
      it('should classify timeout errors', () => {
        const error = new Error('operation timeout');
        const classification = classifyError(error);
        
        expect(classification.type).toBe('TIMEOUT');
        expect(classification.category).toBe('timeout');
        expect(classification.isTransient).toBe(true);
        expect(classification.recoverable).toBe(true);
      });

      it('should classify timed out errors', () => {
        const error = new Error('request timed out');
        const classification = classifyError(error);
        
        expect(classification.type).toBe('TIMEOUT');
        expect(classification.isTransient).toBe(true);
      });
    });

    describe('BLOCKED errors', () => {
      it('should classify blocked errors', () => {
        const error = new Error('account blocked');
        const classification = classifyError(error);
        
        expect(classification.type).toBe('BLOCKED');
        expect(classification.category).toBe('authentication');
        expect(classification.isTransient).toBe(false);
        expect(classification.recoverable).toBe(false);
      });

      it('should classify 401 errors', () => {
        const error = new Error('401 unauthorized');
        const classification = classifyError(error);
        
        expect(classification.type).toBe('BLOCKED');
        expect(classification.recoverable).toBe(false);
      });

      it('should classify 403 errors', () => {
        const error = new Error('403 forbidden access');
        const classification = classifyError(error);
        
        expect(classification.type).toBe('BLOCKED');
        expect(classification.recoverable).toBe(false);
      });
    });

    describe('NOT_FOUND errors', () => {
      it('should classify 404 errors', () => {
        const error = new Error('404 not found');
        const classification = classifyError(error);
        
        expect(classification.type).toBe('NOT_FOUND');
        expect(classification.category).toBe('http_error');
        expect(classification.isTransient).toBe(false);
        expect(classification.recoverable).toBe(false);
      });

      it('should classify not found errors', () => {
        const error = new Error('resource not found');
        const classification = classifyError(error);
        
        expect(classification.type).toBe('NOT_FOUND');
        expect(classification.recoverable).toBe(false);
      });
    });

    describe('BROWSER_CRASH errors', () => {
      it('should classify crash errors', () => {
        const error = new Error('browser crash detected');
        const classification = classifyError(error);
        
        expect(classification.type).toBe('BROWSER_CRASH');
        expect(classification.category).toBe('browser');
        expect(classification.isTransient).toBe(true);
        expect(classification.recoverable).toBe(true);
      });

      it('should classify closed errors', () => {
        const error = new Error('browser closed unexpectedly');
        const classification = classifyError(error);
        
        expect(classification.type).toBe('BROWSER_CRASH');
        expect(classification.isTransient).toBe(true);
      });
    });

    describe('UNKNOWN errors', () => {
      it('should classify unknown errors', () => {
        const error = new Error('some random error');
        const classification = classifyError(error);
        
        expect(classification.type).toBe('UNKNOWN');
        expect(classification.category).toBe('unknown');
        expect(classification.isTransient).toBe(false);
        expect(classification.recoverable).toBe(false);
      });

      it('should handle errors without message', () => {
        const error = new Error();
        const classification = classifyError(error);
        
        expect(classification.type).toBe('UNKNOWN');
      });

      it('should handle null error', () => {
        const classification = classifyError(null);
        
        expect(classification.type).toBe('UNKNOWN');
      });

      it('should handle undefined error', () => {
        const classification = classifyError(undefined);
        
        expect(classification.type).toBe('UNKNOWN');
      });

      it('should handle error objects without message property', () => {
        const classification = classifyError({});
        
        expect(classification.type).toBe('UNKNOWN');
      });
    });

    describe('case insensitivity', () => {
      it('should handle uppercase error messages', () => {
        const error = new Error('TIMEOUT OCCURRED');
        const classification = classifyError(error);
        
        expect(classification.type).toBe('TIMEOUT');
      });

      it('should handle mixed case error messages', () => {
        const error = new Error('Tunnel Connection Failed');
        const classification = classifyError(error);
        
        expect(classification.type).toBe('NETWORK');
      });
    });

    describe('multiple keywords', () => {
      it('should prioritize timeout over blocked when both present', () => {
        // "timeout" keyword appears before "blocked" in error message
        const error = new Error('request timeout, account may be blocked');
        const classification = classifyError(error);
        
        // TIMEOUT check comes before BLOCKED check in the function
        expect(classification.type).toBe('TIMEOUT');
      });
    });
  });
});
