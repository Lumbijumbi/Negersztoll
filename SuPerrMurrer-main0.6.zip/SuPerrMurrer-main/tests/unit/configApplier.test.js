'use strict';

jest.mock('../../utils/configProfiles', () => ({
  applyProfile: jest.fn((config, profile) => {
    if (profile === 'fast') return { ...config, browser: { headless: true }, batch: { maxParallelWorkers: 8 } };
    if (profile === 'balanced') return { ...config, browser: { headless: false }, batch: { maxParallelWorkers: 4 } };
    if (profile === 'invalid') throw new Error('Unknown profile: invalid');
    return config;
  })
}));

const { applyUserConfig } = require('../../utils/configApplier');

describe('configApplier', () => {
  let systemConfig;

  beforeEach(() => {
    jest.spyOn(console, 'warn').mockImplementation(() => {});
    jest.spyOn(console, 'log').mockImplementation(() => {});
    systemConfig = {
      browser: { headless: false },
      batch: { maxParallelWorkers: 4, credentialsPerProxy: 10 },
      session: {},
      retry: {},
      notifications: {},
      performance: {},
      stability: {}
    };
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('should return systemConfig unchanged when userConfig is null', () => {
    const result = applyUserConfig(systemConfig, null);
    expect(result).toBe(systemConfig);
  });

  it('should apply a known profile', () => {
    const result = applyUserConfig(systemConfig, { profile: 'fast' });
    expect(result.batch.maxParallelWorkers).toBe(8);
    expect(result.browser.headless).toBe(true);
  });

  it('should skip profile application for "custom"', () => {
    const { applyProfile } = require('../../utils/configProfiles');
    applyProfile.mockClear();
    applyUserConfig(systemConfig, { profile: 'custom' });
    expect(applyProfile).not.toHaveBeenCalled();
  });

  it('should warn and continue when profile application throws', () => {
    applyUserConfig(systemConfig, { profile: 'invalid' });
    expect(console.warn).toHaveBeenCalledWith(expect.stringContaining('Failed to apply profile'));
  });

  describe('feature toggles', () => {
    it('should set session.enabled from features.sessionReuse', () => {
      const result = applyUserConfig(systemConfig, { features: { sessionReuse: true } });
      expect(result.session.enabled).toBe(true);
    });

    it('should set retry.enabled from features.retryQueue', () => {
      const result = applyUserConfig(systemConfig, { features: { retryQueue: false } });
      expect(result.retry.enabled).toBe(false);
    });

    it('should set performance.enableConnectionPool from features.connectionPool', () => {
      const result = applyUserConfig(systemConfig, { features: { connectionPool: true } });
      expect(result.performance.enableConnectionPool).toBe(true);
    });

    it('should set performance.autoTuneWorkers from features.autoTuneWorkers', () => {
      const result = applyUserConfig(systemConfig, { features: { autoTuneWorkers: false } });
      expect(result.performance.autoTuneWorkers).toBe(false);
    });

    it('should set stability.enableHealthChecks from features.healthChecks', () => {
      const result = applyUserConfig(systemConfig, { features: { healthChecks: true } });
      expect(result.stability.enableHealthChecks).toBe(true);
    });

    it('should set stability.enableAutoRecovery from features.autoRecovery', () => {
      const result = applyUserConfig(systemConfig, { features: { autoRecovery: true } });
      expect(result.stability.enableAutoRecovery).toBe(true);
    });

    it('should create session object if not present', () => {
      delete systemConfig.session;
      const result = applyUserConfig(systemConfig, { features: { sessionReuse: true } });
      expect(result.session).toBeDefined();
      expect(result.session.enabled).toBe(true);
    });

    it('should create retry object if not present', () => {
      delete systemConfig.retry;
      const result = applyUserConfig(systemConfig, { features: { retryQueue: true } });
      expect(result.retry.enabled).toBe(true);
    });

    it('should create performance object if not present for connectionPool', () => {
      delete systemConfig.performance;
      const result = applyUserConfig(systemConfig, { features: { connectionPool: true } });
      expect(result.performance.enableConnectionPool).toBe(true);
    });

    it('should create performance object if not present for autoTuneWorkers', () => {
      delete systemConfig.performance;
      const result = applyUserConfig(systemConfig, { features: { autoTuneWorkers: true } });
      expect(result.performance.autoTuneWorkers).toBe(true);
    });

    it('should create stability object if not present for healthChecks', () => {
      delete systemConfig.stability;
      const result = applyUserConfig(systemConfig, { features: { healthChecks: true } });
      expect(result.stability.enableHealthChecks).toBe(true);
    });

    it('should create stability object if not present for autoRecovery', () => {
      delete systemConfig.stability;
      const result = applyUserConfig(systemConfig, { features: { autoRecovery: true } });
      expect(result.stability.enableAutoRecovery).toBe(true);
    });
  });

  describe('overrides', () => {
    it('should apply maxParallelWorkers override', () => {
      const result = applyUserConfig(systemConfig, { overrides: { maxParallelWorkers: 10 } });
      expect(result.batch.maxParallelWorkers).toBe(10);
    });

    it('should apply headless override', () => {
      const result = applyUserConfig(systemConfig, { overrides: { headless: true } });
      expect(result.browser.headless).toBe(true);
    });

    it('should apply credentialsPerProxy override', () => {
      const result = applyUserConfig(systemConfig, { overrides: { credentialsPerProxy: 20 } });
      expect(result.batch.credentialsPerProxy).toBe(20);
    });

    it('should not apply non-numeric maxParallelWorkers', () => {
      const original = systemConfig.batch.maxParallelWorkers;
      applyUserConfig(systemConfig, { overrides: { maxParallelWorkers: 'ten' } });
      expect(systemConfig.batch.maxParallelWorkers).toBe(original);
    });
  });

  it('should return systemConfig when userConfig has no recognized keys', () => {
    const result = applyUserConfig(systemConfig, {});
    expect(result).toBe(systemConfig);
  });
});
