'use strict';

jest.mock('../../config', () => ({
  captcha: { username: 'test_user', password: 'test_pass' }
}));

// Mock axios as a virtual module since it may not be installed
const mockAxios = {
  post: jest.fn(),
  get: jest.fn()
};
jest.mock('axios', () => mockAxios, { virtual: true });

const axios = mockAxios;
const { solveDataDome } = require('../../utils/dataDomeSolver');

describe('dataDomeSolver', () => {
  let page;
  let frame;

  beforeEach(() => {
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
    jest.clearAllMocks();

    frame = {
      evaluate: jest.fn().mockResolvedValue('test-sitekey-123'),
    };

    page = {
      waitForSelector: jest.fn().mockResolvedValue({
        contentFrame: jest.fn().mockResolvedValue(frame),
        getAttribute: jest.fn().mockResolvedValue('https://captcha-delivery.com/captcha/?hash=abc')
      }),
      waitForNavigation: jest.fn().mockResolvedValue(undefined)
    };
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('should return false when no siteKey found', async () => {
    frame.evaluate.mockResolvedValueOnce(null);
    const result = await solveDataDome(page);
    expect(result).toBe(false);
    expect(console.error).toHaveBeenCalledWith(expect.stringContaining('Could not find DataDome sitekey'));
  });

  it('should return false when waitForSelector fails', async () => {
    page.waitForSelector.mockRejectedValue(new Error('selector timeout'));
    const result = await solveDataDome(page);
    expect(result).toBe(false);
    expect(console.error).toHaveBeenCalledWith(expect.stringContaining('selector timeout'));
  });

  it('should submit to DBC API and return true when token found on first poll', async () => {
    // Override the setTimeout to avoid 5-second delays
    const origSetTimeout = global.setTimeout;
    global.setTimeout = (fn, _ms) => origSetTimeout(fn, 0);

    axios.post.mockResolvedValue({ data: { captcha: '12345' } });
    // First poll immediately returns the solved token
    axios.get.mockResolvedValue({ data: { text: 'solved-token' } });

    const result = await solveDataDome(page);
    global.setTimeout = origSetTimeout;
    expect(result).toBe(true);
    expect(axios.post).toHaveBeenCalledWith(
      'http://api.dbcapi.me/api/captcha',
      expect.objectContaining({ username: 'test_user', type: 4 })
    );
  });

  it('should return false when axios.post fails', async () => {
    axios.post.mockRejectedValue(new Error('network error'));
    const result = await solveDataDome(page);
    expect(result).toBe(false);
  });

  it('should inject token and navigate when solved', async () => {
    const origSetTimeout = global.setTimeout;
    global.setTimeout = (fn, _ms) => origSetTimeout(fn, 0);

    axios.post.mockResolvedValue({ data: { captcha: '12345' } });
    axios.get.mockResolvedValue({ data: { text: 'my-token' } });

    const result = await solveDataDome(page);
    global.setTimeout = origSetTimeout;
    expect(result).toBe(true);
    expect(frame.evaluate).toHaveBeenCalledTimes(2);
    expect(page.waitForNavigation).toHaveBeenCalled();
  });

  it('should return false when waitForNavigation fails', async () => {
    const origSetTimeout = global.setTimeout;
    global.setTimeout = (fn, _ms) => origSetTimeout(fn, 0);

    axios.post.mockResolvedValue({ data: { captcha: '12345' } });
    axios.get.mockResolvedValue({ data: { text: 'my-token' } });
    page.waitForNavigation.mockRejectedValue(new Error('Navigation timeout'));

    const result = await solveDataDome(page);
    global.setTimeout = origSetTimeout;
    expect(result).toBe(false);
  });
});
