/**
 * Tests for fileHelper utility
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const {
  readJSONFile,
  writeJSONFile,
  writeJSONFileAtomic,
  readTextFile,
  writeTextFile,
  ensureDirectory,
  ensureDirectories
} = require('../../utils/fileHelper');

describe('FileHelper', () => {
  let testDir;

  beforeEach(() => {
    // Create a unique temp directory for each test
    testDir = fs.mkdtempSync(path.join(os.tmpdir(), 'filehelper-test-'));
  });

  afterEach(() => {
    // Clean up test directory
    if (fs.existsSync(testDir)) {
      fs.rmSync(testDir, { recursive: true, force: true });
    }
  });

  describe('readJSONFile', () => {
    it('should read and parse a valid JSON file', () => {
      const testFile = path.join(testDir, 'test.json');
      const testData = { foo: 'bar', count: 42 };
      fs.writeFileSync(testFile, JSON.stringify(testData), 'utf8');

      const result = readJSONFile(testFile);
      expect(result).toEqual(testData);
    });

    it('should return default value for non-existent file', () => {
      const testFile = path.join(testDir, 'nonexistent.json');
      const defaultValue = { default: true };

      const result = readJSONFile(testFile, defaultValue);
      expect(result).toEqual(defaultValue);
    });

    it('should return default value for invalid JSON', () => {
      const testFile = path.join(testDir, 'invalid.json');
      fs.writeFileSync(testFile, 'not valid json', 'utf8');

      const result = readJSONFile(testFile, null);
      expect(result).toBeNull();
    });

    it('should return null by default for non-existent file', () => {
      const testFile = path.join(testDir, 'nonexistent.json');
      const result = readJSONFile(testFile);
      expect(result).toBeNull();
    });
  });

  describe('writeJSONFile', () => {
    it('should write JSON data to file (pretty formatted)', () => {
      const testFile = path.join(testDir, 'output.json');
      const testData = { foo: 'bar', nested: { value: 123 } };

      const success = writeJSONFile(testFile, testData);
      expect(success).toBe(true);

      const content = fs.readFileSync(testFile, 'utf8');
      expect(JSON.parse(content)).toEqual(testData);
      expect(content).toContain('\n'); // Pretty formatted
    });

    it('should write JSON data to file (compact)', () => {
      const testFile = path.join(testDir, 'compact.json');
      const testData = { foo: 'bar' };

      const success = writeJSONFile(testFile, testData, { pretty: false });
      expect(success).toBe(true);

      const content = fs.readFileSync(testFile, 'utf8');
      expect(content).toBe('{"foo":"bar"}');
    });

    it('should return false on write error', () => {
      const invalidPath = path.join(testDir, 'nonexistent', 'deep', 'output.json');
      const success = writeJSONFile(invalidPath, { foo: 'bar' });
      expect(success).toBe(false);
    });
  });

  describe('writeJSONFileAtomic', () => {
    it('should write JSON data atomically', () => {
      const testFile = path.join(testDir, 'atomic.json');
      const testData = { atomic: true, value: 456 };

      const success = writeJSONFileAtomic(testFile, testData);
      expect(success).toBe(true);

      const content = fs.readFileSync(testFile, 'utf8');
      expect(JSON.parse(content)).toEqual(testData);
    });

    it('should overwrite existing file atomically', () => {
      const testFile = path.join(testDir, 'atomic.json');
      fs.writeFileSync(testFile, JSON.stringify({ old: 'data' }), 'utf8');

      const newData = { new: 'data' };
      const success = writeJSONFileAtomic(testFile, newData);
      expect(success).toBe(true);

      const content = fs.readFileSync(testFile, 'utf8');
      expect(JSON.parse(content)).toEqual(newData);
    });

    it('should not leave temp file after successful write', () => {
      const testFile = path.join(testDir, 'atomic.json');
      const tempFile = `${testFile}.tmp`;

      writeJSONFileAtomic(testFile, { test: true });
      expect(fs.existsSync(tempFile)).toBe(false);
    });
  });

  describe('readTextFile', () => {
    it('should read text file content', () => {
      const testFile = path.join(testDir, 'text.txt');
      const content = 'Hello, World!\nLine 2';
      fs.writeFileSync(testFile, content, 'utf8');

      const result = readTextFile(testFile);
      expect(result).toBe(content);
    });

    it('should return default value for non-existent file', () => {
      const testFile = path.join(testDir, 'nonexistent.txt');
      const result = readTextFile(testFile, 'default content');
      expect(result).toBe('default content');
    });

    it('should return empty string by default', () => {
      const testFile = path.join(testDir, 'nonexistent.txt');
      const result = readTextFile(testFile);
      expect(result).toBe('');
    });
  });

  describe('writeTextFile', () => {
    it('should write text content to file', () => {
      const testFile = path.join(testDir, 'output.txt');
      const content = 'Test content\nWith newlines';

      const success = writeTextFile(testFile, content);
      expect(success).toBe(true);

      const readContent = fs.readFileSync(testFile, 'utf8');
      expect(readContent).toBe(content);
    });

    it('should return false on write error', () => {
      const invalidPath = path.join(testDir, 'nonexistent', 'output.txt');
      const success = writeTextFile(invalidPath, 'content');
      expect(success).toBe(false);
    });
  });

  describe('ensureDirectory', () => {
    it('should create directory if it does not exist', () => {
      const newDir = path.join(testDir, 'newdir');
      expect(fs.existsSync(newDir)).toBe(false);

      const success = ensureDirectory(newDir);
      expect(success).toBe(true);
      expect(fs.existsSync(newDir)).toBe(true);
    });

    it('should succeed if directory already exists', () => {
      const existingDir = path.join(testDir, 'existing');
      fs.mkdirSync(existingDir);

      const success = ensureDirectory(existingDir);
      expect(success).toBe(true);
      expect(fs.existsSync(existingDir)).toBe(true);
    });

    it('should create nested directories with recursive option', () => {
      const nestedDir = path.join(testDir, 'level1', 'level2', 'level3');
      
      const success = ensureDirectory(nestedDir, true);
      expect(success).toBe(true);
      expect(fs.existsSync(nestedDir)).toBe(true);
    });
  });

  describe('ensureDirectories', () => {
    it('should create multiple directories', () => {
      const dirs = [
        path.join(testDir, 'dir1'),
        path.join(testDir, 'dir2'),
        path.join(testDir, 'dir3')
      ];

      const success = ensureDirectories(dirs);
      expect(success).toBe(true);
      
      dirs.forEach(dir => {
        expect(fs.existsSync(dir)).toBe(true);
      });
    });

    it('should succeed if some directories already exist', () => {
      const dir1 = path.join(testDir, 'existing');
      fs.mkdirSync(dir1);

      const dirs = [
        dir1,
        path.join(testDir, 'new1'),
        path.join(testDir, 'new2')
      ];

      const success = ensureDirectories(dirs);
      expect(success).toBe(true);
      
      dirs.forEach(dir => {
        expect(fs.existsSync(dir)).toBe(true);
      });
    });

    it('should handle empty array', () => {
      const success = ensureDirectories([]);
      expect(success).toBe(true);
    });
  });
});
