'use strict';

const { CONFIG_FILE_HEADER, generateConfigFile } = require('../../utils/configHelper');

describe('configHelper', () => {
  beforeEach(() => {
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'warn').mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('CONFIG_FILE_HEADER', () => {
    it('should be a non-empty string', () => {
      expect(typeof CONFIG_FILE_HEADER).toBe('string');
      expect(CONFIG_FILE_HEADER.length).toBeGreaterThan(0);
    });

    it('should contain expected header text', () => {
      expect(CONFIG_FILE_HEADER).toContain('Centralized Configuration');
    });
  });

  describe('generateConfigFile', () => {
    it('should return a string', () => {
      const result = generateConfigFile({ key: 'value' });
      expect(typeof result).toBe('string');
    });

    it('should include the CONFIG_FILE_HEADER', () => {
      const result = generateConfigFile({});
      expect(result).toContain(CONFIG_FILE_HEADER);
    });

    it('should include module.exports', () => {
      const result = generateConfigFile({ test: 123 });
      expect(result).toContain('module.exports =');
    });

    it('should serialize the config object as JSON', () => {
      const config = { browser: { headless: true }, batch: { workers: 4 } };
      const result = generateConfigFile(config);
      expect(result).toContain('"browser"');
      expect(result).toContain('"headless": true');
      expect(result).toContain('"workers": 4');
    });

    it('should handle empty config object', () => {
      const result = generateConfigFile({});
      expect(result).toContain('{}');
    });

    it('should handle nested config', () => {
      const config = { a: { b: { c: 42 } } };
      const result = generateConfigFile(config);
      expect(result).toContain('"a"');
      expect(result).toContain('"b"');
      expect(result).toContain('42');
    });

    it('should end with a newline', () => {
      const result = generateConfigFile({ x: 1 });
      expect(result.endsWith('\n')).toBe(true);
    });
  });
});
