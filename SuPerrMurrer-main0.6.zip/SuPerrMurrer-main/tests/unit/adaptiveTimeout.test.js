/**
 * Unit Tests for AdaptiveDetectionTimeout
 * Tests adaptive timeout adjustment based on historical timing data
 */

const AdaptiveDetectionTimeout = require('../../utils/adaptiveTimeout');

describe('AdaptiveDetectionTimeout', () => {
  let timeout;

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Constructor', () => {
    it('should initialize with default options', () => {
      timeout = new AdaptiveDetectionTimeout(12000);

      expect(timeout.baseTimeout).toBe(12000);
      expect(timeout.minTimeout).toBe(3000);
      expect(timeout.maxSamples).toBe(20);
      expect(timeout.bufferMultiplier).toBe(1.5);
      expect(timeout.successTimings).toEqual([]);
    });

    it('should initialize with custom options', () => {
      timeout = new AdaptiveDetectionTimeout(15000, {
        minTimeout: 5000,
        maxSamples: 30,
        bufferMultiplier: 2.0
      });

      expect(timeout.baseTimeout).toBe(15000);
      expect(timeout.minTimeout).toBe(5000);
      expect(timeout.maxSamples).toBe(30);
      expect(timeout.bufferMultiplier).toBe(2.0);
    });
  });

  describe('recordSuccess()', () => {
    beforeEach(() => {
      timeout = new AdaptiveDetectionTimeout(12000);
    });

    it('should record valid timing values', () => {
      timeout.recordSuccess(5000);

      expect(timeout.successTimings).toEqual([5000]);
    });

    it('should record multiple timing values', () => {
      timeout.recordSuccess(1000);
      timeout.recordSuccess(2000);
      timeout.recordSuccess(3000);

      expect(timeout.successTimings).toEqual([1000, 2000, 3000]);
    });

    it('should ignore negative values', () => {
      timeout.recordSuccess(5000);
      timeout.recordSuccess(-100);
      timeout.recordSuccess(6000);

      expect(timeout.successTimings).toEqual([5000, 6000]);
    });

    it('should ignore null values', () => {
      timeout.recordSuccess(5000);
      timeout.recordSuccess(null);
      timeout.recordSuccess(6000);

      expect(timeout.successTimings).toEqual([5000, 6000]);
    });

    it('should ignore undefined values', () => {
      timeout.recordSuccess(5000);
      timeout.recordSuccess(undefined);
      timeout.recordSuccess(6000);

      expect(timeout.successTimings).toEqual([5000, 6000]);
    });

    it('should ignore non-numeric values', () => {
      timeout.recordSuccess(5000);
      timeout.recordSuccess('invalid');
      timeout.recordSuccess(6000);

      expect(timeout.successTimings).toEqual([5000, 6000]);
    });

    it('should accept zero as valid timing', () => {
      timeout.recordSuccess(0);

      expect(timeout.successTimings).toEqual([0]);
    });

    it('should maintain sliding window when maxSamples exceeded', () => {
      timeout = new AdaptiveDetectionTimeout(12000, { maxSamples: 5 });

      for (let i = 1; i <= 10; i++) {
        timeout.recordSuccess(i * 1000);
      }

      expect(timeout.successTimings.length).toBe(5);
      expect(timeout.successTimings).toEqual([6000, 7000, 8000, 9000, 10000]);
    });

    it('should remove oldest sample when exceeding maxSamples', () => {
      timeout = new AdaptiveDetectionTimeout(12000, { maxSamples: 3 });

      timeout.recordSuccess(1000);
      timeout.recordSuccess(2000);
      timeout.recordSuccess(3000);
      timeout.recordSuccess(4000);

      expect(timeout.successTimings).toEqual([2000, 3000, 4000]);
    });
  });

  describe('getTimeout()', () => {
    beforeEach(() => {
      timeout = new AdaptiveDetectionTimeout(12000);
    });

    it('should return base timeout when no samples', () => {
      expect(timeout.getTimeout()).toBe(12000);
    });

    it('should return base timeout with 1 sample', () => {
      timeout.recordSuccess(5000);

      expect(timeout.getTimeout()).toBe(12000);
    });

    it('should return base timeout with 2 samples', () => {
      timeout.recordSuccess(5000);
      timeout.recordSuccess(6000);

      expect(timeout.getTimeout()).toBe(12000);
    });

    it('should adapt timeout after 3 samples', () => {
      timeout.recordSuccess(2000);
      timeout.recordSuccess(3000);
      timeout.recordSuccess(4000);

      const adaptive = timeout.getTimeout();

      expect(adaptive).toBeLessThan(12000);
      expect(adaptive).toBeGreaterThan(3000);
    });

    it('should calculate p95 correctly with 5 samples', () => {
      timeout = new AdaptiveDetectionTimeout(20000, { bufferMultiplier: 1.5 });

      timeout.recordSuccess(2000);
      timeout.recordSuccess(3000);
      timeout.recordSuccess(4000);
      timeout.recordSuccess(5000);
      timeout.recordSuccess(10000);

      // p95 of [2000, 3000, 4000, 5000, 10000] is 10000 (index 4)
      // adaptive = ceil(10000 * 1.5) = 15000
      const adaptive = timeout.getTimeout();

      expect(adaptive).toBe(15000);
    });

    it('should cap at base timeout when adaptive exceeds it', () => {
      timeout = new AdaptiveDetectionTimeout(12000, { bufferMultiplier: 1.5 });

      timeout.recordSuccess(2000);
      timeout.recordSuccess(3000);
      timeout.recordSuccess(4000);
      timeout.recordSuccess(5000);
      timeout.recordSuccess(10000);

      // p95 = 10000, adaptive = 15000, but capped at 12000
      const adaptive = timeout.getTimeout();

      expect(adaptive).toBe(12000);
    });

    it('should respect min timeout floor', () => {
      timeout = new AdaptiveDetectionTimeout(12000, {
        minTimeout: 5000,
        bufferMultiplier: 1.5
      });

      timeout.recordSuccess(100);
      timeout.recordSuccess(200);
      timeout.recordSuccess(300);

      const adaptive = timeout.getTimeout();

      expect(adaptive).toBeGreaterThanOrEqual(5000);
    });

    it('should handle all same values', () => {
      timeout = new AdaptiveDetectionTimeout(12000, { bufferMultiplier: 1.5 });

      timeout.recordSuccess(5000);
      timeout.recordSuccess(5000);
      timeout.recordSuccess(5000);
      timeout.recordSuccess(5000);

      // p95 of all 5000s is 5000, with 1.5x buffer = 7500
      const adaptive = timeout.getTimeout();

      expect(adaptive).toBe(7500);
    });

    it('should handle single very slow outlier', () => {
      timeout = new AdaptiveDetectionTimeout(15000, { bufferMultiplier: 1.5 });

      timeout.recordSuccess(2000);
      timeout.recordSuccess(2100);
      timeout.recordSuccess(2200);
      timeout.recordSuccess(2300);
      timeout.recordSuccess(12000); // Outlier

      // p95 should be 12000
      // adaptive = ceil(12000 * 1.5) = 18000, capped at 15000
      const adaptive = timeout.getTimeout();

      expect(adaptive).toBe(15000);
    });

    it('should apply buffer multiplier correctly', () => {
      const timeout1 = new AdaptiveDetectionTimeout(20000, { bufferMultiplier: 1.5 });
      const timeout2 = new AdaptiveDetectionTimeout(20000, { bufferMultiplier: 2.0 });

      for (let i = 0; i < 5; i++) {
        timeout1.recordSuccess(4000);
        timeout2.recordSuccess(4000);
      }

      // p95 = 4000, so adaptive1 = 6000, adaptive2 = 8000
      expect(timeout1.getTimeout()).toBe(6000);
      expect(timeout2.getTimeout()).toBe(8000);
    });

    it('should round up adaptive timeout', () => {
      timeout = new AdaptiveDetectionTimeout(20000, { bufferMultiplier: 1.5 });

      timeout.recordSuccess(3333); // Will create non-integer result
      timeout.recordSuccess(3333);
      timeout.recordSuccess(3333);

      const adaptive = timeout.getTimeout();

      // 3333 * 1.5 = 4999.5, should ceil to 5000
      expect(adaptive).toBe(5000);
    });
  });

  describe('getStats()', () => {
    beforeEach(() => {
      timeout = new AdaptiveDetectionTimeout(12000);
    });

    it('should return correct stats with no samples', () => {
      const stats = timeout.getStats();

      expect(stats.samples).toBe(0);
      expect(stats.currentTimeout).toBe(12000);
    });

    it('should return correct stats with samples', () => {
      timeout.recordSuccess(1000);
      timeout.recordSuccess(2000);
      timeout.recordSuccess(3000);
      timeout.recordSuccess(4000);
      timeout.recordSuccess(5000);

      const stats = timeout.getStats();

      expect(stats.samples).toBe(5);
      expect(stats.min).toBe(1000);
      expect(stats.max).toBe(5000);
      expect(stats.median).toBe(3000);
      expect(stats.p95).toBe(5000);
      expect(stats.currentTimeout).toBeDefined();
    });

    it('should calculate correct median with odd number of samples', () => {
      timeout.recordSuccess(1000);
      timeout.recordSuccess(2000);
      timeout.recordSuccess(3000);

      const stats = timeout.getStats();

      expect(stats.median).toBe(2000);
    });

    it('should calculate correct median with even number of samples', () => {
      timeout.recordSuccess(1000);
      timeout.recordSuccess(2000);
      timeout.recordSuccess(3000);
      timeout.recordSuccess(4000);

      const stats = timeout.getStats();

      expect(stats.median).toBe(3000); // Floor(4/2) = index 2, which is 3000
    });

    it('should calculate correct p95 with various sample sizes', () => {
      timeout.recordSuccess(1000);
      timeout.recordSuccess(2000);
      timeout.recordSuccess(3000);

      let stats = timeout.getStats();
      expect(stats.p95).toBe(3000);

      timeout.recordSuccess(4000);
      timeout.recordSuccess(5000);

      stats = timeout.getStats();
      expect(stats.p95).toBe(5000);
    });

    it('should update currentTimeout in stats', () => {
      timeout.recordSuccess(1000);
      timeout.recordSuccess(2000);

      let stats = timeout.getStats();
      expect(stats.currentTimeout).toBe(12000); // Base timeout with < 3 samples

      timeout.recordSuccess(3000);

      stats = timeout.getStats();
      expect(stats.currentTimeout).toBeLessThan(12000); // Should adapt
    });

    it('should handle single sample', () => {
      timeout.recordSuccess(5000);

      const stats = timeout.getStats();

      expect(stats.samples).toBe(1);
      expect(stats.min).toBe(5000);
      expect(stats.max).toBe(5000);
      expect(stats.median).toBe(5000);
      expect(stats.p95).toBe(5000);
    });
  });

  describe('Edge Cases', () => {
    it('should handle very large timing values', () => {
      timeout = new AdaptiveDetectionTimeout(120000, { bufferMultiplier: 1.5 });

      timeout.recordSuccess(50000);
      timeout.recordSuccess(60000);
      timeout.recordSuccess(70000);

      const adaptive = timeout.getTimeout();

      expect(adaptive).toBeLessThanOrEqual(120000);
    });

    it('should handle very small timing values', () => {
      timeout = new AdaptiveDetectionTimeout(12000, { 
        minTimeout: 100,
        bufferMultiplier: 1.5 
      });

      timeout.recordSuccess(1);
      timeout.recordSuccess(2);
      timeout.recordSuccess(3);

      const adaptive = timeout.getTimeout();

      expect(adaptive).toBeGreaterThanOrEqual(100);
    });

    it('should handle maxSamples of 1', () => {
      timeout = new AdaptiveDetectionTimeout(12000, { maxSamples: 1 });

      timeout.recordSuccess(5000);
      timeout.recordSuccess(6000);
      timeout.recordSuccess(7000);

      expect(timeout.successTimings.length).toBe(1);
      expect(timeout.successTimings[0]).toBe(7000);
    });

    it('should handle buffer multiplier of 1.0', () => {
      timeout = new AdaptiveDetectionTimeout(12000, { bufferMultiplier: 1.0 });

      timeout.recordSuccess(4000);
      timeout.recordSuccess(4000);
      timeout.recordSuccess(4000);

      // p95 = 4000, with 1.0x buffer = 4000
      const adaptive = timeout.getTimeout();

      expect(adaptive).toBe(4000);
    });

    it('should handle buffer multiplier less than 1.0', () => {
      timeout = new AdaptiveDetectionTimeout(12000, { bufferMultiplier: 0.8 });

      timeout.recordSuccess(5000);
      timeout.recordSuccess(5000);
      timeout.recordSuccess(5000);

      // p95 = 5000, with 0.8x buffer = 4000
      const adaptive = timeout.getTimeout();

      expect(adaptive).toBe(4000);
    });
  });

  describe('Integration Scenarios', () => {
    it('should adapt timeout based on improving performance', () => {
      timeout = new AdaptiveDetectionTimeout(12000, { 
        maxSamples: 6,
        bufferMultiplier: 1.5 
      });

      // Initial slow timings
      timeout.recordSuccess(8000);
      timeout.recordSuccess(8500);
      timeout.recordSuccess(9000);

      let adaptive = timeout.getTimeout();
      expect(adaptive).toBe(12000); // Capped at base

      // Performance improves - sliding window replaces slow timings
      timeout.recordSuccess(3000);
      timeout.recordSuccess(3500);
      timeout.recordSuccess(4000);
      timeout.recordSuccess(3000);

      // Now window has [8500, 9000, 3000, 3500, 4000, 3000]
      // p95 at index 5 = 9000, still capped
      // Add more to push out the slow ones
      timeout.recordSuccess(3500);
      timeout.recordSuccess(4000);

      // Now window has [3000, 3500, 4000, 3000, 3500, 4000]
      // p95 at index 5 = 4000, adaptive = 6000
      adaptive = timeout.getTimeout();
      expect(adaptive).toBeLessThan(12000);
      expect(adaptive).toBe(6000);
    });

    it('should adapt timeout based on degrading performance', () => {
      timeout = new AdaptiveDetectionTimeout(20000, { 
        maxSamples: 5,
        bufferMultiplier: 1.5 
      });

      // Initial fast timings
      timeout.recordSuccess(2000);
      timeout.recordSuccess(2500);
      timeout.recordSuccess(3000);

      let adaptive = timeout.getTimeout();
      let initial = adaptive;

      // Performance degrades (but still within window)
      timeout.recordSuccess(5000);
      timeout.recordSuccess(5500);

      adaptive = timeout.getTimeout();
      expect(adaptive).toBeGreaterThan(initial);
    });

    it('should maintain stable timeout with consistent timings', () => {
      timeout = new AdaptiveDetectionTimeout(12000, { bufferMultiplier: 1.5 });

      // Record consistent timings
      for (let i = 0; i < 10; i++) {
        timeout.recordSuccess(4000);
      }

      const adaptive1 = timeout.getTimeout();

      // Record more consistent timings
      for (let i = 0; i < 10; i++) {
        timeout.recordSuccess(4000);
      }

      const adaptive2 = timeout.getTimeout();

      expect(adaptive1).toBe(adaptive2);
      expect(adaptive1).toBe(6000); // 4000 * 1.5
    });

    it('should handle mixed fast and slow timings', () => {
      timeout = new AdaptiveDetectionTimeout(15000, { bufferMultiplier: 1.5 });

      // Mix of fast and slow
      timeout.recordSuccess(1000);
      timeout.recordSuccess(2000);
      timeout.recordSuccess(3000);
      timeout.recordSuccess(10000);
      timeout.recordSuccess(11000);

      // p95 should reflect the slower timings
      const adaptive = timeout.getTimeout();

      expect(adaptive).toBeGreaterThan(4500); // Not based on fast timings
      expect(adaptive).toBeLessThanOrEqual(15000);
    });
  });

  describe('Performance Characteristics', () => {
    it('should adapt more aggressively with higher buffer multiplier', () => {
      const timeout1 = new AdaptiveDetectionTimeout(20000, { bufferMultiplier: 1.2 });
      const timeout2 = new AdaptiveDetectionTimeout(20000, { bufferMultiplier: 2.0 });

      const timings = [4000, 4500, 5000, 5500, 6000];
      timings.forEach(t => {
        timeout1.recordSuccess(t);
        timeout2.recordSuccess(t);
      });

      const adaptive1 = timeout1.getTimeout();
      const adaptive2 = timeout2.getTimeout();

      expect(adaptive2).toBeGreaterThan(adaptive1);
    });

    it('should be more conservative with lower minTimeout', () => {
      const timeout1 = new AdaptiveDetectionTimeout(12000, { minTimeout: 2000 });
      const timeout2 = new AdaptiveDetectionTimeout(12000, { minTimeout: 5000 });

      const fastTimings = [100, 200, 300];
      fastTimings.forEach(t => {
        timeout1.recordSuccess(t);
        timeout2.recordSuccess(t);
      });

      const adaptive1 = timeout1.getTimeout();
      const adaptive2 = timeout2.getTimeout();

      expect(adaptive2).toBeGreaterThanOrEqual(5000);
      expect(adaptive1).toBeLessThan(adaptive2);
    });
  });
});
