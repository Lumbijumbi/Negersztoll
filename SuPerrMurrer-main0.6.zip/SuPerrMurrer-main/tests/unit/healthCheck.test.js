/**
 * Unit Tests for HealthCheckSystem Module
 * Tests health check registration, execution, history tracking, and default checks
 */

const HealthCheckSystem = require('../../utils/healthCheck');
const os = require('os');
const fs = require('fs').promises;

// Mock modules
jest.mock('os');
jest.mock('fs', () => ({
  promises: {
    writeFile: jest.fn(),
    unlink: jest.fn()
  }
}));

describe('HealthCheckSystem', () => {
  let healthCheck;

  beforeEach(() => {
    jest.clearAllMocks();
    healthCheck = new HealthCheckSystem();

    // Mock os functions
    os.totalmem.mockReturnValue(16 * 1024 * 1024 * 1024); // 16GB
    os.freemem.mockReturnValue(8 * 1024 * 1024 * 1024); // 8GB

    // Spy on console methods
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    console.log.mockRestore();
    console.error.mockRestore();
  });

  describe('Constructor', () => {
    it('should initialize with empty checks and history', () => {
      expect(healthCheck.checks).toBeInstanceOf(Map);
      expect(healthCheck.checks.size).toBe(0);
      expect(healthCheck.history).toEqual([]);
      expect(healthCheck.maxHistorySize).toBe(100);
    });
  });

  describe('register()', () => {
    it('should register a health check with default interval', () => {
      const checkFn = jest.fn().mockResolvedValue({ healthy: true, message: 'OK' });

      healthCheck.register('test-check', checkFn);

      expect(healthCheck.checks.has('test-check')).toBe(true);
      
      const registered = healthCheck.checks.get('test-check');
      expect(registered.checkFn).toBe(checkFn);
      expect(registered.interval).toBe(30000);
      expect(registered.lastRun).toBe(0);
      expect(registered.lastResult).toBeNull();
    });

    it('should register a health check with custom interval', () => {
      const checkFn = jest.fn().mockResolvedValue({ healthy: true, message: 'OK' });

      healthCheck.register('test-check', checkFn, 60000);

      const registered = healthCheck.checks.get('test-check');
      expect(registered.interval).toBe(60000);
    });

    it('should allow multiple checks to be registered', () => {
      healthCheck.register('check-1', jest.fn(), 10000);
      healthCheck.register('check-2', jest.fn(), 20000);
      healthCheck.register('check-3', jest.fn(), 30000);

      expect(healthCheck.checks.size).toBe(3);
      expect(healthCheck.checks.has('check-1')).toBe(true);
      expect(healthCheck.checks.has('check-2')).toBe(true);
      expect(healthCheck.checks.has('check-3')).toBe(true);
    });

    it('should overwrite existing check with same name', () => {
      const checkFn1 = jest.fn();
      const checkFn2 = jest.fn();

      healthCheck.register('test-check', checkFn1);
      healthCheck.register('test-check', checkFn2);

      expect(healthCheck.checks.size).toBe(1);
      expect(healthCheck.checks.get('test-check').checkFn).toBe(checkFn2);
    });
  });

  describe('runAll()', () => {
    it('should run all registered checks', async () => {
      const check1 = jest.fn().mockResolvedValue({ healthy: true, message: 'Check 1 OK' });
      const check2 = jest.fn().mockResolvedValue({ healthy: true, message: 'Check 2 OK' });

      healthCheck.register('check-1', check1, 0);
      healthCheck.register('check-2', check2, 0);

      const results = await healthCheck.runAll();

      expect(check1).toHaveBeenCalled();
      expect(check2).toHaveBeenCalled();
      expect(results['check-1']).toBeDefined();
      expect(results['check-1'].healthy).toBe(true);
      expect(results['check-1'].message).toBe('Check 1 OK');
      expect(results['check-2']).toBeDefined();
      expect(results['check-2'].healthy).toBe(true);
    });

    it('should respect check intervals', async () => {
      const checkFn = jest.fn().mockResolvedValue({ healthy: true, message: 'OK' });
      
      healthCheck.register('test-check', checkFn, 10000);

      // First run - should execute
      await healthCheck.runAll();
      expect(checkFn).toHaveBeenCalledTimes(1);

      // Second run immediately - should not execute (interval not passed)
      await healthCheck.runAll();
      expect(checkFn).toHaveBeenCalledTimes(1);
    });

    it('should use cached results when interval not met', async () => {
      const checkFn = jest.fn().mockResolvedValue({ healthy: true, message: 'OK' });
      
      healthCheck.register('test-check', checkFn, 10000);

      const results1 = await healthCheck.runAll();
      const results2 = await healthCheck.runAll();

      expect(results2['test-check']).toEqual(results1['test-check']);
    });

    it('should handle check function errors gracefully', async () => {
      const errorCheck = jest.fn().mockRejectedValue(new Error('Check failed'));

      healthCheck.register('error-check', errorCheck, 0);

      const results = await healthCheck.runAll();

      expect(results['error-check']).toBeDefined();
      expect(results['error-check'].healthy).toBe(false);
      expect(results['error-check'].message).toContain('Check failed');
      expect(results['error-check'].details.error).toBe('Check failed');
    });

    it('should add timestamp to results', async () => {
      const checkFn = jest.fn().mockResolvedValue({ healthy: true, message: 'OK' });
      
      healthCheck.register('test-check', checkFn, 0);

      const results = await healthCheck.runAll();

      expect(results['test-check'].timestamp).toBeDefined();
      expect(typeof results['test-check'].timestamp).toBe('number');
    });

    it('should track check results in history', async () => {
      const checkFn = jest.fn().mockResolvedValue({ healthy: true, message: 'OK' });
      
      healthCheck.register('test-check', checkFn, 0);

      await healthCheck.runAll();
      await healthCheck.runAll();

      expect(healthCheck.history.length).toBe(2);
      expect(healthCheck.history[0].timestamp).toBeDefined();
      expect(healthCheck.history[0].results).toBeDefined();
    });

    it('should limit history size to maxHistorySize', async () => {
      healthCheck.maxHistorySize = 5;
      
      const checkFn = jest.fn().mockResolvedValue({ healthy: true, message: 'OK' });
      healthCheck.register('test-check', checkFn, 0);

      for (let i = 0; i < 10; i++) {
        await healthCheck.runAll();
      }

      expect(healthCheck.history.length).toBe(5);
    });

    it('should handle checks with details in results', async () => {
      const checkFn = jest.fn().mockResolvedValue({
        healthy: true,
        message: 'OK',
        details: { metric: 95, threshold: 100 }
      });

      healthCheck.register('test-check', checkFn, 0);

      const results = await healthCheck.runAll();

      expect(results['test-check'].details).toEqual({ metric: 95, threshold: 100 });
    });

    it('should return empty object when no checks registered', async () => {
      const results = await healthCheck.runAll();

      expect(results).toEqual({});
      expect(healthCheck.history.length).toBe(1);
    });
  });

  describe('getOverallHealth()', () => {
    it('should return healthy status when no checks configured', () => {
      const overall = healthCheck.getOverallHealth();

      expect(overall.healthy).toBe(true);
      expect(overall.score).toBe(100);
      expect(overall.message).toBe('No checks configured');
    });

    it('should calculate correct score with all healthy checks', async () => {
      healthCheck.register('check-1', jest.fn().mockResolvedValue({ healthy: true, message: 'OK' }), 0);
      healthCheck.register('check-2', jest.fn().mockResolvedValue({ healthy: true, message: 'OK' }), 0);
      healthCheck.register('check-3', jest.fn().mockResolvedValue({ healthy: true, message: 'OK' }), 0);

      await healthCheck.runAll();

      const overall = healthCheck.getOverallHealth();

      expect(overall.healthy).toBe(true);
      expect(overall.score).toBe('100.0');
      expect(overall.totalChecks).toBe(3);
      expect(overall.healthyChecks).toBe(3);
      expect(overall.failingChecks).toEqual([]);
      expect(overall.message).toBe('All systems operational');
    });

    it('should calculate correct score with some failing checks', async () => {
      healthCheck.register('check-1', jest.fn().mockResolvedValue({ healthy: true, message: 'OK' }), 0);
      healthCheck.register('check-2', jest.fn().mockResolvedValue({ healthy: false, message: 'Failed' }), 0);
      healthCheck.register('check-3', jest.fn().mockResolvedValue({ healthy: true, message: 'OK' }), 0);

      await healthCheck.runAll();

      const overall = healthCheck.getOverallHealth();

      expect(overall.healthy).toBe(false);
      expect(overall.score).toBe('66.7'); // 2/3 = 66.7%
      expect(overall.totalChecks).toBe(3);
      expect(overall.healthyChecks).toBe(2);
      expect(overall.failingChecks.length).toBe(1);
      expect(overall.failingChecks[0]).toContain('check-2');
      expect(overall.message).toContain('1 check(s) failing');
    });

    it('should list all failing checks', async () => {
      healthCheck.register('check-1', jest.fn().mockResolvedValue({ healthy: false, message: 'Error 1' }), 0);
      healthCheck.register('check-2', jest.fn().mockResolvedValue({ healthy: false, message: 'Error 2' }), 0);
      healthCheck.register('check-3', jest.fn().mockResolvedValue({ healthy: true, message: 'OK' }), 0);

      await healthCheck.runAll();

      const overall = healthCheck.getOverallHealth();

      expect(overall.failingChecks.length).toBe(2);
      expect(overall.failingChecks[0]).toContain('check-1');
      expect(overall.failingChecks[0]).toContain('Error 1');
      expect(overall.failingChecks[1]).toContain('check-2');
      expect(overall.failingChecks[1]).toContain('Error 2');
      expect(overall.message).toContain('2 check(s) failing');
    });

    it('should handle checks that have not run yet', () => {
      healthCheck.register('check-1', jest.fn(), 0);

      const overall = healthCheck.getOverallHealth();

      expect(overall.healthy).toBe(true);
      expect(overall.score).toBe('100.0');
      expect(overall.totalChecks).toBe(0);
    });
  });

  describe('getHistory()', () => {
    it('should return empty array when no history', () => {
      const history = healthCheck.getHistory();

      expect(history).toEqual([]);
    });

    it('should return last N entries by default (10)', async () => {
      const checkFn = jest.fn().mockResolvedValue({ healthy: true, message: 'OK' });
      healthCheck.register('test-check', checkFn, 0);

      for (let i = 0; i < 15; i++) {
        await healthCheck.runAll();
      }

      const history = healthCheck.getHistory();

      expect(history.length).toBe(10);
    });

    it('should return specified number of entries', async () => {
      const checkFn = jest.fn().mockResolvedValue({ healthy: true, message: 'OK' });
      healthCheck.register('test-check', checkFn, 0);

      for (let i = 0; i < 10; i++) {
        await healthCheck.runAll();
      }

      const history = healthCheck.getHistory(5);

      expect(history.length).toBe(5);
    });

    it('should return entries in chronological order', async () => {
      const checkFn = jest.fn().mockResolvedValue({ healthy: true, message: 'OK' });
      healthCheck.register('test-check', checkFn, 0);

      await healthCheck.runAll();
      const time1 = Date.now();
      
      await new Promise(resolve => setTimeout(resolve, 10));
      
      await healthCheck.runAll();

      const history = healthCheck.getHistory();

      expect(history[0].timestamp).toBeLessThan(history[1].timestamp);
    });
  });

  describe('createDefaultChecks()', () => {
    it('should create all default checks', () => {
      const checks = HealthCheckSystem.createDefaultChecks();

      expect(checks.proxyHealth).toBeDefined();
      expect(checks.workerHealth).toBeDefined();
      expect(checks.memoryHealth).toBeDefined();
      expect(checks.fileSystemHealth).toBeDefined();
      expect(checks.retryQueueHealth).toBeDefined();
    });

    describe('proxyHealth check', () => {
      it('should pass when no proxy manager', async () => {
        const checks = HealthCheckSystem.createDefaultChecks({});
        const result = await checks.proxyHealth();

        expect(result.healthy).toBe(true);
        expect(result.message).toContain('No proxy manager');
      });

      it('should pass when failure rate is low', async () => {
        const checks = HealthCheckSystem.createDefaultChecks({ 
          proxyManager: {},
          proxyFailureRate: 25 
        });
        const result = await checks.proxyHealth();

        expect(result.healthy).toBe(true);
        expect(result.message).toContain('25.0%');
      });

      it('should fail when failure rate is too high', async () => {
        const checks = HealthCheckSystem.createDefaultChecks({ 
          proxyManager: {},
          proxyFailureRate: 60 
        });
        const result = await checks.proxyHealth();

        expect(result.healthy).toBe(false);
        expect(result.message).toContain('too high');
        expect(result.details.failureRate).toBe(60);
      });
    });

    describe('workerHealth check', () => {
      it('should pass when no workers started', async () => {
        const checks = HealthCheckSystem.createDefaultChecks({});
        const result = await checks.workerHealth();

        expect(result.healthy).toBe(true);
        expect(result.message).toContain('No workers started');
      });

      it('should pass when crash rate is low', async () => {
        const checks = HealthCheckSystem.createDefaultChecks({
          workerStarts: 100,
          workerCrashes: 10
        });
        const result = await checks.workerHealth();

        expect(result.healthy).toBe(true);
        expect(result.message).toContain('10.0%');
      });

      it('should fail when crash rate is too high', async () => {
        const checks = HealthCheckSystem.createDefaultChecks({
          workerStarts: 100,
          workerCrashes: 40
        });
        const result = await checks.workerHealth();

        expect(result.healthy).toBe(false);
        expect(result.message).toContain('too high');
        expect(result.details.crashRate).toBe(40);
      });
    });

    describe('memoryHealth check', () => {
      it('should pass when memory usage is normal', async () => {
        os.totalmem.mockReturnValue(16 * 1024 * 1024 * 1024);
        os.freemem.mockReturnValue(8 * 1024 * 1024 * 1024); // 50% usage

        const checks = HealthCheckSystem.createDefaultChecks();
        const result = await checks.memoryHealth();

        expect(result.healthy).toBe(true);
        expect(result.message).toContain('50.0%');
        expect(result.details.usedPercent).toBe('50.0');
      });

      it('should fail when memory usage is critical', async () => {
        os.totalmem.mockReturnValue(16 * 1024 * 1024 * 1024);
        os.freemem.mockReturnValue(1 * 1024 * 1024 * 1024); // ~93.75% usage

        const checks = HealthCheckSystem.createDefaultChecks();
        const result = await checks.memoryHealth();

        expect(result.healthy).toBe(false);
        expect(result.message).toContain('critical');
        expect(parseFloat(result.details.usedPercent)).toBeGreaterThan(90);
      });
    });

    describe('fileSystemHealth check', () => {
      it('should pass when file system is accessible', async () => {
        fs.writeFile.mockResolvedValue();
        fs.unlink.mockResolvedValue();

        const checks = HealthCheckSystem.createDefaultChecks();
        const result = await checks.fileSystemHealth();

        expect(result.healthy).toBe(true);
        expect(result.message).toContain('OK');
        expect(fs.writeFile).toHaveBeenCalled();
        expect(fs.unlink).toHaveBeenCalled();
      });

      it('should fail when file system write fails', async () => {
        fs.writeFile.mockRejectedValue(new Error('Write failed'));

        const checks = HealthCheckSystem.createDefaultChecks();
        const result = await checks.fileSystemHealth();

        expect(result.healthy).toBe(false);
        expect(result.message).toContain('failed');
        expect(result.details.error).toBe('Write failed');
      });

      it('should fail when file system unlink fails', async () => {
        fs.writeFile.mockResolvedValue();
        fs.unlink.mockRejectedValue(new Error('Unlink failed'));

        const checks = HealthCheckSystem.createDefaultChecks();
        const result = await checks.fileSystemHealth();

        expect(result.healthy).toBe(false);
        expect(result.message).toContain('failed');
      });
    });

    describe('retryQueueHealth check', () => {
      it('should pass when retry queue not enabled', async () => {
        const checks = HealthCheckSystem.createDefaultChecks({});
        const result = await checks.retryQueueHealth();

        expect(result.healthy).toBe(true);
        expect(result.message).toContain('not enabled');
      });

      it('should pass when queue size is normal', async () => {
        const mockQueue = {
          getStats: jest.fn().mockReturnValue({ currentQueueSize: 50 })
        };

        const checks = HealthCheckSystem.createDefaultChecks({ retryQueue: mockQueue });
        const result = await checks.retryQueueHealth();

        expect(result.healthy).toBe(true);
        expect(result.message).toContain('50 items');
      });

      it('should fail when queue has backlog', async () => {
        const mockQueue = {
          getStats: jest.fn().mockReturnValue({ currentQueueSize: 150 })
        };

        const checks = HealthCheckSystem.createDefaultChecks({ retryQueue: mockQueue });
        const result = await checks.retryQueueHealth();

        expect(result.healthy).toBe(false);
        expect(result.message).toContain('backlog');
        expect(result.details.queueSize).toBe(150);
      });

      it('should handle retry queue without getStats method', async () => {
        const mockQueue = {};

        const checks = HealthCheckSystem.createDefaultChecks({ retryQueue: mockQueue });
        const result = await checks.retryQueueHealth();

        expect(result.healthy).toBe(true);
        expect(result.details.queueSize).toBe(0);
      });
    });
  });

  describe('exportReport()', () => {
    it('should export overall health and check details', async () => {
      healthCheck.register('check-1', jest.fn().mockResolvedValue({ healthy: true, message: 'OK' }), 0);
      healthCheck.register('check-2', jest.fn().mockResolvedValue({ 
        healthy: false, 
        message: 'Failed',
        details: { reason: 'timeout' }
      }), 0);

      await healthCheck.runAll();

      const report = healthCheck.exportReport();

      expect(report.overall).toBeDefined();
      expect(report.overall.healthy).toBe(false);
      expect(report.overall.score).toBe('50.0');

      expect(report.checks).toBeDefined();
      expect(report.checks['check-1']).toBeDefined();
      expect(report.checks['check-1'].healthy).toBe(true);
      expect(report.checks['check-2']).toBeDefined();
      expect(report.checks['check-2'].healthy).toBe(false);
      expect(report.checks['check-2'].details.reason).toBe('timeout');

      expect(report.timestamp).toBeDefined();
    });

    it('should include lastChecked timestamp for each check', async () => {
      healthCheck.register('test-check', jest.fn().mockResolvedValue({ healthy: true, message: 'OK' }), 0);

      await healthCheck.runAll();

      const report = healthCheck.exportReport();

      expect(report.checks['test-check'].lastChecked).toBeDefined();
      expect(typeof report.checks['test-check'].lastChecked).toBe('string');
    });

    it('should not include checks that have not run', () => {
      healthCheck.register('not-run', jest.fn(), 1000000);

      const report = healthCheck.exportReport();

      expect(report.checks['not-run']).toBeUndefined();
    });

    it('should handle empty checks', () => {
      const report = healthCheck.exportReport();

      expect(report.overall.healthy).toBe(true);
      expect(report.overall.score).toBe(100);
      expect(report.checks).toEqual({});
    });
  });

  describe('Integration Tests', () => {
    it('should handle complete health check lifecycle', async () => {
      // Register checks
      healthCheck.register('memory', jest.fn().mockResolvedValue({ healthy: true, message: 'Memory OK' }), 0);
      healthCheck.register('disk', jest.fn().mockResolvedValue({ healthy: true, message: 'Disk OK' }), 0);

      // Run checks multiple times
      await healthCheck.runAll();
      await healthCheck.runAll();
      await healthCheck.runAll();

      // Check overall health
      const overall = healthCheck.getOverallHealth();
      expect(overall.healthy).toBe(true);

      // Check history
      const history = healthCheck.getHistory(3);
      expect(history.length).toBe(3);

      // Export report
      const report = healthCheck.exportReport();
      expect(report.overall.healthy).toBe(true);
      expect(Object.keys(report.checks).length).toBe(2);
    });

    it('should detect system degradation over time', async () => {
      let checkCount = 0;
      const degradingCheck = jest.fn().mockImplementation(() => {
        checkCount++;
        return Promise.resolve({
          healthy: checkCount <= 2,
          message: checkCount <= 2 ? 'OK' : 'Degraded'
        });
      });

      healthCheck.register('degrading', degradingCheck, 0);

      // First two runs are healthy
      await healthCheck.runAll();
      expect(healthCheck.getOverallHealth().healthy).toBe(true);

      await healthCheck.runAll();
      expect(healthCheck.getOverallHealth().healthy).toBe(true);

      // Third run becomes unhealthy
      await healthCheck.runAll();
      expect(healthCheck.getOverallHealth().healthy).toBe(false);
    });
  });
});
