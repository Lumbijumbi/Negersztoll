/**
 * Unit Tests for Form Fill Module
 * Tests character-by-character typing and form filling utilities
 */

const { fastFill, fillForm, isBrowserClosedError } = require('../../formFill');

// Mock config
jest.mock('../../config', () => ({
  form: {
    typeDelayMin: 4,
    typeDelayMax: 10
  }
}));

describe('Form Fill Module', () => {
  let mockPage;

  beforeEach(() => {
    const mockClick = jest.fn().mockResolvedValue(undefined);
    mockPage = {
      locator: jest.fn().mockReturnValue({ click: mockClick }),
      keyboard: {
        type: jest.fn().mockResolvedValue(undefined),
        press: jest.fn().mockResolvedValue(undefined)
      },
      inputValue: jest.fn().mockResolvedValue('')
    };

    // Suppress console output in tests
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'warn').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('fastFill', () => {
    it('should successfully fill field with character-by-character typing', async () => {
      const testText = 'test@example.com';
      mockPage.inputValue.mockResolvedValue(testText);

      const result = await fastFill(mockPage, '#email', testText);

      expect(result).toBe(true);
      expect(mockPage.locator).toHaveBeenCalledWith('#email');
      expect(mockPage.keyboard.type).toHaveBeenCalledTimes(testText.length);
    });

    it('should clear field before typing when clearFirst is true', async () => {
      const testText = 'test';
      mockPage.inputValue.mockResolvedValue(testText);

      await fastFill(mockPage, '#email', testText, { clearFirst: true });

      const locatorResult = mockPage.locator.mock.results[0].value;
      expect(locatorResult.click).toHaveBeenCalledWith({ clickCount: 3 });
      expect(mockPage.keyboard.press).toHaveBeenCalledWith('Backspace');
    });

    it('should skip clearing when clearFirst is false', async () => {
      const testText = 'test';
      mockPage.inputValue.mockResolvedValue(testText);

      await fastFill(mockPage, '#email', testText, { clearFirst: false });

      const locatorResult = mockPage.locator.mock.results[0].value;
      // Should call click() without clickCount: 3 (just to focus)
      expect(locatorResult.click).toHaveBeenCalledWith();
      expect(mockPage.keyboard.press).not.toHaveBeenCalledWith('Backspace');
    });

    it('should type each character via keyboard.type', async () => {
      const testText = 'abc';
      mockPage.inputValue.mockResolvedValue(testText);

      await fastFill(mockPage, '#input', testText);

      expect(mockPage.keyboard.type).toHaveBeenCalledTimes(3);
      expect(mockPage.keyboard.type).toHaveBeenCalledWith('a');
      expect(mockPage.keyboard.type).toHaveBeenCalledWith('b');
      expect(mockPage.keyboard.type).toHaveBeenCalledWith('c');
    });

    it('should return false if verification fails (no fallback)', async () => {
      const testText = 'test@example.com';
      mockPage.inputValue.mockResolvedValue('wrong_value');

      const result = await fastFill(mockPage, '#email', testText);

      expect(result).toBe(false);
    });

    it('should handle click/focus failures gracefully', async () => {
      const testText = 'test';
      const mockClick = jest.fn().mockRejectedValue(new Error('Click failed'));
      mockPage.locator.mockReturnValue({ click: mockClick });
      mockPage.inputValue.mockResolvedValue(testText);

      const result = await fastFill(mockPage, '#email', testText);

      // Should continue despite click failure
      expect(result).toBe(true);
      expect(mockPage.keyboard.type).toHaveBeenCalled();
    });

    it('should handle type failures for individual characters', async () => {
      const testText = 'abc';
      mockPage.keyboard.type
        .mockResolvedValueOnce(undefined) // 'a' succeeds
        .mockRejectedValueOnce(new Error('Type failed')) // 'b' fails
        .mockResolvedValueOnce(undefined); // 'c' succeeds
      
      mockPage.inputValue.mockResolvedValue('ac'); // Missing 'b'

      await fastFill(mockPage, '#input', testText);

      // Should attempt all characters despite individual failures
      expect(mockPage.keyboard.type).toHaveBeenCalledTimes(3);
    });

    it('should accept custom type delay options without error', async () => {
      const testText = 'ab';
      mockPage.inputValue.mockResolvedValue(testText);

      const result = await fastFill(mockPage, '#input', testText, {
        typeDelayMin: 50,
        typeDelayMax: 100
      });

      expect(result).toBe(true);
      expect(mockPage.keyboard.type).toHaveBeenCalledTimes(2);
    });

    it('should use custom log prefix when provided', async () => {
      const testText = 'test';
      mockPage.inputValue.mockResolvedValue(testText);

      await fastFill(mockPage, '#input', testText, {
        logPrefix: '[CustomPrefix]'
      });

      // Check that custom prefix was used (no second argument expected in actual call)
      const logCalls = console.log.mock.calls;
      const hasCustomPrefix = logCalls.some(call => 
        call[0] && call[0].includes('[CustomPrefix]')
      );
      expect(hasCustomPrefix).toBe(true);
    });

    it('should handle empty text input', async () => {
      mockPage.inputValue.mockResolvedValue('');

      const result = await fastFill(mockPage, '#input', '');

      expect(result).toBe(true);
      expect(mockPage.keyboard.type).not.toHaveBeenCalled();
    });

    it('should handle special characters', async () => {
      const testText = '!@#$%^&*()';
      mockPage.inputValue.mockResolvedValue(testText);

      const result = await fastFill(mockPage, '#input', testText);

      expect(result).toBe(true);
      expect(mockPage.keyboard.type).toHaveBeenCalledTimes(testText.length);
    });

    it('should handle unicode characters', async () => {
      const testText = '😀🎉中文';
      mockPage.inputValue.mockResolvedValue(testText);

      const result = await fastFill(mockPage, '#input', testText);

      expect(result).toBe(true);
    });

    it('should handle page errors gracefully', async () => {
      const mockClick = jest.fn().mockRejectedValue(new Error('Page error'));
      mockPage.locator.mockReturnValue({ click: mockClick });
      mockPage.keyboard.type.mockRejectedValue(new Error('Page error'));
      mockPage.inputValue.mockRejectedValue(new Error('Page error'));

      const result = await fastFill(mockPage, '#input', 'test');

      expect(result).toBe(false);
    });

    it('should count successful characters typed', async () => {
      const testText = 'test';
      mockPage.inputValue.mockResolvedValue('');

      await fastFill(mockPage, '#input', testText);

      expect(console.log).toHaveBeenCalledWith(
        expect.stringContaining('4/4 characters successfully')
      );
    });
  });

  describe('fillForm', () => {
    it('should fill multiple fields successfully', async () => {
      mockPage.inputValue
        .mockResolvedValueOnce('user@example.com')
        .mockResolvedValueOnce('password123');

      const fieldMap = {
        '#email': 'user@example.com',
        '#password': 'password123'
      };

      const result = await fillForm(mockPage, fieldMap);

      expect(result.success).toBe(true);
      expect(result.filled).toBe(2);
      expect(result.total).toBe(2);
    });

    it('should report partial success when some fields fail', async () => {
      mockPage.inputValue
        .mockResolvedValueOnce('user@example.com')
        .mockResolvedValue('wrong_value');

      const fieldMap = {
        '#email': 'user@example.com',
        '#password': 'password123'
      };

      const result = await fillForm(mockPage, fieldMap);

      expect(result.success).toBe(false);
      expect(result.filled).toBe(1);
      expect(result.total).toBe(2);
    });

    it('should handle empty field map', async () => {
      const result = await fillForm(mockPage, {});

      expect(result.success).toBe(true);
      expect(result.filled).toBe(0);
      expect(result.total).toBe(0);
    });

    it('should fill fields in order', async () => {
      const fieldOrder = [];
      mockPage.locator.mockImplementation((selector) => {
        fieldOrder.push(selector);
        return { click: jest.fn().mockResolvedValue(undefined) };
      });
      mockPage.inputValue
        .mockResolvedValueOnce('value1')
        .mockResolvedValueOnce('value2')
        .mockResolvedValueOnce('value3');

      const fieldMap = {
        '#field1': 'value1',
        '#field2': 'value2',
        '#field3': 'value3'
      };

      await fillForm(mockPage, fieldMap);

      expect(fieldOrder[0]).toBe('#field1');
      expect(fieldOrder[1]).toBe('#field2');
      expect(fieldOrder[2]).toBe('#field3');
    });

    it('should pass options to fastFill', async () => {
      mockPage.inputValue.mockResolvedValue('test');

      const fieldMap = { '#field': 'test' };
      const options = {
        typeDelayMin: 100,
        typeDelayMax: 200,
        clearFirst: false,
        logPrefix: '[CustomLog]'
      };

      await fillForm(mockPage, fieldMap, options);

      // Verify custom options were used
      const logCalls = console.log.mock.calls;
      const hasCustomPrefix = logCalls.some(call => 
        call[0] && call[0].includes('[CustomLog]')
      );
      expect(hasCustomPrefix).toBe(true);
    });

    it('should handle many fields', async () => {
      const fieldMap = {};
      for (let i = 0; i < 10; i++) {
        fieldMap[`#field${i}`] = `value${i}`;
        mockPage.inputValue.mockResolvedValueOnce(`value${i}`);
      }

      const result = await fillForm(mockPage, fieldMap);

      expect(result.success).toBe(true);
      expect(result.filled).toBe(10);
      expect(result.total).toBe(10);
    });

    it('should continue filling fields even if one fails', async () => {
      mockPage.inputValue
        .mockResolvedValueOnce('value1')   // field1 succeeds
        .mockResolvedValueOnce('wrong')    // field2 fails (no fallback)
        .mockResolvedValueOnce('value3');  // field3 succeeds

      const fieldMap = {
        '#field1': 'value1',
        '#field2': 'value2',
        '#field3': 'value3'
      };

      const result = await fillForm(mockPage, fieldMap);

      expect(result.success).toBe(false);
      expect(result.filled).toBe(2);
      expect(result.total).toBe(3);
    });
  });

  describe('integration scenarios', () => {
    it('should simulate realistic login form filling', async () => {
      mockPage.inputValue
        .mockResolvedValueOnce('user@example.com')
        .mockResolvedValueOnce('SecureP@ssw0rd');

      const result = await fillForm(mockPage, {
        '#username': 'user@example.com',
        '#password': 'SecureP@ssw0rd'
      });

      expect(result.success).toBe(true);
      expect(mockPage.keyboard.type).toHaveBeenCalled();
    });

    it('should handle form with mixed success/failure', async () => {
      mockPage.inputValue
        .mockResolvedValueOnce('John')              // firstName succeeds
        .mockResolvedValueOnce('wrong')             // lastName fails (no fallback)
        .mockResolvedValueOnce('john@example.com')  // email succeeds
        .mockResolvedValueOnce('wrong');            // phone fails (no fallback)

      const result = await fillForm(mockPage, {
        '#firstName': 'John',
        '#lastName': 'Doe',
        '#email': 'john@example.com',
        '#phone': '1234567890'
      });

      expect(result.success).toBe(false);
      expect(result.filled).toBe(2); // Only firstName and email succeed
      expect(result.total).toBe(4);
    });
  });

  describe('isBrowserClosedError()', () => {
    it('should return true for "Target page" error', () => {
      expect(isBrowserClosedError('Target page, context or browser has been closed')).toBe(true);
    });

    it('should return true for "context or browser has been closed" error', () => {
      expect(isBrowserClosedError('locator.click: Target page, context or browser has been closed')).toBe(true);
    });

    it('should return true for "browser has been closed" error', () => {
      expect(isBrowserClosedError('browser has been closed')).toBe(true);
    });

    it('should return true for "context was destroyed" error', () => {
      expect(isBrowserClosedError('Execution context was destroyed')).toBe(true);
    });

    it('should return true for "session closed" error', () => {
      expect(isBrowserClosedError('Target closed: session closed')).toBe(true);
    });

    it('should return true for "page crashed" error', () => {
      expect(isBrowserClosedError('page crashed')).toBe(true);
    });

    it('should return false for non-fatal errors', () => {
      expect(isBrowserClosedError('Element not found')).toBe(false);
      expect(isBrowserClosedError('Timeout exceeded')).toBe(false);
      expect(isBrowserClosedError('Navigation failed')).toBe(false);
    });

    it('should return false for empty or null input', () => {
      expect(isBrowserClosedError('')).toBe(false);
      expect(isBrowserClosedError(null)).toBe(false);
      expect(isBrowserClosedError(undefined)).toBe(false);
    });
  });

  describe('fastFill — browser closed early-abort', () => {
    it('should return false immediately when page.isClosed() returns true', async () => {
      mockPage.isClosed = jest.fn().mockReturnValue(true);

      const result = await fastFill(mockPage, '#email', 'test');

      expect(result).toBe(false);
      expect(mockPage.locator).not.toHaveBeenCalled();
      expect(mockPage.keyboard.type).not.toHaveBeenCalled();
    });

    it('should return false when page.isClosed() throws', async () => {
      mockPage.isClosed = jest.fn(() => { throw new Error('invalid page'); });

      const result = await fastFill(mockPage, '#email', 'test');

      expect(result).toBe(false);
      expect(mockPage.keyboard.type).not.toHaveBeenCalled();
    });

    it('should proceed normally when page.isClosed() returns false', async () => {
      mockPage.isClosed = jest.fn().mockReturnValue(false);
      mockPage.inputValue.mockResolvedValue('test');

      const result = await fastFill(mockPage, '#email', 'test');

      expect(result).toBe(true);
      expect(mockPage.keyboard.type).toHaveBeenCalled();
    });

    it('should abort immediately when keyboard.type throws a browser-closed error', async () => {
      mockPage.isClosed = jest.fn().mockReturnValue(false);
      mockPage.keyboard.type.mockRejectedValue(
        new Error('Target page, context or browser has been closed')
      );

      const result = await fastFill(mockPage, '#email', 'abc');

      expect(result).toBe(false);
      // Only one type call should be made before abort
      expect(mockPage.keyboard.type).toHaveBeenCalledTimes(1);
    });

    it('should abort immediately when keyboard.type catch handler detects browser-closed error', async () => {
      mockPage.isClosed = jest.fn().mockReturnValue(false);
      mockPage.keyboard.type.mockImplementation(() =>
        Promise.reject(new Error('browser has been closed'))
      );

      const result = await fastFill(mockPage, '#email', 'abc');

      expect(result).toBe(false);
    });
  });
});
