/**
 * Unit Tests for Configuration Module
 * Tests configuration structure and defaults
 */

const config = require('../../config');

describe('Configuration Module', () => {
  describe('structure', () => {
    it('should export configuration object', () => {
      expect(config).toBeDefined();
      expect(typeof config).toBe('object');
    });

    it('should have browser configuration', () => {
      expect(config.browser).toBeDefined();
      expect(config.browser.timeout).toBeDefined();
      expect(config.browser.headless).toBeDefined();
      expect(config.browser.channel).toBeDefined();
    });

    it('should have proxy configuration', () => {
      expect(config.proxy).toBeDefined();
      expect(config.proxy.blacklistTTL).toBeDefined();
      expect(config.proxy.tcpTimeout).toBeDefined();
    });

    it('should have batch configuration', () => {
      expect(config.batch).toBeDefined();
      expect(config.batch.credentialsPerProxy).toBeDefined();
      expect(config.batch.maxParallelWorkers).toBeDefined();
    });

    it('should have form configuration', () => {
      expect(config.form).toBeDefined();
      expect(config.form.typeDelayMin).toBeDefined();
      expect(config.form.typeDelayMax).toBeDefined();
    });

    it('should have navigation configuration', () => {
      expect(config.navigation).toBeDefined();
      expect(config.navigation.timeout).toBeDefined();
      expect(config.navigation.domWaitUntil).toBeDefined();
    });

    it('should have login configuration', () => {
      expect(config.login).toBeDefined();
      expect(config.login.url).toBeDefined();
      expect(config.login.usernameSelector).toBeDefined();
      expect(config.login.passwordSelector).toBeDefined();
    });

    it('should have account configuration', () => {
      expect(config.account).toBeDefined();
      expect(config.account.url).toBeDefined();
      expect(config.account.logoutPhrases).toBeDefined();
    });

    it('should have detection configuration', () => {
      expect(config.detection).toBeDefined();
      expect(config.detection.confidenceThresholds).toBeDefined();
      expect(config.detection.minimumSuccessConfidence).toBeDefined();
    });

    it('should have casDetection configuration', () => {
      expect(config.casDetection).toBeDefined();
      expect(config.casDetection.tgcCookieNames).toBeDefined();
      expect(config.casDetection.monitoringStrategies).toBeDefined();
    });

    it('should have errorRecovery configuration', () => {
      expect(config.errorRecovery).toBeDefined();
      expect(config.errorRecovery.maxRetries).toBeDefined();
      expect(config.errorRecovery.retryStrategies).toBeDefined();
    });

    it('should have retry configuration', () => {
      expect(config.retry).toBeDefined();
      expect(config.retry.enabled).toBeDefined();
      expect(config.retry.maxRetries).toBeDefined();
    });

    it('should have session configuration', () => {
      expect(config.session).toBeDefined();
      expect(config.session.enabled).toBeDefined();
      expect(config.session.directory).toBeDefined();
    });

  });

  describe('browser configuration', () => {
    it('should have valid timeout', () => {
      expect(config.browser.timeout).toBeGreaterThan(0);
      expect(typeof config.browser.timeout).toBe('number');
    });

    it('should have valid channel', () => {
      expect(config.browser.channel).toBe('chrome');
    });

    it('should have browser args array', () => {
      expect(Array.isArray(config.browser.args)).toBe(true);
      expect(config.browser.args.length).toBeGreaterThan(0);
    });

    it('should contain required anti-detection args', () => {
      const args = config.browser.args;
      expect(args).toContain('--disable-blink-features=AutomationControlled');
      // --exclude-switches=enable-automation is not a valid Chrome flag;
      // automation switch suppression is handled via ignoreDefaultArgs
      expect(args).toContain('--disable-ipc-flooding-protection');
      expect(args).toContain('--disable-renderer-backgrounding');
      expect(args).toContain('--disable-backgrounding-occluded-windows');
      expect(args).toContain('--disable-field-trial-config');
      expect(args).toContain('--no-service-autorun');
      expect(args).toContain('--no-default-browser-check');
      expect(args).toContain('--disable-component-extensions-with-background-pages');
    });

    it('should have ignoreDefaultArgs suppressing --enable-automation', () => {
      expect(Array.isArray(config.browser.ignoreDefaultArgs)).toBe(true);
      expect(config.browser.ignoreDefaultArgs).toContain('--enable-automation');
    });

    it('should not contain --disable-web-security in default args', () => {
      // --disable-web-security removes same-origin/CORS protections; it must be opt-in
      // via config.browser.allowInsecureWebSecurity, not present by default
      expect(config.browser.args).not.toContain('--disable-web-security');
    });

    it('should have allowInsecureWebSecurity defaulting to false', () => {
      expect(config.browser.allowInsecureWebSecurity).toBe(false);
    });

    it('should have adaptive timeout configuration', () => {
      expect(config.browser.adaptiveTimeout).toBeDefined();
      expect(config.browser.adaptiveTimeout.initial).toBeGreaterThan(0);
      expect(config.browser.adaptiveTimeout.perCredential).toBeGreaterThan(0);
    });
  });

  describe('detection configuration', () => {
    it('should have valid confidence thresholds', () => {
      const thresholds = config.detection.confidenceThresholds;
      
      expect(thresholds.tgc_cookie.minConfidence).toBe(0.99);
      expect(thresholds.cas_ticket.minConfidence).toBe(0.99);
      expect(thresholds.oidc.minConfidence).toBe(0.95);
      expect(thresholds.body_token.minConfidence).toBe(0.90);
      expect(thresholds.set_cookie.minConfidence).toBe(0.85);
    });

    it('should have valid minimum success confidence', () => {
      expect(config.detection.minimumSuccessConfidence).toBe(0.85);
      expect(config.detection.minimumSuccessConfidence).toBeGreaterThan(0);
      expect(config.detection.minimumSuccessConfidence).toBeLessThanOrEqual(1);
    });

    it('should have CAS detection patterns', () => {
      expect(config.detection.cas.loginPath).toBe('/cas/login');
      expect(config.detection.cas.callbackPath).toBe('callbackAuthorize');
      expect(config.detection.cas.oidcAuthorize).toBe('/cas/oidc/authorize');
    });

    it('should have block detection status codes', () => {
      expect(Array.isArray(config.detection.blockDetection.statusCodes)).toBe(true);
      expect(config.detection.blockDetection.statusCodes).toContain(403);
      expect(config.detection.blockDetection.statusCodes).toContain(401);
    });

    it('should have invalid credentials phrase', () => {
      expect(config.detection.invalidCredentialsPhrase).toBeDefined();
      expect(typeof config.detection.invalidCredentialsPhrase).toBe('string');
      expect(config.detection.invalidCredentialsPhrase.length).toBeGreaterThan(0);
    });

    it('should have block, captcha, and suspicious behavior phrases', () => {
      expect(Array.isArray(config.detection.blockPhrases)).toBe(true);
      expect(config.detection.suspiciousBehaviorPhrase).toBeDefined();
      expect(config.detection.captchaPhrase).toBeDefined();
    });

    it('should include German block phrase', () => {
      expect(config.detection.blockPhrases).toContain('Der Zugriff ist vorübergehend eingeschränkt');
    });
  });

  describe('retry configuration', () => {
    it('should have valid retry settings', () => {
      expect(typeof config.retry.enabled).toBe('boolean');
      expect(config.retry.maxRetries).toBeGreaterThan(0);
      expect(config.retry.queueFile).toBe('retry_queue.json');
    });

    it('should have valid retry delay ranges', () => {
      expect(config.retry.retryDelayMin).toBeGreaterThan(0);
      expect(config.retry.retryDelayMax).toBeGreaterThan(config.retry.retryDelayMin);
    });
  });

  describe('session configuration', () => {
    it('should have valid session settings', () => {
      expect(typeof config.session.enabled).toBe('boolean');
      expect(config.session.directory).toBe('sessions');
      expect(config.session.maxAge).toBeGreaterThan(0);
    });

    it('should have cleanup setting', () => {
      expect(typeof config.session.cleanupOnStart).toBe('boolean');
    });
  });

  describe('form configuration', () => {
    it('should have valid type delay range', () => {
      expect(config.form.typeDelayMin).toBeGreaterThan(0);
      expect(config.form.typeDelayMax).toBeGreaterThan(config.form.typeDelayMin);
      expect(config.form.typeDelayMin).toBeLessThan(100); // Reasonable upper bound
    });

    it('should have valid pause range between credentials', () => {
      expect(config.form.pauseBetweenCredsMin).toBeGreaterThan(0);
      expect(config.form.pauseBetweenCredsMax).toBeGreaterThan(config.form.pauseBetweenCredsMin);
    });
  });

  describe('batch configuration', () => {
    it('should have valid credentials per proxy', () => {
      expect(config.batch.credentialsPerProxy).toBeGreaterThan(0);
      expect(config.batch.credentialsPerProxy).toBeLessThan(100); // Reasonable limit
    });

    it('should have valid max parallel workers', () => {
      expect(config.batch.maxParallelWorkers).toBeGreaterThan(0);
      expect(config.batch.maxParallelWorkers).toBeLessThan(50); // Reasonable limit
    });

    it('should have valid pause ranges', () => {
      expect(config.batch.pauseBetweenBatchMin).toBeGreaterThan(0);
      expect(config.batch.pauseBetweenBatchMax).toBeGreaterThan(config.batch.pauseBetweenBatchMin);
    });
  });

  describe('login configuration', () => {
    it('should have valid login URL', () => {
      expect(config.login.url).toMatch(/^https?:\/\//);
      expect(config.login.url).toContain('supercard.ch');
    });

    it('should have valid CSS selectors', () => {
      expect(config.login.usernameSelector).toMatch(/^[#.]/);
      expect(config.login.passwordSelector).toMatch(/^[#.]/);
    });

    it('should have submit selectors array', () => {
      expect(Array.isArray(config.login.submitSelectors)).toBe(true);
      expect(config.login.submitSelectors.length).toBeGreaterThan(0);
    });

    it('should have recaptcha configuration', () => {
      expect(config.login.recaptcha).toBeDefined();
      expect(typeof config.login.recaptcha.enabled).toBe('boolean');
      expect(Array.isArray(config.login.recaptcha.selectors)).toBe(true);
    });
  });

  describe('account configuration', () => {
    it('should have valid account URL', () => {
      expect(config.account.url).toMatch(/^https?:\/\//);
      expect(config.account.url).toContain('supercard.ch');
    });

    it('should have logout phrases array', () => {
      expect(Array.isArray(config.account.logoutPhrases)).toBe(true);
      expect(config.account.logoutPhrases.length).toBeGreaterThan(0);
    });

    it('should have logout selectors array', () => {
      expect(Array.isArray(config.account.logoutSelectors)).toBe(true);
      expect(config.account.logoutSelectors.length).toBeGreaterThan(0);
    });

    it('should have balance selectors', () => {
      expect(config.account.balanceSelectors).toBeDefined();
      expect(config.account.balanceSelectors.points).toBeDefined();
      expect(config.account.balanceSelectors.money).toBeDefined();
    });

    it('should have cookie popup selectors', () => {
      expect(config.account.cookiePopupSelectors).toBeDefined();
      expect(Array.isArray(config.account.cookiePopupSelectors)).toBe(true);
      expect(config.account.cookiePopupSelectors.length).toBeGreaterThan(0);
    });

    it('should include UserCentrics cookie popup selector', () => {
      expect(config.account.cookiePopupSelectors).toContain('button[data-testid="uc-accept-all-button"]');
    });
  });

  describe('errorRecovery configuration', () => {
    it('should have valid max retries', () => {
      expect(config.errorRecovery.maxRetries).toBeGreaterThan(0);
      expect(config.errorRecovery.maxRetries).toBeLessThan(20);
    });

    it('should have retry strategies', () => {
      const strategies = config.errorRecovery.retryStrategies;
      expect(strategies.exponentialBackoff).toBeDefined();
      expect(strategies.backoffBase).toBeGreaterThanOrEqual(1);
      expect(strategies.maxBackoffDelay).toBeGreaterThan(0);
    });
  });

  describe('casDetection configuration', () => {
    it('should have TGC cookie names array', () => {
      expect(Array.isArray(config.casDetection.tgcCookieNames)).toBe(true);
      expect(config.casDetection.tgcCookieNames).toContain('TGC');
    });

    it('should have monitoring strategies', () => {
      const strategies = config.casDetection.monitoringStrategies;
      expect(strategies.tgc_cookie).toBeDefined();
      expect(strategies.redirect_location).toBeDefined();
      expect(strategies.set_cookie).toBeDefined();
      expect(strategies.body_token).toBeDefined();
    });

    it('should have fallback strategies', () => {
      const fallbacks = config.casDetection.fallbackStrategies;
      expect(typeof fallbacks.checkTGC).toBe('boolean');
      expect(typeof fallbacks.checkDOM).toBe('boolean');
      expect(typeof fallbacks.checkCookies).toBe('boolean');
    });
  });

  describe('output configuration', () => {
    it('should have output file paths', () => {
      expect(config.output.failedFile).toBeDefined();
    });
  });

  describe('logging configuration', () => {
    it('should have logging settings', () => {
      expect(config.logging).toBeDefined();
      expect(typeof config.logging.enableStructuredLogging).toBe('boolean');
      expect(config.logging.logLevel).toBeDefined();
    });

    it('should have valid log level', () => {
      const validLevels = ['debug', 'info', 'warn', 'error'];
      expect(validLevels).toContain(config.logging.logLevel);
    });
  });

  describe('performance configuration', () => {
    it('should have performance settings', () => {
      expect(config.performance).toBeDefined();
      expect(typeof config.performance.enableConnectionPool).toBe('boolean');
    });

    it('should have valid pool size', () => {
      if (config.performance.poolSize) {
        expect(config.performance.poolSize).toBeGreaterThan(0);
      }
    });
  });

  describe('stability configuration', () => {
    it('should have stability settings', () => {
      expect(config.stability).toBeDefined();
      expect(typeof config.stability.enableHealthChecks).toBe('boolean');
      expect(typeof config.stability.enableAutoRecovery).toBe('boolean');
    });

    it('should have valid health check interval', () => {
      if (config.stability.healthCheckInterval) {
        expect(config.stability.healthCheckInterval).toBeGreaterThan(0);
      }
    });
  });

  describe('ux configuration', () => {
    it('should have UX settings', () => {
      expect(config.ux).toBeDefined();
      expect(typeof config.ux.interactiveMode).toBe('boolean');
      expect(typeof config.ux.showDashboard).toBe('boolean');
    });
  });

  describe('validation', () => {
    it('should have consistent timeout values', () => {
      expect(config.browser.timeout).toBeGreaterThan(config.navigation.timeout);
    });

    it('should have consistent delay ranges', () => {
      expect(config.form.typeDelayMin).toBeLessThan(config.form.typeDelayMax);
      expect(config.batch.pauseBetweenBatchMin).toBeLessThan(config.batch.pauseBetweenBatchMax);
    });

    it('should have valid confidence threshold ordering', () => {
      const thresholds = config.detection.confidenceThresholds;
      expect(thresholds.tgc_cookie.minConfidence).toBeGreaterThanOrEqual(
        config.detection.minimumSuccessConfidence
      );
      expect(thresholds.cas_ticket.minConfidence).toBeGreaterThanOrEqual(
        config.detection.minimumSuccessConfidence
      );
    });

    it('should have all confidence values between 0 and 1', () => {
      const thresholds = config.detection.confidenceThresholds;
      Object.values(thresholds).forEach(threshold => {
        expect(threshold.minConfidence).toBeGreaterThanOrEqual(0);
        expect(threshold.minConfidence).toBeLessThanOrEqual(1);
      });
    });
  });

  describe('Traffic Optimization Configuration', () => {
    describe('resource blocking', () => {
      it('should have resource blocking configuration', () => {
        expect(config.browser.resourceBlocking).toBeDefined();
        expect(typeof config.browser.resourceBlocking).toBe('object');
      });

      it('should have enabled flag', () => {
        expect(config.browser.resourceBlocking.enabled).toBeDefined();
        expect(typeof config.browser.resourceBlocking.enabled).toBe('boolean');
      });

      it('should have blockTypes array', () => {
        expect(config.browser.resourceBlocking.blockTypes).toBeDefined();
        expect(Array.isArray(config.browser.resourceBlocking.blockTypes)).toBe(true);
      });

      it('should have valid block types', () => {
        const validTypes = ['image', 'font', 'media', 'stylesheet', 'script', 'xhr', 'fetch', 'websocket'];
        const blockTypes = config.browser.resourceBlocking.blockTypes;
        
        blockTypes.forEach(type => {
          expect(validTypes).toContain(type);
        });
      });

      it('should have blockThirdParty flag', () => {
        expect(config.browser.resourceBlocking.blockThirdParty).toBeDefined();
        expect(typeof config.browser.resourceBlocking.blockThirdParty).toBe('boolean');
      });

      it('should have allowList array', () => {
        expect(config.browser.resourceBlocking.allowList).toBeDefined();
        expect(Array.isArray(config.browser.resourceBlocking.allowList)).toBe(true);
      });

      it('should include authentication domains in allowList', () => {
        const allowList = config.browser.resourceBlocking.allowList;
        
        // Essential domains should be in allowList
        expect(allowList.some(domain => domain.includes('supercard.ch'))).toBe(true);
        expect(allowList.some(domain => domain.includes('cas'))).toBe(true);
      });
    });

    describe('navigation optimization', () => {
      it('should have optimized waitUntil strategy', () => {
        expect(config.navigation.domWaitUntil).toBeDefined();
        expect(['domcontentloaded', 'load', 'networkidle', 'commit']).toContain(
          config.navigation.domWaitUntil
        );
      });

      it('should have waitForLoadState configuration', () => {
        expect(config.navigation.waitForLoadState).toBeDefined();
        expect(['domcontentloaded', 'load', 'networkidle', 'commit']).toContain(
          config.navigation.waitForLoadState
        );
      });

      it('should have disableReloadOnFirstAttempt flag', () => {
        expect(config.navigation.disableReloadOnFirstAttempt).toBeDefined();
        expect(typeof config.navigation.disableReloadOnFirstAttempt).toBe('boolean');
      });
    });

    describe('traffic logging', () => {
      it('should have traffic logging configuration', () => {
        expect(config.logging.logNetworkTraffic).toBeDefined();
        expect(typeof config.logging.logNetworkTraffic).toBe('boolean');
      });

      it('should have blocked resources logging configuration', () => {
        expect(config.logging.logBlockedResources).toBeDefined();
        expect(typeof config.logging.logBlockedResources).toBe('boolean');
      });
    });

    describe('recommended settings validation', () => {
      it('should use domcontentloaded for traffic optimization', () => {
        // domcontentloaded is more traffic-efficient than 'load'
        expect(config.navigation.domWaitUntil).toBe('domcontentloaded');
      });

      it('should have resource blocking disabled by default', () => {
        // Resource blocking is disabled to avoid disrupting DataDome JS fingerprinting
        expect(config.browser.resourceBlocking.enabled).toBe(false);
      });

      it('should block at least images for traffic savings', () => {
        // Images are typically the largest resource type
        const blockTypes = config.browser.resourceBlocking.blockTypes;
        expect(blockTypes).toContain('image');
      });

      it('should have third-party blocking configured', () => {
        // Third-party resources can be blocked if needed
        expect(typeof config.browser.resourceBlocking.blockThirdParty).toBe('boolean');
      });
    });
  });

  describe('Queue Configuration', () => {
    it('should have queue configuration', () => {
      expect(config.queue).toBeDefined();
      expect(typeof config.queue).toBe('object');
    });

    it('should have enabled flag', () => {
      expect(typeof config.queue.enabled).toBe('boolean');
    });

    it('should have queue file path', () => {
      expect(config.queue.queueFile).toBeDefined();
      expect(typeof config.queue.queueFile).toBe('string');
    });

    it('should have randomize option', () => {
      expect(typeof config.queue.randomize).toBe('boolean');
    });

    it('should have listDelay and listDelayJitter', () => {
      expect(typeof config.queue.listDelay).toBe('number');
      expect(config.queue.listDelay).toBeGreaterThanOrEqual(0);
      expect(typeof config.queue.listDelayJitter).toBe('number');
      expect(config.queue.listDelayJitter).toBeGreaterThanOrEqual(0);
    });

    it('should have autoFeed option', () => {
      expect(typeof config.queue.autoFeed).toBe('boolean');
    });

    it('should have deduplication configuration', () => {
      expect(config.queue.deduplication).toBeDefined();
      expect(typeof config.queue.deduplication.enabled).toBe('boolean');
      expect(typeof config.queue.deduplication.crossFile).toBe('boolean');
      expect(typeof config.queue.deduplication.againstHistory).toBe('boolean');
      expect(typeof config.queue.deduplication.caseSensitive).toBe('boolean');
    });

    it('should have valid default priority', () => {
      expect(config.queue.defaultPriority).toBeGreaterThanOrEqual(1);
      expect(config.queue.defaultPriority).toBeLessThanOrEqual(5);
    });

    it('should have maxQueueSize', () => {
      expect(typeof config.queue.maxQueueSize).toBe('number');
      expect(config.queue.maxQueueSize).toBeGreaterThanOrEqual(0);
    });

    it('should have watchDirectory and watchInterval', () => {
      expect(typeof config.queue.watchDirectory).toBe('string');
      expect(typeof config.queue.watchInterval).toBe('number');
      expect(config.queue.watchInterval).toBeGreaterThan(0);
    });
  });

  describe('Enhanced Browser Configuration', () => {
    it('should have viewport configuration', () => {
      expect(config.browser.viewport).toBeDefined();
      expect(config.browser.viewport.width).toBeGreaterThan(0);
      expect(config.browser.viewport.height).toBeGreaterThan(0);
      expect(typeof config.browser.viewport.randomize).toBe('boolean');
    });

    it('should have locale and timezone', () => {
      expect(typeof config.browser.locale).toBe('string');
      expect(typeof config.browser.timezone).toBe('string');
    });

    it('should have userAgent option', () => {
      expect(typeof config.browser.userAgent).toBe('string');
    });

    it('should have userAgentOverride option', () => {
      expect(typeof config.browser.userAgentOverride).toBe('boolean');
    });
  });

  describe('Enhanced Batch Configuration', () => {
    it('should have shuffleCredentials option', () => {
      expect(typeof config.batch.shuffleCredentials).toBe('boolean');
    });

    it('should have cooldownAfterBlock', () => {
      expect(config.batch.cooldownAfterBlock).toBeGreaterThan(0);
    });

    it('should have maxConsecutiveFailures', () => {
      expect(config.batch.maxConsecutiveFailures).toBeGreaterThan(0);
    });

    it('should have adaptiveWorkers configuration', () => {
      expect(config.batch.adaptiveWorkers).toBeDefined();
      expect(typeof config.batch.adaptiveWorkers.enabled).toBe('boolean');
      expect(config.batch.adaptiveWorkers.minWorkers).toBeGreaterThan(0);
      expect(config.batch.adaptiveWorkers.maxWorkers).toBeGreaterThan(config.batch.adaptiveWorkers.minWorkers);
      expect(config.batch.adaptiveWorkers.scaleUpThreshold).toBeGreaterThan(0);
      expect(config.batch.adaptiveWorkers.scaleUpThreshold).toBeLessThanOrEqual(1);
      expect(config.batch.adaptiveWorkers.scaleDownThreshold).toBeGreaterThan(0);
      expect(config.batch.adaptiveWorkers.scaleDownThreshold).toBeLessThanOrEqual(1);
    });
  });

  describe('Enhanced Logging Configuration', () => {
    it('should have colorize and timestamps', () => {
      expect(typeof config.logging.colorize).toBe('boolean');
      expect(typeof config.logging.timestamps).toBe('boolean');
    });

    it('should have logRotation configuration', () => {
      expect(config.logging.logRotation).toBeDefined();
      expect(typeof config.logging.logRotation.enabled).toBe('boolean');
      expect(typeof config.logging.logRotation.maxFileSize).toBe('string');
      expect(config.logging.logRotation.maxFiles).toBeGreaterThan(0);
    });
  });
});
