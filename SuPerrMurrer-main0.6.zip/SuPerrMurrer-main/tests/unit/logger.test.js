'use strict';

const fs = require('fs');
const path = require('path');

jest.mock('../../config', () => ({
  detection: { minimumSuccessConfidence: 0.85 }
}));

describe('AdvancedLogger', () => {
  let logger;
  let testLogDir;

  beforeEach(() => {
    testLogDir = path.join(__dirname, `test_logs_logger_${Date.now()}`);
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'warn').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
    jest.spyOn(process.stdout, 'write').mockImplementation(() => {});

    const AdvancedLogger = require('../../utils/logger');
    logger = new AdvancedLogger({
      logDir: testLogDir,
      level: 'debug',
      bufferSize: 100,
      flushInterval: 60000,
      prettyPrint: true
    });
  });

  afterEach(async () => {
    if (logger) {
      await logger.cleanup();
    }
    if (fs.existsSync(testLogDir)) {
      fs.rmSync(testLogDir, { recursive: true, force: true });
    }
    jest.restoreAllMocks();
  });

  describe('constructor', () => {
    it('should initialize with custom options', () => {
      expect(logger.logDir).toBe(testLogDir);
      expect(logger.level).toBe('debug');
      expect(logger.prettyPrint).toBe(true);
    });

    it('should create log directories', () => {
      expect(fs.existsSync(testLogDir)).toBe(true);
      expect(fs.existsSync(path.join(testLogDir, 'successful'))).toBe(true);
      expect(fs.existsSync(path.join(testLogDir, 'failed'))).toBe(true);
    });

    it('should initialize stats', () => {
      expect(logger.stats.totalProcessed).toBe(0);
      expect(logger.stats.successful).toBe(0);
      expect(logger.stats.failed).toBe(0);
    });
  });

  describe('log', () => {
    it('should call console.log', () => {
      logger.log('info', '[TEST]', 'test message');
      expect(console.log).toHaveBeenCalled();
    });

    it('should suppress messages below current level', () => {
      const AdvancedLogger = require('../../utils/logger');
      const warnLogger = new AdvancedLogger({ logDir: testLogDir, level: 'error', flushInterval: 60000 });
      jest.clearAllMocks();
      warnLogger.info('[TEST]', 'should be suppressed');
      // Should not log since 'info' < 'error' level
      expect(console.log).not.toHaveBeenCalled();
      warnLogger.cleanup();
    });

    it('should log data with pretty print', () => {
      logger.log('info', '[TEST]', 'message with data', { key: 'value' });
      expect(console.log).toHaveBeenCalledTimes(2);
    });
  });

  describe('convenience log methods', () => {
    it('debug should call log with debug level', () => {
      const spy = jest.spyOn(logger, 'log');
      logger.debug('[D]', 'debug msg');
      expect(spy).toHaveBeenCalledWith('debug', '[D]', 'debug msg', undefined);
    });

    it('info should call log with info level', () => {
      const spy = jest.spyOn(logger, 'log');
      logger.info('[I]', 'info msg');
      expect(spy).toHaveBeenCalledWith('info', '[I]', 'info msg', undefined);
    });

    it('warn should call log with warn level', () => {
      const spy = jest.spyOn(logger, 'log');
      logger.warn('[W]', 'warn msg');
      expect(spy).toHaveBeenCalledWith('warn', '[W]', 'warn msg', undefined);
    });

    it('error should call log with error level', () => {
      const spy = jest.spyOn(logger, 'log');
      logger.error('[E]', 'error msg');
      expect(spy).toHaveBeenCalledWith('error', '[E]', 'error msg', undefined);
    });

    it('success should call log with success level', () => {
      const spy = jest.spyOn(logger, 'log');
      logger.success('[S]', 'success msg');
      expect(spy).toHaveBeenCalledWith('success', '[S]', 'success msg', undefined);
    });
  });

  describe('progressBar', () => {
    it('should write to stdout', () => {
      logger.progressBar(50, 100, 'Progress:');
      expect(process.stdout.write).toHaveBeenCalled();
    });

    it('clearProgressBar should write blank to stdout', () => {
      logger.clearProgressBar();
      expect(process.stdout.write).toHaveBeenCalled();
    });
  });

  describe('logSuccess', () => {
    it('should log success above minimum confidence', () => {
      logger.logSuccess('user@test.com', 'pass', 'tgc_cookie', 0.99, 1500);
      expect(logger.stats.successful).toBe(1);
      expect(logger.stats.totalProcessed).toBe(1);
      expect(logger.results.successful.length).toBe(1);
    });

    it('should skip low-confidence results', () => {
      logger.logSuccess('user@test.com', 'pass', 'form_submit', 0.50, 1000);
      expect(logger.stats.successful).toBe(0);
    });

    it('should track oauth_code_redirect method', () => {
      logger.logSuccess('user@test.com', 'pass', 'oauth_code_redirect', 0.99, 1000);
      expect(logger.stats.oauthCodeRedirect).toBe(1);
    });

    it('should track cas_ticket_redirect method', () => {
      logger.logSuccess('user@test.com', 'pass', 'cas_ticket_redirect', 0.99, 1000);
      expect(logger.stats.casTicketRedirect).toBe(1);
    });

    it('should track tgc_cookie method', () => {
      logger.logSuccess('user@test.com', 'pass', 'tgc_cookie', 0.99, 1000);
      expect(logger.stats.tgcSuccess).toBe(1);
    });

    it('should track redirect/302 methods', () => {
      logger.logSuccess('user@test.com', 'pass', 'redirect_302', 0.99, 1000);
      expect(logger.stats.redirect302Success).toBe(1);
    });

    it('should track other methods', () => {
      logger.logSuccess('user@test.com', 'pass', 'body_token', 0.90, 1000);
      expect(logger.stats.otherSuccess).toBe(1);
    });

    it('should include pointsBalance and moneyBalance when provided', () => {
      logger.logSuccess('user@test.com', 'pass', 'tgc_cookie', 0.99, 1000, 500, 10.5);
      const entry = logger.results.successful[0];
      expect(entry.pointsBalance).toBe(500);
      expect(entry.moneyBalance).toBe(10.5);
    });
  });

  describe('logFailed', () => {
    it('should log failed attempts', () => {
      logger.logFailed('user@test.com', 'pass', 'invalid_credentials', 'Form showed error');
      expect(logger.stats.failed).toBe(1);
      expect(logger.results.failed.length).toBe(1);
    });

    it('should work without details', () => {
      logger.logFailed('user@test.com', 'pass', 'invalid_credentials');
      expect(logger.stats.failed).toBe(1);
    });
  });

  describe('logBlocked', () => {
    it('should log blocked accounts', () => {
      logger.logBlocked('user@test.com', 'pass', 'IP rate limited', 2);
      expect(logger.stats.blocked).toBe(1);
      expect(logger.results.blocked.length).toBe(1);
    });
  });

  describe('logCaptcha', () => {
    it('should log captcha encounters', () => {
      logger.logCaptcha('user@test.com', 'pass', 'v2', 3);
      expect(logger.stats.captcha).toBe(1);
      expect(logger.results.captcha.length).toBe(1);
    });
  });

  describe('logError', () => {
    it('should log errors', () => {
      logger.logError('user@test.com', 'pass', new Error('Page crashed'), 'worker-1');
      expect(logger.results.errors.length).toBe(1);
    });
  });

  describe('getCachedFilename', () => {
    it('should return filename with today\'s date', () => {
      const filename = logger.getCachedFilename('successful');
      expect(filename).toContain('successes_');
      expect(filename).toContain('.jsonl');
    });

    it('should cache filenames', () => {
      const f1 = logger.getCachedFilename('failed');
      const f2 = logger.getCachedFilename('failed');
      expect(f1).toBe(f2);
    });
  });

  describe('categorizeSuccess', () => {
    it('should categorize oauth_code_redirect', () => {
      expect(logger.categorizeSuccess('oauth_code_redirect')).toBe('OAUTH_CODE_REDIRECT');
    });

    it('should categorize cas_ticket_redirect', () => {
      expect(logger.categorizeSuccess('cas_ticket_redirect')).toBe('CAS_TICKET_REDIRECT');
    });

    it('should categorize tgc_cookie', () => {
      expect(logger.categorizeSuccess('tgc_cookie')).toBe('TGC_COOKIE');
    });

    it('should categorize oidc redirect', () => {
      expect(logger.categorizeSuccess('oidc_authorize_redirect')).toBe('REDIRECT_OIDC');
    });

    it('should return OTHER for unknown methods', () => {
      expect(logger.categorizeSuccess('unknown_method')).toBe('OTHER');
    });
  });

  describe('generateSummaryReport', () => {
    it('should return a report string', () => {
      logger.logSuccess('u', 'p', 'tgc_cookie', 0.99, 1000);
      const report = logger.generateSummaryReport();
      expect(typeof report).toBe('string');
      expect(report).toContain('TESTING SUMMARY REPORT');
    });
  });

  describe('generateDetailedReport', () => {
    it('should return a report string', () => {
      logger.logSuccess('u', 'p', 'tgc_cookie', 0.99, 1000);
      logger.logFailed('u2', 'p2', 'invalid');
      const report = logger.generateDetailedReport();
      expect(typeof report).toBe('string');
    });
  });

  describe('addToResults', () => {
    it('should trim results array when it exceeds max size', () => {
      for (let i = 0; i < 1005; i++) {
        logger.addToResults('failed', { i });
      }
      expect(logger.results.failed.length).toBeLessThanOrEqual(1000);
    });
  });

  describe('exportResults', () => {
    it('should export JSON results', () => {
      logger.logSuccess('u', 'p', 'tgc_cookie', 0.99, 1000);
      logger.exportResults('json');
      const reportDir = path.join(testLogDir, 'reports');
      const files = fs.readdirSync(reportDir);
      expect(files.some(f => f.endsWith('.json'))).toBe(true);
    });

    it('should export CSV results', () => {
      logger.logSuccess('u', 'p', 'tgc_cookie', 0.99, 1000);
      logger.logFailed('u2', 'p2', 'invalid');
      logger.exportResults('csv');
      const reportDir = path.join(testLogDir, 'reports');
      const files = fs.readdirSync(reportDir);
      expect(files.some(f => f.includes('.csv'))).toBe(true);
    });
  });

  describe('cleanupSync', () => {
    it('should flush buffers synchronously', () => {
      logger.logSuccess('u', 'p', 'tgc_cookie', 0.99, 1000);
      expect(() => logger.cleanupSync()).not.toThrow();
    });
  });

  describe('flushAllBuffers', () => {
    it('should flush all buffers', async () => {
      logger.logSuccess('u', 'p', 'tgc_cookie', 0.99, 1000);
      logger.logFailed('u2', 'p2', 'invalid');
      await expect(logger.flushAllBuffers()).resolves.not.toThrow();
    });
  });

  describe('enhanced visual methods', () => {
    it('header should call console.header', () => {
      expect(() => logger.header('Test Header')).not.toThrow();
    });

    it('section should not throw', () => {
      expect(() => logger.section('Title', 'content')).not.toThrow();
    });

    it('separator should not throw', () => {
      expect(() => logger.separator(50, '=', 'cyan')).not.toThrow();
    });

    it('table should not throw', () => {
      expect(() => logger.table(['Col1', 'Col2'], [['a', 'b']])).not.toThrow();
    });

    it('formatDuration should return a string', () => {
      expect(typeof logger.formatDuration(1500)).toBe('string');
    });
  });
});
