'use strict';

jest.mock('../../config', () => ({
  userBehavior: {
    randomMouseMovement: {
      enabled: true,
      beforeFormFill: { enabled: true, movements: 3, delayMin: 50, delayMax: 200 },
      duringFormFill: { enabled: true, movements: 2, delayMin: 100, delayMax: 300 },
      afterSubmit: { enabled: true, movements: 2, delayMin: 150, delayMax: 400 }
    }
  }
}));

const {
  performRandomMouseMovements,
  mouseMovementBeforeFormFill,
  mouseMovementDuringFormFill,
  mouseMovementAfterSubmit
} = require('../../utils/mouseMovement');

describe('mouseMovement', () => {
  let page;

  beforeEach(() => {
    jest.spyOn(console, 'debug').mockImplementation(() => {});
    page = {
      viewportSize: jest.fn().mockReturnValue({ width: 1920, height: 1080 }),
      mouse: {
        move: jest.fn().mockResolvedValue(undefined)
      }
    };
    // Override setTimeout to be instant
    jest.spyOn(global, 'setTimeout').mockImplementation((fn) => { fn(); return 0; });
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('performRandomMouseMovements', () => {
    it('should perform mouse movements', async () => {
      await performRandomMouseMovements(page, 2);
      expect(page.mouse.move).toHaveBeenCalled();
    });

    it('should use default viewport if viewportSize returns null', async () => {
      page.viewportSize.mockReturnValue(null);
      await performRandomMouseMovements(page, 1);
      expect(page.mouse.move).toHaveBeenCalled();
    });

    it('should handle mouse.move errors gracefully', async () => {
      page.mouse.move.mockRejectedValue(new Error('element not interactable'));
      await expect(performRandomMouseMovements(page, 2)).resolves.not.toThrow();
      expect(console.debug).toHaveBeenCalled();
    });

    it('should perform the requested number of movements', async () => {
      await performRandomMouseMovements(page, 3);
      // Each movement involves moveMouseAlongPath with steps, so mouse.move is called many times
      expect(page.mouse.move.mock.calls.length).toBeGreaterThan(3);
    });

    it('should handle page errors gracefully', async () => {
      page.viewportSize.mockImplementation(() => { throw new Error('page closed'); });
      await expect(performRandomMouseMovements(page, 1)).resolves.not.toThrow();
    });
  });

  describe('mouseMovementBeforeFormFill', () => {
    it('should call performRandomMouseMovements with before config', async () => {
      await mouseMovementBeforeFormFill(page);
      expect(page.mouse.move).toHaveBeenCalled();
    });

    it('should skip when config.userBehavior is not set', async () => {
      const config = require('../../config');
      const savedBehavior = config.userBehavior;
      config.userBehavior = undefined;
      await mouseMovementBeforeFormFill(page);
      expect(page.mouse.move).not.toHaveBeenCalled();
      config.userBehavior = savedBehavior;
    });

    it('should skip when randomMouseMovement.enabled is false', async () => {
      const config = require('../../config');
      const saved = config.userBehavior.randomMouseMovement.enabled;
      config.userBehavior.randomMouseMovement.enabled = false;
      await mouseMovementBeforeFormFill(page);
      expect(page.mouse.move).not.toHaveBeenCalled();
      config.userBehavior.randomMouseMovement.enabled = saved;
    });

    it('should skip when beforeFormFill.enabled is false', async () => {
      const config = require('../../config');
      const saved = config.userBehavior.randomMouseMovement.beforeFormFill.enabled;
      config.userBehavior.randomMouseMovement.beforeFormFill.enabled = false;
      await mouseMovementBeforeFormFill(page);
      expect(page.mouse.move).not.toHaveBeenCalled();
      config.userBehavior.randomMouseMovement.beforeFormFill.enabled = saved;
    });
  });

  describe('mouseMovementDuringFormFill', () => {
    it('should call performRandomMouseMovements with during config', async () => {
      await mouseMovementDuringFormFill(page);
      expect(page.mouse.move).toHaveBeenCalled();
    });

    it('should skip when duringFormFill.enabled is false', async () => {
      const config = require('../../config');
      const saved = config.userBehavior.randomMouseMovement.duringFormFill.enabled;
      config.userBehavior.randomMouseMovement.duringFormFill.enabled = false;
      await mouseMovementDuringFormFill(page);
      expect(page.mouse.move).not.toHaveBeenCalled();
      config.userBehavior.randomMouseMovement.duringFormFill.enabled = saved;
    });
  });

  describe('mouseMovementAfterSubmit', () => {
    it('should call performRandomMouseMovements with after config', async () => {
      await mouseMovementAfterSubmit(page);
      expect(page.mouse.move).toHaveBeenCalled();
    });

    it('should skip when afterSubmit.enabled is false', async () => {
      const config = require('../../config');
      const saved = config.userBehavior.randomMouseMovement.afterSubmit.enabled;
      config.userBehavior.randomMouseMovement.afterSubmit.enabled = false;
      await mouseMovementAfterSubmit(page);
      expect(page.mouse.move).not.toHaveBeenCalled();
      config.userBehavior.randomMouseMovement.afterSubmit.enabled = saved;
    });
  });
});
