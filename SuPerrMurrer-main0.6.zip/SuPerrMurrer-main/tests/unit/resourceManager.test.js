/**
 * Unit Tests for ResourceManager Module
 * Tests system resource monitoring, worker count optimization, and performance recommendations
 */

const ResourceManager = require('../../utils/resourceManager');
const os = require('os');

// Mock os module
jest.mock('os');

describe('ResourceManager', () => {
  let manager;

  beforeEach(() => {
    jest.clearAllMocks();
    manager = new ResourceManager();

    // Mock os.cpus()
    os.cpus.mockReturnValue(Array(8).fill({}));

    // Mock os.totalmem() - 16GB
    os.totalmem.mockReturnValue(16 * 1024 * 1024 * 1024);

    // Mock os.freemem() - 8GB
    os.freemem.mockReturnValue(8 * 1024 * 1024 * 1024);

    // Mock os.platform()
    os.platform.mockReturnValue('linux');

    // Mock os.arch()
    os.arch.mockReturnValue('x64');

    // Spy on console methods
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    console.log.mockRestore();
    console.error.mockRestore();
  });

  describe('Constructor', () => {
    it('should initialize with empty history arrays', () => {
      expect(manager.cpuUsageHistory).toEqual([]);
      expect(manager.memoryUsageHistory).toEqual([]);
      expect(manager.maxHistorySize).toBe(10);
      expect(manager.workerPerformance).toBeInstanceOf(Map);
    });
  });

  describe('getOptimalWorkerCount()', () => {
    it('should calculate optimal worker count based on CPU and memory', () => {
      // 8 CPUs, 8GB free memory
      os.cpus.mockReturnValue(Array(8).fill({}));
      os.freemem.mockReturnValue(8 * 1024 * 1024 * 1024);

      const result = manager.getOptimalWorkerCount();

      expect(result.cpuCount).toBe(8);
      expect(result.availableCores).toBe(7); // 8 - 1 reserved
      expect(result.memoryBasedWorkers).toBe(16); // 8GB / 0.5GB
      expect(result.recommended).toBe(7); // Min of CPU-based and memory-based
      expect(result.reason).toContain('CPU limited');
    });

    it('should be memory limited when free memory is low', () => {
      // 8 CPUs, 1GB free memory
      os.cpus.mockReturnValue(Array(8).fill({}));
      os.freemem.mockReturnValue(1 * 1024 * 1024 * 1024);

      const result = manager.getOptimalWorkerCount();

      expect(result.memoryBasedWorkers).toBe(2); // 1GB / 0.5GB
      expect(result.recommended).toBe(2);
      expect(result.reason).toContain('Memory limited');
    });

    it('should cap at maximum of 16 workers', () => {
      // 32 CPUs, 32GB free memory
      os.cpus.mockReturnValue(Array(32).fill({}));
      os.freemem.mockReturnValue(32 * 1024 * 1024 * 1024);

      const result = manager.getOptimalWorkerCount();

      expect(result.recommended).toBe(16); // Capped at 16
    });

    it('should return minimum 1 worker', () => {
      // 1 CPU, very low memory
      os.cpus.mockReturnValue(Array(1).fill({}));
      os.freemem.mockReturnValue(100 * 1024 * 1024); // 100MB

      const result = manager.getOptimalWorkerCount();

      expect(result.recommended).toBe(1); // Minimum 1
      expect(result.availableCores).toBe(1); // Max(1, 1-1) = 1
    });

    it('should provide correct system information', () => {
      os.cpus.mockReturnValue(Array(4).fill({}));
      os.totalmem.mockReturnValue(8 * 1024 * 1024 * 1024);
      os.freemem.mockReturnValue(4 * 1024 * 1024 * 1024);

      const result = manager.getOptimalWorkerCount();

      expect(result.cpuCount).toBe(4);
      expect(result.totalMemoryGB).toBe('8.0');
      expect(result.freeMemoryGB).toBe('4.0');
    });
  });

  describe('getCPUUsage()', () => {
    it('should return CPU usage percentage', async () => {
      // Mock process.cpuUsage
      let callCount = 0;
      const originalCpuUsage = process.cpuUsage;
      process.cpuUsage = jest.fn((prevUsage) => {
        callCount++;
        if (callCount === 1) {
          return { user: 1000000, system: 500000 };
        } else {
          // Second call with delta
          return { user: 50000, system: 25000 }; // 75000 microseconds total
        }
      });

      const usage = await manager.getCPUUsage();

      expect(typeof usage).toBe('number');
      expect(usage).toBeGreaterThanOrEqual(0);
      expect(usage).toBeLessThanOrEqual(100);

      process.cpuUsage = originalCpuUsage;
    });

    it('should cap CPU usage at 100%', async () => {
      // Mock very high CPU usage
      const originalCpuUsage = process.cpuUsage;
      process.cpuUsage = jest.fn((prevUsage) => {
        return { user: 10000000, system: 10000000 };
      });

      const usage = await manager.getCPUUsage();

      expect(usage).toBeLessThanOrEqual(100);

      process.cpuUsage = originalCpuUsage;
    });

    it('should return minimum 0%', async () => {
      // Mock very low CPU usage
      const originalCpuUsage = process.cpuUsage;
      process.cpuUsage = jest.fn((prevUsage) => {
        return { user: 10, system: 5 };
      });

      const usage = await manager.getCPUUsage();

      expect(usage).toBeGreaterThanOrEqual(0);

      process.cpuUsage = originalCpuUsage;
    });
  });

  describe('getMemoryUsage()', () => {
    it('should return memory usage statistics', () => {
      os.totalmem.mockReturnValue(16 * 1024 * 1024 * 1024); // 16GB
      os.freemem.mockReturnValue(8 * 1024 * 1024 * 1024); // 8GB

      const result = manager.getMemoryUsage();

      expect(result.totalGB).toBe('16.00');
      expect(result.usedGB).toBe('8.00');
      expect(result.freeGB).toBe('8.00');
      expect(result.usedPercent).toBe('50.0');
      expect(result.freePercent).toBe('50.0');
    });

    it('should handle high memory usage', () => {
      os.totalmem.mockReturnValue(8 * 1024 * 1024 * 1024); // 8GB
      os.freemem.mockReturnValue(0.5 * 1024 * 1024 * 1024); // 0.5GB

      const result = manager.getMemoryUsage();

      expect(parseFloat(result.usedPercent)).toBeGreaterThan(90);
      expect(parseFloat(result.freePercent)).toBeLessThan(10);
    });

    it('should handle low memory usage', () => {
      os.totalmem.mockReturnValue(16 * 1024 * 1024 * 1024); // 16GB
      os.freemem.mockReturnValue(15 * 1024 * 1024 * 1024); // 15GB

      const result = manager.getMemoryUsage();

      expect(parseFloat(result.usedPercent)).toBeLessThan(10);
      expect(parseFloat(result.freePercent)).toBeGreaterThan(90);
    });
  });

  describe('monitorResources()', () => {
    beforeEach(() => {
      // Mock process.cpuUsage for getCPUUsage
      const originalCpuUsage = process.cpuUsage;
      process.cpuUsage = jest.fn((prevUsage) => {
        return { user: 50000, system: 25000 };
      });
    });

    it('should monitor and return current resource usage', async () => {
      os.totalmem.mockReturnValue(16 * 1024 * 1024 * 1024);
      os.freemem.mockReturnValue(8 * 1024 * 1024 * 1024);

      const result = await manager.monitorResources();

      expect(result.current).toBeDefined();
      expect(result.current.cpu).toBeDefined();
      expect(result.current.memory).toBe('50.0');
      expect(result.current.freeCPU).toBeDefined();
      expect(result.current.freeMemoryPercent).toBe('50.0');
      expect(result.timestamp).toBeDefined();
    });

    it('should track usage history', async () => {
      await manager.monitorResources();
      await manager.monitorResources();
      await manager.monitorResources();

      expect(manager.cpuUsageHistory.length).toBe(3);
      expect(manager.memoryUsageHistory.length).toBe(3);
    });

    it('should calculate average usage', async () => {
      os.freemem.mockReturnValue(8 * 1024 * 1024 * 1024); // 50% usage
      await manager.monitorResources();

      os.freemem.mockReturnValue(6 * 1024 * 1024 * 1024); // ~62.5% usage
      await manager.monitorResources();

      os.freemem.mockReturnValue(4 * 1024 * 1024 * 1024); // 75% usage
      const result = await manager.monitorResources();

      expect(result.average).toBeDefined();
      expect(result.average.cpu).toBeDefined();
      expect(result.average.memory).toBeDefined();
      expect(parseFloat(result.average.memory)).toBeGreaterThan(50);
    });

    it('should limit history size to maxHistorySize', async () => {
      manager.maxHistorySize = 5;

      for (let i = 0; i < 10; i++) {
        await manager.monitorResources();
      }

      expect(manager.cpuUsageHistory.length).toBe(5);
      expect(manager.memoryUsageHistory.length).toBe(5);
    });

    it('should set shouldThrottle when CPU > 90%', async () => {
      // Mock high CPU usage
      const originalCpuUsage = process.cpuUsage;
      process.cpuUsage = jest.fn(() => {
        return { user: 9500000, system: 500000 }; // High CPU
      });

      manager.cpuUsageHistory = [91, 92, 93, 94, 95];

      const result = await manager.monitorResources();

      expect(result.shouldThrottle).toBe(true);

      process.cpuUsage = originalCpuUsage;
    });

    it('should set shouldThrottle when memory > 80%', async () => {
      os.freemem.mockReturnValue(1 * 1024 * 1024 * 1024); // ~93.75% usage

      manager.memoryUsageHistory = [81, 82, 83, 84, 85];

      const result = await manager.monitorResources();

      expect(result.shouldThrottle).toBe(true);
    });

    it('should not throttle under normal conditions', async () => {
      os.freemem.mockReturnValue(8 * 1024 * 1024 * 1024); // 50% usage

      const result = await manager.monitorResources();

      expect(result.shouldThrottle).toBe(false);
    });
  });

  describe('getRecommendations()', () => {
    it('should return empty array when no history', () => {
      const recommendations = manager.getRecommendations();

      expect(recommendations).toEqual([]);
    });

    it('should recommend reducing workers on critical CPU usage', () => {
      manager.cpuUsageHistory = [91, 92, 93, 94, 95];
      manager.memoryUsageHistory = [50, 50, 50, 50, 50];

      const recommendations = manager.getRecommendations();

      expect(recommendations.length).toBeGreaterThan(0);
      expect(recommendations.some(r => r.type === 'critical' && r.category === 'cpu')).toBe(true);
      expect(recommendations.some(r => r.action === 'reduce_workers')).toBe(true);
    });

    it('should warn on high CPU usage', () => {
      manager.cpuUsageHistory = [76, 77, 78, 79, 80];
      manager.memoryUsageHistory = [50, 50, 50, 50, 50];

      const recommendations = manager.getRecommendations();

      expect(recommendations.length).toBeGreaterThan(0);
      expect(recommendations.some(r => r.type === 'warning' && r.category === 'cpu')).toBe(true);
    });

    it('should recommend action on critical memory usage', () => {
      manager.cpuUsageHistory = [50, 50, 50, 50, 50];
      manager.memoryUsageHistory = [91, 92, 93, 94, 95];

      const recommendations = manager.getRecommendations();

      expect(recommendations.length).toBeGreaterThan(0);
      expect(recommendations.some(r => r.type === 'critical' && r.category === 'memory')).toBe(true);
      expect(recommendations.some(r => r.action === 'enable_headless_reduce_workers')).toBe(true);
    });

    it('should warn on high memory usage', () => {
      manager.cpuUsageHistory = [50, 50, 50, 50, 50];
      manager.memoryUsageHistory = [81, 82, 83, 84, 85];

      const recommendations = manager.getRecommendations();

      expect(recommendations.length).toBeGreaterThan(0);
      expect(recommendations.some(r => r.type === 'warning' && r.category === 'memory')).toBe(true);
      expect(recommendations.some(r => r.action === 'enable_headless')).toBe(true);
    });

    it('should suggest increasing workers when underutilized', () => {
      manager.cpuUsageHistory = [30, 32, 35, 33, 31];
      manager.memoryUsageHistory = [40, 42, 45, 43, 41];

      const recommendations = manager.getRecommendations();

      expect(recommendations.length).toBeGreaterThan(0);
      expect(recommendations.some(r => r.type === 'info' && r.category === 'performance')).toBe(true);
      expect(recommendations.some(r => r.action === 'increase_workers')).toBe(true);
    });

    it('should not recommend increase when CPU or memory is high', () => {
      manager.cpuUsageHistory = [30, 32, 35, 33, 31];
      manager.memoryUsageHistory = [60, 62, 65, 63, 61]; // Over 50%

      const recommendations = manager.getRecommendations();

      expect(recommendations.some(r => r.action === 'increase_workers')).toBe(false);
    });

    it('should return multiple recommendations when appropriate', () => {
      manager.cpuUsageHistory = [91, 92, 93, 94, 95];
      manager.memoryUsageHistory = [91, 92, 93, 94, 95];

      const recommendations = manager.getRecommendations();

      expect(recommendations.length).toBeGreaterThanOrEqual(2);
      expect(recommendations.some(r => r.category === 'cpu')).toBe(true);
      expect(recommendations.some(r => r.category === 'memory')).toBe(true);
    });
  });

  describe('trackWorkerPerformance()', () => {
    it('should track worker metrics', () => {
      const workerId = 'worker-1';
      const metrics = {
        tasksCompleted: 10,
        avgResponseTime: 5000,
        errorRate: 0.05
      };

      manager.trackWorkerPerformance(workerId, metrics);

      expect(manager.workerPerformance.has(workerId)).toBe(true);
      
      const tracked = manager.workerPerformance.get(workerId);
      expect(tracked.tasksCompleted).toBe(10);
      expect(tracked.avgResponseTime).toBe(5000);
      expect(tracked.errorRate).toBe(0.05);
      expect(tracked.timestamp).toBeDefined();
    });

    it('should update existing worker metrics', () => {
      const workerId = 'worker-1';
      
      manager.trackWorkerPerformance(workerId, { tasksCompleted: 5 });
      manager.trackWorkerPerformance(workerId, { tasksCompleted: 10 });

      expect(manager.workerPerformance.get(workerId).tasksCompleted).toBe(10);
    });

    it('should track multiple workers', () => {
      manager.trackWorkerPerformance('worker-1', { tasksCompleted: 5 });
      manager.trackWorkerPerformance('worker-2', { tasksCompleted: 8 });
      manager.trackWorkerPerformance('worker-3', { tasksCompleted: 12 });

      expect(manager.workerPerformance.size).toBe(3);
    });
  });

  describe('exportSystemReport()', () => {
    it('should export comprehensive system report', () => {
      os.cpus.mockReturnValue(Array(8).fill({}));
      os.totalmem.mockReturnValue(16 * 1024 * 1024 * 1024);
      os.freemem.mockReturnValue(8 * 1024 * 1024 * 1024);
      os.platform.mockReturnValue('linux');
      os.arch.mockReturnValue('x64');

      manager.cpuUsageHistory = [50, 52, 51];
      manager.memoryUsageHistory = [60, 62, 61];

      const report = manager.exportSystemReport();

      expect(report.system).toBeDefined();
      expect(report.system.cpuCount).toBe(8);
      expect(report.system.totalMemoryGB).toBe('16.0');
      expect(report.system.platform).toBe('linux');
      expect(report.system.arch).toBe('x64');
      expect(report.system.nodeVersion).toBeDefined();

      expect(report.optimal).toBeDefined();
      expect(report.optimal.recommendedWorkers).toBeDefined();
      expect(report.optimal.reason).toBeDefined();

      expect(report.current).toBeDefined();
      expect(report.current.cpu).toBeDefined();
      expect(report.current.memory).toBeDefined();

      expect(report.recommendations).toBeDefined();
      expect(Array.isArray(report.recommendations)).toBe(true);

      expect(report.timestamp).toBeDefined();
    });

    it('should handle empty history in report', () => {
      const report = manager.exportSystemReport();

      expect(report.current.cpu).toBe('0.0');
      expect(report.current.memory).toBe('0.0');
    });

    it('should include recommendations in report', () => {
      manager.cpuUsageHistory = [91, 92, 93, 94, 95];
      manager.memoryUsageHistory = [50, 50, 50, 50, 50];

      const report = manager.exportSystemReport();

      expect(report.recommendations.length).toBeGreaterThan(0);
      expect(report.recommendations.some(r => r.category === 'cpu')).toBe(true);
    });
  });

  describe('triggerGarbageCollection()', () => {
    afterEach(() => {
      // Restore global.gc after each test
      delete global.gc;
    });

    it('should return false when global.gc is not available', () => {
      delete global.gc;
      const result = manager.triggerGarbageCollection();
      expect(result).toBe(false);
    });

    it('should call global.gc and return true when available', () => {
      global.gc = jest.fn();
      const result = manager.triggerGarbageCollection();
      expect(result).toBe(true);
      expect(global.gc).toHaveBeenCalledTimes(1);
    });

    it('should return false when global.gc throws', () => {
      global.gc = jest.fn(() => { throw new Error('GC failed'); });
      const result = manager.triggerGarbageCollection();
      expect(result).toBe(false);
    });
  });

  describe('checkMemoryPressure()', () => {
    afterEach(() => {
      delete global.gc;
    });

    it('should return current memory usage percentage as a number', () => {
      // 8GB free out of 16GB = 50% used
      os.freemem.mockReturnValue(8 * 1024 * 1024 * 1024);
      const result = manager.checkMemoryPressure();
      expect(typeof result).toBe('number');
      expect(result).toBeGreaterThan(0);
      expect(result).toBeLessThanOrEqual(100);
    });

    it('should trigger GC when memory usage exceeds 90%', () => {
      // 1GB free out of 16GB ≈ 93.75% used
      os.freemem.mockReturnValue(1 * 1024 * 1024 * 1024);
      global.gc = jest.fn();
      manager.checkMemoryPressure();
      expect(global.gc).toHaveBeenCalledTimes(1);
    });

    it('should NOT trigger GC when memory usage is below 90%', () => {
      // 8GB free out of 16GB = 50% used
      os.freemem.mockReturnValue(8 * 1024 * 1024 * 1024);
      global.gc = jest.fn();
      manager.checkMemoryPressure();
      expect(global.gc).not.toHaveBeenCalled();
    });
  });
});
