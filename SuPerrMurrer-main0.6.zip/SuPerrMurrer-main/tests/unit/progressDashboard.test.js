'use strict';

const ProgressDashboard = require('../../utils/progressDashboard');

describe('ProgressDashboard', () => {
  let dashboard;

  beforeEach(() => {
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(process.stdout, 'write').mockImplementation(() => {});
    dashboard = new ProgressDashboard();
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('constructor', () => {
    it('should initialize with default stats', () => {
      expect(dashboard.stats.total).toBe(0);
      expect(dashboard.stats.processed).toBe(0);
      expect(dashboard.stats.successful).toBe(0);
      expect(dashboard.stats.failed).toBe(0);
      expect(dashboard.stats.blocked).toBe(0);
      expect(dashboard.stats.captcha).toBe(0);
    });

    it('should initialize empty collections', () => {
      expect(dashboard.workers).toBeInstanceOf(Map);
      expect(dashboard.recentResults).toEqual([]);
      expect(dashboard.proxyHealth).toBeInstanceOf(Map);
    });
  });

  describe('updateStats', () => {
    it('should update stats and call render', () => {
      const renderSpy = jest.spyOn(dashboard, 'render').mockImplementation(() => {});
      dashboard.updateStats({ total: 100, processed: 50 });
      expect(dashboard.stats.total).toBe(100);
      expect(dashboard.stats.processed).toBe(50);
      expect(renderSpy).toHaveBeenCalled();
    });
  });

  describe('addResult', () => {
    it('should add result to front of list', () => {
      jest.spyOn(dashboard, 'render').mockImplementation(() => {});
      dashboard.addResult({ username: 'user1', success: true, reason: 'ok' });
      expect(dashboard.recentResults.length).toBe(1);
      expect(dashboard.recentResults[0].username).toBe('user1');
    });

    it('should keep only last 5 results', () => {
      jest.spyOn(dashboard, 'render').mockImplementation(() => {});
      for (let i = 0; i < 7; i++) {
        dashboard.addResult({ username: `user${i}`, success: true, reason: 'ok' });
      }
      expect(dashboard.recentResults.length).toBe(5);
    });

    it('should add most recent result first', () => {
      jest.spyOn(dashboard, 'render').mockImplementation(() => {});
      dashboard.addResult({ username: 'first', success: true, reason: 'ok' });
      dashboard.addResult({ username: 'second', success: true, reason: 'ok' });
      expect(dashboard.recentResults[0].username).toBe('second');
    });
  });

  describe('updateWorker', () => {
    it('should update worker status', () => {
      jest.spyOn(dashboard, 'render').mockImplementation(() => {});
      dashboard.updateWorker(1, { active: true, current: 'user@test.com' });
      const worker = dashboard.workers.get(1);
      expect(worker.active).toBe(true);
      expect(worker.current).toBe('user@test.com');
    });
  });

  describe('updateProxy', () => {
    it('should update proxy health', () => {
      jest.spyOn(dashboard, 'render').mockImplementation(() => {});
      dashboard.updateProxy('proxy1:8080', 75, 100);
      const health = dashboard.proxyHealth.get('proxy1:8080');
      expect(health.successRate).toBe(75);
      expect(health.attempts).toBe(100);
    });

    it('should default to 0 when values not provided', () => {
      jest.spyOn(dashboard, 'render').mockImplementation(() => {});
      dashboard.updateProxy('proxy2:8080', null, null);
      const health = dashboard.proxyHealth.get('proxy2:8080');
      expect(health.successRate).toBe(0);
      expect(health.attempts).toBe(0);
    });
  });

  describe('createProgressBar', () => {
    it('should create a progress bar string', () => {
      const bar = dashboard.createProgressBar(50, 20);
      expect(bar).toContain('50.0%');
      expect(bar).toContain('[');
      expect(bar).toContain(']');
    });

    it('should show 0% progress', () => {
      const bar = dashboard.createProgressBar(0);
      expect(bar).toContain('0.0%');
    });

    it('should show 100% progress', () => {
      const bar = dashboard.createProgressBar(100);
      expect(bar).toContain('100.0%');
    });

    it('should use filled block characters', () => {
      const bar = dashboard.createProgressBar(100, 10);
      expect(bar).toContain('█'.repeat(10));
    });
  });

  describe('formatTime', () => {
    it('should return --:-- for non-finite values', () => {
      expect(dashboard.formatTime(Infinity)).toBe('--:--');
      expect(dashboard.formatTime(-1)).toBe('--:--');
      expect(dashboard.formatTime(NaN)).toBe('--:--');
    });

    it('should format minutes correctly', () => {
      expect(dashboard.formatTime(5)).toBe('5m');
    });

    it('should format hours correctly', () => {
      expect(dashboard.formatTime(90)).toBe('1:30');
    });

    it('should format zero', () => {
      expect(dashboard.formatTime(0)).toBe('0m');
    });
  });

  describe('calculateETA', () => {
    it('should return --:-- when nothing processed', () => {
      expect(dashboard.calculateETA()).toBe('--:--');
    });

    it('should return --:-- when everything processed', () => {
      dashboard.stats.total = 100;
      dashboard.stats.processed = 100;
      expect(dashboard.calculateETA()).toBe('--:--');
    });

    it('should calculate ETA based on rate', () => {
      dashboard.stats.total = 200;
      dashboard.stats.processed = 100;
      dashboard.stats.startTime = Date.now() - 60000; // 1 minute ago
      const eta = dashboard.calculateETA();
      expect(eta).not.toBe('--:--');
    });
  });

  describe('calculateRate', () => {
    it('should return 0.0 when nothing processed', () => {
      expect(dashboard.calculateRate()).toBe('0.0');
    });

    it('should calculate rate per minute', () => {
      dashboard.stats.processed = 60;
      dashboard.stats.startTime = Date.now() - 60000;
      const rate = parseFloat(dashboard.calculateRate());
      expect(rate).toBeGreaterThan(0);
    });
  });

  describe('miniProgressBar', () => {
    it('should include green color for high rates', () => {
      const bar = dashboard.miniProgressBar(90);
      expect(bar).toContain('🟢');
    });

    it('should include yellow color for medium rates', () => {
      const bar = dashboard.miniProgressBar(60);
      expect(bar).toContain('🟡');
    });

    it('should include red color for low rates', () => {
      const bar = dashboard.miniProgressBar(20);
      expect(bar).toContain('🔴');
    });
  });

  describe('clearConsole', () => {
    it('should write ANSI clear sequence to stdout', () => {
      dashboard.clearConsole();
      expect(process.stdout.write).toHaveBeenCalledWith('\x1Bc');
    });
  });

  describe('render', () => {
    it('should throttle renders', () => {
      const clearSpy = jest.spyOn(dashboard, 'clearConsole').mockImplementation(() => {});
      dashboard.lastRender = Date.now();
      dashboard.render();
      expect(clearSpy).not.toHaveBeenCalled();
    });

    it('should render when enough time has passed', () => {
      const clearSpy = jest.spyOn(dashboard, 'clearConsole').mockImplementation(() => {});
      dashboard.lastRender = Date.now() - 1000;
      dashboard.stats.total = 100;
      dashboard.stats.processed = 50;
      dashboard.render();
      expect(clearSpy).toHaveBeenCalled();
    });

    it('should skip render when isRendering flag is set', () => {
      const clearSpy = jest.spyOn(dashboard, 'clearConsole').mockImplementation(() => {});
      dashboard.isRendering = true;
      dashboard.lastRender = 0;
      dashboard.render();
      expect(clearSpy).not.toHaveBeenCalled();
    });

    it('should render workers if present', () => {
      dashboard.lastRender = 0;
      dashboard.workers.set(1, { active: true, current: 'user@test.com', timestamp: Date.now() });
      dashboard.render();
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Worker'));
    });

    it('should render recent results if present', () => {
      dashboard.lastRender = 0;
      dashboard.recentResults = [{ username: 'user1', success: true, reason: 'ok', timestamp: Date.now() }];
      dashboard.render();
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Recent'));
    });

    it('should render proxy health if present', () => {
      dashboard.lastRender = 0;
      dashboard.proxyHealth.set('proxy:8080', { successRate: 75, attempts: 10, timestamp: Date.now() });
      dashboard.render();
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Proxy'));
    });
  });

  describe('renderFinalSummary', () => {
    it('should render final summary to console', () => {
      jest.spyOn(dashboard, 'clearConsole').mockImplementation(() => {});
      dashboard.stats.processed = 100;
      dashboard.stats.successful = 50;
      dashboard.renderFinalSummary();
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('FINAL'));
    });
  });
});
