/**
 * Unit Tests for CAS Detection Module
 * Tests all detection methods and edge cases
 */

const { CASDetector, submitAndDetectCasFlow } = require('../../utils/casDetection');

describe('CASDetector', () => {
  let detector;

  beforeEach(() => {
    detector = new CASDetector();
  });

  describe('detectOAuthCodeRedirect', () => {
    it('should detect valid OAuth code redirect URL', () => {
      const url = 'https://www.supercard.ch/de.nocache.html?code=OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0';
      const result = detector.detectOAuthCodeRedirect(url);
      
      expect(result).not.toBeNull();
      expect(result.type).toBe('oauth_code_redirect');
      expect(result.code).toBe('OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0');
      expect(result.method).toBe('oauth_authorization_code');
      expect(result.priority).toBe('primary');
      expect(result.url).toBe(url);
    });

    it('should detect code without www prefix', () => {
      const url = 'https://supercard.ch/de.nocache.html?code=OC-169617-Km-SLJiWfU-ZoMWkuP4jsgG3zyQRG22Y-cas-85dc444855-mini0';
      const result = detector.detectOAuthCodeRedirect(url);
      
      expect(result).not.toBeNull();
      expect(result.code).toBe('OC-169617-Km-SLJiWfU-ZoMWkuP4jsgG3zyQRG22Y-cas-85dc444855-mini0');
    });

    it('should detect code with different locale (fr)', () => {
      const url = 'https://www.supercard.ch/fr.nocache.html?code=OC-169044-lyWSS6g5GtQGZsQxMXuTd0bcH-XlA45E-cas-85dc444855-vao4s';
      const result = detector.detectOAuthCodeRedirect(url);
      
      expect(result).not.toBeNull();
      expect(result.code).toBe('OC-169044-lyWSS6g5GtQGZsQxMXuTd0bcH-XlA45E-cas-85dc444855-vao4s');
    });

    it('should detect code with different locale (it)', () => {
      const url = 'https://www.supercard.ch/it.nocache.html?code=OC-170146-bBzSOVzN-AZcQExruHIjKuFeZaUf-H5r-cas-85dc444855-7sb4f';
      const result = detector.detectOAuthCodeRedirect(url);
      
      expect(result).not.toBeNull();
      expect(result.code).toBe('OC-170146-bBzSOVzN-AZcQExruHIjKuFeZaUf-H5r-cas-85dc444855-7sb4f');
    });

    it('should require protocol in URL', () => {
      const url = 'supercard.ch/de.nocache.html?code=OC-169617-Km-SLJiWfU-ZoMWkuP4jsgG3zyQRG22Y-cas-85dc444855-mini';
      const result = detector.detectOAuthCodeRedirect(url);
      
      // Without http:// or https://, the pattern won't match
      expect(result).toBeNull();
    });

    it('should return null for URL without code parameter', () => {
      const url = 'https://www.supercard.ch/de.nocache.html?other=param';
      const result = detector.detectOAuthCodeRedirect(url);
      
      expect(result).toBeNull();
    });

    it('should return null for URL with invalid code format', () => {
      const url = 'https://www.supercard.ch/de.nocache.html?code=INVALID-CODE';
      const result = detector.detectOAuthCodeRedirect(url);
      
      expect(result).toBeNull();
    });

    it('should return null for invalid URL', () => {
      expect(detector.detectOAuthCodeRedirect('')).toBeNull();
      expect(detector.detectOAuthCodeRedirect(null)).toBeNull();
      expect(detector.detectOAuthCodeRedirect(undefined)).toBeNull();
      expect(detector.detectOAuthCodeRedirect(123)).toBeNull();
    });

    it('should handle case-insensitive domain matching', () => {
      const url = 'HTTPS://WWW.SUPERCARD.CH/de.nocache.html?code=OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0';
      const result = detector.detectOAuthCodeRedirect(url);
      
      expect(result).not.toBeNull();
      expect(result.code).toBe('OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0');
    });

    it('should detect all provided example URLs with protocols', () => {
      const examples = [
        'https://www.supercard.ch/de.nocache.html?code=OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0',
        'https://www.supercard.ch/de.nocache.html?code=OC-169044-lyWSS6g5GtQGZsQxMXuTd0bcH-XlA45E-cas-85dc444855-vao4s',
        'https://www.supercard.ch/de.nocache.html?code=OC-170146-bBzSOVzN-AZcQExruHIjKuFeZaUf-H5r-cas-85dc444855-7sb4f',
        'https://supercard.ch/de.nocache.html?code=OC-169617-Km-SLJiWfU-ZoMWkuP4jsgG3zyQRG22Y-cas-85dc444855-mini',
        'https://www.supercard.ch/de.nocache.html?code=OC-169080-PNM3x669aPbdExdfNaXh9y7TaJmo7JWY-cas-85dc444855-vao4s',
        'https://www.supercard.ch/de.nocache.html?code=OC-169647-TDMFyOsxT2AmUNUPc-7optgKzc-5VbzM-cas-85dc444855-mini0'
      ];

      examples.forEach(url => {
        const result = detector.detectOAuthCodeRedirect(url);
        expect(result).not.toBeNull();
        expect(result.type).toBe('oauth_code_redirect');
        expect(result.code).toMatch(/^OC-\d{6}-/);
      });
    });
  });

  describe('isValidOAuthCodeFormat', () => {
    it('should validate correct OAuth code formats', () => {
      expect(detector.isValidOAuthCodeFormat('OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0')).toBe(true);
      expect(detector.isValidOAuthCodeFormat('OC-169044-lyWSS6g5GtQGZsQxMXuTd0bcH-XlA45E-cas-85dc444855-vao4s')).toBe(true);
      expect(detector.isValidOAuthCodeFormat('OC-170146-bBzSOVzN-AZcQExruHIjKuFeZaUf-H5r-cas-85dc444855-7sb4f')).toBe(true);
      expect(detector.isValidOAuthCodeFormat('OC-169617-Km-SLJiWfU-ZoMWkuP4jsgG3zyQRG22Y-cas-85dc444855-mini0')).toBe(true);
    });

    it('should reject invalid OAuth code formats', () => {
      expect(detector.isValidOAuthCodeFormat('INVALID-CODE')).toBe(false);
      expect(detector.isValidOAuthCodeFormat('ST-123456-ABCDEF')).toBe(false);
      expect(detector.isValidOAuthCodeFormat('OC-123-short')).toBe(false);
      expect(detector.isValidOAuthCodeFormat('OC-1234567-toolong-cas-123-xyz')).toBe(false);
      expect(detector.isValidOAuthCodeFormat('OC-169606-missing-cas-part')).toBe(false);
    });

    it('should handle invalid inputs', () => {
      expect(detector.isValidOAuthCodeFormat('')).toBe(false);
      expect(detector.isValidOAuthCodeFormat(null)).toBe(false);
      expect(detector.isValidOAuthCodeFormat(undefined)).toBe(false);
      expect(detector.isValidOAuthCodeFormat(123)).toBe(false);
    });

    it('should handle case insensitivity', () => {
      expect(detector.isValidOAuthCodeFormat('oc-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0')).toBe(true);
      expect(detector.isValidOAuthCodeFormat('OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-CAS-85dc444855-mini0')).toBe(true);
    });
  });

  describe('extractOAuthCode', () => {
    it('should extract OAuth code from URL', () => {
      const url = 'https://www.supercard.ch/de.nocache.html?code=OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0';
      expect(detector.extractOAuthCode(url)).toBe('OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0');
    });

    it('should extract OAuth code from URL with multiple parameters', () => {
      const url = 'https://www.supercard.ch/de.nocache.html?code=OC-169044-lyWSS6g5GtQGZsQxMXuTd0bcH-XlA45E-cas-85dc444855-vao4s&other=param';
      expect(detector.extractOAuthCode(url)).toBe('OC-169044-lyWSS6g5GtQGZsQxMXuTd0bcH-XlA45E-cas-85dc444855-vao4s');
    });

    it('should return null for URL without code parameter', () => {
      const url = 'https://www.supercard.ch/de.nocache.html?other=param';
      expect(detector.extractOAuthCode(url)).toBeNull();
    });

    it('should handle invalid inputs', () => {
      expect(detector.extractOAuthCode('')).toBeNull();
      expect(detector.extractOAuthCode(null)).toBeNull();
      expect(detector.extractOAuthCode(undefined)).toBeNull();
    });

    it('should extract OAuth code with underscores and hyphens', () => {
      const url = 'https://www.supercard.ch/de.nocache.html?code=OC-169617-Km-SLJiWfU-ZoMWkuP4jsgG3zyQRG22Y-cas-85dc444855-mini_0';
      expect(detector.extractOAuthCode(url)).toBe('OC-169617-Km-SLJiWfU-ZoMWkuP4jsgG3zyQRG22Y-cas-85dc444855-mini_0');
    });
  });

  describe('detectCASTicketRedirect', () => {
    it('should detect valid CAS ticket redirect URL', () => {
      const url = 'https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?ticket=ST-123456-ABCDEF&client_id=test';
      const result = detector.detectCASTicketRedirect(url);
      
      expect(result).not.toBeNull();
      expect(result.type).toBe('cas_ticket_redirect');
      expect(result.ticket).toBe('ST-123456-ABCDEF');
      expect(result.method).toBe('ticket_parameter');
      expect(result.priority).toBe('secondary');
      expect(result.url).toBe(url);
    });

    it('should detect ticket with complex format', () => {
      const url = 'https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?ticket=ST-999-AAAAA-BBBBB-12345&other=param';
      const result = detector.detectCASTicketRedirect(url);
      
      expect(result).not.toBeNull();
      expect(result.ticket).toBe('ST-999-AAAAA-BBBBB-12345');
    });

    it('should return null for URL without ticket', () => {
      const url = 'https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?client_id=test';
      const result = detector.detectCASTicketRedirect(url);
      
      expect(result).toBeNull();
    });

    it('should return null for invalid URL', () => {
      expect(detector.detectCASTicketRedirect('')).toBeNull();
      expect(detector.detectCASTicketRedirect(null)).toBeNull();
      expect(detector.detectCASTicketRedirect(undefined)).toBeNull();
      expect(detector.detectCASTicketRedirect(123)).toBeNull();
    });

    it('should handle case-insensitive matching', () => {
      const url = 'HTTPS://LOGIN.SUPERCARD.CH/CAS/OAUTH2.0/CALLBACKAUTHORIZE?TICKET=ST-123';
      const result = detector.detectCASTicketRedirect(url);
      
      expect(result).not.toBeNull();
      expect(result.ticket).toBe('ST-123');
    });

    it('should detect ticket anywhere in query string', () => {
      const url = 'https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?a=1&b=2&ticket=ST-ABC&c=3';
      const result = detector.detectCASTicketRedirect(url);
      
      expect(result).not.toBeNull();
      expect(result.ticket).toBe('ST-ABC');
    });
  });

  describe('isCallbackAuthorizeURL', () => {
    it('should validate correct callback authorize URL', () => {
      const url = 'https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?client_id=test&scope=openid';
      expect(detector.isCallbackAuthorizeURL(url)).toBe(true);
    });

    it('should validate URL with ticket parameter', () => {
      const url = 'https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?ticket=ST-123';
      expect(detector.isCallbackAuthorizeURL(url)).toBe(true);
    });

    it('should reject URL without required parameters', () => {
      const url = 'https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?random=param';
      expect(detector.isCallbackAuthorizeURL(url)).toBe(false);
    });

    it('should reject non-callback URLs', () => {
      expect(detector.isCallbackAuthorizeURL('https://www.supercard.ch')).toBe(false);
      expect(detector.isCallbackAuthorizeURL('https://login.supercard.ch/cas/login')).toBe(false);
    });

    it('should handle invalid inputs', () => {
      expect(detector.isCallbackAuthorizeURL('')).toBe(false);
      expect(detector.isCallbackAuthorizeURL(null)).toBe(false);
      expect(detector.isCallbackAuthorizeURL(undefined)).toBe(false);
    });
  });

  describe('extractTicket', () => {
    it('should extract ticket from query string', () => {
      const url = 'https://example.com?ticket=ST-12345&other=param';
      expect(detector.extractTicket(url)).toBe('ST-12345');
    });

    it('should extract ticket from middle of query string', () => {
      const url = 'https://example.com?a=1&ticket=ST-999&b=2';
      expect(detector.extractTicket(url)).toBe('ST-999');
    });

    it('should return null for URL without ticket', () => {
      const url = 'https://example.com?other=param';
      expect(detector.extractTicket(url)).toBeNull();
    });

    it('should handle invalid inputs', () => {
      expect(detector.extractTicket('')).toBeNull();
      expect(detector.extractTicket(null)).toBeNull();
      expect(detector.extractTicket(undefined)).toBeNull();
    });

    it('should extract ticket with special characters', () => {
      const url = 'https://example.com?ticket=ST-123-ABC-DEF-456';
      expect(detector.extractTicket(url)).toBe('ST-123-ABC-DEF-456');
    });
  });

  describe('isValidTicketFormat', () => {
    it('should validate correct ticket formats', () => {
      expect(detector.isValidTicketFormat('ST-123456-ABCDEF')).toBe(true);
      expect(detector.isValidTicketFormat('ST-1')).toBe(true);
      expect(detector.isValidTicketFormat('ST-999-AAA-BBB-CCC-123')).toBe(true);
    });

    it('should reject invalid ticket formats', () => {
      expect(detector.isValidTicketFormat('TGC-123456')).toBe(false);
      expect(detector.isValidTicketFormat('123456')).toBe(false);
      expect(detector.isValidTicketFormat('ST_123')).toBe(false); // underscore not allowed
      expect(detector.isValidTicketFormat('ST 123')).toBe(false); // space not allowed
    });

    it('should handle invalid inputs', () => {
      expect(detector.isValidTicketFormat('')).toBe(false);
      expect(detector.isValidTicketFormat(null)).toBe(false);
      expect(detector.isValidTicketFormat(undefined)).toBe(false);
      expect(detector.isValidTicketFormat(123)).toBe(false);
    });

    it('should handle case insensitivity for letters after ST prefix', () => {
      // ST prefix accepts any case, followed by alphanumeric
      expect(detector.isValidTicketFormat('ST-123')).toBe(true);
      expect(detector.isValidTicketFormat('ST-abc')).toBe(true);
      expect(detector.isValidTicketFormat('ST-ABC')).toBe(true);
      expect(detector.isValidTicketFormat('ST-AbC-123')).toBe(true);
    });
  });

  describe('detectTGCCookie', () => {
    it('should detect TGC cookie in cookie string', () => {
      const cookieString = 'sessionid=abc123; CASTGC=TGT-123-ABCDEF; other=value';
      const result = detector.detectTGCCookie(cookieString);
      
      expect(result).not.toBeNull();
      expect(result.type).toBe('cas_tgc_cookie');
      expect(result.cookie).toBe('CASTGC=TGT-123-ABCDEF');
      expect(result.method).toBe('tgc_cookie');
      expect(result.priority).toBe('fallback');
    });

    it('should detect TGC cookie at start of string', () => {
      const cookieString = 'CASTGC=TGT-999; other=value';
      const result = detector.detectTGCCookie(cookieString);
      
      expect(result).not.toBeNull();
      expect(result.cookie).toMatch(/CASTGC=TGT-999/);
    });

    it('should detect TGC cookie at end of string', () => {
      const cookieString = 'other=value; CASTGC=TGT-XYZ';
      const result = detector.detectTGCCookie(cookieString);
      
      expect(result).not.toBeNull();
    });

    it('should return null when TGC cookie not present', () => {
      const cookieString = 'sessionid=abc123; other=value';
      const result = detector.detectTGCCookie(cookieString);
      
      expect(result).toBeNull();
    });

    it('should handle invalid inputs', () => {
      expect(detector.detectTGCCookie('')).toBeNull();
      expect(detector.detectTGCCookie(null)).toBeNull();
      expect(detector.detectTGCCookie(undefined)).toBeNull();
    });

    it('should handle case-insensitive matching', () => {
      const cookieString = 'castgc=TGT-123';
      const result = detector.detectTGCCookie(cookieString);
      
      expect(result).not.toBeNull();
    });
  });

  describe('detect (main detection method)', () => {
    it('should prioritize OAuth code redirect over CAS ticket and TGC cookie', () => {
      const context = {
        url: 'https://www.supercard.ch/de.nocache.html?code=OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0',
        cookies: 'CASTGC=TGT-999'
      };
      const result = detector.detect(context);
      
      expect(result).not.toBeNull();
      expect(result.type).toBe('oauth_code_redirect');
      expect(result.code).toBe('OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0');
      expect(result.authenticated).toBe(true);
      expect(result.validated).toBe(true);
    });

    it('should prioritize CAS ticket redirect over TGC cookie when no OAuth code', () => {
      const context = {
        url: 'https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?ticket=ST-123',
        cookies: 'CASTGC=TGT-999'
      };
      const result = detector.detect(context);
      
      expect(result).not.toBeNull();
      expect(result.type).toBe('cas_ticket_redirect');
      expect(result.ticket).toBe('ST-123');
      expect(result.authenticated).toBe(true);
      expect(result.validated).toBe(true);
    });

    it('should fall back to TGC cookie when no OAuth code or ticket redirect', () => {
      const context = {
        url: 'https://www.supercard.ch/account',
        cookies: 'CASTGC=TGT-999'
      };
      const result = detector.detect(context);
      
      expect(result).not.toBeNull();
      expect(result.type).toBe('cas_tgc_cookie');
      expect(result.priority).toBe('fallback');
    });

    it('should return null when no detection methods match', () => {
      const context = {
        url: 'https://www.supercard.ch/account',
        cookies: 'sessionid=abc123'
      };
      const result = detector.detect(context);
      
      expect(result).toBeNull();
    });

    it('should handle partial context (url only) with OAuth code', () => {
      const context = {
        url: 'https://www.supercard.ch/de.nocache.html?code=OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0'
      };
      const result = detector.detect(context);
      
      expect(result).not.toBeNull();
      expect(result.type).toBe('oauth_code_redirect');
    });

    it('should handle partial context (url only) with CAS ticket', () => {
      const context = {
        url: 'https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?ticket=ST-123'
      };
      const result = detector.detect(context);
      
      expect(result).not.toBeNull();
      expect(result.type).toBe('cas_ticket_redirect');
    });

    it('should handle partial context (cookies only)', () => {
      const context = {
        cookies: 'CASTGC=TGT-999'
      };
      const result = detector.detect(context);
      
      expect(result).not.toBeNull();
      expect(result.type).toBe('cas_tgc_cookie');
    });

    it('should handle invalid context', () => {
      expect(detector.detect(null)).toBeNull();
      expect(detector.detect(undefined)).toBeNull();
      expect(detector.detect({})).toBeNull();
      expect(detector.detect('string')).toBeNull();
    });

    it('should not validate ticket if format is invalid', () => {
      const context = {
        url: 'https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?ticket=INVALID-123'
      };
      const result = detector.detect(context);
      
      expect(result).not.toBeNull();
      expect(result.validated).toBeUndefined();
      expect(result.authenticated).toBeUndefined();
    });
  });

  describe('parseCallbackAuthorizeURL', () => {
    it('should parse valid callback authorize URL', () => {
      const url = 'https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?client_id=123&scope=openid&ticket=ST-999';
      const result = detector.parseCallbackAuthorizeURL(url);
      
      expect(result).not.toBeNull();
      expect(result.client_id).toBe('123');
      expect(result.scope).toBe('openid');
      expect(result.ticket).toBe('ST-999');
    });

    it('should extract all standard parameters', () => {
      const url = 'https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?' +
        'client_id=app123&scope=openid%20profile&redirect_uri=https://example.com&' +
        'response_type=code&idpv=1&locale=de&client_name=TestApp&ticket=ST-123';
      const result = detector.parseCallbackAuthorizeURL(url);
      
      expect(result).not.toBeNull();
      expect(result.client_id).toBe('app123');
      expect(result.scope).toBe('openid profile');
      expect(result.redirect_uri).toBe('https://example.com');
      expect(result.response_type).toBe('code');
      expect(result.idpv).toBe('1');
      expect(result.locale).toBe('de');
      expect(result.client_name).toBe('TestApp');
      expect(result.ticket).toBe('ST-123');
    });

    it('should return null for non-callback URL', () => {
      const url = 'https://www.supercard.ch/account';
      const result = detector.parseCallbackAuthorizeURL(url);
      
      expect(result).toBeNull();
    });

    it('should return null for invalid callback URL', () => {
      const url = 'https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?random=param';
      const result = detector.parseCallbackAuthorizeURL(url);
      
      expect(result).toBeNull();
    });

    it('should handle missing optional parameters', () => {
      const url = 'https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?client_id=123';
      const result = detector.parseCallbackAuthorizeURL(url);
      
      expect(result).not.toBeNull();
      expect(result.client_id).toBe('123');
      expect(result.ticket).toBeNull();
      expect(result.scope).toBeNull();
    });
  });
});

describe('submitAndDetectCasFlow', () => {
  let mockPage;

  beforeEach(() => {
    mockPage = {
      url: jest.fn(),
      cookies: jest.fn(),
      evaluate: jest.fn().mockResolvedValue('') // Default empty body text
    };
  });

  it('should detect OAuth code redirect with highest confidence', async () => {
    mockPage.url.mockResolvedValue('https://www.supercard.ch/de.nocache.html?code=OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0');
    mockPage.cookies.mockResolvedValue([]);

    const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'password', {
      verbose: false,
      timeoutMs: 1000
    });

    expect(result.ok).toBe(true);
    expect(result.type).toBe('success');
    expect(result.reason).toBe('oauth_code_redirect');
    expect(result.confidence).toBe(0.99);
    expect(result.code).toBe('OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0');
  });

  it('should prioritize OAuth code over CAS ticket redirect', async () => {
    // First call returns OAuth code URL, second call returns CAS ticket URL
    let callCount = 0;
    mockPage.url.mockImplementation(() => {
      callCount++;
      if (callCount === 1) {
        return Promise.resolve('https://www.supercard.ch/de.nocache.html?code=OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0');
      }
      return Promise.resolve('https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?ticket=ST-123456-ABCDEF');
    });
    mockPage.cookies.mockResolvedValue([]);

    const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'password', {
      verbose: false,
      timeoutMs: 1000
    });

    expect(result.ok).toBe(true);
    expect(result.reason).toBe('oauth_code_redirect');
    expect(result.confidence).toBe(0.99);
    expect(result.code).toBeDefined();
  });

  it('should detect CAS ticket redirect when no OAuth code present', async () => {
    mockPage.url.mockResolvedValue('https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?ticket=ST-123456-ABCDEF');
    mockPage.cookies.mockResolvedValue([]);

    const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'password', {
      verbose: false,
      timeoutMs: 1000
    });

    expect(result.ok).toBe(true);
    expect(result.type).toBe('success');
    expect(result.reason).toBe('cas_ticket_redirect');
    expect(result.confidence).toBe(0.95);
    expect(result.ticket).toBe('ST-123456-ABCDEF');
  });

  it('should detect CAS ticket redirect with high confidence', async () => {
    mockPage.url.mockResolvedValue('https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?ticket=ST-123456-ABCDEF');
    mockPage.cookies.mockResolvedValue([]);

    const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'password', {
      verbose: false,
      timeoutMs: 1000
    });

    expect(result.ok).toBe(true);
    expect(result.type).toBe('success');
    expect(result.reason).toBe('cas_ticket_redirect');
    expect(result.confidence).toBe(0.95);
    expect(result.ticket).toBe('ST-123456-ABCDEF');
  });

  it('should detect TGC cookie when no redirect present', async () => {
    mockPage.url.mockResolvedValue('https://www.supercard.ch/de/mein-konto.html');
    mockPage.cookies.mockResolvedValue([
      { name: 'TGC', value: 'CASTGC=TGT-123-ABCDEF', domain: '.supercard.ch', secure: true }
    ]);

    const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'password', {
      verbose: false,
      timeoutMs: 1000,
      enableTGCDetection: true
    });

    expect(result.ok).toBe(true);
    expect(result.type).toBe('success');
    expect(result.reason).toBe('tgc_cookie_detected');
    expect(result.confidence).toBe(0.99);
    expect(result.cookie.name).toBe('TGC');
  });

  it('should return failure when no detection occurs within timeout', async () => {
    mockPage.url.mockResolvedValue('https://login.supercard.ch/cas/login');
    mockPage.cookies.mockResolvedValue([]);

    const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'password', {
      verbose: false,
      timeoutMs: 500
    });

    expect(result.ok).toBe(false);
    expect(result.type).toBe('failure');
    expect(result.reason).toBe('no_success_indicator');
    expect(result.confidence).toBe(0.0);
  });

  it('should use custom TGC cookie names', async () => {
    mockPage.url.mockResolvedValue('https://www.supercard.ch/account');
    mockPage.cookies.mockResolvedValue([
      { name: 'CUSTOM_TGC', value: 'CASTGC=TGT-999', domain: '.supercard.ch', secure: true }
    ]);

    const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'password', {
      verbose: false,
      timeoutMs: 1000,
      tgcCookieNames: ['CUSTOM_TGC'],
      enableTGCDetection: true
    });

    expect(result.ok).toBe(true);
    expect(result.cookie.name).toBe('CUSTOM_TGC');
  });

  it('should handle page errors gracefully', async () => {
    mockPage.url.mockRejectedValue(new Error('Page closed'));
    mockPage.cookies.mockResolvedValue([]);

    const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'password', {
      verbose: false,
      timeoutMs: 500
    });

    expect(result.ok).toBe(false);
    expect(result.type).toBe('failure');
  });

  it('should handle missing page.cookies() method gracefully', async () => {
    // Create a page object without cookies method (simulates Strategy 3 failure)
    const pageWithoutCookies = {
      url: jest.fn().mockResolvedValue('https://login.supercard.ch/cas/login'),
      evaluate: jest.fn().mockResolvedValue(''),
      // cookies method is intentionally missing/undefined
      cookies: undefined
    };

    const result = await submitAndDetectCasFlow(pageWithoutCookies, 'test@example.com', 'password', {
      verbose: false,
      timeoutMs: 500,
      enableTGCDetection: true
    });

    // Should fail gracefully without throwing error
    expect(result.ok).toBe(false);
    expect(result.type).toBe('failure');
    expect(result.reason).toBe('no_success_indicator');
  });

  it('should handle page.cookies() throwing error', async () => {
    mockPage.url.mockResolvedValue('https://login.supercard.ch/cas/login');
    mockPage.cookies.mockRejectedValue(new Error('page.cookies is not a function'));

    const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'password', {
      verbose: false,
      timeoutMs: 500,
      enableTGCDetection: true
    });

    // Should handle error gracefully and continue
    expect(result.ok).toBe(false);
    expect(result.type).toBe('failure');
    expect(result.reason).toBe('no_success_indicator');
  });

  it('should include duration in result', async () => {
    mockPage.url.mockResolvedValue('https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?ticket=ST-123');
    mockPage.cookies.mockResolvedValue([]);

    const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'password', {
      timeoutMs: 1000
    });

    expect(result.duration).toBeDefined();
    expect(typeof result.duration).toBe('number');
    expect(result.duration).toBeGreaterThan(0);
  });

  it('should call page.cookies() when enableTGCDetection is true (default)', async () => {
    mockPage.url.mockResolvedValue('https://www.supercard.ch/account');
    mockPage.cookies.mockResolvedValue([
      { name: 'TGC', value: 'CASTGC=TGT-123', domain: '.supercard.ch', secure: true }
    ]);

    const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'password', {
      verbose: false,
      timeoutMs: 1000  // Standard timeout for TGC detection tests (see other tests in this suite)
    });

    // Should succeed because TGC detection is enabled by default
    expect(result.ok).toBe(true);
    expect(result.type).toBe('success');
    expect(result.reason).toBe('tgc_cookie_detected');
    // Cookies should be called when TGC detection is enabled
    expect(mockPage.cookies).toHaveBeenCalled();
  });

  it('should detect TGC cookie when enableTGCDetection is true', async () => {
    mockPage.url.mockResolvedValue('https://www.supercard.ch/account');
    mockPage.cookies.mockResolvedValue([
      { name: 'TGC', value: 'CASTGC=TGT-123', domain: '.supercard.ch', secure: true }
    ]);

    const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'password', {
      verbose: false,
      timeoutMs: 1000,
      enableTGCDetection: true
    });

    // Should succeed when TGC detection is enabled
    expect(result.ok).toBe(true);
    expect(result.type).toBe('success');
    expect(result.reason).toBe('tgc_cookie_detected');
    expect(mockPage.cookies).toHaveBeenCalled();
  });

  it('should not detect TGC cookie when enableTGCDetection is explicitly false', async () => {
    mockPage.url.mockResolvedValue('https://www.supercard.ch/account');
    mockPage.cookies.mockResolvedValue([
      { name: 'TGC', value: 'CASTGC=TGT-123', domain: '.supercard.ch', secure: true }
    ]);

    const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'password', {
      verbose: false,
      timeoutMs: 500,
      enableTGCDetection: false
    });

    // Should fail because TGC detection is explicitly disabled
    expect(result.ok).toBe(false);
    expect(result.type).toBe('failure');
    expect(mockPage.cookies).not.toHaveBeenCalled();
  });

  it('should prioritize ticket redirect even when enableTGCDetection is true', async () => {
    mockPage.url.mockResolvedValue('https://login.supercard.ch/cas/oauth2.0/callbackAuthorize?ticket=ST-123');
    mockPage.cookies.mockResolvedValue([
      { name: 'TGC', value: 'CASTGC=TGT-999', domain: '.supercard.ch', secure: true }
    ]);

    const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'password', {
      verbose: false,
      timeoutMs: 1000,
      enableTGCDetection: true
    });

    // Should use ticket redirect (secondary) not TGC cookie (fallback)
    expect(result.ok).toBe(true);
    expect(result.reason).toBe('cas_ticket_redirect');
    expect(result.ticket).toBe('ST-123');
    // Cookies should not be called because ticket redirect was detected first
    expect(mockPage.cookies).not.toHaveBeenCalled();
  });

  it('should prioritize OAuth code over both CAS ticket and TGC cookie', async () => {
    mockPage.url.mockResolvedValue('https://www.supercard.ch/de.nocache.html?code=OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0');
    mockPage.cookies.mockResolvedValue([
      { name: 'TGC', value: 'CASTGC=TGT-999', domain: '.supercard.ch', secure: true }
    ]);

    const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'password', {
      verbose: false,
      timeoutMs: 1000,
      enableTGCDetection: true
    });

    // Should use OAuth code redirect (primary) not ticket redirect or TGC cookie
    expect(result.ok).toBe(true);
    expect(result.reason).toBe('oauth_code_redirect');
    expect(result.confidence).toBe(0.99);
    expect(result.code).toBe('OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0');
    // Cookies should not be called because OAuth code was detected first
    expect(mockPage.cookies).not.toHaveBeenCalled();
  });

  describe('Invalid Credentials Detection', () => {
    it('should detect invalid credentials with German error message', async () => {
      const errorMessage = 'Bitte überprüfen Sie Ihre Eingaben und versuchen Sie es erneut.';
      
      mockPage.url.mockResolvedValue('https://login.supercard.ch/cas/login');
      mockPage.evaluate.mockResolvedValue(errorMessage);

      const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'wrongpassword', {
        verbose: false,
        timeoutMs: 500
      });

      expect(result.ok).toBe(false);
      expect(result.type).toBe('failure');
      expect(result.reason).toBe('invalid_credentials');
      expect(result.confidence).toBe(0.95);
      expect(result.method).toBe('error_message_detection');
      expect(result.detectionMethod).toBe('invalid_credentials_phrase');
      expect(result.details).toContain('Invalid credentials error message');
    });

    it('should detect invalid credentials with extra whitespace in message', async () => {
      const errorMessage = 'Bitte  überprüfen   Sie Ihre  Eingaben und   versuchen Sie es  erneut.';
      
      mockPage.url.mockResolvedValue('https://login.supercard.ch/cas/login');
      mockPage.evaluate.mockResolvedValue(errorMessage);

      const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'wrongpassword', {
        verbose: false,
        timeoutMs: 500
      });

      expect(result.ok).toBe(false);
      expect(result.reason).toBe('invalid_credentials');
      expect(result.confidence).toBe(0.95);
    });

    it('should detect invalid credentials regardless of case', async () => {
      const errorMessage = 'BITTE ÜBERPRÜFEN SIE IHRE EINGABEN UND VERSUCHEN SIE ES ERNEUT.';
      
      mockPage.url.mockResolvedValue('https://login.supercard.ch/cas/login');
      mockPage.evaluate.mockResolvedValue(errorMessage);

      const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'wrongpassword', {
        verbose: false,
        timeoutMs: 500
      });

      expect(result.ok).toBe(false);
      expect(result.reason).toBe('invalid_credentials');
      expect(result.confidence).toBe(0.95);
    });

    it('should detect invalid credentials within longer page text', async () => {
      const pageText = `
        Some header text
        Login Form
        Bitte überprüfen Sie Ihre Eingaben und versuchen Sie es erneut.
        Footer text
      `;
      
      mockPage.url.mockResolvedValue('https://login.supercard.ch/cas/login');
      mockPage.evaluate.mockResolvedValue(pageText);

      const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'wrongpassword', {
        verbose: false,
        timeoutMs: 500
      });

      expect(result.ok).toBe(false);
      expect(result.reason).toBe('invalid_credentials');
      expect(result.confidence).toBe(0.95);
    });

    it('should not detect invalid credentials when message is not present', async () => {
      mockPage.url.mockResolvedValue('https://login.supercard.ch/cas/login');
      mockPage.evaluate.mockResolvedValue('Some other page content without the error message');

      const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'password', {
        verbose: false,
        timeoutMs: 500
      });

      expect(result.ok).toBe(false);
      expect(result.reason).toBe('no_success_indicator');
      expect(result.confidence).toBe(0.0);
    });

    it('should handle error when checking for invalid credentials', async () => {
      mockPage.url.mockResolvedValue('https://login.supercard.ch/cas/login');
      mockPage.evaluate.mockRejectedValue(new Error('Page evaluation failed'));

      const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'password', {
        verbose: false,
        timeoutMs: 500
      });

      // Should fallback to no_success_indicator when evaluation fails
      expect(result.ok).toBe(false);
      expect(result.reason).toBe('no_success_indicator');
    });

    it('should prioritize OAuth success over invalid credentials check', async () => {
      // If a success indicator is found, it should return before checking for invalid credentials
      mockPage.url.mockResolvedValue('https://www.supercard.ch/de.nocache.html?code=OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0');
      mockPage.evaluate.mockResolvedValue('Bitte überprüfen Sie Ihre Eingaben und versuchen Sie es erneut.');

      const result = await submitAndDetectCasFlow(mockPage, 'test@example.com', 'password', {
        verbose: false,
        timeoutMs: 1000
      });

      // Should detect success, not invalid credentials
      expect(result.ok).toBe(true);
      expect(result.reason).toBe('oauth_code_redirect');
      expect(result.confidence).toBe(0.99);
    });
  });
});

describe('submitAndDetectCasFlowOptimized', () => {
  const { submitAndDetectCasFlowOptimized } = require('../../utils/casDetection');
  let mockPage;
  let registeredHandlers;

  beforeEach(() => {
    registeredHandlers = {};

    mockPage = {
      url: jest.fn().mockReturnValue('https://login.supercard.ch/cas/login'),
      isClosed: jest.fn().mockReturnValue(false),
      cookies: jest.fn().mockResolvedValue([]),
      evaluate: jest.fn().mockResolvedValue(false),
      on: jest.fn((event, handler) => {
        registeredHandlers[event] = registeredHandlers[event] || [];
        registeredHandlers[event].push(handler);
      }),
      off: jest.fn()
    };
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should resolve detection_timeout when no indicators detected and timeout fires', async () => {
    // timeoutMs: 50 → resolves after ~250ms (200ms stabilization + 50ms timeout)
    const result = await submitAndDetectCasFlowOptimized(mockPage, 'user@test.com', 'pass', {
      timeoutMs: 50,
      verbose: false,
      enableTGCDetection: false
    });

    expect(result.ok).toBe(false);
    expect(result.reason).toBe('detection_timeout');
  }, 5000);

  it('should detect success via account domain + DOM verification at timeout', async () => {
    // Simulate browser already navigated to account domain
    mockPage.url.mockReturnValue('https://www.supercard.ch/de/mein-konto.html');
    // DOM verification succeeds (e.g. balance element present)
    mockPage.evaluate.mockResolvedValue(true);

    const result = await submitAndDetectCasFlowOptimized(mockPage, 'user@test.com', 'pass', {
      accountHost: 'www.supercard.ch',
      timeoutMs: 50,
      verbose: false,
      enableTGCDetection: false
    });

    expect(result.ok).toBe(true);
    expect(result.reason).toBe('account_domain_verified');
    expect(result.detectionMethod).toBe('account_domain_verified_timeout_fallback');
    expect(result.confidence).toBe(0.85);
  }, 5000);

  it('should NOT resolve success at timeout when on account domain but DOM check returns false', async () => {
    mockPage.url.mockReturnValue('https://www.supercard.ch/de/mein-konto.html');
    mockPage.evaluate.mockResolvedValue(false); // No auth indicators in DOM

    const result = await submitAndDetectCasFlowOptimized(mockPage, 'user@test.com', 'pass', {
      accountHost: 'www.supercard.ch',
      timeoutMs: 50,
      verbose: false,
      enableTGCDetection: false
    });

    expect(result.ok).toBe(false);
    expect(result.reason).toBe('detection_timeout');
  }, 5000);

  it('should detect success via framenavigated event with balance element as auth indicator', async () => {
    // DOM verification returns true (balance element found)
    mockPage.evaluate.mockResolvedValue(true);

    const resultPromise = submitAndDetectCasFlowOptimized(mockPage, 'user@test.com', 'pass', {
      accountHost: 'www.supercard.ch',
      timeoutMs: 2000,
      verbose: false,
      enableTGCDetection: false
    });

    // Wait past the 200ms internal stabilization so handlers are registered
    await new Promise(r => setTimeout(r, 250));

    // Simulate framenavigated event with account domain URL
    const framenavHandlers = registeredHandlers['framenavigated'];
    expect(framenavHandlers).toBeDefined();
    const mockFrame = { url: jest.fn().mockReturnValue('https://www.supercard.ch/de/mein-konto.html') };
    await framenavHandlers[0](mockFrame);

    const result = await resultPromise;

    expect(result.ok).toBe(true);
    expect(result.reason).toBe('account_domain_verified');
    expect(result.detectionMethod).toBe('account_domain_verified_frame_event');
    expect(result.confidence).toBe(0.92);
  }, 5000);

  it('should detect OAuth code via response event', async () => {
    const resultPromise = submitAndDetectCasFlowOptimized(mockPage, 'user@test.com', 'pass', {
      accountHost: 'www.supercard.ch',
      timeoutMs: 2000,
      verbose: false,
      enableTGCDetection: false
    });

    // Wait past the 200ms initial stabilization so handlers are registered
    await new Promise(r => setTimeout(r, 250));

    // Simulate response event with OAuth code URL
    const responseHandlers = registeredHandlers['response'];
    expect(responseHandlers).toBeDefined();
    const mockResponse = {
      url: jest.fn().mockReturnValue(
        'https://www.supercard.ch/de.nocache.html?code=OC-169606-j0vVIHZdSawDs6itMQOhCmWjp8YrFBxp-cas-85dc444855-mini0'
      ),
      status: jest.fn().mockReturnValue(200)
    };
    await responseHandlers[0](mockResponse);

    const result = await resultPromise;

    expect(result.ok).toBe(true);
    expect(result.reason).toBe('oauth_code_redirect');
    expect(result.confidence).toBe(0.99);
  }, 5000);

  it('should detect page_closed_at_timeout when page is closed at timeout', async () => {
    mockPage.isClosed.mockReturnValue(true);

    const result = await submitAndDetectCasFlowOptimized(mockPage, 'user@test.com', 'pass', {
      timeoutMs: 50,
      verbose: false,
      enableTGCDetection: false
    });

    expect(result.ok).toBe(false);
    expect(result.reason).toBe('page_closed_at_timeout');
  }, 5000);
});
