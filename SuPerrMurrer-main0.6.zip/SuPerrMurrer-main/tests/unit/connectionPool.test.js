/**
 * Unit Tests for Connection Pool Module
 * Tests browser connection pooling with bot detection optimizations
 */

const ConnectionPool = require('../../utils/connectionPool');

// Mock browser for testing
const createMockBrowser = () => ({
  close: jest.fn().mockResolvedValue(undefined),
  isConnected: jest.fn().mockReturnValue(true)
});

describe('ConnectionPool', () => {
  let pool;

  beforeEach(() => {
    jest.clearAllMocks();
    jest.useFakeTimers();
  });

  afterEach(async () => {
    if (pool) {
      await pool.closeAll();
    }
    jest.useRealTimers();
  });

  describe('constructor and configuration', () => {
    it('should initialize with optimized default values', () => {
      pool = new ConnectionPool();
      
      const config = pool.getConfig();
      expect(config.maxPoolSize).toBe(20);
      expect(config.maxIdleTime).toBe(300000); // 5 minutes
      expect(config.maxUseCount).toBe(50);
      expect(config.maxConnectionAge).toBe(1800000); // 30 minutes
    });

    it('should accept custom configuration', () => {
      pool = new ConnectionPool({
        maxPoolSize: 10,
        maxIdleTime: 600000,
        maxUseCount: 100,
        maxConnectionAge: 3600000
      });
      
      const config = pool.getConfig();
      expect(config.maxPoolSize).toBe(10);
      expect(config.maxIdleTime).toBe(600000);
      expect(config.maxUseCount).toBe(100);
      expect(config.maxConnectionAge).toBe(3600000);
    });

    it('should start automatic cleanup interval', () => {
      pool = new ConnectionPool();
      expect(pool.cleanupInterval).toBeDefined();
    });

    it('should initialize empty pool and stats', () => {
      pool = new ConnectionPool();
      
      const stats = pool.getStats();
      expect(stats.poolSize).toBe(0);
      expect(stats.available).toBe(0);
      expect(stats.inUse).toBe(0);
      expect(stats.stats.created).toBe(0);
      expect(stats.stats.reused).toBe(0);
    });
  });

  describe('acquire and release', () => {
    beforeEach(() => {
      pool = new ConnectionPool({ maxPoolSize: 5 });
    });

    it('should create new connection when pool is empty', async () => {
      const connection = await pool.acquire('proxy1');
      
      expect(connection.id).toBe(1);
      expect(connection.proxy).toBe('proxy1');
      expect(connection.browser).toBeNull();
      
      const stats = pool.getStats();
      expect(stats.poolSize).toBe(1);
      expect(stats.inUse).toBe(1);
      expect(stats.stats.created).toBe(1);
    });

    it('should set browser instance for connection', async () => {
      const connection = await pool.acquire('proxy1');
      const mockBrowser = createMockBrowser();
      
      pool.setBrowser(connection.id, mockBrowser);
      
      const details = pool.getConnectionDetails();
      expect(details[0].id).toBe(connection.id);
    });

    it('should reuse connection with matching proxy', async () => {
      const conn1 = await pool.acquire('proxy1');
      pool.setBrowser(conn1.id, createMockBrowser());
      pool.release(conn1.id);
      
      const conn2 = await pool.acquire('proxy1');
      
      expect(conn2.id).toBe(conn1.id);
      expect(pool.getStats().stats.reused).toBe(1);
      expect(pool.getStats().poolSize).toBe(1);
    });

    it('should create new connection for different proxy', async () => {
      const conn1 = await pool.acquire('proxy1');
      pool.setBrowser(conn1.id, createMockBrowser());
      pool.release(conn1.id);
      
      const conn2 = await pool.acquire('proxy2');
      
      expect(conn2.id).not.toBe(conn1.id);
      expect(pool.getStats().stats.created).toBe(2);
      expect(pool.getStats().poolSize).toBe(2);
    });

    it('should track useCount on connection reuse', async () => {
      const conn1 = await pool.acquire('proxy1');
      pool.setBrowser(conn1.id, createMockBrowser());
      pool.release(conn1.id);
      
      await pool.acquire('proxy1');
      pool.release(conn1.id);
      
      await pool.acquire('proxy1');
      
      const details = pool.getConnectionDetails();
      expect(details[0].useCount).toBe(3);
    });
  });

  describe('connection retirement (bot detection optimization)', () => {
    beforeEach(() => {
      pool = new ConnectionPool({
        maxPoolSize: 10,
        maxIdleTime: 1000, // 1 second for testing
        maxUseCount: 3,
        maxConnectionAge: 5000 // 5 seconds for testing
      });
    });

    it('should retire connection after maxUseCount', async () => {
      const conn = await pool.acquire('proxy1');
      pool.setBrowser(conn.id, createMockBrowser());
      
      // Use 3 times (initial + 2 more)
      pool.release(conn.id);
      await pool.acquire('proxy1');
      pool.release(conn.id);
      await pool.acquire('proxy1');
      pool.release(conn.id);
      
      const connection = pool.pool.get(conn.id);
      expect(pool.shouldRetire(connection)).toBe(true);
      expect(pool.getStats().stats.maxUseReached).toBeGreaterThan(0);
    });

    it('should retire connection after maxIdleTime', async () => {
      const conn = await pool.acquire('proxy1');
      pool.setBrowser(conn.id, createMockBrowser());
      pool.release(conn.id);
      
      // Advance time past maxIdleTime
      jest.advanceTimersByTime(2000);
      
      const connection = pool.pool.get(conn.id);
      expect(pool.shouldRetire(connection)).toBe(true);
    });

    it('should retire connection after maxConnectionAge', async () => {
      const conn = await pool.acquire('proxy1');
      pool.setBrowser(conn.id, createMockBrowser());
      pool.release(conn.id);
      
      // Advance time past maxConnectionAge
      jest.advanceTimersByTime(6000);
      
      const connection = pool.pool.get(conn.id);
      expect(pool.shouldRetire(connection)).toBe(true);
      expect(pool.getStats().stats.maxAgeReached).toBeGreaterThan(0);
    });

    it('should automatically remove retired connection on acquire', async () => {
      const conn1 = await pool.acquire('proxy1');
      const mockBrowser = createMockBrowser();
      pool.setBrowser(conn1.id, mockBrowser);
      pool.release(conn1.id);
      
      // Age the connection
      jest.advanceTimersByTime(6000);
      
      const conn2 = await pool.acquire('proxy1');
      
      expect(conn2.id).not.toBe(conn1.id);
      expect(mockBrowser.close).toHaveBeenCalled();
    });

    it('should automatically remove retired connection on release', async () => {
      pool = new ConnectionPool({
        maxPoolSize: 5,
        maxUseCount: 2 // Low for testing
      });

      const conn = await pool.acquire('proxy1');
      const mockBrowser = createMockBrowser();
      pool.setBrowser(conn.id, mockBrowser);
      
      // Use twice
      pool.release(conn.id);
      await pool.acquire('proxy1');
      pool.release(conn.id); // Should trigger retirement
      
      // Give time for async removal - use real timer briefly
      jest.useRealTimers();
      await new Promise(resolve => setTimeout(resolve, 10));
      jest.useFakeTimers();
      
      expect(pool.pool.has(conn.id)).toBe(false);
      expect(mockBrowser.close).toHaveBeenCalled();
    });
  });

  describe('cleanup', () => {
    beforeEach(() => {
      pool = new ConnectionPool({
        maxPoolSize: 10,
        maxIdleTime: 1000
      });
    });

    it('should clean up expired available connections', async () => {
      const conn1 = await pool.acquire('proxy1');
      const mockBrowser1 = createMockBrowser();
      pool.setBrowser(conn1.id, mockBrowser1);
      pool.release(conn1.id);
      
      const conn2 = await pool.acquire('proxy2');
      const mockBrowser2 = createMockBrowser();
      pool.setBrowser(conn2.id, mockBrowser2);
      pool.release(conn2.id);
      
      // Age connections
      jest.advanceTimersByTime(2000);
      
      const cleaned = await pool.cleanup();
      
      expect(cleaned).toBe(2);
      expect(pool.getStats().poolSize).toBe(0);
      expect(mockBrowser1.close).toHaveBeenCalled();
      expect(mockBrowser2.close).toHaveBeenCalled();
    });

    it('should not clean up in-use connections', async () => {
      const conn1 = await pool.acquire('proxy1');
      const mockBrowser = createMockBrowser();
      pool.setBrowser(conn1.id, mockBrowser);
      // Don't release - keep in use
      
      jest.advanceTimersByTime(2000);
      
      const cleaned = await pool.cleanup();
      
      expect(cleaned).toBe(0);
      expect(pool.getStats().poolSize).toBe(1);
      expect(mockBrowser.close).not.toHaveBeenCalled();
    });

    it('should run cleanup automatically every minute', async () => {
      const conn = await pool.acquire('proxy1');
      pool.setBrowser(conn.id, createMockBrowser());
      pool.release(conn.id);
      
      // Age connection past maxIdleTime
      jest.advanceTimersByTime(2000);
      
      // Trigger cleanup interval
      jest.advanceTimersByTime(60000);
      
      // Switch to real timers to allow async operations
      jest.useRealTimers();
      await new Promise(resolve => setTimeout(resolve, 50));
      jest.useFakeTimers();
      
      expect(pool.getStats().stats.expired).toBeGreaterThan(0);
    });
  });

  describe('pool size management', () => {
    beforeEach(() => {
      pool = new ConnectionPool({ maxPoolSize: 3 });
    });

    it('should respect maxPoolSize when creating connections', async () => {
      await pool.acquire('proxy1');
      await pool.acquire('proxy2');
      await pool.acquire('proxy3');
      
      const stats = pool.getStats();
      expect(stats.poolSize).toBe(3);
    });

    it('should remove oldest available connection when pool is full', async () => {
      const conn1 = await pool.acquire('proxy1');
      pool.setBrowser(conn1.id, createMockBrowser());
      pool.release(conn1.id);
      
      jest.advanceTimersByTime(100);
      
      const conn2 = await pool.acquire('proxy2');
      pool.setBrowser(conn2.id, createMockBrowser());
      pool.release(conn2.id);
      
      jest.advanceTimersByTime(100);
      
      const conn3 = await pool.acquire('proxy3');
      pool.setBrowser(conn3.id, createMockBrowser());
      pool.release(conn3.id);
      
      // Pool is full, this should remove oldest (conn1)
      const conn4 = await pool.acquire('proxy4');
      
      expect(pool.pool.has(conn1.id)).toBe(false);
      expect(pool.getStats().poolSize).toBe(3);
    });

    it('should allow overflow if all connections are in use', async () => {
      await pool.acquire('proxy1');
      await pool.acquire('proxy2');
      await pool.acquire('proxy3');
      // All in use, no available to remove
      
      const conn4 = await pool.acquire('proxy4');
      
      expect(pool.getStats().poolSize).toBe(4); // Overflow
    });
  });

  describe('statistics and monitoring', () => {
    beforeEach(() => {
      pool = new ConnectionPool();
    });

    it('should track creation statistics', async () => {
      await pool.acquire('proxy1');
      await pool.acquire('proxy2');
      
      const stats = pool.getStats();
      expect(stats.stats.created).toBe(2);
      expect(stats.stats.reused).toBe(0);
    });

    it('should track reuse statistics', async () => {
      const conn = await pool.acquire('proxy1');
      pool.setBrowser(conn.id, createMockBrowser());
      pool.release(conn.id);
      
      await pool.acquire('proxy1'); // First reuse
      pool.release(conn.id); // Release before reusing again
      await pool.acquire('proxy1'); // Second reuse
      
      const stats = pool.getStats();
      expect(stats.stats.reused).toBe(2);
    });

    it('should calculate pool utilization', async () => {
      await pool.acquire('proxy1');
      await pool.acquire('proxy2');
      const conn3 = await pool.acquire('proxy3');
      pool.release(conn3.id);
      
      const stats = pool.getStats();
      expect(stats.utilization).toBe('66.7'); // 2 in use / 3 total
    });

    it('should provide connection health status', async () => {
      pool = new ConnectionPool({
        maxPoolSize: 5,
        maxUseCount: 10,
        maxConnectionAge: 10000
      });

      const conn = await pool.acquire('proxy1');
      pool.setBrowser(conn.id, createMockBrowser());
      
      const details = pool.getConnectionDetails();
      expect(details[0].health).toBe('healthy');
      
      // Age to 80% of max age
      jest.advanceTimersByTime(8000);
      
      const details2 = pool.getConnectionDetails();
      expect(details2[0].health).toBe('warning');
    });

    it('should provide detailed connection information', async () => {
      const conn = await pool.acquire('proxy1');
      pool.setBrowser(conn.id, createMockBrowser());
      pool.release(conn.id);
      
      const details = pool.getConnectionDetails();
      
      expect(details).toHaveLength(1);
      expect(details[0]).toMatchObject({
        id: conn.id,
        proxy: 'proxy1',
        status: 'available',
        useCount: 1
      });
      expect(details[0].age).toBeGreaterThanOrEqual(0);
      expect(details[0].idleTime).toBeGreaterThanOrEqual(0);
    });
  });

  describe('closeAll', () => {
    beforeEach(() => {
      pool = new ConnectionPool();
    });

    it('should close all connections and clear pool', async () => {
      const conn1 = await pool.acquire('proxy1');
      const mockBrowser1 = createMockBrowser();
      pool.setBrowser(conn1.id, mockBrowser1);
      
      const conn2 = await pool.acquire('proxy2');
      const mockBrowser2 = createMockBrowser();
      pool.setBrowser(conn2.id, mockBrowser2);
      
      await pool.closeAll();
      
      expect(pool.getStats().poolSize).toBe(0);
      expect(pool.getStats().available).toBe(0);
      expect(pool.getStats().inUse).toBe(0);
      expect(mockBrowser1.close).toHaveBeenCalled();
      expect(mockBrowser2.close).toHaveBeenCalled();
    });

    it('should stop cleanup interval', async () => {
      const initialInterval = pool.cleanupInterval;
      expect(initialInterval).toBeDefined();
      
      await pool.closeAll();
      
      expect(pool.cleanupInterval).toBeNull();
    });

    it('should handle close errors gracefully', async () => {
      const conn = await pool.acquire('proxy1');
      const mockBrowser = createMockBrowser();
      mockBrowser.close.mockRejectedValue(new Error('Close failed'));
      pool.setBrowser(conn.id, mockBrowser);
      
      await expect(pool.closeAll()).resolves.not.toThrow();
    });
  });

  describe('force remove', () => {
    beforeEach(() => {
      pool = new ConnectionPool();
    });

    it('should force remove a specific connection', async () => {
      const conn = await pool.acquire('proxy1');
      const mockBrowser = createMockBrowser();
      pool.setBrowser(conn.id, mockBrowser);
      
      const removed = await pool.forceRemove(conn.id);
      
      expect(removed).toBe(true);
      expect(pool.pool.has(conn.id)).toBe(false);
      expect(mockBrowser.close).toHaveBeenCalled();
    });

    it('should return false for non-existent connection', async () => {
      const removed = await pool.forceRemove(999);
      expect(removed).toBe(false);
    });
  });
});