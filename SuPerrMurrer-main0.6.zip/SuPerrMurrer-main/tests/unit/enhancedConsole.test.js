/**
 * Unit Tests for EnhancedConsole Module
 * Tests initialization, console output methods, formatting, progress indicators, and tables
 */

const EnhancedConsole = require('../../utils/enhancedConsole');
const chalk = require('chalk');
const boxen = require('boxen');
const cliProgress = require('cli-progress');
const ora = require('ora');

// Mock dependencies
jest.mock('chalk', () => {
  const mockChalk = (text) => text;
  mockChalk.green = jest.fn((text) => text);
  mockChalk.yellow = jest.fn((text) => text);
  mockChalk.red = jest.fn((text) => text);
  mockChalk.blue = jest.fn((text) => text);
  mockChalk.cyan = jest.fn((text) => text);
  mockChalk.gray = jest.fn((text) => text);
  mockChalk.green.bold = jest.fn((text) => text);
  mockChalk.yellow.bold = jest.fn((text) => text);
  mockChalk.red.bold = jest.fn((text) => text);
  mockChalk.blue.bold = jest.fn((text) => text);
  mockChalk.cyan.bold = jest.fn((text) => text);
  return mockChalk;
});

jest.mock('boxen', () => jest.fn((content, options) => `[BOX: ${content}]`));

jest.mock('cli-progress', () => ({
  SingleBar: jest.fn().mockImplementation(() => ({
    start: jest.fn(),
    update: jest.fn(),
    stop: jest.fn()
  })),
  Presets: {
    shades_classic: {}
  }
}));

jest.mock('ora', () => jest.fn((options) => ({
  start: jest.fn().mockReturnThis(),
  stop: jest.fn(),
  succeed: jest.fn(),
  fail: jest.fn(),
  text: options.text
})));

describe('EnhancedConsole', () => {
  let enhancedConsole;
  let consoleLogSpy;
  let consoleClearSpy;

  beforeEach(() => {
    jest.clearAllMocks();
    enhancedConsole = new EnhancedConsole();
    
    // Spy on console methods
    consoleLogSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
    consoleClearSpy = jest.spyOn(console, 'clear').mockImplementation(() => {});
  });

  afterEach(() => {
    consoleLogSpy.mockRestore();
    consoleClearSpy.mockRestore();
  });

  // ============ INITIALIZATION & CONFIGURATION ============

  describe('Constructor', () => {
    it('should initialize with default options', () => {
      const ec = new EnhancedConsole();
      
      expect(ec.verbose).toBe(true);
      expect(ec.useColors).toBe(true);
      expect(ec.useIcons).toBe(true);
      expect(ec.progressBars).toBeInstanceOf(Map);
      expect(ec.progressBars.size).toBe(0);
    });

    it('should initialize with custom options', () => {
      const ec = new EnhancedConsole({
        verbose: false,
        useColors: false,
        useIcons: false
      });
      
      expect(ec.verbose).toBe(false);
      expect(ec.useColors).toBe(false);
      expect(ec.useIcons).toBe(false);
    });

    it('should have all required icons', () => {
      expect(enhancedConsole.icons).toHaveProperty('success');
      expect(enhancedConsole.icons).toHaveProperty('failure');
      expect(enhancedConsole.icons).toHaveProperty('warning');
      expect(enhancedConsole.icons).toHaveProperty('info');
      expect(enhancedConsole.icons).toHaveProperty('inProgress');
      expect(enhancedConsole.icons).toHaveProperty('blocked');
      expect(enhancedConsole.icons).toHaveProperty('captcha');
      expect(enhancedConsole.icons).toHaveProperty('retry');
      expect(enhancedConsole.icons).toHaveProperty('batch');
      expect(enhancedConsole.icons).toHaveProperty('complete');
    });
  });

  // ============ OUTPUT METHODS ============

  describe('success()', () => {
    it('should display success message with icon and colors', () => {
      enhancedConsole.success('Operation completed');
      
      expect(consoleLogSpy).toHaveBeenCalled();
      expect(chalk.green).toHaveBeenCalled();
    });

    it('should display success message without icons when disabled', () => {
      const ec = new EnhancedConsole({ useIcons: false });
      ec.success('Operation completed');
      
      expect(consoleLogSpy).toHaveBeenCalled();
    });

    it('should display success message with details', () => {
      enhancedConsole.success('Operation completed', { count: 10, duration: '5s' });
      
      expect(consoleLogSpy).toHaveBeenCalledTimes(2);
      expect(chalk.gray).toHaveBeenCalled();
    });

    it('should handle string details', () => {
      enhancedConsole.success('Done', 'All items processed');
      
      expect(consoleLogSpy).toHaveBeenCalledTimes(2);
    });

    it('should work without colors', () => {
      const ec = new EnhancedConsole({ useColors: false });
      ec.success('Operation completed');
      
      expect(consoleLogSpy).toHaveBeenCalled();
    });
  });

  describe('warning()', () => {
    it('should display warning message with icon and colors', () => {
      enhancedConsole.warning('Slow response detected');
      
      expect(consoleLogSpy).toHaveBeenCalled();
      expect(chalk.yellow).toHaveBeenCalled();
    });

    it('should display warning message with details', () => {
      enhancedConsole.warning('Low memory', { available: '2GB', total: '16GB' });
      
      expect(consoleLogSpy).toHaveBeenCalledTimes(2);
    });

    it('should work without icons', () => {
      const ec = new EnhancedConsole({ useIcons: false });
      ec.warning('Warning message');
      
      expect(consoleLogSpy).toHaveBeenCalled();
    });
  });

  describe('error()', () => {
    it('should display error message with icon and colors', () => {
      enhancedConsole.error('Failed to connect');
      
      expect(consoleLogSpy).toHaveBeenCalled();
      expect(chalk.red).toHaveBeenCalled();
    });

    it('should display error message with details', () => {
      enhancedConsole.error('Connection failed', { code: 'ECONNREFUSED', host: 'localhost' });
      
      expect(consoleLogSpy).toHaveBeenCalledTimes(2);
    });

    it('should work without colors', () => {
      const ec = new EnhancedConsole({ useColors: false });
      ec.error('Error occurred');
      
      expect(consoleLogSpy).toHaveBeenCalled();
    });
  });

  describe('info()', () => {
    it('should display info message with icon and colors', () => {
      enhancedConsole.info('Starting process');
      
      expect(consoleLogSpy).toHaveBeenCalled();
      expect(chalk.blue).toHaveBeenCalled();
    });

    it('should display info message with details', () => {
      enhancedConsole.info('Configuration loaded', { file: 'config.json', version: '1.0' });
      
      expect(consoleLogSpy).toHaveBeenCalledTimes(2);
    });
  });

  describe('progress()', () => {
    it('should display progress message with icon and colors', () => {
      enhancedConsole.progress('Processing items');
      
      expect(consoleLogSpy).toHaveBeenCalled();
      expect(chalk.cyan).toHaveBeenCalled();
    });

    it('should display progress message with details', () => {
      enhancedConsole.progress('Processing', { current: 50, total: 100 });
      
      expect(consoleLogSpy).toHaveBeenCalledTimes(2);
    });
  });

  // ============ ENHANCED ERROR MESSAGES ============

  describe('enhancedError()', () => {
    it('should display enhanced error with message only', () => {
      enhancedConsole.enhancedError({
        message: 'Database connection failed'
      });
      
      expect(consoleLogSpy).toHaveBeenCalled();
      expect(boxen).toHaveBeenCalled();
    });

    it('should display enhanced error with cause', () => {
      enhancedConsole.enhancedError({
        message: 'Query failed',
        cause: 'Connection timeout'
      });
      
      expect(boxen).toHaveBeenCalled();
      expect(chalk.yellow).toHaveBeenCalled();
    });

    it('should display enhanced error with suggestions', () => {
      enhancedConsole.enhancedError({
        message: 'Authentication failed',
        suggestions: [
          'Check credentials',
          'Verify account status',
          'Contact support'
        ]
      });
      
      expect(boxen).toHaveBeenCalled();
      expect(chalk.green).toHaveBeenCalled();
    });

    it('should display enhanced error with error code', () => {
      enhancedConsole.enhancedError({
        message: 'Server error',
        errorCode: 'ERR_500'
      });
      
      expect(boxen).toHaveBeenCalled();
      expect(chalk.gray).toHaveBeenCalled();
    });

    it('should display enhanced error with context', () => {
      enhancedConsole.enhancedError({
        message: 'Operation failed',
        context: { user: 'testuser', action: 'login' }
      });
      
      expect(boxen).toHaveBeenCalled();
    });

    it('should display enhanced error with all fields', () => {
      enhancedConsole.enhancedError({
        message: 'Critical error',
        cause: 'Network failure',
        errorCode: 'NET_001',
        suggestions: ['Retry', 'Check network'],
        context: { timestamp: '2024-01-01' }
      });
      
      expect(boxen).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          padding: 1,
          margin: 1,
          borderStyle: 'round',
          borderColor: 'red'
        })
      );
    });
  });

  // ============ VISUAL GROUPING & BOXES ============

  describe('section()', () => {
    it('should display section with default options', () => {
      enhancedConsole.section('Test Section', 'Section content');
      
      expect(boxen).toHaveBeenCalledWith(
        'Section content',
        expect.objectContaining({
          title: 'Test Section',
          padding: 1,
          margin: 0,
          borderStyle: 'round',
          borderColor: 'cyan',
          titleAlignment: 'left'
        })
      );
    });

    it('should display section with custom options', () => {
      enhancedConsole.section('Custom Section', 'Content', {
        borderColor: 'green',
        borderStyle: 'double',
        padding: 2,
        margin: 1
      });
      
      expect(boxen).toHaveBeenCalledWith(
        'Content',
        expect.objectContaining({
          borderColor: 'green',
          borderStyle: 'double',
          padding: 2,
          margin: 1
        })
      );
    });

    it('should format object content', () => {
      enhancedConsole.section('Data', { key: 'value', count: 42 });
      
      expect(boxen).toHaveBeenCalled();
      const callArg = boxen.mock.calls[0][0];
      expect(callArg).toContain('key');
      expect(callArg).toContain('value');
    });
  });

  describe('header()', () => {
    it('should display header with default options', () => {
      enhancedConsole.header('Test Header');
      
      expect(consoleLogSpy).toHaveBeenCalledTimes(3);
      expect(chalk.cyan).toHaveBeenCalled();
    });

    it('should display header with custom color', () => {
      enhancedConsole.header('Custom Header', { color: 'green' });
      
      expect(consoleLogSpy).toHaveBeenCalledTimes(3);
      expect(chalk.green).toHaveBeenCalled();
    });

    it('should display header with custom character', () => {
      enhancedConsole.header('Header', { char: '-', length: 40 });
      
      expect(consoleLogSpy).toHaveBeenCalledTimes(3);
    });

    it('should work without colors', () => {
      const ec = new EnhancedConsole({ useColors: false });
      ec.header('Plain Header');
      
      expect(consoleLogSpy).toHaveBeenCalledTimes(3);
    });

    it('should center text properly', () => {
      enhancedConsole.header('Test', { length: 20 });
      
      expect(consoleLogSpy).toHaveBeenCalledTimes(3);
    });
  });

  describe('separator()', () => {
    it('should display separator with default options', () => {
      enhancedConsole.separator();
      
      expect(consoleLogSpy).toHaveBeenCalled();
    });

    it('should display separator with custom length', () => {
      enhancedConsole.separator(40);
      
      expect(consoleLogSpy).toHaveBeenCalled();
    });

    it('should display separator with custom character', () => {
      enhancedConsole.separator(50, '=');
      
      expect(consoleLogSpy).toHaveBeenCalled();
    });

    it('should display separator with custom color', () => {
      enhancedConsole.separator(60, '-', 'blue');
      
      expect(consoleLogSpy).toHaveBeenCalled();
      expect(chalk.blue).toHaveBeenCalled();
    });

    it('should work without colors', () => {
      const ec = new EnhancedConsole({ useColors: false });
      ec.separator();
      
      expect(consoleLogSpy).toHaveBeenCalled();
    });
  });

  // ============ PROGRESS BARS ============

  describe('createProgressBar()', () => {
    it('should create progress bar with default options', () => {
      const name = enhancedConsole.createProgressBar('test-bar', 100);
      
      expect(name).toBe('test-bar');
      expect(enhancedConsole.progressBars.has('test-bar')).toBe(true);
      expect(cliProgress.SingleBar).toHaveBeenCalled();
      
      const progressInfo = enhancedConsole.progressBars.get('test-bar');
      expect(progressInfo.total).toBe(100);
      expect(progressInfo.current).toBe(0);
      expect(progressInfo.successCount).toBe(0);
      expect(progressInfo.failureCount).toBe(0);
    });

    it('should create progress bar with custom options', () => {
      enhancedConsole.createProgressBar('custom-bar', 50, {
        barsize: 30,
        stopOnComplete: true
      });
      
      expect(enhancedConsole.progressBars.has('custom-bar')).toBe(true);
      expect(cliProgress.SingleBar).toHaveBeenCalled();
    });

    it('should start progress bar', () => {
      enhancedConsole.createProgressBar('start-bar', 100);
      
      const progressInfo = enhancedConsole.progressBars.get('start-bar');
      expect(progressInfo.bar.start).toHaveBeenCalledWith(100, 0, expect.any(Object));
    });

    it('should store start time', () => {
      const beforeTime = Date.now();
      enhancedConsole.createProgressBar('time-bar', 100);
      const afterTime = Date.now();
      
      const progressInfo = enhancedConsole.progressBars.get('time-bar');
      expect(progressInfo.startTime).toBeGreaterThanOrEqual(beforeTime);
      expect(progressInfo.startTime).toBeLessThanOrEqual(afterTime);
    });
  });

  describe('updateProgressBar()', () => {
    beforeEach(() => {
      enhancedConsole.createProgressBar('update-bar', 100);
    });

    it('should update progress bar', () => {
      enhancedConsole.updateProgressBar('update-bar', 50);
      
      const progressInfo = enhancedConsole.progressBars.get('update-bar');
      expect(progressInfo.bar.update).toHaveBeenCalled();
      expect(progressInfo.current).toBe(50);
    });

    it('should update with stats', () => {
      enhancedConsole.updateProgressBar('update-bar', 75, {
        successCount: 60,
        failureCount: 15
      });
      
      const progressInfo = enhancedConsole.progressBars.get('update-bar');
      expect(progressInfo.successCount).toBe(60);
      expect(progressInfo.failureCount).toBe(15);
    });

    it('should calculate processing rate', () => {
      enhancedConsole.updateProgressBar('update-bar', 50);
      
      const progressInfo = enhancedConsole.progressBars.get('update-bar');
      expect(progressInfo.bar.update).toHaveBeenCalledWith(
        50,
        expect.objectContaining({
          rate: expect.any(String)
        })
      );
    });

    it('should handle non-existent progress bar', () => {
      expect(() => {
        enhancedConsole.updateProgressBar('non-existent', 50);
      }).not.toThrow();
    });

    it('should handle zero current value', () => {
      enhancedConsole.updateProgressBar('update-bar', 0);
      
      const progressInfo = enhancedConsole.progressBars.get('update-bar');
      expect(progressInfo.bar.update).toHaveBeenCalledWith(
        0,
        expect.objectContaining({
          rate: '0'
        })
      );
    });
  });

  describe('stopProgressBar()', () => {
    beforeEach(() => {
      enhancedConsole.createProgressBar('stop-bar', 100);
    });

    it('should stop progress bar', () => {
      enhancedConsole.stopProgressBar('stop-bar');
      
      const progressInfo = enhancedConsole.progressBars.get('stop-bar');
      expect(progressInfo).toBeUndefined();
    });

    it('should display completion summary', () => {
      enhancedConsole.stopProgressBar('stop-bar');
      
      expect(consoleLogSpy).toHaveBeenCalled();
      expect(chalk.green).toHaveBeenCalled();
    });

    it('should display success and failure counts', () => {
      enhancedConsole.updateProgressBar('stop-bar', 100, {
        successCount: 80,
        failureCount: 20
      });
      enhancedConsole.stopProgressBar('stop-bar');
      
      expect(consoleLogSpy).toHaveBeenCalledWith(expect.stringContaining('Success: 80'));
      expect(consoleLogSpy).toHaveBeenCalledWith(expect.stringContaining('Failed: 20'));
    });

    it('should respect showDetails option', () => {
      enhancedConsole.stopProgressBar('stop-bar', { showDetails: false });
      
      expect(consoleLogSpy).toHaveBeenCalledTimes(1); // Only summary
    });

    it('should handle non-existent progress bar', () => {
      expect(() => {
        enhancedConsole.stopProgressBar('non-existent');
      }).not.toThrow();
    });

    it('should remove progress bar from map', () => {
      expect(enhancedConsole.progressBars.has('stop-bar')).toBe(true);
      enhancedConsole.stopProgressBar('stop-bar');
      expect(enhancedConsole.progressBars.has('stop-bar')).toBe(false);
    });
  });

  // ============ SPINNERS ============

  describe('spinner()', () => {
    it('should create spinner with default options', () => {
      const spinner = enhancedConsole.spinner('Loading...');
      
      expect(ora).toHaveBeenCalledWith({
        text: 'Loading...',
        color: 'cyan',
        spinner: 'dots'
      });
      expect(spinner.start).toHaveBeenCalled();
    });

    it('should create spinner with custom options', () => {
      const spinner = enhancedConsole.spinner('Processing', {
        color: 'green',
        spinner: 'line'
      });
      
      expect(ora).toHaveBeenCalledWith({
        text: 'Processing',
        color: 'green',
        spinner: 'line'
      });
    });

    it('should return spinner instance', () => {
      const spinner = enhancedConsole.spinner('Test');
      
      expect(spinner).toBeDefined();
      expect(spinner.start).toBeDefined();
    });
  });

  // ============ TABLES ============

  describe('table()', () => {
    it('should display simple table', () => {
      enhancedConsole.table(
        ['Name', 'Age'],
        [['John', 30], ['Jane', 25]]
      );
      
      expect(consoleLogSpy).toHaveBeenCalled();
      expect(consoleLogSpy.mock.calls.length).toBeGreaterThan(3);
    });

    it('should display table with custom column widths', () => {
      enhancedConsole.table(
        ['ID', 'Description'],
        [['1', 'Test'], ['2', 'Another']],
        { columnWidths: [5, 15] }
      );
      
      expect(consoleLogSpy).toHaveBeenCalled();
    });

    it('should handle empty rows', () => {
      enhancedConsole.table(['Column1', 'Column2'], []);
      
      expect(consoleLogSpy).toHaveBeenCalled();
    });

    it('should format headers with color', () => {
      enhancedConsole.table(
        ['Header1', 'Header2'],
        [['Data1', 'Data2']],
        { headerColor: 'green' }
      );
      
      expect(chalk.green.bold).toHaveBeenCalled();
    });

    it('should display borders and separators', () => {
      enhancedConsole.table(['A', 'B'], [['1', '2']]);
      
      const calls = consoleLogSpy.mock.calls.map(call => call[0]);
      expect(calls.some(call => call.includes('┌'))).toBe(true); // Top border
      expect(calls.some(call => call.includes('├'))).toBe(true); // Separator
      expect(calls.some(call => call.includes('└'))).toBe(true); // Bottom border
    });

    it('should work without colors', () => {
      const ec = new EnhancedConsole({ useColors: false });
      ec.table(['Col1', 'Col2'], [['Val1', 'Val2']]);
      
      expect(consoleLogSpy).toHaveBeenCalled();
    });
  });

  describe('calculateColumnWidths()', () => {
    it('should calculate widths based on headers', () => {
      const widths = enhancedConsole.calculateColumnWidths(
        ['Name', 'Description'],
        []
      );
      
      expect(widths).toEqual([4, 11]);
    });

    it('should calculate widths based on data', () => {
      const widths = enhancedConsole.calculateColumnWidths(
        ['ID', 'Name'],
        [['12345', 'John'], ['2', 'Jane Smith']]
      );
      
      expect(widths).toEqual([5, 10]);
    });

    it('should use maximum width from headers and data', () => {
      const widths = enhancedConsole.calculateColumnWidths(
        ['Short', 'VeryLongHeader'],
        [['LongValue', 'Short']]
      );
      
      expect(widths[0]).toBe(9); // max('Short', 'LongValue')
      expect(widths[1]).toBe(14); // max('VeryLongHeader', 'Short')
    });

    it('should handle numeric values', () => {
      const widths = enhancedConsole.calculateColumnWidths(
        ['Count', 'Total'],
        [[123, 45678]]
      );
      
      expect(widths[0]).toBeGreaterThanOrEqual(3);
      expect(widths[1]).toBeGreaterThanOrEqual(5);
    });
  });

  // ============ HELPER METHODS ============

  describe('formatDetails()', () => {
    it('should format string as-is', () => {
      const result = enhancedConsole.formatDetails('Simple string');
      expect(result).toBe('Simple string');
    });

    it('should format object as JSON', () => {
      const result = enhancedConsole.formatDetails({ key: 'value', count: 42 });
      expect(result).toContain('"key"');
      expect(result).toContain('"value"');
      expect(result).toContain('42');
    });

    it('should format array as JSON', () => {
      const result = enhancedConsole.formatDetails([1, 2, 3]);
      expect(result).toContain('[');
      expect(result).toContain(']');
    });

    it('should format nested objects', () => {
      const result = enhancedConsole.formatDetails({
        user: { name: 'John', age: 30 }
      });
      expect(result).toContain('user');
      expect(result).toContain('name');
    });

    it('should handle null', () => {
      const result = enhancedConsole.formatDetails(null);
      expect(result).toBe('null');
    });

    it('should handle undefined', () => {
      const result = enhancedConsole.formatDetails(undefined);
      expect(result).toBe('undefined');
    });

    it('should handle numbers', () => {
      const result = enhancedConsole.formatDetails(42);
      expect(result).toBe('42');
    });

    it('should handle booleans', () => {
      expect(enhancedConsole.formatDetails(true)).toBe('true');
      expect(enhancedConsole.formatDetails(false)).toBe('false');
    });
  });

  describe('formatDuration()', () => {
    it('should format seconds', () => {
      const result = enhancedConsole.formatDuration(5000); // 5 seconds
      expect(result).toBe('5s');
    });

    it('should format minutes and seconds', () => {
      const result = enhancedConsole.formatDuration(125000); // 125 seconds
      expect(result).toBe('2m 5s');
    });

    it('should format hours, minutes and seconds', () => {
      const result = enhancedConsole.formatDuration(3665000); // 1h 1m 5s
      expect(result).toBe('1h 1m 5s');
    });

    it('should handle zero duration', () => {
      const result = enhancedConsole.formatDuration(0);
      expect(result).toBe('0s');
    });

    it('should handle milliseconds less than 1 second', () => {
      const result = enhancedConsole.formatDuration(500); // 0.5 seconds
      expect(result).toBe('0s');
    });

    it('should format large durations', () => {
      const result = enhancedConsole.formatDuration(7265000); // 2h 1m 5s
      expect(result).toBe('2h 1m 5s');
    });

    it('should handle exactly 1 minute', () => {
      const result = enhancedConsole.formatDuration(60000);
      expect(result).toBe('1m 0s');
    });

    it('should handle exactly 1 hour', () => {
      const result = enhancedConsole.formatDuration(3600000);
      expect(result).toBe('1h 0m 0s');
    });
  });

  describe('clear()', () => {
    it('should clear console', () => {
      enhancedConsole.clear();
      expect(consoleClearSpy).toHaveBeenCalled();
    });
  });

  describe('spacing()', () => {
    it('should add single blank line', () => {
      enhancedConsole.spacing(1);
      expect(consoleLogSpy).toHaveBeenCalledWith('');
    });

    it('should add multiple blank lines', () => {
      enhancedConsole.spacing(3);
      expect(consoleLogSpy).toHaveBeenCalledWith('\n\n');
    });

    it('should handle zero spacing', () => {
      expect(() => {
        enhancedConsole.spacing(0);
      }).toThrow('Invalid count value');
    });

    it('should handle negative spacing', () => {
      expect(() => {
        enhancedConsole.spacing(-1);
      }).toThrow('Invalid count value');
    });
  });

  // ============ INTEGRATION TESTS ============

  describe('Integration scenarios', () => {
    it('should handle multiple progress bars simultaneously', () => {
      enhancedConsole.createProgressBar('bar1', 100);
      enhancedConsole.createProgressBar('bar2', 50);
      enhancedConsole.createProgressBar('bar3', 200);
      
      expect(enhancedConsole.progressBars.size).toBe(3);
      
      enhancedConsole.updateProgressBar('bar1', 50);
      enhancedConsole.updateProgressBar('bar2', 25);
      enhancedConsole.updateProgressBar('bar3', 100);
      
      expect(enhancedConsole.progressBars.get('bar1').current).toBe(50);
      expect(enhancedConsole.progressBars.get('bar2').current).toBe(25);
      expect(enhancedConsole.progressBars.get('bar3').current).toBe(100);
      
      enhancedConsole.stopProgressBar('bar2');
      expect(enhancedConsole.progressBars.size).toBe(2);
    });

    it('should work with all output methods in sequence', () => {
      enhancedConsole.info('Starting operation');
      enhancedConsole.progress('Processing...');
      enhancedConsole.success('Step 1 completed');
      enhancedConsole.warning('Minor issue detected');
      enhancedConsole.error('Critical error');
      
      expect(consoleLogSpy).toHaveBeenCalledTimes(5);
    });

    it('should format complex error scenarios', () => {
      enhancedConsole.enhancedError({
        message: 'Multi-level failure',
        cause: 'Network timeout during authentication',
        errorCode: 'AUTH_TIMEOUT_001',
        suggestions: [
          'Check network connection',
          'Verify credentials',
          'Increase timeout value',
          'Contact system administrator'
        ],
        context: {
          user: 'testuser',
          timestamp: '2024-01-01T12:00:00Z',
          retries: 3,
          lastError: 'ETIMEDOUT'
        }
      });
      
      expect(boxen).toHaveBeenCalled();
      expect(consoleLogSpy).toHaveBeenCalled();
    });

    it('should create formatted report with sections and tables', () => {
      enhancedConsole.header('System Report');
      enhancedConsole.section('Overview', 'System is operational');
      enhancedConsole.table(
        ['Metric', 'Value'],
        [['CPU', '45%'], ['Memory', '8GB'], ['Disk', '250GB']]
      );
      enhancedConsole.separator();
      
      expect(consoleLogSpy.mock.calls.length).toBeGreaterThan(5);
    });
  });

  // ============ EDGE CASES ============

  describe('Edge cases', () => {
    it('should handle very long text in table cells', () => {
      const longText = 'A'.repeat(100);
      enhancedConsole.table(['Column'], [[longText]]);
      
      expect(consoleLogSpy).toHaveBeenCalled();
    });

    it('should handle empty strings', () => {
      enhancedConsole.success('');
      enhancedConsole.warning('');
      enhancedConsole.error('');
      
      expect(consoleLogSpy).toHaveBeenCalledTimes(3);
    });

    it('should handle special characters in messages', () => {
      enhancedConsole.info('Special: áéíóú ñ 中文 🎉');
      expect(consoleLogSpy).toHaveBeenCalled();
    });

    it('should handle deeply nested objects in formatDetails', () => {
      const nested = { a: { b: { c: { d: { e: 'value' } } } } };
      const result = enhancedConsole.formatDetails(nested);
      
      expect(result).toContain('"e"');
      expect(result).toContain('"value"');
    });

    it('should handle circular references in objects gracefully', () => {
      const circular = { name: 'test' };
      circular.self = circular;
      
      expect(() => {
        enhancedConsole.formatDetails(circular);
      }).toThrow();
    });

    it('should handle very short header text', () => {
      enhancedConsole.header('X', { length: 80 });
      expect(consoleLogSpy).toHaveBeenCalledTimes(3);
    });

    it('should handle progress bar update with same value multiple times', () => {
      enhancedConsole.createProgressBar('repeat-bar', 100);
      enhancedConsole.updateProgressBar('repeat-bar', 50);
      enhancedConsole.updateProgressBar('repeat-bar', 50);
      enhancedConsole.updateProgressBar('repeat-bar', 50);
      
      const progressInfo = enhancedConsole.progressBars.get('repeat-bar');
      expect(progressInfo.current).toBe(50);
    });
  });
});
