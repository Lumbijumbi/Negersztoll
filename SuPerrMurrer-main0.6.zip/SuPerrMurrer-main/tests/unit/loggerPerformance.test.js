/**
 * Performance tests for buffered logger
 */

const fs = require('fs');
const path = require('path');
const AdvancedLogger = require('../../utils/logger');

describe('Logger Performance Optimizations', () => {
  let testLogDir;
  let logger;

  beforeEach(() => {
    testLogDir = path.join(__dirname, `test_logs_${Date.now()}`);
    logger = new AdvancedLogger({ 
      logDir: testLogDir,
      bufferSize: 5, // Small buffer for testing
      flushInterval: 10000 // Long interval so we control flushing
    });
  });

  afterEach(async () => {
    // Cleanup logger
    if (logger) {
      await logger.cleanup();
    }
    
    // Remove test directory
    if (fs.existsSync(testLogDir)) {
      fs.rmSync(testLogDir, { recursive: true, force: true });
    }
  });

  test('should buffer writes instead of writing immediately', async () => {
    const successFile = path.join(testLogDir, 'successful', logger.getCachedFilename('successful'));
    
    // Log 3 entries (less than buffer size of 5)
    logger.logSuccess('user1', 'pass1', 'tgc_cookie', 0.95);
    logger.logSuccess('user2', 'pass2', 'tgc_cookie', 0.90);
    logger.logSuccess('user3', 'pass3', 'tgc_cookie', 0.85);
    
    // File should NOT exist yet (buffered)
    expect(fs.existsSync(successFile)).toBe(false);
    
    // Flush manually
    await logger.flushAllBuffers();
    
    // Now file should exist with 3 entries
    expect(fs.existsSync(successFile)).toBe(true);
    const content = fs.readFileSync(successFile, 'utf8');
    const lines = content.trim().split('\n');
    expect(lines.length).toBe(3);
  });

  test('should auto-flush when buffer size is reached', async () => {
    const successFile = path.join(testLogDir, 'successful', logger.getCachedFilename('successful'));
    
    // Log 5 entries (exactly buffer size)
    for (let i = 1; i <= 5; i++) {
      logger.logSuccess(`user${i}`, `pass${i}`, 'tgc_cookie', 0.95);
    }
    
    // Wait a bit for async flush to complete
    await new Promise(resolve => setTimeout(resolve, 50));
    
    // File should exist now (auto-flushed at 5 items)
    expect(fs.existsSync(successFile)).toBe(true);
    const content = fs.readFileSync(successFile, 'utf8');
    const lines = content.trim().split('\n');
    expect(lines.length).toBe(5);
  });

  test('should cache filenames to avoid repeated date parsing', () => {
    const filename1 = logger.getCachedFilename('successful');
    const filename2 = logger.getCachedFilename('successful');
    const filename3 = logger.getCachedFilename('failed');
    
    // Should return same filename (cached)
    expect(filename1).toBe(filename2);
    
    // Different types should have different filenames
    expect(filename1).not.toBe(filename3);
    
    // Should match expected format
    expect(filename1).toMatch(/^successes_\d{4}-\d{2}-\d{2}\.jsonl$/);
    expect(filename3).toMatch(/^failures_\d{4}-\d{2}-\d{2}\.jsonl$/);
  });

  test('should batch multiple entries into single write operation', async () => {
    const successFile = path.join(testLogDir, 'successful', logger.getCachedFilename('successful'));
    
    // Add 3 entries to buffer
    logger.logSuccess('user1', 'pass1', 'tgc_cookie', 0.95);
    logger.logSuccess('user2', 'pass2', 'tgc_cookie', 0.90);
    logger.logSuccess('user3', 'pass3', 'tgc_cookie', 0.85);
    
    // Flush (should write all 3 in one operation)
    await logger.flushBuffer('successful');
    
    // Verify all entries were written
    const content = fs.readFileSync(successFile, 'utf8');
    const lines = content.trim().split('\n');
    expect(lines.length).toBe(3);
    
    // Verify each line is valid JSON
    lines.forEach(line => {
      const entry = JSON.parse(line);
      expect(entry).toHaveProperty('username');
      expect(entry).toHaveProperty('password');
    });
  });

  test('cleanup should flush all pending buffers', async () => {
    const successFile = path.join(testLogDir, 'successful', logger.getCachedFilename('successful'));
    const failedFile = path.join(testLogDir, 'failed', logger.getCachedFilename('failed'));
    
    // Add entries to different buffers
    logger.logSuccess('user1', 'pass1', 'tgc_cookie', 0.95);
    logger.logSuccess('user2', 'pass2', 'tgc_cookie', 0.90);
    logger.logFailed('user3', 'pass3', 'invalid_credentials', '');
    
    // Neither file should exist yet
    expect(fs.existsSync(successFile)).toBe(false);
    expect(fs.existsSync(failedFile)).toBe(false);
    
    // Cleanup (should flush all buffers)
    await logger.cleanup();
    
    // Both files should now exist
    expect(fs.existsSync(successFile)).toBe(true);
    expect(fs.existsSync(failedFile)).toBe(true);
    
    // Verify content
    const successContent = fs.readFileSync(successFile, 'utf8');
    const failedContent = fs.readFileSync(failedFile, 'utf8');
    expect(successContent.trim().split('\n').length).toBe(2);
    expect(failedContent.trim().split('\n').length).toBe(1);
  });

  test('should handle multiple flush cycles correctly', async () => {
    const successFile = path.join(testLogDir, 'successful', logger.getCachedFilename('successful'));
    
    // First batch
    logger.logSuccess('user1', 'pass1', 'tgc_cookie', 0.95);
    logger.logSuccess('user2', 'pass2', 'tgc_cookie', 0.90);
    await logger.flushBuffer('successful');
    
    // Second batch
    logger.logSuccess('user3', 'pass3', 'tgc_cookie', 0.85);
    logger.logSuccess('user4', 'pass4', 'tgc_cookie', 0.88);
    await logger.flushBuffer('successful');
    
    // Should have 4 total entries
    const content = fs.readFileSync(successFile, 'utf8');
    const lines = content.trim().split('\n');
    expect(lines.length).toBe(4);
  });
});
