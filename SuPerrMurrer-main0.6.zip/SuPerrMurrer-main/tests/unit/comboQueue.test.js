/**
 * Unit Tests for ComboQueue Module
 * Tests the queue/backlog system with file management, deduplication, and persistence
 */

const ComboQueue = require('../../utils/comboQueue');
const fs = require('fs');
const path = require('path');

// Mock fs module
jest.mock('fs');

describe('ComboQueue', () => {
  let queue;
  let mockHistoryInstance;
  const testQueueFile = '/test/queue.json';

  beforeEach(() => {
    jest.clearAllMocks();
    
    // Mock history instance
    mockHistoryInstance = {
      shouldSkip: jest.fn().mockReturnValue({ skip: false })
    };

    // Mock fs.existsSync to return false by default (no existing queue file)
    fs.existsSync.mockReturnValue(false);
    
    // Mock fs.readFileSync
    fs.readFileSync.mockReturnValue('');
    
    // Mock fs.writeFileSync
    fs.writeFileSync.mockImplementation(() => {});
    
    // Spy on console methods
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    console.log.mockRestore();
    console.error.mockRestore();
  });

  describe('Constructor & Initialization', () => {
    it('should initialize with default options', () => {
      queue = new ComboQueue({ queueFile: testQueueFile });
      
      expect(queue.queueFile).toBe(testQueueFile);
      expect(queue.randomize).toBe(false);
      expect(queue.listDelay).toBe(0);
      expect(queue.listDelayJitter).toBe(0);
      expect(queue.autoFeed).toBe(true);
      expect(queue.defaultPriority).toBe(3);
      expect(queue.maxQueueSize).toBe(0);
      expect(queue.paused).toBe(false);
    });

    it('should initialize with custom options', () => {
      queue = new ComboQueue({
        queueFile: testQueueFile,
        randomize: true,
        listDelay: 1000,
        listDelayJitter: 500,
        autoFeed: false,
        defaultPriority: 2,
        maxQueueSize: 1000,
        historyInstance: mockHistoryInstance
      });
      
      expect(queue.randomize).toBe(true);
      expect(queue.listDelay).toBe(1000);
      expect(queue.listDelayJitter).toBe(500);
      expect(queue.autoFeed).toBe(false);
      expect(queue.defaultPriority).toBe(2);
      expect(queue.maxQueueSize).toBe(1000);
      expect(queue.historyInstance).toBe(mockHistoryInstance);
    });

    it('should convert relative paths to absolute', () => {
      queue = new ComboQueue({ queueFile: 'relative_queue.json' });
      
      expect(path.isAbsolute(queue.queueFile)).toBe(true);
      expect(queue.queueFile).toContain('relative_queue.json');
    });

    it('should load existing queue on instantiation', () => {
      const mockQueueData = {
        files: [{ filename: 'test.txt', queuedCount: 5 }],
        combos: [['user1\tpass1', { username: 'user1', password: 'pass1', source: 'test.txt', priority: 3 }]],
        paused: true,
        stats: { totalFilesAdded: 1 }
      };
      
      fs.existsSync.mockReturnValue(true);
      fs.readFileSync.mockReturnValue(JSON.stringify(mockQueueData));
      
      queue = new ComboQueue({ queueFile: testQueueFile });
      
      expect(queue.files.length).toBe(1);
      expect(queue.combos.size).toBe(1);
      expect(queue.paused).toBe(true);
    });
  });

  describe('Key Generation (_key)', () => {
    it('should generate case-insensitive keys by default', () => {
      queue = new ComboQueue({ queueFile: testQueueFile });
      
      const key1 = queue._key('User1', 'Pass1');
      const key2 = queue._key('user1', 'pass1');
      
      expect(key1).toBe('user1\tpass1');
      expect(key2).toBe('user1\tpass1');
      expect(key1).toBe(key2);
    });

    it('should generate case-sensitive keys when configured', () => {
      queue = new ComboQueue({ 
        queueFile: testQueueFile,
        deduplication: { caseSensitive: true }
      });
      
      const key1 = queue._key('User1', 'Pass1');
      const key2 = queue._key('user1', 'pass1');
      
      expect(key1).toBe('User1\tPass1');
      expect(key2).toBe('user1\tpass1');
      expect(key1).not.toBe(key2);
    });

    it('should handle special characters in credentials', () => {
      queue = new ComboQueue({ queueFile: testQueueFile });
      
      const key = queue._key('user@email.com', 'p@ss:w0rd!');
      
      expect(key).toContain('user@email.com');
      expect(key).toContain('p@ss:w0rd!');
    });
  });

  describe('Combo Parsing (_parseComboLine)', () => {
    beforeEach(() => {
      queue = new ComboQueue({ queueFile: testQueueFile });
    });

    it('should parse valid "user:pass" format', () => {
      const result = queue._parseComboLine('username:password');
      
      expect(result).toEqual({ username: 'username', password: 'password' });
    });

    it('should parse combos with multiple colons (email:complex:pass)', () => {
      const result = queue._parseComboLine('user@email.com:pass:word:123');
      
      expect(result).toEqual({ username: 'user@email.com', password: 'pass:word:123' });
    });

    it('should trim whitespace', () => {
      const result = queue._parseComboLine('  username  :  password  ');
      
      expect(result).toEqual({ username: 'username', password: 'password' });
    });

    it('should return null for empty lines', () => {
      expect(queue._parseComboLine('')).toBeNull();
      expect(queue._parseComboLine('   ')).toBeNull();
    });

    it('should return null for lines without colon separator', () => {
      expect(queue._parseComboLine('username')).toBeNull();
      expect(queue._parseComboLine('usernamepassword')).toBeNull();
    });

    it('should return null for empty username', () => {
      expect(queue._parseComboLine(':password')).toBeNull();
      expect(queue._parseComboLine('  :password')).toBeNull();
    });

    it('should return null for empty password', () => {
      expect(queue._parseComboLine('username:')).toBeNull();
      expect(queue._parseComboLine('username:  ')).toBeNull();
    });
  });

  describe('Adding Files (addFile)', () => {
    beforeEach(() => {
      queue = new ComboQueue({ queueFile: testQueueFile });
    });

    it('should successfully add a file', () => {
      const filePath = '/test/combos.txt';
      const fileContent = 'user1:pass1\nuser2:pass2\nuser3:pass3';
      
      fs.existsSync.mockReturnValue(true);
      fs.readFileSync.mockReturnValue(fileContent);
      
      const result = queue.addFile(filePath);
      
      expect(result.added).toBe(3);
      expect(result.queued).toBe(3);
      expect(result.duplicatesRemoved).toBe(0);
      expect(result.alreadyProcessed).toBe(0);
      expect(queue.combos.size).toBe(3);
      expect(queue.files.length).toBe(1);
    });

    it('should throw error for non-existent file', () => {
      fs.existsSync.mockReturnValue(false);
      
      expect(() => queue.addFile('/nonexistent.txt')).toThrow('File not found');
    });

    it('should validate priority range', () => {
      // Note: priority 0 gets replaced with defaultPriority (3) due to || operator
      // So we test priority -1 which is truly invalid
      expect(() => {
        fs.existsSync.mockReturnValue(true);
        fs.readFileSync.mockReturnValue('user:pass');
        queue.addFile('/test.txt', { priority: -1 });
      }).toThrow('Priority must be between 1 and 5');
      
      expect(() => {
        fs.existsSync.mockReturnValue(true);
        fs.readFileSync.mockReturnValue('user:pass');
        queue.addFile('/test.txt', { priority: 6 });
      }).toThrow('Priority must be between 1 and 5');
    });

    it('should use default priority when not specified', () => {
      queue.defaultPriority = 4;
      
      fs.existsSync.mockReturnValue(true);
      fs.readFileSync.mockReturnValue('user:pass');
      
      queue.addFile('/test.txt');
      
      const files = queue.getFiles();
      expect(files[0].priority).toBe(4);
    });
  });

  describe('Adding Combos (addCombos)', () => {
    beforeEach(() => {
      queue = new ComboQueue({ queueFile: testQueueFile });
    });

    it('should add raw combo lines', () => {
      const lines = ['user1:pass1', 'user2:pass2'];
      const result = queue.addCombos(lines, 'manual_input');
      
      expect(result.added).toBe(2);
      expect(result.queued).toBe(2);
      expect(queue.combos.size).toBe(2);
    });

    it('should deduplicate within queue', () => {
      // Add first batch
      queue.addCombos(['user1:pass1', 'user2:pass2'], 'batch1');
      
      // Add second batch with duplicates
      const result = queue.addCombos(['user1:pass1', 'user3:pass3'], 'batch2');
      
      expect(result.added).toBe(2);
      expect(result.duplicatesRemoved).toBe(1);
      expect(result.queued).toBe(1);
      expect(queue.combos.size).toBe(3);
    });

    it('should deduplicate against history when configured', () => {
      queue = new ComboQueue({ 
        queueFile: testQueueFile,
        historyInstance: mockHistoryInstance
      });
      
      // Mock history to skip user1:pass1
      mockHistoryInstance.shouldSkip.mockImplementation((user, pass) => {
        return { skip: user === 'user1' && pass === 'pass1' };
      });
      
      const result = queue.addCombos(['user1:pass1', 'user2:pass2'], 'test');
      
      expect(result.added).toBe(2);
      expect(result.alreadyProcessed).toBe(1);
      expect(result.queued).toBe(1);
      expect(queue.combos.size).toBe(1);
    });

    it('should enforce max queue size', () => {
      queue = new ComboQueue({ 
        queueFile: testQueueFile,
        maxQueueSize: 2
      });
      
      queue.addCombos(['user1:pass1', 'user2:pass2'], 'batch1');
      
      expect(() => {
        queue.addCombos(['user3:pass3', 'user4:pass4'], 'batch2');
      }).toThrow('Queue size limit exceeded');
    });

    it('should track stats correctly', () => {
      queue.addCombos(['user1:pass1'], 'batch1');
      queue.addCombos(['user1:pass1', 'user2:pass2'], 'batch2');
      
      expect(queue.stats.totalCombosAdded).toBe(3);
      expect(queue.stats.totalDuplicatesRemoved).toBe(1);
    });

    it('should create file metadata', () => {
      queue.addCombos(['user1:pass1', 'user2:pass2'], 'test_source', { priority: 2 });
      
      const files = queue.getFiles();
      expect(files.length).toBe(1);
      expect(files[0].filename).toBe('test_source');
      expect(files[0].lineCount).toBe(2);
      expect(files[0].queuedCount).toBe(2);
      expect(files[0].processedCount).toBe(0);
      expect(files[0].status).toBe('pending');
      expect(files[0].priority).toBe(2);
    });

    it('should update existing file metadata', () => {
      queue.addCombos(['user1:pass1'], 'source1', { priority: 3 });
      queue.addCombos(['user2:pass2', 'user3:pass3'], 'source1', { priority: 2 });
      
      const files = queue.getFiles();
      expect(files.length).toBe(1);
      expect(files[0].lineCount).toBe(3);
      expect(files[0].queuedCount).toBe(3);
      expect(files[0].priority).toBe(2);
    });
  });

  describe('Batch Retrieval (getNextBatch)', () => {
    beforeEach(() => {
      queue = new ComboQueue({ queueFile: testQueueFile });
    });

    it('should return empty array when paused', () => {
      queue.addCombos(['user1:pass1'], 'test');
      queue.pause();
      
      const batch = queue.getNextBatch(10);
      
      expect(batch).toEqual([]);
    });

    it('should return combos sorted by priority', () => {
      queue.addCombos(['user1:pass1'], 'high', { priority: 1 });
      queue.addCombos(['user2:pass2'], 'low', { priority: 5 });
      queue.addCombos(['user3:pass3'], 'medium', { priority: 3 });
      
      const batch = queue.getNextBatch(10);
      
      expect(batch.length).toBe(3);
      expect(batch[0].priority).toBe(1);
      expect(batch[1].priority).toBe(3);
      expect(batch[2].priority).toBe(5);
    });

    it('should respect batch size limit', () => {
      queue.addCombos(['user1:pass1', 'user2:pass2', 'user3:pass3', 'user4:pass4'], 'test');
      
      const batch = queue.getNextBatch(2);
      
      expect(batch.length).toBe(2);
    });

    it('should return all combos if batch size exceeds queue size', () => {
      queue.addCombos(['user1:pass1', 'user2:pass2'], 'test');
      
      const batch = queue.getNextBatch(100);
      
      expect(batch.length).toBe(2);
    });
  });

  describe('Processing (markProcessed)', () => {
    beforeEach(() => {
      queue = new ComboQueue({ queueFile: testQueueFile });
    });

    it('should remove combo from queue', () => {
      queue.addCombos(['user1:pass1', 'user2:pass2'], 'test');
      
      queue.markProcessed('user1', 'pass1');
      
      expect(queue.combos.size).toBe(1);
      expect(queue._hasCombo('user1', 'pass1')).toBe(false);
      expect(queue._hasCombo('user2', 'pass2')).toBe(true);
    });

    it('should update file metadata counts', () => {
      queue.addCombos(['user1:pass1', 'user2:pass2'], 'test');
      
      queue.markProcessed('user1', 'pass1');
      
      const file = queue.files[0];
      expect(file.processedCount).toBe(1);
      expect(file.queuedCount).toBe(1);
    });

    it('should update status to processing after first combo', () => {
      queue.addCombos(['user1:pass1', 'user2:pass2'], 'test');
      
      queue.markProcessed('user1', 'pass1');
      
      const file = queue.files[0];
      expect(file.status).toBe('processing');
    });

    it('should update status to completed when all combos processed', () => {
      queue.addCombos(['user1:pass1', 'user2:pass2'], 'test');
      
      queue.markProcessed('user1', 'pass1');
      queue.markProcessed('user2', 'pass2');
      
      const file = queue.files[0];
      expect(file.status).toBe('completed');
      expect(file.queuedCount).toBe(0);
    });

    it('should update global stats', () => {
      queue.addCombos(['user1:pass1'], 'test');
      
      queue.markProcessed('user1', 'pass1');
      
      expect(queue.stats.totalProcessed).toBe(1);
    });

    it('should handle processing non-existent combo gracefully', () => {
      queue.addCombos(['user1:pass1'], 'test');
      
      expect(() => {
        queue.markProcessed('nonexistent', 'combo');
      }).not.toThrow();
      
      expect(queue.combos.size).toBe(1);
    });
  });

  describe('Queue Stats (getStats)', () => {
    beforeEach(() => {
      queue = new ComboQueue({ queueFile: testQueueFile });
    });

    it('should return correct counts', () => {
      queue.addCombos(['user1:pass1'], 'file1');
      queue.addCombos(['user2:pass2'], 'file2');
      
      const stats = queue.getStats();
      
      expect(stats.totalFiles).toBe(2);
      expect(stats.totalCombos).toBe(2);
      expect(stats.pending).toBe(2);
      expect(stats.processing).toBe(0);
      expect(stats.completed).toBe(0);
    });

    it('should reflect processing status', () => {
      queue.addCombos(['user1:pass1', 'user2:pass2'], 'file1');
      queue.markProcessed('user1', 'pass1');
      
      const stats = queue.getStats();
      
      expect(stats.processing).toBe(1);
      expect(stats.totalProcessed).toBe(1);
    });

    it('should reflect completed status', () => {
      queue.addCombos(['user1:pass1'], 'file1');
      queue.markProcessed('user1', 'pass1');
      
      const stats = queue.getStats();
      
      expect(stats.completed).toBe(1);
    });

    it('should reflect paused state', () => {
      queue.addCombos(['user1:pass1'], 'test');
      queue.pause();
      
      const stats = queue.getStats();
      
      expect(stats.paused).toBe(true);
    });
  });

  describe('File Management', () => {
    beforeEach(() => {
      queue = new ComboQueue({ queueFile: testQueueFile });
    });

    describe('getFiles()', () => {
      it('should return files sorted by priority then addedAt', () => {
        queue.addCombos(['user1:pass1'], 'low', { priority: 5 });
        queue.addCombos(['user2:pass2'], 'high', { priority: 1 });
        queue.addCombos(['user3:pass3'], 'medium', { priority: 3 });
        
        const files = queue.getFiles();
        
        expect(files[0].filename).toBe('high');
        expect(files[1].filename).toBe('medium');
        expect(files[2].filename).toBe('low');
      });
    });

    describe('removeFile()', () => {
      it('should remove file and all its combos', () => {
        queue.addCombos(['user1:pass1', 'user2:pass2'], 'file1');
        queue.addCombos(['user3:pass3'], 'file2');
        
        const removed = queue.removeFile('file1');
        
        expect(removed).toBe(true);
        expect(queue.files.length).toBe(1);
        expect(queue.combos.size).toBe(1);
        expect(queue._hasCombo('user3', 'pass3')).toBe(true);
      });

      it('should return false for non-existent file', () => {
        const removed = queue.removeFile('nonexistent');
        
        expect(removed).toBe(false);
      });
    });

    describe('setPriority()', () => {
      it('should update file and combo priorities', () => {
        queue.addCombos(['user1:pass1', 'user2:pass2'], 'test', { priority: 3 });
        
        const updated = queue.setPriority('test', 1);
        
        expect(updated).toBe(true);
        
        const file = queue.files[0];
        expect(file.priority).toBe(1);
        
        const batch = queue.getNextBatch(10);
        expect(batch[0].priority).toBe(1);
      });

      it('should validate priority range', () => {
        queue.addCombos(['user1:pass1'], 'test');
        
        expect(() => queue.setPriority('test', 0)).toThrow('Priority must be between 1 and 5');
        expect(() => queue.setPriority('test', 6)).toThrow('Priority must be between 1 and 5');
      });

      it('should return false for non-existent file', () => {
        const updated = queue.setPriority('nonexistent', 3);
        
        expect(updated).toBe(false);
      });
    });
  });

  describe('Shuffle (shuffle)', () => {
    beforeEach(() => {
      queue = new ComboQueue({ queueFile: testQueueFile });
      // Mock Math.random for predictable shuffling
      jest.spyOn(Math, 'random');
    });

    afterEach(() => {
      Math.random.mockRestore();
    });

    it('should shuffle the queue', () => {
      queue.addCombos(['user1:pass1', 'user2:pass2', 'user3:pass3'], 'test');
      
      const beforeKeys = Array.from(queue.combos.keys());
      
      // Mock random to create a deterministic shuffle
      let callCount = 0;
      Math.random.mockImplementation(() => {
        callCount++;
        return callCount % 2 === 0 ? 0.9 : 0.1;
      });
      
      queue.shuffle();
      
      const afterKeys = Array.from(queue.combos.keys());
      
      // Verify all combos still present
      expect(afterKeys.length).toBe(3);
      expect(afterKeys.sort()).toEqual(beforeKeys.sort());
    });

    it('should save after shuffle', () => {
      queue.addCombos(['user1:pass1'], 'test');
      
      fs.writeFileSync.mockClear();
      queue.shuffle();
      
      expect(fs.writeFileSync).toHaveBeenCalled();
    });
  });

  describe('Pause/Resume', () => {
    beforeEach(() => {
      queue = new ComboQueue({ queueFile: testQueueFile });
    });

    it('should pause the queue', () => {
      queue.pause();
      
      expect(queue.paused).toBe(true);
      expect(queue.isPaused()).toBe(true);
    });

    it('should resume the queue', () => {
      queue.pause();
      queue.resume();
      
      expect(queue.paused).toBe(false);
      expect(queue.isPaused()).toBe(false);
    });

    it('should save state on pause', () => {
      fs.writeFileSync.mockClear();
      queue.pause();
      
      expect(fs.writeFileSync).toHaveBeenCalled();
    });

    it('should save state on resume', () => {
      queue.pause();
      fs.writeFileSync.mockClear();
      queue.resume();
      
      expect(fs.writeFileSync).toHaveBeenCalled();
    });
  });

  describe('Persistence (save/load)', () => {
    beforeEach(() => {
      queue = new ComboQueue({ queueFile: testQueueFile });
    });

    it('should save queue to file', () => {
      queue.addCombos(['user1:pass1'], 'test');
      
      fs.writeFileSync.mockClear();
      fs.renameSync.mockClear();
      queue.save();
      
      // Atomic write: writes to temp file, then renames
      expect(fs.writeFileSync).toHaveBeenCalledWith(
        `${testQueueFile}.tmp`,
        expect.any(String),
        'utf8'
      );
      
      expect(fs.renameSync).toHaveBeenCalledWith(
        `${testQueueFile}.tmp`,
        testQueueFile
      );
      
      const savedData = JSON.parse(fs.writeFileSync.mock.calls[0][1]);
      expect(savedData).toHaveProperty('files');
      expect(savedData).toHaveProperty('combos');
      expect(savedData).toHaveProperty('paused');
      expect(savedData).toHaveProperty('stats');
    });

    it('should load queue from file', () => {
      const mockData = {
        files: [{ filename: 'test.txt', queuedCount: 2 }],
        combos: [
          ['user1\tpass1', { username: 'user1', password: 'pass1', source: 'test.txt', priority: 3 }],
          ['user2\tpass2', { username: 'user2', password: 'pass2', source: 'test.txt', priority: 3 }]
        ],
        paused: false,
        stats: { totalFilesAdded: 1 }
      };
      
      fs.existsSync.mockReturnValue(true);
      fs.readFileSync.mockReturnValue(JSON.stringify(mockData));
      
      queue = new ComboQueue({ queueFile: testQueueFile });
      
      expect(queue.files.length).toBe(1);
      expect(queue.combos.size).toBe(2);
      expect(queue.paused).toBe(false);
    });

    it('should handle missing file gracefully', () => {
      fs.existsSync.mockReturnValue(false);
      
      expect(() => {
        queue = new ComboQueue({ queueFile: testQueueFile });
      }).not.toThrow();
      
      expect(queue.files.length).toBe(0);
      expect(queue.combos.size).toBe(0);
    });

    it('should handle corrupted JSON gracefully', () => {
      fs.existsSync.mockReturnValue(true);
      fs.readFileSync.mockReturnValue('{ invalid json }');
      
      expect(() => {
        queue = new ComboQueue({ queueFile: testQueueFile });
      }).not.toThrow();
    });

    it('should round-trip save and load', () => {
      queue.addCombos(['user1:pass1', 'user2:pass2'], 'test', { priority: 2 });
      queue.markProcessed('user1', 'pass1');
      
      // Capture saved data
      fs.writeFileSync.mockClear();
      queue.save();
      const savedData = fs.writeFileSync.mock.calls[0][1];
      
      // Create new queue and load
      fs.existsSync.mockReturnValue(true);
      fs.readFileSync.mockReturnValue(savedData);
      
      const newQueue = new ComboQueue({ queueFile: testQueueFile });
      
      expect(newQueue.combos.size).toBe(1);
      expect(newQueue.files[0].processedCount).toBe(1);
      expect(newQueue.stats.totalProcessed).toBe(1);
    });
  });

  describe('Clear Completed (clearCompleted)', () => {
    beforeEach(() => {
      queue = new ComboQueue({ queueFile: testQueueFile });
    });

    it('should remove completed files', () => {
      queue.addCombos(['user1:pass1'], 'file1');
      queue.addCombos(['user2:pass2'], 'file2');
      queue.addCombos(['user3:pass3'], 'file3');
      
      // Complete file1 and file2
      queue.markProcessed('user1', 'pass1');
      queue.markProcessed('user2', 'pass2');
      
      const cleared = queue.clearCompleted();
      
      expect(cleared).toBe(2);
      expect(queue.files.length).toBe(1);
      expect(queue.files[0].filename).toBe('file3');
    });

    it('should return count of removed files', () => {
      queue.addCombos(['user1:pass1'], 'file1');
      queue.markProcessed('user1', 'pass1');
      
      const cleared = queue.clearCompleted();
      
      expect(cleared).toBe(1);
    });

    it('should keep non-completed files', () => {
      queue.addCombos(['user1:pass1', 'user2:pass2'], 'file1');
      queue.markProcessed('user1', 'pass1');
      
      const cleared = queue.clearCompleted();
      
      expect(cleared).toBe(0);
      expect(queue.files.length).toBe(1);
    });

    it('should save after clearing', () => {
      queue.addCombos(['user1:pass1'], 'file1');
      queue.markProcessed('user1', 'pass1');
      
      fs.writeFileSync.mockClear();
      queue.clearCompleted();
      
      expect(fs.writeFileSync).toHaveBeenCalled();
    });
  });

  describe('List Delay (getListDelay)', () => {
    it('should return base delay when no jitter', () => {
      queue = new ComboQueue({ 
        queueFile: testQueueFile,
        listDelay: 1000,
        listDelayJitter: 0
      });
      
      const delay = queue.getListDelay();
      
      expect(delay).toBe(1000);
    });

    it('should return delay with jitter', () => {
      queue = new ComboQueue({ 
        queueFile: testQueueFile,
        listDelay: 1000,
        listDelayJitter: 500
      });
      
      jest.spyOn(Math, 'random').mockReturnValue(0.5);
      
      const delay = queue.getListDelay();
      
      expect(delay).toBeGreaterThanOrEqual(1000);
      expect(delay).toBeLessThanOrEqual(1500);
      
      Math.random.mockRestore();
    });
  });
});
