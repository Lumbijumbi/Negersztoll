'use strict';

jest.mock('fs');
jest.mock('../../utils/fileHelper', () => ({
  ensureDirectory: jest.fn().mockReturnValue(true),
  writeJSONFileAtomic: jest.fn().mockReturnValue(true),
  readJSONFile: jest.fn()
}));

const fs = require('fs');
const { ensureDirectory, writeJSONFileAtomic, readJSONFile } = require('../../utils/fileHelper');
const SessionManager = require('../../utils/sessionManager');

describe('SessionManager', () => {
  let manager;
  const validSession = {
    username: 'testuser',
    savedAt: new Date().toISOString(),
    savedTimestamp: Date.now(),
    maxAge: 24 * 60 * 60 * 1000,
    cookies: [{ name: 'session', value: 'abc123', domain: 'example.com', path: '/', expires: -1, httpOnly: true, secure: true, sameSite: 'Lax' }]
  };

  beforeEach(() => {
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'warn').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});

    ensureDirectory.mockReturnValue(true);
    readJSONFile.mockReturnValue(null);
    fs.existsSync = jest.fn().mockReturnValue(false);
    fs.readdirSync = jest.fn().mockReturnValue([]);
    fs.unlinkSync = jest.fn();

    manager = new SessionManager({ sessionDir: '/fake/sessions', cleanupOnStart: false });
  });

  afterEach(() => {
    jest.restoreAllMocks();
    jest.clearAllMocks();
  });

  describe('constructor', () => {
    it('should use provided sessionDir', () => {
      expect(manager.sessionDir).toBe('/fake/sessions');
    });

    it('should use default maxAge', () => {
      expect(manager.maxAge).toBe(24 * 60 * 60 * 1000);
    });

    it('should throw when ensureDirectory fails', () => {
      ensureDirectory.mockReturnValueOnce(false);
      expect(() => new SessionManager({ cleanupOnStart: false })).toThrow('Failed to create sessions directory');
    });

    it('should run clearExpiredSessions on start if enabled', () => {
      fs.existsSync.mockReturnValue(false);
      const spy = jest.spyOn(SessionManager.prototype, 'clearExpiredSessions');
      new SessionManager({ cleanupOnStart: true });
      expect(spy).toHaveBeenCalled();
    });
  });

  describe('sanitizeUsername', () => {
    it('should replace spaces with underscores', () => {
      expect(manager.sanitizeUsername('user name')).toBe('user_name');
    });

    it('should return unknown for null/empty', () => {
      expect(manager.sanitizeUsername(null)).toBe('unknown');
      expect(manager.sanitizeUsername('')).toBe('unknown');
    });

    it('should truncate to 100 characters', () => {
      const long = 'a'.repeat(200);
      expect(manager.sanitizeUsername(long).length).toBe(100);
    });

    it('should replace slashes', () => {
      const result = manager.sanitizeUsername('user/path\\file');
      expect(result).not.toContain('/');
      expect(result).not.toContain('\\');
    });
  });

  describe('getSessionFilePath', () => {
    it('should return correct session file path', () => {
      const fp = manager.getSessionFilePath('testuser');
      expect(fp).toContain('testuser.json');
      expect(fp).toContain('/fake/sessions');
    });
  });

  describe('saveSession', () => {
    it('should save session successfully', async () => {
      const page = {
        context: () => ({ cookies: jest.fn().mockResolvedValue([{ name: 'sess', value: 'val', domain: 'example.com' }]) })
      };
      writeJSONFileAtomic.mockReturnValue(true);
      const result = await manager.saveSession(page, 'user@test.com');
      expect(result).toBe(true);
      expect(writeJSONFileAtomic).toHaveBeenCalled();
    });

    it('should return false when page is null', async () => {
      const result = await manager.saveSession(null, 'user');
      expect(result).toBe(false);
    });

    it('should return false when username is null', async () => {
      const result = await manager.saveSession({}, null);
      expect(result).toBe(false);
    });

    it('should return false when no cookies found', async () => {
      const page = {
        context: () => ({ cookies: jest.fn().mockResolvedValue([]) })
      };
      const result = await manager.saveSession(page, 'user@test.com');
      expect(result).toBe(false);
    });

    it('should fall back to page.evaluate if context().cookies() fails', async () => {
      const page = {
        context: () => ({ cookies: jest.fn().mockRejectedValue(new Error('context unavailable')) }),
        evaluate: jest.fn().mockResolvedValue([{ name: 'sess', value: 'val' }])
      };
      writeJSONFileAtomic.mockReturnValue(true);
      const result = await manager.saveSession(page, 'testuser');
      expect(result).toBe(true);
    });

    it('should return false when writeJSONFileAtomic fails', async () => {
      const page = {
        context: () => ({ cookies: jest.fn().mockResolvedValue([{ name: 'sess', value: 'val' }]) })
      };
      writeJSONFileAtomic.mockReturnValue(false);
      const result = await manager.saveSession(page, 'user');
      expect(result).toBe(false);
    });
  });

  describe('loadSession', () => {
    it('should return false when page is null', async () => {
      const result = await manager.loadSession(null, 'user');
      expect(result).toBe(false);
    });

    it('should return false when no session file found', async () => {
      readJSONFile.mockReturnValue(null);
      const result = await manager.loadSession({}, 'user');
      expect(result).toBe(false);
    });

    it('should return false for invalid session data (no cookies array)', async () => {
      readJSONFile.mockReturnValue({ username: 'user', savedTimestamp: Date.now() });
      const result = await manager.loadSession({}, 'user');
      expect(result).toBe(false);
    });

    it('should return false for expired session and delete file', async () => {
      const expired = { ...validSession, savedTimestamp: Date.now() - (25 * 60 * 60 * 1000) };
      readJSONFile.mockReturnValue(expired);
      fs.unlinkSync.mockImplementation(() => {});
      const result = await manager.loadSession({}, 'testuser');
      expect(result).toBe(false);
      expect(fs.unlinkSync).toHaveBeenCalled();
    });

    it('should load and apply cookies', async () => {
      readJSONFile.mockReturnValue(validSession);
      const addCookies = jest.fn().mockResolvedValue(undefined);
      const page = { context: () => ({ addCookies }) };
      const result = await manager.loadSession(page, 'testuser');
      expect(result).toBe(true);
      expect(addCookies).toHaveBeenCalledWith(validSession.cookies);
    });

    it('should return false if addCookies fails', async () => {
      readJSONFile.mockReturnValue(validSession);
      const addCookies = jest.fn().mockRejectedValue(new Error('context error'));
      const page = { context: () => ({ addCookies }) };
      const result = await manager.loadSession(page, 'testuser');
      expect(result).toBe(false);
    });
  });

  describe('hasValidSession', () => {
    it('should return false when no session file', () => {
      readJSONFile.mockReturnValue(null);
      expect(manager.hasValidSession('user')).toBe(false);
    });

    it('should return true for valid session', () => {
      readJSONFile.mockReturnValue(validSession);
      expect(manager.hasValidSession('testuser')).toBe(true);
    });

    it('should return false for expired session', () => {
      const expired = { ...validSession, savedTimestamp: Date.now() - (25 * 60 * 60 * 1000) };
      readJSONFile.mockReturnValue(expired);
      expect(manager.hasValidSession('testuser')).toBe(false);
    });

    it('should handle errors gracefully', () => {
      readJSONFile.mockImplementation(() => { throw new Error('read error'); });
      expect(manager.hasValidSession('user')).toBe(false);
    });
  });

  describe('isSessionValid', () => {
    it('should return false for null/no savedTimestamp', () => {
      expect(manager.isSessionValid(null)).toBe(false);
      expect(manager.isSessionValid({})).toBe(false);
    });

    it('should return false when session exceeds maxAge', () => {
      const old = { savedTimestamp: Date.now() - (25 * 60 * 60 * 1000), maxAge: 24 * 60 * 60 * 1000, cookies: [] };
      expect(manager.isSessionValid(old)).toBe(false);
    });

    it('should return false when a cookie has expired', () => {
      const expired = {
        savedTimestamp: Date.now(),
        maxAge: 24 * 60 * 60 * 1000,
        cookies: [{ name: 'sess', value: 'val', expires: Math.floor((Date.now() - 10000) / 1000) }]
      };
      expect(manager.isSessionValid(expired)).toBe(false);
    });

    it('should return true for valid session', () => {
      expect(manager.isSessionValid(validSession)).toBe(true);
    });

    it('should skip cookies with expires=-1 (session cookies)', () => {
      const s = { ...validSession, cookies: [{ name: 'sess', value: 'val', expires: -1 }] };
      expect(manager.isSessionValid(s)).toBe(true);
    });
  });

  describe('clearExpiredSessions', () => {
    it('should return 0 when directory does not exist', () => {
      fs.existsSync.mockReturnValue(false);
      expect(manager.clearExpiredSessions()).toBe(0);
    });

    it('should skip non-json files', () => {
      fs.existsSync.mockReturnValue(true);
      fs.readdirSync.mockReturnValue(['data.csv', 'readme.txt']);
      expect(manager.clearExpiredSessions()).toBe(0);
    });

    it('should delete corrupted session files', () => {
      fs.existsSync.mockReturnValue(true);
      fs.readdirSync.mockReturnValue(['corrupted.json']);
      readJSONFile.mockReturnValue(null);
      const count = manager.clearExpiredSessions();
      expect(count).toBe(1);
      expect(fs.unlinkSync).toHaveBeenCalled();
    });

    it('should delete expired session files', () => {
      fs.existsSync.mockReturnValue(true);
      fs.readdirSync.mockReturnValue(['expired.json']);
      const expired = { ...validSession, savedTimestamp: Date.now() - (25 * 60 * 60 * 1000) };
      readJSONFile.mockReturnValue(expired);
      const count = manager.clearExpiredSessions();
      expect(count).toBe(1);
    });

    it('should not delete valid sessions', () => {
      fs.existsSync.mockReturnValue(true);
      fs.readdirSync.mockReturnValue(['valid.json']);
      readJSONFile.mockReturnValue(validSession);
      const count = manager.clearExpiredSessions();
      expect(count).toBe(0);
    });
  });

  describe('deleteSession', () => {
    it('should delete existing session', () => {
      fs.existsSync.mockReturnValue(true);
      const result = manager.deleteSession('user@test.com');
      expect(result).toBe(true);
      expect(fs.unlinkSync).toHaveBeenCalled();
    });

    it('should return false when session does not exist', () => {
      fs.existsSync.mockReturnValue(false);
      const result = manager.deleteSession('nonexistent');
      expect(result).toBe(false);
    });

    it('should handle errors gracefully', () => {
      fs.existsSync.mockReturnValue(true);
      fs.unlinkSync.mockImplementation(() => { throw new Error('permission denied'); });
      const result = manager.deleteSession('user');
      expect(result).toBe(false);
    });
  });

  describe('getStats', () => {
    it('should return zeros when directory does not exist', () => {
      fs.existsSync.mockReturnValue(false);
      const stats = manager.getStats();
      expect(stats).toEqual({ total: 0, valid: 0, expired: 0 });
    });

    it('should count valid and expired sessions', () => {
      fs.existsSync.mockReturnValue(true);
      fs.readdirSync.mockReturnValue(['valid.json', 'expired.json', 'data.txt']);
      readJSONFile
        .mockReturnValueOnce(validSession)
        .mockReturnValueOnce({ ...validSession, savedTimestamp: Date.now() - (25 * 60 * 60 * 1000) });
      const stats = manager.getStats();
      expect(stats.total).toBe(2);
      expect(stats.valid).toBe(1);
      expect(stats.expired).toBe(1);
    });

    it('should count unreadable sessions as expired', () => {
      fs.existsSync.mockReturnValue(true);
      fs.readdirSync.mockReturnValue(['bad.json']);
      readJSONFile.mockReturnValue(null);
      const stats = manager.getStats();
      expect(stats.expired).toBe(1);
    });
  });
});
