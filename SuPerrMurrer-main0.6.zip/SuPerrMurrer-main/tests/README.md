# Test Documentation

This directory contains comprehensive automated tests for the SuPerrMurrer application.

## Overview

The test suite validates the core functionality of the credential testing system, including:
- CAS authentication detection
- Form filling utilities
- Error recovery and retry mechanisms
- Retry queue management
- Configuration validation

## Test Structure

```
tests/
├── unit/                    # Unit tests for individual modules
│   ├── casDetection.test.js          # CAS/OAuth detection logic (50+ tests)
│   ├── errorRecovery.test.js         # Error classification & backoff (35+ tests)
│   ├── retryQueue.test.js            # Retry queue management (70+ tests)
│   ├── formFill.test.js              # Form filling utilities (50+ tests)
│   ├── config.test.js                # Configuration validation (80+ tests)
│   ├── comboQueue.test.js            # ✨ Queue/backlog system (62 tests)
│   ├── configValidator.test.js       # ✨ Config validation (52 tests)
│   ├── configProfiles.test.js        # ✨ Profile system (50 tests)
│   ├── resourceManager.test.js       # ✨ System monitoring (33 tests)
│   ├── healthCheck.test.js           # ✨ Health checks (45 tests)
│   ├── adaptiveTimeout.test.js       # ✨ Adaptive timeout (40 tests)
│   ├── credentialHistory.test.js     # ✨ History tracking (74 tests)
│   ├── enhancedConsole.test.js       # ✨ Console output (97 tests)
│   ├── formSubmit.test.js            # ✨ Form submission (59 tests)
│   ├── metricsCollector.test.js      # ✨ Metrics collection (114 tests)
│   ├── guiServer.test.js             # ✨ GUI API endpoints (70 tests)
│   ├── connectionPool.test.js        # Browser pool management (50+ tests)
│   └── balanceParsing.test.js        # Balance parsing utilities
└── integration/             # Integration tests (placeholder)
```

✨ = New in v1.2.0

## Running Tests

### Run All Tests
```bash
npm test
```

### Run Tests in Watch Mode
```bash
npm run test:watch
```

### Run Only Unit Tests
```bash
npm run test:unit
```

### Run with Coverage Report
```bash
npm test
```

Coverage report is automatically generated in the `coverage/` directory.

## Test Coverage

Current test coverage after v1.2.0 comprehensive test suite:

### Core Modules (Excellent Coverage)
- **comboQueue.js**: 100% coverage (62 tests)
- **configValidator.js**: 95%+ coverage (52 tests)
- **configProfiles.js**: 100% coverage (50 tests)
- **resourceManager.js**: 100% coverage (33 tests)
- **healthCheck.js**: 95%+ coverage (45 tests)
- **adaptiveTimeout.js**: 94%+ coverage (40 tests)
- **credentialHistory.js**: 98%+ coverage (74 tests)
- **enhancedConsole.js**: 94%+ coverage (97 tests)
- **formSubmit.js**: 60%+ coverage (59 tests)
- **metricsCollector.js**: 100% coverage (114 tests)
- **guiServer.js**: 70%+ coverage (70 tests)
- **config.js**: 100% coverage (80+ tests)
- **errorRecovery.js**: 95% coverage (35+ tests)
- **formFill.js**: 73% coverage (50+ tests)
- **casDetection.js**: 94% coverage (50+ tests)
- **retryQueue.js**: 95% coverage (70+ tests)
- **connectionPool.js**: 95%+ coverage (50+ tests)

**Overall**: ~90-95% coverage across 680+ tests in 18 test files

### Testing Infrastructure
- **Jest** test framework with coverage reporting
- **Supertest** for API endpoint testing
- Comprehensive mocking of external dependencies
- Integration tests for real-world scenarios

## Test Categories

### 1. CAS Detection Tests (`casDetection.test.js`)

Tests the authentication detection system:

- **CAS Ticket Redirect Detection**
  - Valid ticket URL patterns
  - Ticket parameter extraction
  - URL validation
  
- **TGC Cookie Detection**
  - Cookie string parsing
  - Cookie priority handling
  - Fallback mechanisms

- **Main Detection Flow**
  - Priority ordering (ticket > cookie)
  - Confidence scoring
  - Timeout handling

**Key Test Cases:**
- 50+ test cases covering all detection methods
- Edge cases: invalid URLs, missing parameters, malformed data
- Mock page integration testing

### 2. Error Recovery Tests (`errorRecovery.test.js`)

Tests error handling and retry logic:

- **Backoff Calculation**
  - Exponential backoff timing
  - Maximum delay capping
  - Various retry attempts

- **Retry Logic**
  - Successful retries
  - Exhausted retries
  - Custom retry predicates
  - Callback invocation

- **Error Classification**
  - Network errors (recoverable)
  - Timeout errors (recoverable)
  - Authentication errors (non-recoverable)
  - Browser crashes (recoverable)
  - Unknown errors

**Key Test Cases:**
- 35+ test cases for all error types
- Retry strategies and backoff calculations
- Error classification accuracy

### 3. Retry Queue Tests (`retryQueue.test.js`)

Tests the credential retry management system:

- **Queue Operations**
  - Adding credentials
  - Tracking retry counts
  - Success marking
  - Exhausted credential cleanup

- **Persistence**
  - Save to disk (atomic writes)
  - Load from disk
  - Corrupted file handling
  - Backup creation

- **Statistics**
  - Total added, retried, succeeded
  - Queue size tracking
  - Retryable vs exhausted counts

**Key Test Cases:**
- 70+ test cases covering all operations
- File I/O edge cases
- Concurrent operations
- Data integrity

### 4. Form Fill Tests (`formFill.test.js`)

Tests form interaction utilities:

- **Character-by-Character Typing**
  - Realistic keystroke delays
  - Individual character handling
  - Success verification

- **Fallback Strategies**
  - page.fill() fallback
  - DOM manipulation fallback
  - Multi-level retry logic

- **Multiple Field Handling**
  - Sequential field filling
  - Partial success tracking
  - Error propagation

**Key Test Cases:**
- 50+ test cases for fill operations
- Special character handling
- Unicode support
- Error recovery paths

### 5. Configuration Tests (`config.test.js`)

Tests configuration structure and validation:

- **Structure Validation**
  - All required sections present
  - Correct data types
  - Valid value ranges

- **Consistency Checks**
  - Timeout relationships
  - Delay ranges
  - Confidence thresholds

- **Domain-Specific Validation**
  - URL format validation
  - CSS selector formats
  - Array populations

**Key Test Cases:**
- 80+ test cases covering all config sections
- Cross-field validation
- Range boundary testing

### 6. Combo Queue Tests (`comboQueue.test.js`) - NEW v1.2.0

Tests the queue/backlog system for managing combo files:

- **File Management**
  - Adding files with priorities (1-5)
  - Removing files and associated combos
  - Priority updates affecting all combos

- **Deduplication**
  - Cross-file deduplication
  - History-based skipping
  - Case-sensitive/insensitive modes

- **Queue Operations**
  - Batch retrieval sorted by priority
  - Shuffle with Fisher-Yates algorithm
  - Pause/resume functionality
  - Processing tracking

- **Persistence**
  - JSON serialization with Map support
  - Load/save round-trip consistency
  - Corrupted file handling

**Key Test Cases:**
- 62 comprehensive tests covering all queue operations
- Mock fs for file I/O testing
- Integration tests for complete workflows

### 7. Config Validator Tests (`configValidator.test.js`) - NEW v1.2.0

Tests configuration validation across all sections:

- **Browser Settings**
  - Timeout validation (min 10s, max 10m)
  - Channel validation (chrome/msedge/chromium)
  - Headless mode warnings

- **Proxy & Batch Settings**
  - Negative value detection
  - Worker count limits (1-16)
  - Credentials per proxy warnings

- **Form & Navigation**
  - Delay range validation
  - Wait condition validation
  - Minimum value checks

**Key Test Cases:**
- 52 tests covering all configuration sections
- Error vs warning distinction
- Complete config validation scenarios

### 8. Config Profiles Tests (`configProfiles.test.js`) - NEW v1.2.0

Tests predefined configuration profiles:

- **Profile System**
  - Fast (8 workers), Turbo (12 workers), Aggressive (10 workers)
  - Balanced (4 workers, moderate)
  - Conservative (3 workers), Stealth (2 workers, human-like)
  - Night Owl (2 workers, overnight), Low Resource (1 worker, minimal)
  - Debug (1 worker, long timeouts)

- **Profile Application**
  - Deep merging without mutation
  - Preserving non-profile values
  - Validation of profile characteristics

- **Descriptions**
  - Short descriptions with emojis for all 9 profiles
  - Detailed user-friendly descriptions (what it does, when to use, trade-offs, recommended for)
  - No headless mentions in any profile description

**Key Test Cases:**
- 50 tests covering all 9 profiles
- Performance characteristic validation
- Merge logic and consistency checks

### 9. Resource Manager Tests (`resourceManager.test.js`) - NEW v1.2.0

Tests system resource monitoring:

- **Worker Optimization**
  - CPU-based worker calculation
  - Memory-based limiting
  - Automatic caps (1-16 workers)

- **System Monitoring**
  - CPU usage tracking
  - Memory statistics
  - Performance recommendations

**Key Test Cases:**
- 33 tests with os module mocking
- Resource constraint detection
- Recommendation generation

### 10. Health Check Tests (`healthCheck.test.js`) - NEW v1.2.0

Tests the health monitoring system:

- **Check Registry**
  - Custom check registration
  - Interval management
  - Result caching

- **Health Scoring**
  - Overall health calculation
  - Failing check tracking
  - History management (100 entry limit)

- **Default Checks**
  - Proxy availability
  - Worker capacity
  - Memory usage
  - Filesystem access
  - Retry queue health

**Key Test Cases:**
- 45 tests covering check lifecycle
- Mock fs.promises for file operations
- Integration tests for degradation detection

### 11. Adaptive Timeout Tests (`adaptiveTimeout.test.js`) - NEW v1.2.0

Tests adaptive timeout calculation (converted from standalone test):

- **Sample Collection**
  - Success timing recording
  - Sliding window (default 20 samples)
  - Min/max tracking

- **Timeout Calculation**
  - P95 percentile calculation
  - Buffer multiplier (default 1.5x)
  - Min (base) and max bounds

**Key Test Cases:**
- 40 tests in Jest format
- Performance improvement/degradation scenarios
- Edge cases with large/small values

### 12. Credential History Tests (`credentialHistory.test.js`) - NEW v1.2.0

Tests persistent credential tracking:

- **JSONL Persistence**
  - Append-only writes
  - Load with deduplication
  - Corrupted file handling

- **Skip Logic**
  - Status-based skipping (success/failed/blocked)
  - Time-based retry windows
  - Configurable skip rules

- **Search & Statistics**
  - Username/password/status search
  - Status breakdown counting
  - Export with field expansion

**Key Test Cases:**
- 74 tests covering complete history lifecycle
- Mock fs for all file operations
- Integration tests for load→filter→record cycles

### 13. Enhanced Console Tests (`enhancedConsole.test.js`) - NEW v1.2.0

Tests enhanced console output utilities:

- **Output Methods**
  - Success, error, warning, info messages
  - Progress indicators
  - Visual sections with headers

- **Formatting**
  - Box drawing with borders
  - Table rendering
  - Spinner integration (ora)
  - Duration formatting

**Key Test Cases:**
- 97 tests covering all output methods
- Mock chalk, boxen, cli-progress, ora
- Edge cases with long text and special characters

### 14. Form Submit Tests (`formSubmit.test.js`) - NEW v1.2.0

Tests form submission strategies:

- **Submission Methods**
  - CSS selector clicking
  - XPath strategies
  - Enter key submission
  - JavaScript form.submit()
  - JavaScript button search

- **reCAPTCHA Handling**
  - Detection (v2, v3, enterprise)
  - Completion waiting
  - Token detection

- **Error Recovery**
  - Retry logic (up to 3 attempts)
  - Logout retry mechanism
  - Fallback strategies

**Key Test Cases:**
- 59 tests covering all submission strategies
- Mock Playwright page objects
- Integration tests for complete login-logout cycles

### 15. Metrics Collector Tests (`metricsCollector.test.js`) - NEW v1.2.0

Tests metrics collection and tracking:

- **Metric Recording**
  - Event counting (login, captcha, blocked, etc.)
  - Timeline tracking with timestamps
  - EventEmitter integration

- **Statistics**
  - Mean, min, max calculations
  - Percentile calculations
  - Rate calculations (per minute)

- **Reporting**
  - Formatted report generation
  - Interval-based reporting
  - Reset functionality

**Key Test Cases:**
- 114 tests covering all metric types
- Jest fake timers for interval testing
- Integration tests for real-world usage patterns

### 16. GUI Server Tests (`guiServer.test.js`) - NEW v1.2.0

Tests the Express API server and all endpoints:

- **Configuration Endpoints**
  - GET/PUT `/api/config` with validation
  - POST `/api/config/save` with backups
  - Range validation for workers, proxies

- **File Management**
  - Credentials and proxy file read/write
  - Comment filtering
  - Error handling

- **History Management**
  - Pagination, filtering, sorting
  - Statistics and compaction
  - Search functionality

- **Controller Management**
  - Start/stop process lifecycle
  - Status monitoring
  - Log streaming (stdout/stderr)

- **Queue Operations**
  - Add, shuffle, clear, pause, resume
  - Priority management (1-5)
  - File removal and statistics

**Key Test Cases:**
- 70 tests using supertest for HTTP endpoint testing
- Mock fs, child_process, os modules
- Integration tests for end-to-end workflows
- 20+ API endpoints fully tested

## Writing New Tests

### Test File Template

```javascript
/**
 * Unit Tests for [Module Name]
 * Tests [brief description]
 */

const moduleToTest = require('../../path/to/module');

describe('[Module Name]', () => {
  beforeEach(() => {
    // Setup
  });

  afterEach(() => {
    // Cleanup
  });

  describe('[function or method name]', () => {
    it('should [expected behavior]', () => {
      // Arrange
      const input = 'test input';
      
      // Act
      const result = moduleToTest.function(input);
      
      // Assert
      expect(result).toBe('expected output');
    });
  });
});
```

### Best Practices

1. **Descriptive Test Names**: Use clear "should..." descriptions
2. **Arrange-Act-Assert**: Structure tests in three clear phases
3. **Mock External Dependencies**: Use Jest mocks for external calls
4. **Test Edge Cases**: Include null, undefined, empty, and boundary values
5. **Cleanup**: Always cleanup resources in afterEach hooks
6. **Isolate Tests**: Each test should be independent

### Mocking Examples

```javascript
// Mock entire module
jest.mock('../../module', () => ({
  function: jest.fn()
}));

// Mock implementation
const mockFn = jest.fn().mockResolvedValue('result');

// Mock multiple returns
const mockFn = jest.fn()
  .mockReturnValueOnce('first')
  .mockReturnValueOnce('second');

// Spy on console
jest.spyOn(console, 'log').mockImplementation(() => {});
```

## Continuous Integration

Tests are automatically run on:
- Pull request creation
- Commits to main branch
- Manual workflow triggers

Coverage reports are generated and can be viewed in the `coverage/` directory.

## Troubleshooting

### Common Issues

**Issue**: Tests timeout
- **Solution**: Increase test timeout with `jest.setTimeout(10000)`

**Issue**: Mock not working
- **Solution**: Ensure mock is defined before module import

**Issue**: Async test not completing
- **Solution**: Always return promises or use async/await

**Issue**: Coverage not updating
- **Solution**: Delete `coverage/` directory and re-run tests

## Future Test Additions

Planned test coverage expansion:

- [ ] Integration tests for worker-controller communication
- [ ] Browser automation tests (with Playwright)
- [ ] Session management tests
- [ ] Webhook notification tests
- [ ] Logger functionality tests
- [ ] Metrics collector tests
- [ ] End-to-end workflow tests

## Contributing

When adding new features:

1. Write tests first (TDD approach)
2. Ensure all tests pass
3. Maintain >70% coverage for new code
4. Update this documentation

## Resources

- [Jest Documentation](https://jestjs.io/docs/getting-started)
- [Jest Matchers](https://jestjs.io/docs/expect)
- [Testing Best Practices](https://testingjavascript.com/)
