# SuPerrMurrer — Technical Onboarding Guide

> **Generated:** 2026-03-04  
> **Repository:** [Lumbijumbi/SuPerrMurrer](https://github.com/Lumbijumbi/SuPerrMurrer)  
> **Version:** 2.0.0

---

## Table of Contents

1. [README / Instruction Files Summary](#1-readme--instruction-files-summary)
2. [Detailed Technology Stack](#2-detailed-technology-stack)
3. [System Overview and Purpose](#3-system-overview-and-purpose)
4. [Project Structure and Reading Recommendations](#4-project-structure-and-reading-recommendations)
5. [Key Components](#5-key-components)
6. [Execution and Data Flows](#6-execution-and-data-flows)
7. [Dependencies and Integrations](#7-dependencies-and-integrations)
8. [Diagrams](#8-diagrams)
9. [Testing](#9-testing)
10. [Error Handling and Logging](#10-error-handling-and-logging)
11. [Security Considerations](#11-security-considerations)
12. [Other Relevant Observations (Build / Deploy)](#12-other-relevant-observations-build--deploy)

---

## 1. README / Instruction Files Summary

### Root Documentation Files

| File | Purpose |
|------|---------|
| [`README.md`](README.md) | Main project overview, quick start, architecture, feature list, configuration reference, file structure |
| [`CONTRIBUTING.md`](CONTRIBUTING.md) | Contribution workflow, code style, PR process |
| [`CHANGELOG.md`](CHANGELOG.md) | Version history (Keep a Changelog format with semantic versioning) |
| [`SECURITY.md`](SECURITY.md) | Vulnerability reporting policy, responsible disclosure |
| [`CODE_OF_CONDUCT.md`](CODE_OF_CONDUCT.md) | Contributor Covenant 2.1 community standards |
| [`LICENSE`](LICENSE) | MIT License with Educational Use Disclaimer |

### Key README Sections for New Developers

#### Project Overview
SuPerrMurrer is a **distributed automated credential testing system** built with Node.js and Playwright (via the [Patchright](https://github.com/Kaliiiiiiiiii-Vinyzu/patchright) stealth wrapper). It tests login credentials against the **Supercard.ch** Swiss loyalty-card platform (which uses CAS 3.x / OAuth2 / OIDC) using a controller-worker architecture with advanced detection mechanisms and anti-fingerprint capabilities.

> **⚠️ Legal Notice:** Use of this tool without explicit written authorization from the target system owner may violate computer access laws (CFAA, Computer Misuse Act, and equivalents). The tool is intended for authorized security testing and educational purposes only.

#### Local Setup (Quick Start)

```bash
# 1. Clone and install
git clone https://github.com/Lumbijumbi/SuPerrMurrer.git
cd SuPerrMurrer
npm install

# 2. Copy and configure environment variables
cp .env.example .env
# Edit .env as needed

# 3. Create input files
echo "user@example.com:password123" > test.txt
echo "http://user:pass@proxy.host:port" > Lightning_Proxies.txt

# 4. Launch interactive menu
npm start

# Alternatively, run the controller directly:
npm run direct

# Or launch the web GUI dashboard:
npm run gui   # → http://localhost:3773
```

#### Adopted Standards and Conventions
- **CommonJS modules** (`require`/`module.exports`) throughout — no transpilation step
- **Single config source:** all runtime settings live in [`config.js`](config.js)
- **Atomic file writes** for all persistent state via temp-file + rename pattern
- **JSONL** (newline-delimited JSON) for append-only log files
- **70% test coverage** enforced via Jest coverage thresholds
- **Keep a Changelog** format for [`CHANGELOG.md`](CHANGELOG.md)

#### Contribution Guidelines ([`CONTRIBUTING.md`](CONTRIBUTING.md))
1. Fork the repository and create a feature branch
2. Implement changes with accompanying tests
3. Run `npm test` — all tests must pass and coverage must stay ≥ 70%
4. Submit a PR with a clear description of changes

### Supplemental Documentation (`docs/`)

```
docs/
├── INDEX.md                           ← Central documentation index
├── QUICKSTART.md                      ← 5-minute setup guide
├── ARCHITECTURE.md                    ← Detailed architecture docs
├── CONFIGURATION.md                   ← All config options explained
├── API.md                             ← GUI REST API reference
├── DETECTION.md                       ← CAS detection strategies deep-dive
├── ADVANCED_USAGE.md                  ← Advanced patterns and use cases
├── TROUBLESHOOTING.md                 ← Common issues and fixes
├── DOCKER_DEPLOYMENT.md               ← Container deployment guide
├── COMBO_EXTRACTOR.md                 ← Python combo extractor guide
├── TRAFFIC_OPTIMIZATION.md            ← Performance tuning
├── status/                            ← Project planning and roadmap
├── implementation/                    ← Implementation summaries
└── guides/                            ← Resolution guides
```

---

## 2. Detailed Technology Stack

### Runtime and Language

| Item | Detail | Config Reference |
|------|--------|-----------------|
| **Runtime** | Node.js ≥ 14.0.0 (recommended) | Not enforced in [`package.json`](package.json) (no `engines` field) |
| **Language** | JavaScript (ES2020, CommonJS) | All `.js` files |
| **Python** | Python 3 (stdlib only) | [`scripts/combo_extractor.py`](scripts/combo_extractor.py), [`scripts/extractor_core.py`](scripts/extractor_core.py) |

### Browser Automation

| Item | Detail |
|------|--------|
| **[patchright](https://github.com/Kaliiiiiiiiii-Vinyzu/patchright) `^1.48.2`** | Stealth fork of Playwright; patches Chromium fingerprint detection vectors. Drop-in replacement for `playwright`. Used in [`play_version2_worker_integrated_Version5.js`](play_version2_worker_integrated_Version5.js) |
| **Engine** | Chromium / Google Chrome (`channel: 'chrome'`) |

### Web Framework

| Item | Detail |
|------|--------|
| **[express](https://expressjs.com/) `^4.22.1`** | REST API server for the web dashboard GUI. See [`gui/server.js`](gui/server.js) |

### Proxy Management

| Item | Detail |
|------|--------|
| **[proxy-chain](https://github.com/apify/proxy-chain) `^2.5.4`** | Converts upstream HTTP/HTTPS/SOCKS proxies to local TCP tunnels usable by Playwright |

### CLI/UX Libraries

| Package | Version | Role |
|---------|---------|------|
| `chalk` | `^4.1.2` | Terminal string coloring |
| `boxen` | `^5.1.2` | Boxed terminal output |
| `cli-progress` | `^3.12.0` | Progress bars with ETA |
| `ora` | `^5.4.1` | Terminal spinners |
| `inquirer` | `^8.2.6` | Interactive CLI prompts and menus |

> All CLI deps configured in [`package.json`](package.json).

### Persistence / Storage

No external database. All state is stored as **local files**:

| File | Format | Purpose |
|------|--------|---------|
| `combo_history.jsonl` | JSONL (append-only) | Credential test history / deduplication |
| `combo_queue.json` | JSON (atomic-write) | Combo file backlog queue |
| `retry_queue.json` | JSON (atomic-write) | Failed credential retry state |
| `sessions/*.json` | JSON | Per-user session cookies |
| `logs/*/YYYY-MM-DD.jsonl` | JSONL | Categorized test result logs |
| `CookieExports/*.json` | JSON | Exported session data with Python snippet |

### Architecture Style

**Controller-Worker Monolith** with IPC message passing:
- Single controller process orchestrates multiple worker sub-processes
- Workers communicate back via Node.js IPC (`process.send` / `process.on('message')`)
- All state files are local on the filesystem

### Build Tools and Package Manager

| Item | Detail |
|------|--------|
| **npm** | Package manager ([`package.json`](package.json)) |
| **No transpilation** | Plain CommonJS — no Babel, TypeScript, or webpack |

### Containerization

| Item | Detail | Config |
|------|--------|--------|
| **Docker** | Multi-stage build (node:18-alpine) | [`Dockerfile`](Dockerfile) |
| **Docker Compose** | Orchestrates app + optional Prometheus + Grafana | [`docker-compose.yml`](docker-compose.yml) |

### Testing

| Item | Detail |
|------|--------|
| **[jest](https://jestjs.io/) `^29.7.0`** | Test runner with coverage |
| **[supertest](https://github.com/ladjs/supertest) `^6.3.4`** | HTTP assertion library for Express testing |
| **`@types/jest` `^29.5.14`** | TypeScript types for IDE support |

### CI/CD

| Item | Detail | Config |
|------|--------|--------|
| **GitHub Actions** | AI-powered issue summarizer on issue creation | [`.github/workflows/summary.yml`](.github/workflows/summary.yml) |

### Optional Monitoring (Docker Compose profile)

| Item | Detail |
|------|--------|
| **Prometheus** | Metrics collection (port 9091) |
| **Grafana** | Metrics visualization (port 3000) |

---

## 3. System Overview and Purpose

### What the System Does

SuPerrMurrer automates the process of testing whether a list of `username:password` credential pairs successfully authenticate against a target web system that uses **CAS (Central Authentication Service) with OAuth2/OIDC**. Specifically, the current configuration targets **login.supercard.ch** (the Supercard.ch Swiss loyalty-card platform).

### Who It Is For

Security professionals performing authorized penetration testing or credential validation audits on systems using CAS-based authentication.

### Core Functionalities

| Feature | Description |
|---------|-------------|
| **Multi-Worker Parallel Testing** | Configurable pool of browser workers (default: 6 parallel) |
| **Advanced CAS Detection** | Multiple ranked strategies with confidence scoring (92%–99%) |
| **TGC Cookie Priority** | Highest-confidence (99%) success detection via CAS Ticket Granting Cookie |
| **Stealth Form Filling** | Character-by-character typing with random delays (80–160 ms) |
| **Proxy Rotation** | Per-reason blacklist TTLs, TCP health checks, auto-replacement |
| **Credential Deduplication** | JSONL-backed history with O(1) lookup; skips already-tested combos |
| **Retry Queue** | Multi-pass retry loop (up to 3 passes) for failed credentials with priority ordering |
| **Session Cookie Reuse** | Save and restore session cookies to skip re-authentication (24h default TTL) |
| **Cookie Export** | Export cookies + Python `requests` snippet for manual post-processing |
| **CAPTCHA Detection** | Automatic reCAPTCHA v2 detection and reporting |
| **Real-Time Metrics** | EventEmitter-based live progress and analytics |
| **Web GUI Dashboard** | Express REST API + single-page frontend at port 3773 |
| **Interactive CLI** | Inquirer.js menu with configuration profiles (fast, balanced, stealth, custom) |
| **Python Combo Extractor** | Pre-process large combo files (GUI + CLI) with deduplication |

---

## 4. Project Structure and Reading Recommendations

### Entry Points

| Entry Point | Command | Description |
|-------------|---------|-------------|
| [`cli.js`](cli.js) | `npm start` | Primary CLI entry; parses commands, launches interactive menu |
| [`play_version2_controller.js`](play_version2_controller.js) | `npm run direct` | Core batch orchestrator; spawns workers |
| [`play_version2_worker_integrated_Version5.js`](play_version2_worker_integrated_Version5.js) | (spawned by controller) | Browser automation worker process |
| [`gui/server.js`](gui/server.js) | `npm run gui` | Express REST API server on port 3773 |

### General Folder Structure

```
SuPerrMurrer/
│
├── cli.js                                    ← Primary CLI entry point
├── config.js                                 ← Single-source configuration
├── play_version2_controller.js               ← Orchestrator / batch scheduler
├── play_version2_worker_integrated_Version5.js ← Browser automation worker
├── formFill.js                               ← Form filling utilities
├── errorRecovery.js                          ← Retry / backoff / error classification
├── metricsCollector.js                       ← Real-time metrics (EventEmitter)
│
├── utils/                                    ← All utility modules (25+ files)
│   ├── casDetection.js                       ← CAS/OAuth detection engine
│   ├── cookieExporter.js                     ← Cookie + Python snippet exporter
│   ├── credentialHistory.js                  ← JSONL-backed deduplication
│   ├── retryQueue.js                         ← Failed-credential retry manager
│   ├── comboQueue.js                         ← Combo file backlog manager
│   ├── sessionManager.js                     ← Cookie session persistence
│   ├── logger.js                             ← Structured ANSI + JSONL logger
│   ├── fileHelper.js                         ← Atomic file I/O utilities
│   ├── adaptiveTimeout.js                    ← Dynamic timeout tuner (p95)
│   ├── autoRecovery.js                       ← Pluggable self-healing strategies
│   ├── healthCheck.js                        ← Health check registry
│   ├── resourceManager.js                    ← CPU/mem worker-count advisor
│   ├── mouseMovement.js                      ← Human-like mouse simulation
│   ├── configApplier.js                      ← Runtime config patch application
│   ├── configHelper.js                       ← Config getter / setter helpers
│   ├── configProfiles.js                     ← Predefined config profiles
│   ├── configValidator.js                    ← Config schema validation
│   ├── connectionPool.js                     ← Connection pool abstraction
│   ├── dataDomeSolver.js                     ← DataDome challenge handling
│   ├── enhancedConsole.js                    ← Rich console output helpers
│   ├── formSubmit.js                         ← Form submission strategies
│   ├── progressDashboard.js                  ← Live dashboard renderer
│   ├── sessionState.js                       ← In-memory session state
│   ├── usedEntries.js                        ← Combo deduplication tracking
│   ├── workflowManager.js                    ← Project management automation
│   ├── interactiveCLI.js                     ← Startup configuration wizard
│   ├── interactiveMenu.js                    ← Inquirer.js interactive menu
│   └── projectTracker.js                     ← PROJECT_STATUS.md CLI updater
│
├── gui/
│   ├── server.js                             ← Express REST API (port 3773)
│   └── public/
│       └── index.html                        ← Single-page web dashboard
│
├── scripts/
│   ├── combo_extractor.py                    ← tkinter GUI combo extractor
│   └── extractor_core.py                     ← Core regex extraction library
│
├── tests/
│   ├── unit/                                 ← 32 Jest unit test files
│   ├── integration/                          ← 2 workflow integration test files
│   ├── adaptiveTimeout.test.js               ← Legacy root-level test
│   ├── backoff.test.js
│   ├── blacklistTTL.test.js
│   └── detectionImprovements.test.js
│
├── docs/                                     ← 30+ Markdown documentation files
├── examples/                                 ← Sample input/output combo files
├── config/
│   └── README.md                             ← Config directory notes
│
├── Dockerfile                                ← Multi-stage Docker build
├── docker-compose.yml                        ← App + Prometheus + Grafana
├── .env.example                              ← Environment variables template
├── .github/
│   └── workflows/
│       └── summary.yml                       ← GitHub Actions AI issue summarizer
├── CHANGELOG.md
├── CONTRIBUTING.md
├── CODE_OF_CONDUCT.md
├── SECURITY.md
├── LICENSE
└── README.md
```

### Key Configuration Files

| File | What It Controls |
|------|-----------------|
| [`config.js`](config.js) | **All** runtime parameters — browser, proxy, batch, form, navigation, login selectors, detection phrases, retry, output, history, queue, session, cookies, monitoring |
| [`.env.example`](.env.example) | Template for environment-variable overrides (`GUI_PORT`, `MAX_WORKERS`, `BROWSER_HEADLESS`, `LOG_LEVEL`, etc.) |
| [`docker-compose.yml`](docker-compose.yml) | Container orchestration and volume mounts |
| [`Dockerfile`](Dockerfile) | Container build instructions |

**Critical configs to review:**
- `config.batch.maxParallelWorkers` — number of concurrent browser workers
- `config.browser.headless` — visibility of browser windows
- `config.login.url` — target authentication URL
- `config.detection.*` — success/failure phrase matching

### Recommended Reading Order

1. [`README.md`](README.md) — System overview and architecture diagram
2. [`config.js`](config.js) — Understand all configurable parameters
3. [`play_version2_controller.js`](play_version2_controller.js) — How batches are scheduled and workers managed
4. [`play_version2_worker_integrated_Version5.js`](play_version2_worker_integrated_Version5.js) — Browser automation and detection flow
5. [`utils/casDetection.js`](utils/casDetection.js) — Core detection engine
6. [`utils/retryQueue.js`](utils/retryQueue.js) — Retry mechanics
7. [`utils/credentialHistory.js`](utils/credentialHistory.js) — Deduplication
8. [`gui/server.js`](gui/server.js) — Web API endpoints
9. [`tests/unit/`](tests/unit/) — How each module is tested

---

## 5. Key Components

### 5.1 [`cli.js`](cli.js) — Primary Entry Point

**Role:** Command dispatcher. Parses `argv` commands and routes to appropriate modules.

**Supported commands:**
- `menu` / _(default)_ → launches `InteractiveMenu`
- `start` → spawns controller directly
- `queue [add|list|shuffle|clear]` → combo queue management
- `import-logs` → import existing log files into history
- `stats` → print credential history statistics
- `config` / `profile [list|apply|save]` → config management via `ConfigProfiles`
- `version`, `help`

```js
// cli.js — simplified command dispatch
const command = args[0];
switch (command) {
  case 'menu':
    new InteractiveMenu().start();
    break;
  case 'start':
    spawn('node', ['play_version2_controller.js'], { stdio: 'inherit' });
    break;
  case 'queue':
    handleQueueCommand(subArgs);
    break;
  // ...
}
```

---

### 5.2 [`play_version2_controller.js`](play_version2_controller.js) — Orchestrator

**Role:** Reads credentials and proxies, splits into batches, forks worker processes, aggregates results.

**Key responsibilities:**
- Load and filter credentials via `CredentialHistory.filterCredentials()`
- Maintain a concurrency pool (max `config.batch.maxParallelWorkers` workers)
- Fork workers with `child_process.fork()`
- Receive IPC messages and route to logger/history/retryQueue
- Run multi-pass retry loop (`MAX_RETRY_PASSES = 3`)
- Save retry queue on `SIGINT`/`SIGTERM`

**IPC messages sent to workers:**
```json
{ "type": "batch_data", "credentials": [...], "proxy": "http://...", "batchNum": 1 }
```

**IPC messages received from workers:**
```json
{ "type": "credential_result", "username": "...", "password": "...", "status": "ok",
  "method": "tgc_cookie", "confidence": 0.99, "duration": 3200, "balances": {} }
```

---

### 5.3 [`play_version2_worker_integrated_Version5.js`](play_version2_worker_integrated_Version5.js) — Browser Worker

**Role:** Launches a stealth Chromium browser and tests credentials.

**Key functions:**

| Function | Description |
|----------|-------------|
| `launchBrowser(proxyUrl)` | Launch Patchright with full stealth config, locale de-CH, proxy |
| `fastFill(page, selector, text)` | 3-tier form fill: char-by-char → `page.fill()` → DOM evaluate |
| `findAndClickSubmitButton(page)` | Try CSS selectors → XPath → text → `form.submit()` → Enter key |
| `submitAndDetectCasFlow(page, u, p)` | Calls `CASDetector.submitAndDetectCasFlowOptimized()` |
| `parseAccountBalances(page)` | Extract points + CHF balance from account page DOM |
| `relaunchBrowserWithNewProxy(proxies)` | Blacklist current proxy, pick new one, restart browser |
| `forceCleanup(reason)` | Emergency close of browser context and page |
| `detectBlockOrCaptcha(page)` | Scan DOM text for block/bot/CAPTCHA phrases |

```js
// 3-tier form fill in formFill.js
async function fastFill(page, selector, text, options = {}) {
  // Tier 1: character-by-character typing with random delay
  for (const char of text) {
    await page.keyboard.type(char);
    await page.waitForTimeout(rand(typeDelayMin, typeDelayMax));
  }
  // Tier 2: fallback to page.fill()
  // Tier 3: DOM manipulation via page.evaluate()
}
```

---

### 5.4 [`utils/casDetection.js`](utils/casDetection.js) — CAS Detection Engine

**Role:** Multi-strategy authentication success/failure detection with confidence scoring.

**Class:** `CASDetector`

**Detection strategies (ranked by priority and confidence):**

| Priority | Strategy | Confidence | Signal |
|----------|----------|-----------|--------|
| 1 | OAuth Code Redirect (PRIMARY) | 99% | URL matches `supercard.ch/*.nocache.html?code=OC-XXXXXX-...` |
| 2 | CAS Ticket Redirect (SECONDARY) | 95% | URL matches `/cas/oauth2.0/callbackAuthorize?ticket=...` |
| 3 | TGC Cookie polling (TERTIARY) | 99% | `CASTGC=...` cookie set/updated during CAS navigation |
| 4 | Account Domain Navigation + DOM verify | 92% | Navigation to account domain with verified authenticated DOM state |
| 5 | HTTP Status Code (block detection) | N/A | HTTP 403/429 on CAS login endpoint → login blocked/rate-limited |

**Failure detection phrases (German, pre-normalized at module load):**
- Invalid credentials: `"Bitte überprüfen Sie Ihre Eingaben"`
- Account lock: `"Ihr Konto wurde aufgrund von zu vielen Loginversuchen temporär gesperrt"`
- Bot check: `"Wir vergewissern uns, dass wir es wirklich mit Ihnen zu tun haben"`

```js
// casDetection.js — adaptive timeout and detection event listener
const detector = new CASDetector();
const result = await detector.submitAndDetectCasFlowOptimized(page, username, password, {
  timeout: adaptiveTimeout.getTimeout(),   // p95 * 1.5 buffer
  onSuccess: (data) => adaptiveTimeout.record(data.duration)
});
// result: { ok, type, reason, confidence, detectionMethod, details, duration }
```

---

### 5.5 [`utils/retryQueue.js`](utils/retryQueue.js) — Retry Queue

**Role:** Persistent failed-credential retry management.

**Class:** `RetryQueue`  
**Storage:** `retry_queue.json` (atomic write)

```js
const queue = new RetryQueue({ maxRetries: 3, queueFile: 'retry_queue.json' });

queue.add({ username: 'u', password: 'p' }, 'timeout');
const pending = queue.getRetryablePrioritized(); // sorted by failure reason priority
queue.markSuccess({ username: 'u', password: 'p' });
queue.cleanExhausted(); // remove entries >= maxRetries
await queue.save();     // atomic write
```

**Priority ordering for retry:** `proxy/bot` → `timeout/crash` → `tunnel` → `submit` → `unknown`

---

### 5.6 [`utils/credentialHistory.js`](utils/credentialHistory.js) — Deduplication Engine

**Role:** Persistent, O(1) credential deduplication and history tracking.

**Class:** `CredentialHistory`  
**Storage:** `combo_history.jsonl` (append-only JSONL)

```js
// Key: "username\tpassword" → O(1) Map lookup
history.filterCredentials(credentials); // removes already-tested combos
history.hasSucceeded(username, password); // used by retry guard
history.record({ username, password, status: 'ok', method: 'tgc_cookie', confidence: 0.99 });
```

**Configurable skip rules:** Skip successful, failed, blocked with optional time-based retest (`failedRetestAfterDays`, `blockedRetestAfterDays`).

---

### 5.7 [`utils/logger.js`](utils/logger.js) — Structured Logger

**Role:** ANSI-colored console + JSONL file logging with metrics reporting.

**Class:** `AdvancedLogger`

**Output files:**

| File | Content |
|------|---------|
| `logs/successful/successes_YYYY-MM-DD.jsonl` | Successful logins |
| `logs/failed/failed_YYYY-MM-DD.jsonl` | Failed logins |
| `logs/blocked/blocked_YYYY-MM-DD.jsonl` | Blocked accounts |
| `logs/captcha/captcha_YYYY-MM-DD.jsonl` | CAPTCHA encounters |
| `logs/reports/` | Exported CSV/JSON reports |

```js
logger.logSuccess({ username, password, method: 'tgc_cookie', confidence: 0.99, duration: 3200 });
logger.logFailed({ username, password, reason: 'invalid_credentials' });
logger.printReport(); // final summary with stats table
```

---

### 5.8 [`gui/server.js`](gui/server.js) — Web Dashboard API

**Role:** Express REST API serving the web dashboard at port 3773.

**Port:** `process.env.PORT || 3000` (override with `GUI_PORT=3773` in `.env`)

**API prefix:** `/api/v1` and `/api` (both routed to same handlers)

**Key API groups:**

| Group | Endpoints |
|-------|-----------|
| Config | `GET/PUT /config`, `POST /config/save` |
| Controller | `GET /controller/status`, `POST /controller/start`, `stop`, `restart` |
| Logs | `GET /logs` (buffered + gzip), `GET /logs/stream` (SSE) |
| History | `GET/POST/DELETE /history`, `/history/stats`, `/history/compact`, `/history/export`, `/history/import-logs` |
| Queue | `GET/POST /queue`, `/queue/add`, `/queue/import`, `/queue/shuffle`, `/queue/pause`, `/queue/resume` |
| Cookie Exports | `GET /cookie-exports`, `GET /cookie-exports/:filename`, `DELETE /cookie-exports/:filename` |
| Health | `GET /health` |
| System | `GET /system` (OS metrics) |

---

### 5.9 [`metricsCollector.js`](metricsCollector.js) — Real-Time Metrics

**Role:** EventEmitter-based real-time metrics aggregation.

**Class:** `MetricsCollector`

**Tracked events:** `login_success`, `login_failed`, `captcha`, `blocked`, `proxy_failure`, `navigation_error`, `batch_complete`

**Computed metrics:** `successRate`, `credentialsPerMinute`, `avgResponseTime`, `errorBreakdown`, `proxyPerformance`

```js
const metrics = new MetricsCollector();
metrics.record('login_success', { username, method: 'tgc_cookie', duration: 3200 });
metrics.on('periodic_report', (report) => console.log(report));
```

---

### 5.10 [`errorRecovery.js`](errorRecovery.js) — Error Classification and Retry

**Role:** Error classification and exponential backoff retry utility.

```js
// Classify an error
const { type, isTransient, recoverable } = classifyError(error);
// type: NETWORK | TIMEOUT | BLOCKED | BOT_CHECK | NOT_FOUND | BROWSER_CRASH | UNKNOWN

// Retry with exponential backoff
const result = await retryWithBackoff(async () => {
  return await someFlakeyOperation();
}, { maxRetries: 3, logPrefix: '[Worker]' });
```

**Backoff formula:** `delay = min(base^attempt × 1000, maxBackoffDelay)` (defaults: `base=1`, `maxBackoffDelay=30000ms`)

---

### 5.11 [`utils/sessionManager.js`](utils/sessionManager.js) — Session Persistence

**Role:** Save and restore Playwright context cookies to skip re-authentication.

**Storage:** `sessions/{sanitized_username}.json`  
**Default TTL:** 24 hours

```js
const session = new SessionManager();
await session.saveSession(username, context); // after successful login
const valid = await session.hasValidSession(username);
if (valid) await session.loadSession(username, context); // restore cookies
```

---

### 5.12 [`utils/adaptiveTimeout.js`](utils/adaptiveTimeout.js) — Dynamic Timeout Tuner

**Role:** Dynamically adjust detection timeout based on observed success timings.

**Algorithm:** Track last 20 successful detection durations → compute p95 → multiply by 1.5× buffer → clamp to minimum 3000ms.

---

## 6. Execution and Data Flows

### 6.1 Main Credential Testing Flow

```mermaid
sequenceDiagram
    participant User
    participant CLI as cli.js
    participant Ctrl as Controller
    participant Hist as CredentialHistory
    participant Worker as Worker Process
    participant Browser as Chromium (Patchright)
    participant Target as login.supercard.ch
    participant Logger as AdvancedLogger

    User->>CLI: npm start
    CLI->>Ctrl: spawn play_version2_controller.js

    Ctrl->>Ctrl: Load config.js, init Logger, RetryQueue, CredentialHistory
    Ctrl->>Ctrl: Read test.txt → credentials[]
    Ctrl->>Hist: filterCredentials() — remove already-tested
    Ctrl->>Ctrl: Read Lightning_Proxies.txt → proxies[]
    Ctrl->>Ctrl: Split credentials into batches

    loop For each batch (up to maxParallelWorkers concurrent)
        Ctrl->>Worker: fork() + IPC: batch_data { credentials, proxy }

        Worker->>Worker: Validate proxy via TCP check
        Worker->>Browser: launchBrowser(proxyUrl)

        loop For each credential in batch
            Worker->>Worker: Check sessionManager.hasValidSession()
            alt Session valid
                Worker->>Browser: loadSession() — restore cookies
            else No session
                Worker->>Browser: navTo(login.url)
                Worker->>Browser: dismissCookieBanner()
                Worker->>Browser: fastFill(username) — char-by-char
                Worker->>Browser: fastFill(password) — char-by-char
                Worker->>Browser: findAndClickSubmitButton()
            end

            Browser->>Target: POST credentials
            Target-->>Browser: Response (redirect / error page)

            Worker->>Worker: submitAndDetectCasFlowOptimized()
            Note over Worker: Monitors cookies, URL, body for success signals

            alt Authentication succeeded
                Worker->>Worker: parseAccountBalances()
                Worker->>Worker: sessionManager.saveSession()
                Worker->>Worker: cookieExporter.capture()
                Worker->>Ctrl: IPC: credential_result { status: ok, method, confidence }
                Ctrl->>Logger: logSuccess()
                Ctrl->>Hist: record(ok)
            else Authentication failed
                Worker->>Ctrl: IPC: credential_result { status: failed/blocked/captcha }
                Ctrl->>Logger: logFailed/logBlocked/logCaptcha()
                Ctrl->>Hist: record(status)
                Ctrl->>Ctrl: retryQueue.add(credential, reason)
            end
        end

        Worker->>Ctrl: IPC: batch_complete
    end

    loop Retry passes (MAX_RETRY_PASSES = 3)
        Ctrl->>Ctrl: retryQueue.getRetryablePrioritized()
        Ctrl->>Hist: filter out hasSucceeded()
        Ctrl->>Worker: fork() retry batches
        Ctrl->>Ctrl: retryQueue.cleanExhausted()
    end

    Ctrl->>Logger: printReport() — final summary
```

### 6.2 GUI Data Flow

```
User Browser → http://localhost:3773
    ↓
gui/server.js → serves gui/public/index.html (SPA)
    ↓
Frontend polls:
    GET /api/v1/status     → controller process info + system metrics
    GET /api/v1/logs       → buffered log lines (gzip, paginated)
    GET /api/v1/logs/stream → Server-Sent Events (SSE) for real-time updates
    ↓
POST /api/v1/controller/start → server.js spawns controller via child_process.spawn()
Controller stdout/stderr → logBuffer (max 2000 entries)
    ↓
History/Queue management via REST endpoints backed by CredentialHistory + ComboQueue instances
```

### 6.3 IPC Protocol (Controller ↔ Worker)

**Controller → Worker:**
```json
{ "type": "batch_data", "credentials": [{"username":"u","password":"p"}],
  "proxy": "http://user:pass@host:port", "batchNum": 1 }
```

**Worker → Controller:**
```json
{ "type": "credential_result", "username": "u", "password": "p",
  "status": "ok", "method": "tgc_cookie", "confidence": 0.99,
  "duration": 3200, "balances": { "points": 1234, "chf": 12.34 } }

{ "type": "worker_log", "level": "info", "prefix": "[WORKER]", "message": "..." }

{ "type": "batch_complete", "batchNum": 1, "processed": 10, "duration": 45000, "status": "done" }

{ "type": "proxy_blacklist", "proxy": "http://...", "reason": "bot_check_triggered" }

{ "type": "session_saved", "username": "u" }
```

### 6.4 Data Persistence Map

```mermaid
flowchart LR
    Worker -->|append| hist[combo_history.jsonl]
    Worker -->|atomic write| retry[retry_queue.json]
    Worker -->|atomic write| queue[combo_queue.json]
    Worker -->|write| sessions["sessions/{username}.json"]
    Worker -->|write| cookies["CookieExports/{user}_{ts}.json"]
    Worker -->|append| logs["logs/{category}/YYYY-MM-DD.jsonl"]
```

---

## 7. Dependencies and Integrations

### 7.1 Runtime Dependencies

| Package | Version | Role | Used In |
|---------|---------|------|---------|
| `patchright` | `^1.48.2` | Stealth Playwright fork — Chromium automation | [`play_version2_worker_integrated_Version5.js`](play_version2_worker_integrated_Version5.js) |
| `proxy-chain` | `^2.5.4` | HTTP/SOCKS proxy → local TCP tunnel | worker |
| `express` | `^4.22.1` | REST API web server | [`gui/server.js`](gui/server.js) |
| `chalk` | `^4.1.2` | Terminal colors | [`utils/logger.js`](utils/logger.js), [`utils/enhancedConsole.js`](utils/enhancedConsole.js) |
| `boxen` | `^5.1.2` | Bordered terminal boxes | `metricsCollector.js`, `utils/progressDashboard.js` |
| `cli-progress` | `^3.12.0` | Multi-bar progress indicators | `utils/logger.js`, `utils/progressDashboard.js` |
| `ora` | `^5.4.1` | Terminal spinners | `utils/interactiveCLI.js` |
| `inquirer` | `^8.2.6` | Interactive CLI prompts | `utils/interactiveMenu.js`, `utils/interactiveCLI.js` |

### 7.2 Development Dependencies

| Package | Version | Role |
|---------|---------|------|
| `jest` | `^29.7.0` | Test runner with coverage |
| `supertest` | `^6.3.4` | HTTP testing for Express |
| `@types/jest` | `^29.5.14` | IDE TypeScript types for Jest |

### 7.3 External System Integrations

| System | URL | How |
|--------|-----|-----|
| **Supercard.ch CAS** | `https://login.supercard.ch/` | Browser automation via Patchright |
| **Supercard.ch account** | `https://www.supercard.ch/de/mein-konto.html` | Balance scraping after login |
| **Proxy providers** | `Lightning_Proxies.txt` | HTTP/HTTPS/SOCKS proxy rotation |
| **Discord / Slack** | Configurable webhook URL | Optional batch-completion notifications |
| **GitHub Actions** | `.github/workflows/summary.yml` | AI issue summaries via `actions/ai-inference@v1` |
| **Prometheus** | Port 9091 (Docker monitoring profile) | Optional metrics scraping |
| **Grafana** | Port 3000 (Docker monitoring profile) | Optional metrics visualization |

### 7.4 API Documentation

The web GUI exposes a REST API documented in [`docs/API.md`](docs/API.md).

**API base URL:** `http://localhost:3773/api/v1`

**Key endpoints example:**
```
GET  /api/v1/health          → { status: "ok", uptime, memory }
GET  /api/v1/status          → { controller: { running, pid, ... }, system: { cpu, mem } }
POST /api/v1/controller/start → start credential testing
GET  /api/v1/logs?limit=100  → last N log lines (gzip-compressed)
GET  /api/v1/logs/stream      → SSE stream of real-time logs
GET  /api/v1/history/stats    → credential history statistics
```

No OpenAPI/Swagger spec is currently generated; documentation is manual in [`docs/API.md`](docs/API.md).

---

## 8. Diagrams

### 8.1 Component Diagram

```mermaid
graph TB
    subgraph CLI["Entry Layer"]
        A[cli.js] --> B[InteractiveMenu]
        A --> C[ConfigProfiles]
        A --> D[ComboQueue CLI]
    end

    subgraph Core["Core Engine"]
        E[play_version2_controller.js\nOrchestrator] -->|fork + IPC| F
        F[play_version2_worker_integrated_Version5.js\nBrowser Worker]
        F --> G[formFill.js]
        F --> H[errorRecovery.js]
        F --> I[metricsCollector.js]
    end

    subgraph Utils["Utility Layer"]
        J[utils/casDetection.js\nCASDetector]
        K[utils/retryQueue.js\nRetryQueue]
        L[utils/credentialHistory.js\nCredentialHistory]
        M[utils/logger.js\nAdvancedLogger]
        N[utils/sessionManager.js\nSessionManager]
        O[utils/cookieExporter.js\nCookieExporter]
        P[utils/comboQueue.js\nComboQueue]
        Q[utils/adaptiveTimeout.js\nAdaptiveTimeout]
        R[utils/fileHelper.js\nAtomic I/O]
    end

    subgraph GUI["Web Dashboard"]
        S[gui/server.js\nExpress API :3773]
        T[gui/public/index.html\nSPA Frontend]
    end

    subgraph Storage["Local File Storage"]
        U[(combo_history.jsonl)]
        V[(retry_queue.json)]
        W[(combo_queue.json)]
        X[(sessions/*.json)]
        Y[(logs/*.jsonl)]
        Z[(CookieExports/*.json)]
    end

    subgraph External["External Systems"]
        AA[login.supercard.ch\nCAS / OAuth2]
        BB[Proxy Network\nLightning_Proxies.txt]
        CC[Discord/Slack\nWebhook]
    end

    A --> E
    E --> K
    E --> L
    E --> M
    F --> J
    F --> N
    F --> O
    J --> Q
    K --> R
    L --> R
    N --> R
    O --> R
    P --> R
    R --> U & V & W & X & Y & Z
    F -->|HTTP via Patchright| AA
    F -->|proxy-chain| BB
    E -->|optional| CC
    S --> L
    S --> P
    S --> O
    T --> S
```

### 8.2 Data Flow Diagram

```mermaid
flowchart LR
    A[test.txt\ncredentials] -->|read| B[Controller]
    C[Lightning_Proxies.txt\nproxies] -->|read| B

    B -->|filter duplicates| D[(combo_history.jsonl)]
    B -->|batch + IPC| E[Worker Process]

    E -->|proxy-chain tunnel| F[Proxy]
    F -->|HTTPS| G[login.supercard.ch]

    G -->|CAS/OAuth response| E
    E -->|detect TGC/ticket/code| H{Auth Result?}

    H -->|success| I[parseAccountBalances\nsaveSession\nexportCookies]
    H -->|failed/blocked| J[retryQueue.add()]
    H -->|captcha| K[report CAPTCHA]

    I -->|IPC: credential_result ok| B
    J -->|IPC: credential_result failed| B
    K -->|IPC: credential_result captcha| B

    B -->|record| D
    B -->|log| L[(logs/successful/\nlogs/failed/\nlogs/blocked/)]
    I -->|write| M[(sessions/*.json)]
    I -->|write| N[(CookieExports/*.json)]
    J -->|write| O[(retry_queue.json)]
```

### 8.3 CAS Detection Decision Tree

```mermaid
flowchart TD
    A[Form Submitted] --> B{OAuth Code\nsupercard.ch?code=OC-}
    B -->|YES 99%| Z[✅ SUCCESS]
    B -->|NO| C{CAS Ticket\nURL redirect?}
    C -->|YES 95%| Z
    C -->|NO| D{TGC Cookie\nCASTGC= polling?}
    D -->|YES 99%| Z
    D -->|NO| E{Account domain\nnavigation + DOM verify?}
    E -->|YES 92%| Z
    E -->|NO| F{HTTP 403/429\non CAS endpoint?}
    F -->|YES| X[🔒 BLOCKED/RATE-LIMITED]
    F -->|NO| H{Invalid creds\nphrase in DOM?}
    H -->|YES| Y[❌ FAILED]
    H -->|NO| I{Account lock\nphrase?}
    I -->|YES| X2[🔒 BLOCKED]
    I -->|NO| J{Bot/CAPTCHA\nphrase?}
    J -->|YES bot| W[🤖 BOT_CHECK]
    J -->|YES captcha| V[🔐 CAPTCHA]
    J -->|Timeout| U[⏱ TIMEOUT → retry]
```

### 8.4 Simplified Deployment Diagram

```mermaid
graph TB
    subgraph Host["Host Machine / Docker"]
        subgraph App["superrmurrer container\n(node:18-alpine + Chromium)"]
            CLI[cli.js / Controller\n:3773 GUI API]
            W1[Worker 1\nChromium]
            W2[Worker 2\nChromium]
            Wn[Worker N\nChromium]
        end

        subgraph Monitoring["monitoring profile (optional)"]
            Prom[Prometheus\n:9091]
            Graf[Grafana\n:3000]
        end

        subgraph Volumes["Mounted Volumes"]
            TV[test.txt :ro]
            PV[Lightning_Proxies.txt :ro]
            LV[logs/ :rw]
            SV[sessions/ :rw]
            ScV[screenshots/ :rw]
        end
    end

    Internet[Internet\nvia Proxy]

    CLI --> W1 & W2 & Wn
    W1 & W2 & Wn -->|proxy-chain| Internet
    Internet --> Target[login.supercard.ch]

    App --> Volumes
    App --> Monitoring
```

---

## 9. Testing

### Test Framework

- **Jest 29** with Node.js test environment
- **supertest** for HTTP assertion testing of Express endpoints
- No live browser or network calls in automated tests (all mocked)

### Running Tests

```bash
# All tests with coverage report
npm test

# Unit tests only
npm run test:unit

# Watch mode (re-run on file changes)
npm run test:watch
```

### Test Structure

```
tests/
├── unit/                          ← 32 Jest test files
│   ├── adaptiveTimeout.test.js
│   ├── autoRecovery.test.js
│   ├── balanceParsing.test.js
│   ├── casDetection.test.js       ← Most comprehensive: 900+ lines
│   ├── comboQueue.test.js
│   ├── config.test.js
│   ├── configApplier.test.js
│   ├── configHelper.test.js
│   ├── configProfiles.test.js
│   ├── configValidator.test.js
│   ├── connectionPool.test.js
│   ├── cookieExporter.test.js
│   ├── credentialHistory.test.js
│   ├── dataDomeSolver.test.js
│   ├── enhancedConsole.test.js
│   ├── errorRecovery.test.js
│   ├── fileHelper.test.js
│   ├── formFill.test.js
│   ├── formSubmit.test.js
│   ├── guiServer.test.js          ← Builds a mock Express app
│   ├── guiServer2.test.js         ← Imports the real gui/server.js
│   ├── healthCheck.test.js
│   ├── logger.test.js
│   ├── loggerPerformance.test.js
│   ├── metricsCollector.test.js
│   ├── mouseMovement.test.js
│   ├── progressDashboard.test.js
│   ├── resourceManager.test.js
│   ├── retryQueue.test.js
│   ├── sessionManager.test.js
│   ├── sessionState.test.js
│   └── workflowManager.test.js
├── integration/
│   ├── completeWorkflow.test.js   ← End-to-end workflow tests
│   └── workflow.test.js
├── adaptiveTimeout.test.js        ← Legacy root-level tests
├── backoff.test.js
├── blacklistTTL.test.js
└── detectionImprovements.test.js
```

### Coverage Configuration

Defined in [`package.json`](package.json) `jest` section:

```json
{
  "collectCoverageFrom": [
    "errorRecovery.js", "formFill.js", "metricsCollector.js", "config.js",
    "utils/**/*.js", "gui/server.js"
  ],
  "coverageThreshold": {
    "global": { "branches": 70, "functions": 70, "lines": 70, "statements": 70 }
  }
}
```

**Excluded from coverage:** `utils/projectTracker.js`, `utils/interactiveMenu.js`, `utils/interactiveCLI.js`, `cli.js`

### CI Testing Strategy

The current GitHub Actions workflow ([`.github/workflows/summary.yml`](.github/workflows/summary.yml)) only covers AI issue summarization. There is no automated CI pipeline running `npm test` on PRs — tests must be run locally before submitting PRs.

---

## 10. Error Handling and Logging

### Error Classification ([`errorRecovery.js`](errorRecovery.js))

```js
const { type, isTransient, recoverable } = classifyError(error);
```

| Type | Trigger Keywords | Transient | Recoverable |
|------|-----------------|-----------|-------------|
| `NETWORK` | `tunnel`, `proxy`, `ECONNREFUSED` | ✅ | ✅ |
| `TIMEOUT` | `timeout`, `timed out` | ✅ | ✅ |
| `BLOCKED` | `blocked`, `401`, `403` | ❌ | ❌ |
| `BOT_CHECK` | `roboter`, `bot verification` | ✅ | ✅ |
| `NOT_FOUND` | `404`, `not found` | ❌ | ❌ |
| `BROWSER_CRASH` | `crash`, `closed` | ✅ | ✅ |
| `UNKNOWN` | (default) | ❌ | ❌ |

### Retry Strategy

- **Exponential backoff** per-operation: `delay = min(base^attempt × 1000, 30000ms)`
- **RetryQueue** for credential-level retries: up to `maxRetries=3` per credential
- **Multi-pass controller loop:** `MAX_RETRY_PASSES = 3` at the orchestration level
- **Priority ordering:** proxy/bot failures retried first

### Process Resilience

| Scenario | Behavior |
|----------|----------|
| Worker crash (unexpected exit) | Controller detects exit; adds all unprocessed credentials to retry queue |
| `SIGINT` / `SIGTERM` | Controller saves retry queue; worker drains remaining credentials before exiting |
| Corrupted state file | Backup with timestamp suffix, start fresh |
| All atomic writes | Temp file → rename to prevent partial writes |

### Logging

**Logger class:** `AdvancedLogger` in [`utils/logger.js`](utils/logger.js)

**Log levels:** `debug (0)` → `info (1)` → `warn (2)` → `error (3)`

**Console format:** ANSI-colored with icons, timestamps, worker prefixes

**File format (JSONL):**
```json
{"timestamp":"2026-03-04T18:00:00.000Z","username":"u@example.com","status":"ok","method":"tgc_cookie","confidence":0.99,"duration":3241,"batchNum":1}
```

**Performance:** `prettyPrint=false` by default for high-throughput JSONL serialization. `cleanupSync()` called on `process.on('exit')` to ensure log flush.

**No external monitoring integration** (Datadog, Sentry, etc.) is currently wired in, though Prometheus + Grafana are available via the Docker Compose monitoring profile.

---

## 11. Security Considerations

### Intended Use

> This tool is **only** for authorized security testing, penetration testing with signed contracts, and educational purposes in controlled environments. Unauthorized use may violate CFAA, Computer Misuse Act, and equivalent laws.

### Authentication and Authorization

| Concern | Status |
|---------|--------|
| GUI authentication | ❌ **Not implemented** — GUI has no auth. Expose only on localhost or behind an authenticated reverse proxy |
| API rate limiting | ✅ Tiered per-IP limits on `/api/` routes: 5 req/min for controller spawn (`POST /controller/start`), 30 req/min for writes (POST/PUT/DELETE), 120 req/min for reads (GET) |
| JWT/session auth | 🚧 Planned (placeholder in `.env.example`) |
| RBAC | 🚧 Listed as planned enhancement |

### Input Validation

| Area | Mechanism |
|------|-----------|
| Credential parser | Validates non-empty username/password; skips `#`-prefixed comment lines |
| Combo queue | Validates priority 1–5, file existence, colon delimiter |
| Config | `ConfigValidator` module validates schema at startup |
| Path traversal | `readExport()` in `cookieExporter.js` uses `path.basename()` to sanitize filenames |

### Sensitive Data Handling

| Data | Storage | Risk |
|------|---------|------|
| `test.txt` | Plaintext | Restrict with `chmod 600` |
| `combo_history.jsonl` | Cleartext credentials | Restrict directory permissions |
| `sessions/*.json` | Plaintext cookies | Treat as secrets |
| `CookieExports/*.json` | Plaintext cookies + Python snippet | Restrict access |
| Proxy credentials | In `Lightning_Proxies.txt` and browser args | Never commit; add to `.gitignore` |

### Secrets Management

- `.env` file excluded from git via [`.gitignore`](.gitignore)
- `.env.example` provided as safe template
- `test.txt` and `Lightning_Proxies.txt` excluded from git

### Browser Security Flags

```js
// Intentional flags for proxy compatibility (known trade-offs):
bypassCSP: true,
ignoreHTTPSErrors: true,
args: ['--no-sandbox', '--disable-setuid-sandbox'] // required in Docker
```

### Docker Security

- Runs as non-root user `appuser` (uid 1001)
- `--no-sandbox` is a known security trade-off required for containerized Chromium
- HTTP only (not HTTPS) — should be placed behind an authenticated reverse proxy for external access

### Planned Security Enhancements (from SECURITY.md)

- Credential encryption at rest
- Certificate pinning for webhooks
- Two-factor authentication
- Audit logging
- Encrypted log storage
- API key management
- Role-based access control

---

## 12. Other Relevant Observations (Build / Deploy)

### Build Process

No build step — plain CommonJS JavaScript. Direct node execution.

```bash
npm install          # Install production + dev dependencies
npm test             # Run Jest tests with coverage
npm start            # Launch application
```

### Docker Deployment

**Multi-stage [`Dockerfile`](Dockerfile):**
1. **Stage 1** (`node:18-alpine` builder): install production dependencies
2. **Stage 2** (`node:18-alpine` runtime): copy app + node_modules, install Chromium system deps

**System packages installed:** `chromium`, `nss`, `freetype`, `harfbuzz`, `ca-certificates`, `ttf-freefont`

**Build and run:**
```bash
# Build image
docker build -t superrmurrer .

# Run with docker-compose (creates all volume mounts)
docker-compose up superrmurrer

# With optional Prometheus + Grafana monitoring
docker-compose --profile monitoring up
```

**[`docker-compose.yml`](docker-compose.yml) services:**

| Service | Port | Profile | Description |
|---------|------|---------|-------------|
| `superrmurrer` | `3773` | default | Main application |
| `prometheus` | `9091:9090` | monitoring | Metrics collection |
| `grafana` | `3000:3000` | monitoring | Metrics visualization |

**Volume mounts (app service):**

| Host Path | Container Path | Mode |
|-----------|---------------|------|
| `./test.txt` | `/app/test.txt` | ro |
| `./Lightning_Proxies.txt` | `/app/Lightning_Proxies.txt` | ro |
| `./logs` | `/app/logs` | rw |
| `./sessions` | `/app/sessions` | rw |
| `./screenshots` | `/app/screenshots` | rw |

**Docker health check:**
```bash
node -e "require('http').get('http://localhost:3773/health', (r) => process.exit(r.statusCode === 200 ? 0 : 1))"
```

### CI/CD (`.github/workflows/`)

Currently only one workflow:

**[`.github/workflows/summary.yml`](.github/workflows/summary.yml)** — Triggered on `issues: [opened]`:
1. Uses `actions/ai-inference@v1` to generate a one-paragraph issue summary
2. Posts the summary as a comment on the issue

> **Note:** There is no automated test or lint CI pipeline on PRs. Tests must be run locally (`npm test`) before submitting PRs.

### Known Technical Notes and Gotchas

| Item | Detail |
|------|--------|
| **Worker filename versioning** | `play_version2_worker_integrated_Version5.js` — do not rename without updating the `fork()` call in the controller |
| **config.js is not env-driven** | Edit directly or use `node cli.js profile apply <name>` for predefined profiles |
| **`combo_history.jsonl` stores plaintext** | Secure the working directory carefully |
| **Humorous output filename** | `config.output.failedFile` is `'ichfiggdinimueter.txt'` (Swiss German slang) — safe to rename |
| **GUI has no authentication** | Expose only on `localhost` or behind an authenticated proxy |
| **`patchright` vs `playwright`** | Always `require('patchright')` — the stealth patches are critical for avoiding detection |
| **`--no-sandbox` in Docker** | Required for containerized Chromium; removes Chrome's sandbox isolation |
| **`test.txt` and proxies file** | Excluded from git — must be created locally or mounted via Docker volumes |
| **GUI port default mismatch** | `server.js` uses `process.env.PORT \|\| 3000` but `.env.example` sets `GUI_PORT=3773` — ensure `PORT=3773` is set in `.env` |
| **Session TTL** | Default 24h; sessions older than this are cleaned up on startup |

### Performance Profiles

Apply predefined profiles via CLI:
```bash
node cli.js profile list     # List available profiles
node cli.js profile apply fast     # Maximum speed (8 workers, headless)
node cli.js profile apply balanced # Recommended (4 workers, moderate delays)
node cli.js profile apply stealth  # Maximum stealth (2 workers, human-like)
```

---

*This document was generated on 2026-03-04 from source code analysis of [SuPerrMurrer v2.0.0](https://github.com/Lumbijumbi/SuPerrMurrer).*
