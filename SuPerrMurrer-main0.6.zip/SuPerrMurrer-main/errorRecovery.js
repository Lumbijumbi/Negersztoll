/**
 * Error recovery utilities with exponential backoff
 */
const config = require('./config');

/**
 * Exponential backoff calculator
 * @param {number} attempt - Current attempt number (0-indexed)
 * @returns {number} - Delay in milliseconds
 */
function calculateBackoffDelay(attempt) {
  const {
    exponentialBackoff,
    backoffBase,
    maxBackoffDelay
  } = config.errorRecovery.retryStrategies;

  if (!exponentialBackoff) {
    return 1000; // Default 1 second
  }

  const delay = Math.pow(backoffBase, attempt) * 1000;
  return Math.min(delay, maxBackoffDelay);
}

/**
 * Retry async function with exponential backoff
 * @param {Function} fn - Async function to retry
 * @param {Object} options - Retry options
 * @returns {Promise<*>} - Function result
 */
async function retryWithBackoff(fn, options = {}) {
  const {
    maxRetries = config.errorRecovery.maxRetries,
    onRetry = null,
    shouldRetry = null,
    logPrefix = '[Retry]',
    verbose = false
  } = options;

  let lastError = null;

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      if (verbose) console.log(`${logPrefix} Attempt ${attempt + 1}/${maxRetries}`);
      return await fn();
    } catch (error) {
      lastError = error;
      const isTransient = error.message.includes('timeout') ||
                         error.message.includes('temporarily') ||
                         error.message.includes('ECONNREFUSED') ||
                         error.message.includes('tunnel');

      // Check if we should retry
      if (shouldRetry && !shouldRetry(error, attempt)) {
        throw error;
      }

      if (attempt < maxRetries - 1) {
        const delay = calculateBackoffDelay(attempt);
        console.warn(`${logPrefix} Attempt ${attempt + 1} failed: ${error?.message}`);
        console.log(`${logPrefix} Retrying after ${delay}ms (attempt ${attempt + 2}/${maxRetries})...`);

        if (onRetry) {
          await onRetry(error, attempt, delay);
        }

        await new Promise(r => setTimeout(r, delay));
      }
    }
  }

  throw lastError || new Error('Max retries exceeded');
}

/**
 * Classify error type for better handling
 */
function classifyError(error) {
  const msg = error?.message?.toLowerCase() || '';

  if (msg.includes('tunnel') || msg.includes('proxy') || msg.includes('econnrefused')) {
    return {
      type: 'NETWORK',
      category: 'tunnel_or_proxy',
      isTransient: true,
      recoverable: true
    };
  }

  if (msg.includes('timeout') || msg.includes('timed out')) {
    return {
      type: 'TIMEOUT',
      category: 'timeout',
      isTransient: true,
      recoverable: true
    };
  }

  if (msg.includes('blocked') || msg.includes('401') || msg.includes('403')) {
    return {
      type: 'BLOCKED',
      category: 'authentication',
      isTransient: false,
      recoverable: false
    };
  }

  if (msg.includes('roboter') || msg.includes('bot verification') || msg.includes('bot_check')) {
    return {
      type: 'BOT_CHECK',
      category: 'bot_verification',
      isTransient: true,
      recoverable: true
    };
  }

  if (msg.includes('404') || msg.includes('not found')) {
    return {
      type: 'NOT_FOUND',
      category: 'http_error',
      isTransient: false,
      recoverable: false
    };
  }

  if (msg.includes('crash') || msg.includes('closed')) {
    return {
      type: 'BROWSER_CRASH',
      category: 'browser',
      isTransient: true,
      recoverable: true
    };
  }

  return {
    type: 'UNKNOWN',
    category: 'unknown',
    isTransient: false,
    recoverable: false
  };
}

module.exports = {
  calculateBackoffDelay,
  retryWithBackoff,
  classifyError
};