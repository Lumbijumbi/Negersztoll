# Changelog

All notable changes to SuPerrMurrer documentation and features.

## [0.50Alpha] - 2026-04-08

### Performance — Six Non-Breaking Utils Layer Optimizations (PR [#158](https://github.com/Lumbijumbi/SuPerrMurrer/pull/158))

Six surgical, non-breaking performance improvements targeting high-frequency hot paths in the `utils/` layer at 16-worker scale. No public APIs, IPC message formats, config keys, or logging side-effects changed.

#### Fix 1 — `utils/credentialHistory.js`: Eliminate Blocking Disk Writes

- **Problem**: `fs.appendFileSync` on every `record()` call blocked the event loop ~960×/min at 16-worker scale
- **Solution**:
  - Replaced synchronous file appends with lazy `fs.createWriteStream(path, { flags: 'a' })`
  - Added module-level `_activeInstances` Set with single shared `process.on('exit')` listener to prevent `MaxListenersExceededWarning` when multiple instances are created
  - Implemented `_pendingLines[]` array tracking — each `record()` pushes the line before async stream write and removes it in callback
  - `cleanupSync()` flushes remaining `_pendingLines` via `fs.appendFileSync` before stream destruction, ensuring buffered writes survive abrupt shutdown (mirrors `logger.js` pattern)
  - `compact()` clears `_pendingLines` and closes stream before file rewrite to avoid stale handles
  - Disabled instances never write data and never register exit handlers
- **Impact**: Eliminates ~960 blocking disk writes/min from event loop; buffered writes survive abrupt process exit

#### Fix 2 — `utils/casDetection.js`: Reduce Expensive DOM Text Extraction

- **Problem**: `document.body.innerText` forced full layout recalculation every 600ms × 16 workers
- **Solution**:
  - Replaced with targeted error-selector query: `.alert.alert-danger`, `.error`, `[role="alert"]`, `#error`, `.login-error`, `.errorMessage`
  - Falls back to `textContent` (no layout recalculation, ~10× faster than `innerText`) limited to first 2000 chars
  - JS-side normalization retained for backward compatibility with test mocks
- **Impact**: Eliminates full layout recalculation on every CAS early-failure check

#### Fix 3 — `utils/retryQueue.js`: Fix Silent Credential Overwrites

- **Problem**: Map keyed by username only — same username + different password silently overwrites retry count
- **Solution**:
  - Introduced `_key(username, password)` → `username\tpassword` composite key (consistent with `credentialHistory.js`)
  - Updated `add()`, `isMaxRetriesReached()`, `markSuccess()`, `load()` to use composite key
  - Added backward-compat username-only scan for callers that don't pass `password`
  - `load()` logs warning for legacy entries missing `password` field instead of silently dropping them
- **Impact**: Prevents retry-count collisions for same username with different passwords

#### Fix 4 — `utils/connectionPool.js`: O(n) → O(1) Proxy-Filtered Acquire

- **Problem**: `acquire(proxy)` iterated entire `available` Set — O(n) with lock contention under concurrent workers
- **Solution**:
  - Added `this._proxyIndex = new Map()` (proxy string → `Set<connectionId>`)
  - `acquire()` now iterates `_proxyIndex.get(proxy)` instead of full `available` Set
  - Index maintained in `createConnection`, `removeConnection` (prunes empty proxy keys), `closeAll`
- **Impact**: O(n) → O(1) proxy-filtered acquire; reduces lock contention at multi-worker scale

#### Fix 5 — `utils/adaptiveTimeout.js`: Cache Timeout Calculation

- **Problem**: `getTimeout()` spread + sorted `successTimings` array on every credential processed
- **Solution**:
  - Added `_cachedTimeout` and `_dirty` flag
  - `recordSuccess()` sets `_dirty = true`
  - `getTimeout()` returns cached value when `!_dirty`; recomputes, caches, and clears flag otherwise
  - `getStats()` unchanged — always computes from full sorted array
- **Impact**: Eliminates array spread+sort on every credential attempt

#### Fix 6 — `utils/sessionManager.js`: Cache Session Validation

- **Problem**: `hasValidSession()` called `fs.readFileSync` + `JSON.parse` before every login attempt
- **Solution**:
  - Added `_cache = new Map()` with `_cacheTTL = 30000` (30s)
  - `hasValidSession()` checks cache first; on miss reads from disk and populates cache
  - Added `_computeSessionExpiry()` helper — cache `expiresAt` set to `Math.min(now + _cacheTTL, sessionExpiryMs)` so near-expiry sessions are never served as valid past their actual expiry time
  - Cache invalidated immediately in `saveSession()` (after successful write) and `deleteSession()`
- **Impact**: Eliminates `readFileSync` + `JSON.parse` before every login attempt; cache TTL capped at actual session expiry to prevent stale results

#### Tests

All 7 directly affected test suites pass (292 tests): `retryQueue`, `credentialHistory`, `adaptiveTimeout`, `sessionManager`, `connectionPool`, `blockDetectionRespawn`, `casDetection`.

Test mocks updated:
- `tests/unit/credentialHistory.test.js`: mock `fs.createWriteStream` with writable mock stream; assertions expect 3-arg `stream.write(data, encoding, callback)` form; explicit `not.toHaveBeenCalled()` for disabled-recording path

#### Notes

- Session cache TTL (30s) is intentionally conservative — sessions valid for 24h, worst-case cross-worker lag is 30s
- `credentialHistory` write stream backpressure intentionally not handled — write volume (~960/min) well within Node.js stream buffer limits
- Module-level `_activeInstances` singleton pattern means only one `process.on('exit')` listener registered regardless of instance count

## [2.5.0] - 2026-04-03

### Fixed — Chrome "automatisierte Testsoftware" Warning (Complete Stealth Mode)

- **`config.js`** — Added `--exclude-switches=enable-automation`, `--no-service-autorun`,
  `--no-default-browser-check`, `--use-mock-keychain`,
  `--disable-component-extensions-with-background-pages`, and `--disable-plugins-discovery` to
  `browser.args`. These flags complete the suppression of Chrome's automation-detection infobar
  ("Chrome wird von automatisierter Testsoftware gesteuert").

- **`config.js`** — Added `browser.ignoreDefaultArgs` array containing `--enable-automation` and
  `--enable-blink-features=IdleDetection`. Patchright passes these flags by default; excluding them
  is required for full stealth-mode compliance.

- **`play_version2_worker_integrated_Version5.js`** — Passed `ignoreDefaultArgs` from
  `config.browser.ignoreDefaultArgs` to `chromium.launchPersistentContext()` so the
  `--enable-automation` switch is never injected by Patchright even after a crash relaunch.

- **`play_version2_worker_integrated_Version5.js`** — Added `context.addInitScript()` immediately
  after browser launch. The script sets `navigator.webdriver` to `undefined` and removes
  `chrome.runtime.onConnect` / `onMessage` so that detection-fingerprinting scripts cannot observe
  automation signals via JavaScript.

- **`play_version2_worker_integrated_Version5.js`** — Extended `crashRecoveryArgs` with the same
  new stealth flags so they are always guaranteed even after a browser crash-relaunch.

## [2.4.0] - 2026-04-03

### Fixed — Cloudflare/DataDome Automation Detection

- **`config.js`** — Added missing anti-detection Chrome flags to `browser.args`:
  `--disable-blink-features=AutomationControlled`, `--disable-web-security`,
  `--disable-ipc-flooding-protection`, `--disable-renderer-backgrounding`,
  `--disable-backgrounding-occluded-windows`, `--disable-field-trial-config`.
  These flags suppress the automation-detection signals that Cloudflare and DataDome use to
  fingerprint headless/automated browsers (the "Chrome wird von automatisierter Testsoftware
  gesteuert" notification and behavioural blocking).

- **`play_version2_worker_integrated_Version5.js`** — Added the same anti-detection flags to
  `crashRecoveryArgs` so they are always injected even after a browser relaunch where the
  `config.browser.args` array is rebuilt from scratch.

- **`docs/TRAFFIC_OPTIMIZATION.md`** — Updated Resource Blocking section with a prominent
  warning: `enabled: false` must remain permanent; the `page.route()` handler was already removed
  (v2.1.0 PR #112) because it disrupts Patchright's stealth injection chain. Replaced the
  "Advanced: Custom Resource Blocking" code example with a warning explaining why adding any
  `page.route()` call will re-introduce DataDome detection.

- **`docs/implementation/TRAFFIC_OPTIMIZATION_SUMMARY.md`** — Updated "Disable" section to
  reflect the permanent disabled state and explain the DataDome rationale.

## [2.3.0] - 2026-03-23

### Added

#### Reverify — Manual Browser Verification (New)
- **`gui/server.js`** — New `POST /api/reverify` endpoint launches a visible browser window,
  navigates to the login page, dismisses cookie popups, and fills in the username and password
  fields — but does NOT click the Login button. The browser window stays open indefinitely for
  the user to manually click Login and inspect the result. Uses a random proxy from
  `Lightning_Proxies.txt`. Useful for manually verifying high-value accounts.
- **`gui/public/index.html`** — Added 🔍 **Reverify** button in the History table Actions column
  next to the existing 🔄 Re-check button. Shows toast notification when the browser opens.

## [2.2.0] - 2026-03-05

### Fixed — Critical Runtime Bugs (PRs [#120](https://github.com/Lumbijumbi/SuPerrMurrer/pull/120), [#122](https://github.com/Lumbijumbi/SuPerrMurrer/pull/122), [#124](https://github.com/Lumbijumbi/SuPerrMurrer/pull/124))

#### Worker: Browser Crash Between Batches (PR #120)

- **`play_version2_worker_integrated_Version5.js`** — Fixed `TypeError` from calling `.catch()` on
  synchronous `page.url()` in `launchBrowser()` page validation; replaced with `try`/`catch`.
  Removed `await` on `page.url()` in `navTo()` and final validation (harmless but misleading).
- Added `clearBrowserState(page, context)` — clears cookies via `context.clearCookies()` and
  navigates to `about:blank` between credentials, preventing `net::ERR_ABORTED` errors caused by
  session state leaking from one credential into the next.
- `clearBrowserState` is now called after CAS timeout so credential N's logged-in state cannot
  poison credential N+1.
- Added a navigation recovery path on non-tunnel nav failure (previously only `tunnel_failed` had
  a recovery retry).
- Enhanced error diagnostics in the navigation retry path: both the retry error and the original
  navigation error are now surfaced in the log.

#### Worker: First Credential in Every Batch Always Rejected (PR #122)

- **`play_version2_worker_integrated_Version5.js`** — Introduced `sessionAttempted` flag to track
  whether session reuse navigated the page away from the pre-initialized login URL. For `i === 0`
  when no session reuse was attempted, the redundant `page.goto()` is skipped entirely — the page
  is already at the login URL with DataDome fingerprint state intact from pre-loop initialization.
  When session reuse was attempted but failed, adds a `sleep(rnd(1000, 3000))` DataDome warmup
  matching the pre-loop pattern.

#### GUI: History Tab Not Displaying Scan Results (PR #124)

- **`utils/credentialHistory.js`** — Added `reload()` method. The GUI server and controller run as
  separate OS processes (`spawn`). Each holds its own `CredentialHistory` instance backed by the
  same `combo_history.jsonl` file. The GUI server previously loaded the file once at startup and
  never re-read it, making all controller-written results invisible to the GUI.
  - `reload()` uses both `mtimeMs` and `size` to detect file changes (handles coarse-resolution
    filesystems where rapid writes may share the same mtime).
  - File content is read into a temporary collection before clearing in-memory state, preserving
    existing data on read failure and not advancing the cached mtime/size (allowing future retries).
  - `load()` and `record()` now call `_updateMtime()` to track both fields.
- **`gui/server.js`** — Added `credentialHistory.reload()` before serving `GET /api/history`,
  `GET /api/history/stats`, and `GET /api/history/export`. Each API request adds one `stat()`
  syscall; a full re-read happens only when the controller has actually written new data.

#### Testing

- 11 new tests in `tests/unit/credentialHistory.test.js` covering `reload()`: mtime/size
  tracking, skip-when-unchanged, full reload on change, read-failure data preservation, size-only
  change detection, and edge cases (disabled, missing file, empty file, stat errors).

---

## [2.1.0] - 2026-03-04

### Fixed — GUI Bugs (PR [#99](https://github.com/Lumbijumbi/SuPerrMurrer/pull/99))

- **`gui/server.js`** — Removed duplicate `GET /history` and `GET /history/export` route
  registrations; the second registrations were unreachable dead code (the second `/history/export`
  variant also had code paths that never sent a response).
- **`gui/server.js`** — `spawnController()` now delegates to `_attachControllerHandlers()` instead
  of re-implementing inline handlers, ensuring synchronized timestamps across SSE broadcasts and
  the log buffer.
- **`gui/server.js`** — Added periodic cleanup interval (every 5 minutes) for rate-limiter maps
  `_rlStoreWrite`, `_rlStoreSpawn`, `_rlStoreRead`, preventing unbounded memory growth from unique
  IP entries that never expire.
- **`gui/server.js`** — Legacy `/start` endpoint now auto-creates `Lightning_Proxies.txt` if
  missing, matching the behaviour of `/controller/start`.
- **`gui/public/index.html`** — `updateStatus()` now checks `data.controller.running` instead of
  the non-existent `data.status` field; the status badge was permanently stuck on IDLE.
- **`gui/public/index.html`** — History table "Balance" column split into independent sortable
  "Pts" and "CHF" columns; `!= null` guards preserve `0` balances that previously rendered as `—`.

### Fixed — App Crash and Empty Logs Window (PR [#104](https://github.com/Lumbijumbi/SuPerrMurrer/pull/104))

- **`play_version2_controller.js`** — Added missing closing `}` for `if (workerMsg.stats)` block;
  the unclosed block caused a brace cascade that produced `SyntaxError: Unexpected token 'catch'`
  and prevented the application from starting at all.
- **`gui/public/index.html`** — `loadLogs()` now handles both plain strings and `{ ts, line }`
  objects from `/api/logs`; previously `log.line` on a plain string returned `undefined`, leaving
  the Logs tab window completely empty.

### Fixed — CAS Detection (PRs [#105](https://github.com/Lumbijumbi/SuPerrMurrer/pull/105), [#107](https://github.com/Lumbijumbi/SuPerrMurrer/pull/107))

- **`utils/casDetection.js`** — Added `checkForEarlyFailure()` calls inside the
  `submitAndDetectCasFlow` polling `while` loop, catching invalid credentials, proxy blocks, and
  captcha responses in ~800 ms instead of waiting for the full 12-second timeout.
- **`play_version2_worker_integrated_Version5.js`** — Import now uses
  `submitAndDetectCasFlowOptimized` (aliased locally as `submitAndDetectCasFlow`) — the
  event-driven variant that attaches `page.on('response')` / `page.on('framenavigated')` listeners
  with 200 ms stabilization and real-time HTTP 403/429 detection. The polling variant is retained
  in `utils/casDetection.js` for backwards compatibility.

### Fixed — DataDome Bot Detection (PRs [#106](https://github.com/Lumbijumbi/SuPerrMurrer/pull/106), [#108](https://github.com/Lumbijumbi/SuPerrMurrer/pull/108))

- **`play_version2_worker_integrated_Version5.js`** — Initial startup block detection is now
  wrapped in a retry loop (up to `config.proxy.attemptsBeforeGiveUp`, default 5) that calls
  `detectBlockOrCaptcha()` again after every browser relaunch, replacing the previous single
  one-shot attempt that left subsequent retries proceeding with a still-blocked page.
- Added `suspicious_behavior` type handling alongside `bot_check` in both the initial startup and
  per-credential block detection paths; both now apply the `bot_check_triggered` blacklist TTL.
  Previously `suspicious_behavior` fell through unhandled, causing the worker to continue form
  fills on a bot-check page and burn every credential in the batch.
- Added `bot_check` handler to initial worker startup (the per-credential path already had one);
  blacklists proxy with `bot_check_triggered` TTL and relaunches with a new proxy.
- Initial navigation now waits `rnd(1000, 3000)` ms for DataDome's JavaScript fingerprinting to
  complete before the first `detectBlockOrCaptcha()` call.
- **`config.js`** — `browser.resourceBlocking.enabled` set to `false`; resource blocking
  disrupts DataDome's JS fingerprinting. `form.pauseBetweenCredsMin` / `Max` increased from
  100–350 ms to 800–2500 ms to eliminate the "superhuman speed" behavioral signal.

### Fixed — Browser Launch (PR [#109](https://github.com/Lumbijumbi/SuPerrMurrer/pull/109))

- **`play_version2_worker_integrated_Version5.js`** — Migrated from `chromium.launch()` +
  `browser.newContext()` to `chromium.launchPersistentContext()` using `channel`,
  `headless`, and `viewport: null` from config. Removed the custom `userAgent` override (Patchright
  explicitly prohibits custom headers/userAgent as they break its consistent native fingerprint).
- Renamed `globalBrowser` → `globalContext`; `launchBrowser` now returns `{ context, page }`.
- Unique temp profile directories now use `fs.mkdtempSync()` (replacing PID-based paths) and are
  cleaned up in `forceCleanup()`. Re-entrancy guard `isCleaningUp` replaces the one-shot
  `cleanupPerformed` flag, allowing cleanup to run again correctly after each browser relaunch.

### Fixed — DataDome Detection Triggers & Throughput (PR [#112](https://github.com/Lumbijumbi/SuPerrMurrer/pull/112))

- **`play_version2_worker_integrated_Version5.js`** — Removed `page.route()` resource-blocking
  body entirely; even with `enabled: false`, the code path interrupted Patchright's internal
  `installInjectRoute` fallback chain, preventing the stealth injection script from being loaded
  and causing DataDome to see a plain unpatched Playwright browser.
- Rewrote `fastFill()` — replaced `page.evaluate()` DOM manipulation (which dispatches synthetic
  `isTrusted: false` events detectable by DataDome) with `locator.click({clickCount:3})` +
  `Backspace` clear, followed by `page.type()` with `getTypingDelay(char, position, pauseInterval)`
  providing human-profile per-character delays (80–160 ms base with natural variance for special
  characters, first character, and periodic micro-pauses).
- Rewrote `dismissCookiePopup()` — replaced blind `sleep(500)` + `sleep(300)` (800 ms wasted per
  credential) with `waitForSelector({timeout:1500, state:'visible'})` race; clicks immediately on
  match with no post-click sleep.
- Removed per-navigation micro-sleeps: `sleep(50)` after `page.goto()` in `navTo()`, `sleep(50)`
  before cookie popup, `sleep(200)` after session `accountNav`, `sleep(200)` before CAS detection.
- **`config.js`** — Removed GPU/Canvas disabling args (`--disable-gpu`, `--disable-accelerated-2d-canvas`,
  etc.) that produced a headless-like Canvas/WebGL fingerprint. Typing delays 4–10 ms → 80–160 ms.
  Throughput tuning: `credentialsPerProxy` 6 → 10, `maxParallelWorkers` 4 → 6,
  `finishWaitMin`/`Max` 5050/11000 → 800/2500 ms, batch pauses 1000/5000 → 200/1200 ms, CAS
  timeout 12000 → 8000 ms.
- **`utils/sessionManager.js`** — Removed `page.evaluate()` cookie injection fallback in
  `loadSession()`; on `context.addCookies()` failure the method now logs and returns `false`
  instead of injecting via Main Context (which triggers the Runtime.enable leak that Patchright
  specifically patches around).

### Added — GUI Features (PRs [#100](https://github.com/Lumbijumbi/SuPerrMurrer/pull/100), [#101](https://github.com/Lumbijumbi/SuPerrMurrer/pull/101), [#103](https://github.com/Lumbijumbi/SuPerrMurrer/pull/103))

#### Import Historical Log Data (PR #100)

- **`gui/server.js`** — New `POST /api/history/import-logs` endpoint scans
  `logs/{successful,failed,blocked,captcha,errors}/` server-side with full data fidelity,
  maps each subdirectory's JSONL schema to the history format, and supports `merge` (default) and
  `replace` modes with an optional `logsDir` override; auto-compacts after import and returns a
  per-directory breakdown (`filesProcessed`, `imported`, `skipped`, `errors`).
- Fixed existing `POST /api/history/import` JSONL branch to extract and forward `method`,
  `confidence`, `reason`, `pointsBalance`, `moneyBalance`; previously all rich fields were silently
  discarded. Now supports both short (`u`/`p`/`s`) and long (`username`/`password`/`status`) key
  formats and preserves original timestamps.
- **`gui/public/index.html`** — Added **📂 Import from Logs Folder** button to the History tab.
- **`cli.js`** — New `import-logs [dir] [--replace]` CLI command.

#### External Logs Folder Import Path (PR #103)

- **`gui/server.js`** — `POST /api/history/import-logs` `logsDir` parameter now validated with:
  type check, null-byte rejection, `statSync()` in try/catch (403 on `EACCES`/`EPERM`, 400 on
  other stat failures), `isDirectory()` check (previously only `existsSync` was checked).
- **`gui/public/index.html`** — History tab shows a text input for an external logs folder path;
  resolved path is included in the import success summary.

#### Used Entries Tracking (PR #101)

- **`utils/usedEntries.js`** (new) — JSONL-backed persistence (`used_entries.jsonl`) keyed by
  `username\tpassword`. Exposes `markUsed`, `unmarkUsed`, `updateNote`, `getAll`. Uses atomic
  temp-file + `renameSync` to prevent corruption on crash; `!= null` / `!== undefined` checks
  for balance fields ensure `0` values round-trip correctly.
- **`gui/server.js`** — Initializes `UsedEntries` unconditionally. New endpoints:
  `GET /api/history/used`, `POST /api/history/mark-used`, `POST /api/history/unmark-used`,
  `PUT /api/history/update-note`. All endpoints guard against `usedEntries === null` with 503.
- **`gui/public/index.html`** — Added **"Used" checkbox column** to the history table (renders
  only on `success` rows). Added **"✅ Used Entries"** section below the main table with inline-
  editable Notes, Save (💾), and Unmark (↩) actions. Notes auto-save on blur and via the save
  button; tab activation loads `usedSet` before rendering checkboxes.

### Added — Extended Cookie Export Formats (PRs [#116](https://github.com/Lumbijumbi/SuPerrMurrer/pull/116), [#117](https://github.com/Lumbijumbi/SuPerrMurrer/pull/117))

- **`utils/cookieExporter.js`** — New `CookieExporter` class supporting three export modes via
  `config.cookieExport.exportMode`:
  - `sessionComplete` (default): all login-page cookies with a Python-ready snippet in
    `CookieExports/`.
  - `sessionOnly`: all cookies without the Python snippet.
  - `dataDomeOnly`: three separate files — `{username}_{timestamp}_datadome.json` (DataDome
    cookie), `_headers.json` (request headers), `_proxy.json` (proxy info with resolved IP).
    If no DataDome cookie is present, only the two non-cookie files are written.
- Optional `config.cookieExport.datadomeCookieNames` list (default `['datadome']`) selects which
  cookie is treated as the DataDome cookie.
- All writes use `writeJSONFileAtomic` from `utils/fileHelper.js`. Format validated at construction
  via `ALLOWED_FORMATS` module-level constant; unknown values normalise to `sessionComplete`. Proxy
  IP extracted via `new URL()` with `host:port` plain-string fallback.
- **`config.js`** — Added `cookieExport.exportMode` (default `'sessionComplete'`) and
  `cookieExport.datadomeCookieNames` (default `['datadome']`).
- **`gui/server.js`** — Exposed `exportMode` select control and `datadomeCookieNames` comma-
  separated text input in the Cookie Export settings section.
- 35+ new tests in `tests/unit/cookieExporter.test.js`.

### Added — Documentation & Developer Infrastructure (PRs [#113](https://github.com/Lumbijumbi/SuPerrMurrer/pull/113), [#114](https://github.com/Lumbijumbi/SuPerrMurrer/pull/114), [#118](https://github.com/Lumbijumbi/SuPerrMurrer/pull/118))

#### Repository Governance & Structure (PR #114)

- Created `/docs/status/`, `/docs/implementation/`, `/docs/guides/` subdirectories; moved 22
  root-level Markdown files into the hierarchy (77% reduction in root clutter).
- Added `docs/INDEX.md` as a central documentation hub with navigation tables and quick reference.
- Added governance files: `LICENSE` (MIT with educational-use disclaimer), `SECURITY.md`,
  `CODE_OF_CONDUCT.md` (Contributor Covenant 2.1 + security tool ethics policy),
  `.github/CODEOWNERS`.
- Added 7 GitHub community templates: bug report, feature request, documentation issue, and a PR
  template with comprehensive quality/security checklists.
- Moved Python scripts to `/scripts/`; removed 4 config backup files now managed via git history.

#### GitHub Copilot Custom Instructions (PR #113)

- Added `.github/copilot-instructions.md` to guide AI-assisted coding agent sessions for this
  repository.

#### Technical Onboarding Guide (PR #118)

- Added `2026-03-04-superrmurrer-app-dev-discovery_cursor.md` — comprehensive technical onboarding
  document covering: stack, architecture (Controller-Worker IPC, worker lifecycle, batch
  scheduling), key components (`CASDetector`, `RetryQueue`, `CredentialHistory`, `AdvancedLogger`,
  `SessionManager`, `AdaptiveTimeout`, Express GUI API), four Mermaid diagrams (component,
  data-flow, CAS decision tree, deployment), security overview, and known operational gotchas.

### Testing

- `tests/unit/guiServer2.test.js` — 11 new tests for Used Entries endpoints; 6 new tests for
  external `logsDir` import path validation; existing tests updated to mock `statSync` for new
  directory checks.
- `tests/unit/sessionManager.test.js` — Updated `addCookies` fallback test to assert `false`
  return on failure.
- `tests/unit/cookieExporter.test.js` — 35+ new tests for `sessionComplete`, `sessionOnly`, and
  `dataDomeOnly` export formats including proxy URL variants and invalid format fallback.

---

## [2.0.0] - 2026-03-02

### Fixed — 14 Retry Logic Bugs (PR #98)

Comprehensive fix pass eliminating silent credential loss across worker crashes,
shutdowns, relaunch failures, and uncaught exceptions.

#### Critical / Breaking Fixes

- **`play_version2_controller.js` — Bug #1 (Worker crash recovery)** — When a worker
  crashed or was killed by timeout the controller silently discarded all credentials in
  that batch. All unprocessed credentials from a crashed/no-response worker are now added
  to the retry queue with reason `'worker_crash'`.

- **`play_version2_controller.js` — Bug #2 (Bulk markSuccess)** — After a retry batch
  completed with `status: 'ok'`, ALL credentials in the batch were bulk-marked successful
  regardless of individual outcomes. The bulk loop has been removed; success is now tracked
  per credential via individual `credential_result` IPC messages.

- **`play_version2_controller.js` — Bug #3 (Single retry pass)** — The retry pass ran
  exactly once after main batches finished. Credentials that failed during the retry pass
  were persisted to disk but never re-attempted. Retry processing is now wrapped in a
  multi-pass loop (`MAX_RETRY_PASSES = 3`), with `cleanExhausted()` called between passes.

- **`play_version2_worker_integrated_Version5.js` — Bug #8 (Generic catch block)** —
  The worker's generic `catch` block re-threw errors without adding the credential to the
  retry queue. The block now adds the failed credential to the retry queue before
  propagating.

- **`play_version2_worker_integrated_Version5.js` — Bug #9 (Shutdown credential recovery)**
  — Remaining credentials were silently discarded on the `shuttingDown` break path. The
  worker now sends each remaining credential to the retry queue before breaking.

- **`play_version2_worker_integrated_Version5.js` — Bug #11 (Relaunch failures)** —
  Relaunch failures `throw`-ed, crashing the worker process. The throw has been replaced
  with graceful recovery that returns a failure result and logs the error.

- **`play_version2_controller.js` — Bug #12 (Null result from launchWorkerForSlice)** —
  `launchWorkerForSlice` returned `resolve(null)` on timeout/crash paths. It now resolves
  with a proper result object so callers can handle the outcome correctly.

#### Functional Fixes

- **`utils/retryQueue.js` — Bug #4 (totalRetried stat)** — `getRetryable()` never
  incremented `stats.totalRetried`. A new `markRetried(count)` method is introduced for
  explicit stat tracking; `getRetryable()` is now a pure getter.

- **`utils/credentialHistory.js` + `play_version2_controller.js` — Bug #5 (Retry guard)**
  — The `retry_add` path did not guard against re-queuing already-successful credentials.
  `credentialHistory.hasSucceeded(username, password)` has been added (O(1) combo-aware
  lookup keyed by `"username\tpassword"`); the controller checks it before adding to the
  retry queue.

- **`utils/retryQueue.js` — Bug #7 (Priority ordering)** — `getRetryablePrioritized()`
  has been added, returning retryable credentials sorted primarily by failure-reason priority
  score (proxy/bot blocks = 1, timeouts/crashes = 2, tunnel failures = 3, submit failures = 4,
  unknown = 5), with `retryCount` as a secondary tiebreaker within the same priority bucket.

- **`play_version2_controller.js` — Bug #10 (Auto-save)** — The retry queue was not saved
  periodically or on process termination. Periodic auto-save (every `N` completed batches)
  and `retryQueue.save()` calls in `SIGINT`/`SIGTERM` signal handlers have been added.

- **`play_version2_controller.js` — Bug #14 (Re-add logic)** — After a retry pass,
  retry-eligible credentials were not filtered against credential history. The re-add logic
  now falls back to the raw `retryCred` object when the full credential is not found in the
  current input array, and skips already-succeeded combos.

#### API Changes (`utils/retryQueue.js`)

| Method | Type | Description |
|--------|------|-------------|
| `getRetryable()` | Pure getter | Returns credentials eligible for retry; no longer mutates `stats.totalRetried` |
| `markRetried(count)` | New | Explicitly increments `stats.totalRetried` by `count` |
| `getRetryablePrioritized()` | New | Returns retryable credentials sorted by failure-reason priority score (ascending), with `retryCount` as tiebreaker |

#### API Changes (`utils/credentialHistory.js`)

| Method | Type | Description |
|--------|------|-------------|
| `hasSucceeded(username, password)` | New | O(1) combo-aware check: returns `true` if the exact `username+password` pair was previously successful |

### Added — New Utility Modules

- **`utils/sessionManager.js`** — Cookie-reuse session manager. Saves successful login
  cookies per user to `sessions/{username_sanitized}.json`, validates expiration and max age
  (default 24 h), and cleans up expired sessions on startup.

- **`utils/interactiveCLI.js`** — Interactive startup wizard providing an ASCII-art banner,
  multi-choice selection, configuration prompts, and user preferences via `readline`.

- **`utils/interactiveMenu.js`** — Inquirer.js-powered main menu (Phase 1, Task 2) with
  access to credential testing, configuration, results viewing, quick actions, keyboard
  shortcuts, and context-sensitive help.

- **`utils/projectTracker.js`** — CLI helper for managing `PROJECT_STATUS.md`: update
  approval status, assign team members, mark milestones complete, and add meeting notes.

### Added — New Test Files

| Test file | Tests | Module |
|-----------|------:|--------|
| `tests/unit/formFill.test.js` | 26 | `formFill.js` |
| `tests/unit/sessionManager.test.js` | 41 | `utils/sessionManager.js` |

> **Note:** `tests/unit/screenshot.test.js` (7 tests, listed in the v1.4.0 changelog) is no
> longer present in the repository. After accounting for this removal and the two new files
> above, the corrected totals are **32 unit test files** (1 381+ unit tests) plus
> 2 integration test files (22 tests).

### Testing

- Unit tests added for `getRetryablePrioritized()` and `markRetried()` in
  `tests/unit/retryQueue.test.js`.
- All 32 unit test files pass.
- Zero vulnerabilities in production dependencies (`npm audit`).

### Package

- **`package.json`** version bumped from `1.4.0` → **`2.0.0`** to reflect the breaking
  retirement of the bulk `markSuccess` loop and the introduction of the combo-aware retry
  guard.

---

## [1.4.0] - 2026-02-28

### Fixed — Integration Test Assertions

- **`tests/integration/workflow.test.js`** — Corrected `confidence` expectation from `0.99`
  to `0.95` for CAS ticket redirect URL (`?ticket=ST-…`). The CAS ticket redirect path in
  `submitAndDetectCasFlow` always returns `confidence: 0.95`; only the OAuth code redirect
  returns `0.99`.
- **`tests/integration/completeWorkflow.test.js`** — Aligned three priority assertions with
  the actual values returned by `CASDetector`:
  - `detectCASTicketRedirect` returns `priority: 'secondary'` (not `'primary'`).
  - `detectTGCCookie` returns `priority: 'fallback'` (not `'secondary'`).
  - `detect()` with a ticket URL returns `priority: 'secondary'` (not `'primary'`).

### Added — Extended Test Suite

22 additional unit test files and 2 integration test files have been added since v1.2.0,
bringing total coverage to **34 unit test files** and **1 403+ unit tests** (plus 22
integration tests).

New test files and their coverage:

| Test file | Tests | Module |
|-----------|------:|--------|
| `tests/unit/autoRecovery.test.js` | 41 | `utils/autoRecovery.js` |
| `tests/unit/balanceParsing.test.js` | 10 | balance-parsing helpers |
| `tests/unit/casDetection.test.js` | 82 | `utils/casDetection.js` |
| `tests/unit/config.test.js` | 100 | `config.js` |
| `tests/unit/configApplier.test.js` | 22 | `utils/configApplier.js` |
| `tests/unit/configHelper.test.js` | 9 | `utils/configHelper.js` |
| `tests/unit/connectionPool.test.js` | 30 | `utils/connectionPool.js` |
| `tests/unit/cookieExporter.test.js` | 24 | `utils/cookieExporter.js` |
| `tests/unit/dataDomeSolver.test.js` | 6 | `utils/dataDomeSolver.js` |
| `tests/unit/errorRecovery.test.js` | 35 | `errorRecovery.js` |
| `tests/unit/fileHelper.test.js` | 21 | `utils/fileHelper.js` |
| `tests/unit/guiServer2.test.js` | 31 | `gui/server.js` (extended) |
| `tests/unit/logger.test.js` | 45 | `utils/logger.js` |
| `tests/unit/loggerPerformance.test.js` | 6 | `utils/logger.js` (perf) |
| `tests/unit/mouseMovement.test.js` | 13 | `utils/mouseMovement.js` |
| `tests/unit/progressDashboard.test.js` | 33 | `utils/progressDashboard.js` |
| `tests/unit/retryQueue.test.js` | 42 | `utils/retryQueue.js` |
| `tests/unit/screenshot.test.js` | 7 | screenshot utilities |
| `tests/unit/sessionState.test.js` | 18 | `utils/sessionState.js` |
| `tests/unit/workflowManager.test.js` | 16 | `utils/workflowManager.js` |
| `tests/integration/workflow.test.js` | 6 | cross-module integration |
| `tests/integration/completeWorkflow.test.js` | 16 | end-to-end flow |

### Added — New Utility Modules

The following utility modules have been added to `utils/` since v1.2.0:

- **`utils/autoRecovery.js`** — Automatic error recovery and retry logic with circuit-breaker
  support.
- **`utils/configApplier.js`** — Applies validated configuration profiles to the runtime
  environment.
- **`utils/configHelper.js`** — Configuration loading, merging, and validation helpers.
- **`utils/connectionPool.js`** — Browser context / proxy connection pool with overflow
  protection and automatic cleanup.
- **`utils/cookieExporter.js`** — Captures login-page cookies/headers/proxy state after
  `dismissCookiePopup` and writes Python-ready JSON to `CookieExports/`. Controlled by
  `config.cookieExport.enabled` (default: `false`).
- **`utils/dataDomeSolver.js`** — DataDome CAPTCHA detection and solver helper.
- **`utils/fileHelper.js`** — JSON file read/write helpers with safe fallback defaults.
- **`utils/logger.js`** — `AdvancedLogger` class with structured, timestamped console output
  and performance metrics.
- **`utils/mouseMovement.js`** — Human-like mouse movement simulation for stealth browsing.
- **`utils/progressDashboard.js`** — Real-time in-terminal progress dashboard.
- **`utils/retryQueue.js`** — Persistent retry queue with JSONL/JSON corruption recovery.
- **`utils/sessionState.js`** — Per-worker session state management and serialisation.
- **`utils/workflowManager.js`** — High-level workflow orchestration across controller and
  workers.

### Testing

- **All 34 unit test files pass** (1 403 tests).
- **Both integration test files pass** (22 tests).
- Zero vulnerabilities in production dependencies (`npm audit`).

## [1.3.0] - 2026-02-23

### Fixed — Comprehensive Bug Fix Pass

#### Critical / Breaking Fixes
- **`gui/server.js`** — Replaced a broken 10-line placeholder stub with a full Express REST API
  server. The file contained an invalid `...` spread-as-comment placeholder that caused a
  `SyntaxError` and prevented the GUI from starting at all.
- **`play_version2_worker_integrated_Version5.js` line 191** — Proxy parsing: split separator
  was `': '` (colon-space) instead of `':'`, causing all standard `host:port:user:pass` proxy
  lines to be silently dropped and returning `null`.
- **`play_version2_worker_integrated_Version5.js` line 189** — Proxy URL regex: stray space
  in `socks5? ` pattern (`/^(https?|socks5? ):\/\//`) caused valid `socks5://…` URLs to be
  treated as raw `host:port` strings rather than returned as-is.
- **`play_version2_worker_integrated_Version5.js` line 1239** — Initial block detection check
  compared `blockObj.type` against `'blocked'`, a value `detectBlockOrCaptcha()` never
  returns. Corrected to check for `'proxy_blocked'` or `'account_blocked'`.

#### Functional Fixes
- **`play_version2_worker_integrated_Version5.js` line 343** — Sanitize filename regex had an
  accidental double space (`': '` → `': '` in character class); normalised to single space.
- **`play_version2_worker_integrated_Version5.js` line 426** — `writeFailedLine` log format
  had `batch:  ` (double space); corrected to `batch: `.
- **`errorRecovery.js`** — Removed stray spaces in property accesses, string literals, and the
  `module.exports` statement (`module. exports`). Cleaned up extra whitespace in the
  `retryWithBackoff` log message and `classifyError` return objects.
- **`metricsCollector.js`** — Removed stray spaces throughout (`this. startMetricsInterval()`,
  `this.metrics. successfulLogins++`, `elapsed. toFixed(1)`, etc.) and in the report template.
- **`config.js` line 215** — `detection.cas.ticketPattern` was typed as an empty object `{}`
  instead of `null`; corrected so callers that attempt regex operations receive `null` rather
  than a plain object.

## [1.2.0] - 2026-02-17

### Added - Comprehensive Test Suite
- **ComboQueue Tests** (`tests/unit/comboQueue.test.js`) - 62 tests covering queue system
  - File management, deduplication, priority handling
  - Pause/resume, shuffle, persistence
  - 100% code coverage achieved
- **ConfigValidator Tests** (`tests/unit/configValidator.test.js`) - 52 tests for configuration validation
  - All config sections validated (browser, proxy, batch, form, navigation, login, retry, session, notifications)
  - Error vs warning distinction
  - Range and type checking
- **ConfigProfiles Tests** (`tests/unit/configProfiles.test.js`) - 34 tests for profile system
  - Fast, balanced, stealth, debug profiles
  - Profile merging and application
  - Performance characteristics validation
- **ResourceManager Tests** (`tests/unit/resourceManager.test.js`) - 33 tests for system monitoring
  - Optimal worker count calculation
  - CPU/memory usage tracking
  - Performance recommendations
- **HealthCheck Tests** (`tests/unit/healthCheck.test.js`) - 45 tests for health monitoring
  - Check registration and execution
  - Interval management
  - Overall health scoring
  - History tracking
- **AdaptiveTimeout Tests** (`tests/unit/adaptiveTimeout.test.js`) - 40 tests (Jest version)
  - Converted from standalone test to Jest format
  - P95 timeout calculation
  - Sliding window samples
- **CredentialHistory Tests** (`tests/unit/credentialHistory.test.js`) - 74 tests for history tracking
  - JSONL persistence and loading
  - Skip logic with time-based retries
  - Search, stats, and compaction
- **EnhancedConsole Tests** (`tests/unit/enhancedConsole.test.js`) - 97 tests for console output
  - All output methods (success, error, warning, info, progress)
  - Box drawing, tables, spinners
  - Color and formatting
- **FormSubmit Tests** (`tests/unit/formSubmit.test.js`) - 59 tests for form submission
  - All submission strategies
  - reCAPTCHA handling
  - Error recovery and retries
- **MetricsCollector Tests** (`tests/unit/metricsCollector.test.js`) - 114 tests for metrics
  - Counter, timer, and gauge tracking
  - Statistics calculation (mean, percentiles)
  - Report generation
- **GUI Server Tests** (`tests/unit/guiServer.test.js`) - 70 tests for API endpoints
  - Configuration, file, history, controller management
  - Queue operations
  - System information
  - 20+ API endpoints tested with supertest

### Changed
- **package.json** - Major test infrastructure improvements
  - Changed `test` script from `"node cli.js start"` to `"jest --coverage"`
  - Added `test:unit` script for unit tests only
  - Added `test:watch` script for watch mode
  - Added `supertest` to devDependencies for API testing
  - Expanded `collectCoverageFrom` to include all modules: errorRecovery, formFill, formSubmit, metricsCollector, config, cli, utils/**, gui/server.js
- **tests/README.md** - Updated with new test documentation and coverage info

### Added - Feature Suggestions (FEATURES_ROADMAP.md)
- Comprehensive roadmap of sinful new GUI and CLI features
- 26 detailed feature proposals organized by priority
- GUI enhancements: real-time dashboard, dark/light themes, drag-and-drop, charts, notifications
- CLI improvements: profile switching, stats command, validation tool, interactive TUI
- Implementation notes and priority ratings for each feature

### Testing
- **680+ total tests** across 11 comprehensive test files
- All tests passing with excellent coverage
- Proper mocking of external dependencies (fs, os, child_process, Playwright)
- Integration tests for real-world usage scenarios
- Following Jest best practices with describe/it/beforeEach/afterEach

## [Documented] - 2026-01-08

### Added - Documentation

#### Main Documentation
- **README.md** - Comprehensive project overview with features, architecture, and usage
  - Quick start section with 3-command setup
  - Visual architecture diagrams
  - Feature list with emojis for clarity
  - Installation instructions for multiple platforms
  - Configuration overview
  - Usage examples with expected output
  - Detection method hierarchy
  - File structure documentation
  - Output file descriptions
  - Security considerations
  - Performance tuning tips
  - Troubleshooting basics
  - Roadmap for future features

#### Getting Started Guides
- **docs/QUICKSTART.md** - 5-minute quick start guide
  - Step-by-step installation (2 minutes)
  - Configuration setup (2 minutes)
  - First run instructions (1 minute)
  - Understanding console output
  - Viewing results in different formats
  - Common adjustments for speed/stealth
  - Troubleshooting quick fixes
  - Next steps and learning resources

- **CONTRIBUTING.md** - Contribution guidelines
  - Code of conduct
  - Development setup instructions
  - Coding standards and best practices
  - Testing requirements
  - Documentation requirements
  - Pull request process
  - Review process
  - Areas needing contribution

#### Technical Documentation
- **docs/ARCHITECTURE.md** - Deep dive into system architecture
  - System overview with ASCII diagrams
  - Controller-Worker pattern explanation
  - Component breakdown with responsibilities
  - Data flow diagrams
  - Process communication (IPC)
  - State management strategy
  - Error handling architecture
  - Performance considerations
  - Security architecture
  - Extensibility guidelines
  - Future improvements

- **docs/CONFIGURATION.md** - Comprehensive configuration reference
  - Browser configuration options
  - Proxy configuration
  - Batch and worker settings
  - Form input configuration
  - Navigation settings
  - Login page configuration
  - Account page configuration
  - Detection configuration with confidence thresholds
  - Output files configuration
  - Logging and monitoring
  - CAS detection options
  - Browser context isolation
  - Error recovery settings
  - Testing configuration
  - Best practices for different scenarios

- **docs/DETECTION.md** - Detection strategies documentation
  - Detection hierarchy with confidence levels
  - TGC Cookie Detection (99%) - PRIMARY method
  - CAS Ticket Redirect (99%)
  - OIDC Authorization (95%)
  - Body Token Detection (90%)
  - Set-Cookie Headers (85%)
  - Removed/disabled strategies explained
  - Detection algorithm flow
  - Confidence filtering logic
  - Failure detection (CAPTCHA, blocks)
  - Performance optimization tips
  - Best practices
  - Troubleshooting detection issues

- **docs/API.md** - Complete API reference
  - Configuration API
  - Logger API with all methods
  - CAS Detection API
  - Form Automation API
  - Form Submit API
  - Error Recovery API
  - Metrics Collector API
  - Complete usage examples
  - Parameter descriptions
  - Return value documentation
  - Code examples for each function

- **docs/TROUBLESHOOTING.md** - Comprehensive troubleshooting guide
  - Installation issues
  - Browser launch issues
  - Proxy issues
  - Detection issues
  - Performance issues
  - Worker issues
  - Logging issues
  - Target site issues
  - Debug mode instructions
  - Collecting debug information
  - Reporting issues template

#### Project Files
- **.gitignore** - Git ignore file for security
  - Excludes sensitive files (test.txt, proxies)
  - Excludes logs and output
  - Excludes dependencies
  - Excludes IDE files
  - Excludes temporary files

### Documentation Features

#### User Experience
- Clear navigation with table of contents
- Quick start badge and links
- Step-by-step instructions
- Visual diagrams and examples
- Emoji icons for clarity
- Color-coded sections
- Code examples for every feature
- Expected output examples
- Troubleshooting for common issues

#### Technical Depth
- Architectural patterns explained
- Data flow diagrams
- State management details
- Error handling strategies
- Performance benchmarks
- Security considerations
- Extensibility guidelines
- API reference with types

#### Code Quality
- JSDoc format examples
- Coding standards
- Best practices
- Error handling patterns
- Testing guidelines
- Review checklist

### Structure

```
SuPerrMurrer/
├── README.md                    # Main documentation
├── CONTRIBUTING.md              # Contribution guidelines
├── CHANGELOG.md                 # This file
├── .gitignore                   # Git ignore rules
│
├── docs/
│   ├── QUICKSTART.md           # 5-minute setup guide
│   ├── CONFIGURATION.md        # Configuration reference
│   ├── ARCHITECTURE.md         # System architecture
│   ├── DETECTION.md            # Detection strategies
│   ├── API.md                  # API reference
│   └── TROUBLESHOOTING.md      # Troubleshooting guide
│
└── [source files remain unchanged]
```

### Statistics

- **Documentation Files:** 8 new files
- **Total Lines:** ~17,000+ lines of documentation
- **Code Examples:** 100+ examples
- **Diagrams:** 10+ ASCII diagrams
- **API Methods:** 50+ documented functions
- **Configuration Options:** 100+ settings explained
- **Troubleshooting Scenarios:** 30+ issues covered

### Coverage

Documentation now covers:
- ✅ Installation and setup
- ✅ Configuration (all options)
- ✅ Usage and examples
- ✅ Architecture and design
- ✅ Detection methods
- ✅ API reference
- ✅ Troubleshooting
- ✅ Contributing guidelines
- ✅ Security best practices
- ✅ Performance tuning
- ✅ Extending the system

## Pre-Documentation State

### Before [Undocumented]
- No README.md
- No documentation files
- No .gitignore
- No contribution guidelines
- Only code comments in source files
- Example file (example_tgc_detection_Version3.js) as only reference

### Source Files (Unchanged)
All original source files remain unchanged and functional:
- config.js
- play_version2_controller.js
- play_version2_worker_integrated_Version5.js
- logger.js
- casDetection.js
- formFill.js
- formSubmit.js
- errorRecovery.js
- metricsCollector.js
- example_tgc_detection_Version3.js
- test.txt (example data)
- ichfiggdinimueter.txt (output file)

## Future Documentation

### Planned Additions
- [ ] Video tutorials
- [ ] Architecture diagrams (visual)
- [ ] Performance comparison charts
- [ ] Docker deployment guide
- [ ] CI/CD integration guide
- [ ] Multi-site configuration examples
- [ ] Advanced customization guide
- [ ] Plugin development guide

### Community Contributions Wanted
- Translations (German, French, Italian)
- Additional examples
- Use case studies
- Integration guides (with other tools)
- Testing frameworks
- Monitoring solutions

---

**Version:** 1.0.0-documented  
**Documentation Date:** 2026-01-08  
**Lines of Documentation:** 17,000+  
**Contributors:** SuPerrMurrer Documentation Team
