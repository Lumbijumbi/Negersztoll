/**
 * GUI Server for SuPerrMurrer
 * Express-based REST API server for the web dashboard
 */

'use strict';

const express = require('express');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const os = require('os');
const zlib = require('zlib');
const crypto = require('crypto');

const config = require('../config');
const { applyProfile, getProfile } = require('../utils/configProfiles');
const CredentialHistory = require('../utils/credentialHistory');
const UsedEntries = require('../utils/usedEntries');
const ComboQueue = require('../utils/comboQueue');
const CookieExporter = require('../utils/cookieExporter');
const BulkCookieGenerator = require('../utils/bulkCookieGenerator');

const app = express();
const PORT = process.env.PORT || 3000;
const IS_PRODUCTION = process.env.NODE_ENV === 'production';

// --- Constants & State -------------------------------------------------------
const MAX_LOG_BUFFER = 2000;

let controllerProcess = null;
const logBuffer = [];

let credentialHistory = null;
let comboQueue = null;
let usedEntries = null;

if (config.history && config.history.enabled) {
  try {
    credentialHistory = new CredentialHistory(config.history);
    credentialHistory.load();
  } catch (e) {
    console.error('[GUI] Failed to initialise credential history:', e.message);
  }
}

try {
  usedEntries = new UsedEntries();
} catch (e) {
  console.error('[GUI] Failed to initialise used entries:', e.message);
}

if (config.queue && config.queue.enabled) {
  try {
    comboQueue = new ComboQueue(config.queue);
  } catch (e) {
    console.error('[GUI] Failed to initialise combo queue:', e.message);
  }
}

// --- Helpers -----------------------------------------------------------------

/** Return a safe error message string – hide internals in production. */
function safeError(error) {
  if (IS_PRODUCTION) return 'Internal server error';
  return error && error.message ? error.message : 'Internal server error';
}

function addToLogBuffer(line) {
  const ts = Date.now();
  logBuffer.push({ ts, line });
  if (logBuffer.length > MAX_LOG_BUFFER) {
    logBuffer.shift();
  }
  return ts;
}

/**
 * Determine whether a stderr line is a real error (not informational output).
 * Filters out Node.js version banners, npm warnings, and deprecation notices.
 * @param {string} line - A line of stderr output to evaluate.
 * @returns {boolean} True if the line represents a genuine error, false otherwise.
 */
function isActualError(line) {
  if (!line || !line.trim()) return false;
  const lower = line.toLowerCase();
  if (/^v\d+\.\d+\.\d+/.test(line.trim())) return false;
  if (lower.includes('npm warn') || lower.includes('npm notice')) return false;
  if (lower.includes('deprecationwarning') || lower.includes('experimentalwarning')) return false;
  return true;
}

function gzipIfNeeded(content, wantGzip) {
  if (!wantGzip) return { data: Buffer.from(content), encoding: null };
  return { data: zlib.gzipSync(content), encoding: 'gzip' };
}

function normalizeLimit(value, def, min, max) {
  const n = parseInt(value, 10);
  if (Number.isNaN(n)) return def;
  return Math.min(Math.max(n, min), max);
}

function parseCsvLines(text) {
  return text
    .split('\n')
    .map(l => l.trim())
    .filter(Boolean)
    .map(l => {
      // Use first colon as delimiter: username:password (passwords may contain colons)
      const idx = l.indexOf(':');
      if (idx === -1) return null;
      const u = l.slice(0, idx).trim();
      const p = l.slice(idx + 1).trim();
      if (!u || !p) return null;
      return { username: u, password: p };
    })
    .filter(Boolean);
}

/**
 * Escape a value for safe inclusion in a CSV field.
 * Wraps in quotes if the value contains commas, quotes, or newlines,
 * and prevents CSV formula injection by quoting fields starting with =, +, -, @.
 */
function escapeCsvField(value) {
  const str = String(value == null ? '' : value);
  if (/[",\n\r]/.test(str) || /^[=+\-@]/.test(str)) {
    return '"' + str.replace(/"/g, '""') + '"';
  }
  return str;
}

// --- Middleware ---------------------------------------------------------------
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.disable('x-powered-by');

// Security headers
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  if (IS_PRODUCTION) {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }
  next();
});

// CORS
app.use((req, res, next) => {
  const allowedOrigin = IS_PRODUCTION ? `http://localhost:${PORT}` : '*';
  res.header('Access-Control-Allow-Origin', allowedOrigin);
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

// Simple in-memory rate limiter applied globally to all /api/ routes
// Limits write/mutating operations (POST, PUT, DELETE) more strictly than reads.
const _rlStoreWrite = new Map();
const _rlStoreSpawn = new Map();
const _rlStoreRead = new Map();

// Periodically remove expired entries to prevent unbounded memory growth
setInterval(() => {
  const now = Date.now();
  for (const store of [_rlStoreWrite, _rlStoreSpawn, _rlStoreRead]) {
    for (const [key, entry] of store) {
      if (now > entry.resetAt) store.delete(key);
    }
  }
}, 300000).unref(); // Clean every 5 minutes; unref so it doesn't block process exit

function _checkRateLimit(store, key, maxRequests, windowMs) {
  const now = Date.now();
  const entry = store.get(key) || { count: 0, resetAt: now + windowMs };
  if (now > entry.resetAt) { entry.count = 0; entry.resetAt = now + windowMs; }
  entry.count++;
  store.set(key, entry);
  return entry.count <= maxRequests;
}

// Apply rate limiting to all /api/ requests via app.use for CodeQL visibility
app.use('/api/', (req, res, next) => {
  const key = req.ip || 'local';
  const method = req.method;
  const reqPath = req.path;

  // Tightest limit: process-spawning endpoints
  if ((reqPath === '/start' || reqPath.endsWith('/controller/start') ||
       reqPath.endsWith('/recheck') || reqPath.endsWith('/recheck-all') ||
       reqPath.endsWith('/reverify') || reqPath.endsWith('/cookie-exports/generate-bulk')) && method === 'POST') {
    if (!_checkRateLimit(_rlStoreSpawn, key, 5, 60 * 1000)) {
      return res.status(429).json({ error: 'Too many requests, please slow down.' });
    }
    return next();
  }

  // Write limit: all state-mutating methods
  if (method === 'POST' || method === 'PUT' || method === 'DELETE') {
    if (!_checkRateLimit(_rlStoreWrite, key, 30, 60 * 1000)) {
      return res.status(429).json({ error: 'Too many requests, please slow down.' });
    }
    return next();
  }

  // Read limit: all GET requests
  if (!_checkRateLimit(_rlStoreRead, key, 120, 60 * 1000)) {
    return res.status(429).json({ error: 'Too many requests, please slow down.' });
  }
  next();
});

app.use(express.static(path.join(__dirname, 'public')));

// --- SSE Clients -------------------------------------------------------------
const sseClients = new Set();
const SSE_KEEPALIVE_INTERVAL_MS = 25000;

function broadcastSse(event, payload) {
  const data = `event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const res of sseClients) {
    if (res.writableEnded || res.finished) {
      sseClients.delete(res);
      continue;
    }
    try {
      res.write(data);
    } catch (err) {
      try { res.end(); } catch (endErr) { /* ignore secondary cleanup error */ }
      sseClients.delete(res);
    }
  }
}

// Periodic keep-alive messages to prevent proxy/firewall timeouts
setInterval(() => {
  const keepAliveData = ': keep-alive\n\n';
  for (const res of sseClients) {
    if (res.writableEnded || res.finished) {
      sseClients.delete(res);
      continue;
    }
    try {
      res.write(keepAliveData);
    } catch (err) {
      try { res.end(); } catch (endErr) { /* ignore secondary cleanup error */ }
      sseClients.delete(res);
    }
  }
}, SSE_KEEPALIVE_INTERVAL_MS);

// Periodically poll the history file for changes and push new entries to SSE clients.
// This enables real-time history updates in the GUI without requiring an explicit page refresh.
const HISTORY_POLL_INTERVAL_MS = 3000;

setInterval(() => {
  if (!credentialHistory || sseClients.size === 0) return;
  try {
    // Capture file fingerprint before reload so we can detect changes even when
    // the Map size stays the same (e.g. a retry updating an existing credential's status).
    const fpBefore = credentialHistory.getFileFingerprint();
    credentialHistory.reload();
    const fpAfter = credentialHistory.getFileFingerprint();
    if (fpAfter.mtimeMs !== fpBefore.mtimeMs || fpAfter.size !== fpBefore.size) {
      // File changed – broadcast updated stats so the GUI can refresh
      const stats = credentialHistory.getStats();
      broadcastSse('history_updated', { stats });
    }
  } catch (_) {
    // Ignore errors – polling will retry next interval
  }
}, HISTORY_POLL_INTERVAL_MS).unref();

// --- Router ------------------------------------------------------------------
const router = express.Router();

function isPlainObject(obj) {
  return obj !== null &&
    typeof obj === 'object' &&
    Object.getPrototypeOf(obj) === Object.prototype;
}

const _DANGEROUS_KEYS = new Set(['__proto__', 'constructor', 'prototype']);

function deepMerge(target, source) {
  if (!isPlainObject(target) || !isPlainObject(source)) {
    return;
  }
  for (const key of Object.keys(source)) {
    if (_DANGEROUS_KEYS.has(key)) {
      continue;
    }
    const value = source[key];
    if (isPlainObject(value)) {
      if (!isPlainObject(target[key])) {
        target[key] = {};
      }
      deepMerge(target[key], value);
    } else {
      target[key] = value;
    }
  }
}

/**
 * Persist the current runtime config to disk with a timestamped backup.
 * @returns {{ backupPath: string }} The path of the created backup file.
 * @throws {Error} If the file system operation fails.
 */
function persistConfigToDisk() {
  const configPath = path.join(__dirname, '..', 'config.js');
  const backupPath = `${configPath}.backup.${Date.now()}`;
  fs.copyFileSync(configPath, backupPath);
  const configStr = [
    '/**',
    ' * Centralized Configuration for play_version2_improved.js',
    ' * All magic numbers and settings in one place',
    ' */',
    '',
    'module.exports = ' + JSON.stringify(config, null, 2) + ';',
    ''
  ].join('\n');
  fs.writeFileSync(configPath, configStr, 'utf8');
  return { backupPath };
}

// -- Config -------------------------------------------------------------------
router.get('/config', (req, res) => {
  try {
    res.json(config);
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.put('/config', (req, res) => {
  try {
    const updates = req.body;

    const validKeys = [
      'browser', 'proxy', 'batch', 'form', 'navigation', 'login', 'account',
      'detection', 'output', 'logging', 'casDetection', 'context', 'errorRecovery',
      'test', 'retry', 'history', 'queue', 'session', 'cookieExport', 'notifications', 'ux',
      'performance', 'stability', 'captcha'
    ];

    for (const key in updates) {
      if (!validKeys.includes(key)) {
        return res.status(400).json({ error: `Invalid configuration key: ${key}`, validKeys });
      }
    }

    if (updates.batch) {
      if (updates.batch.maxParallelWorkers !== undefined) {
        const workers = updates.batch.maxParallelWorkers;
        if (typeof workers !== 'number' || workers < 1 || workers > 50) {
          return res.status(400).json({ error: 'maxParallelWorkers must be between 1 and 50' });
        }
      }
      if (updates.batch.credentialsPerProxy !== undefined) {
        const creds = updates.batch.credentialsPerProxy;
        if (typeof creds !== 'number' || creds < 1 || creds > 100) {
          return res.status(400).json({ error: 'credentialsPerProxy must be between 1 and 100' });
        }
      }
    }

    if (updates.queue && updates.queue.defaultPriority !== undefined) {
      const priority = updates.queue.defaultPriority;
      if (typeof priority !== 'number' || priority < 1 || priority > 5) {
        return res.status(400).json({ error: 'defaultPriority must be between 1 and 5' });
      }
    }

    deepMerge(config, updates);
    res.json({ success: true, config });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.post('/config/save', (req, res) => {
  try {
    const { backupPath } = persistConfigToDisk();
    res.json({ success: true, message: 'Configuration saved to disk', backup: backupPath });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

// -- Profiles -----------------------------------------------------------------
router.post('/profiles/apply', (req, res) => {
  try {
    const { profile: profileName } = req.body;
    if (!profileName || typeof profileName !== 'string') {
      return res.status(400).json({ success: false, error: 'Profile name is required' });
    }

    if (!getProfile(profileName)) {
      return res.status(404).json({ success: false, error: `Unknown profile: ${profileName}` });
    }

    const merged = applyProfile(config, profileName);

    // Deep-merge the result back into the runtime config object
    deepMerge(config, merged);
    config.activeProfile = profileName;

    let persisted = false;
    try {
      persistConfigToDisk();
      persisted = true;
    } catch (_) {
      // Non-fatal: runtime change still applied even if disk write fails
    }

    res.json({ success: true, persisted });
  } catch (error) {
    res.status(500).json({ success: false, error: safeError(error) });
  }
});

// -- Credentials & Proxies ----------------------------------------------------
router.get('/credentials', (req, res) => {
  try {
    const credPath = path.join(__dirname, '..', 'test.txt');
    if (!fs.existsSync(credPath)) return res.json({ lines: [], count: 0 });
    const content = fs.readFileSync(credPath, 'utf8');
    const count = content.split('\n').filter(l => l.trim() && !l.trim().startsWith('#')).length;
    res.json({ lines: content, count });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.put('/credentials', (req, res) => {
  try {
    const { content } = req.body;
    const credPath = path.join(__dirname, '..', 'test.txt');
    fs.writeFileSync(credPath, content, 'utf8');
    const count = content.split('\n').filter(l => l.trim() && !l.trim().startsWith('#')).length;
    res.json({ success: true, count });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.get('/proxies', (req, res) => {
  try {
    const proxyPath = path.join(__dirname, '..', 'Lightning_Proxies.txt');
    if (!fs.existsSync(proxyPath)) return res.json({ lines: [], count: 0 });
    const content = fs.readFileSync(proxyPath, 'utf8');
    const count = content.split('\n').filter(l => l.trim() && !l.trim().startsWith('#')).length;
    res.json({ lines: content, count });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.put('/proxies', (req, res) => {
  try {
    const { content } = req.body;
    const proxyPath = path.join(__dirname, '..', 'Lightning_Proxies.txt');
    fs.writeFileSync(proxyPath, content, 'utf8');
    const count = content.split('\n').filter(l => l.trim() && !l.trim().startsWith('#')).length;
    res.json({ success: true, count });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

// -- Status -------------------------------------------------------------------
router.get('/status', (req, res) => {
  return res.json({
    controller: {
      running: !!(controllerProcess && !controllerProcess.killed),
      pid: controllerProcess ? controllerProcess.pid : null,
      uptimeMs: controllerProcess && controllerProcess.startTime
        ? Date.now() - controllerProcess.startTime
        : null,
    },
    queue: comboQueue
      ? { stats: comboQueue.getStats(), files: comboQueue.getFiles().length }
      : { enabled: false },
    history: credentialHistory
      ? { enabled: true }
      : { enabled: false },
    rateLimit: { enabled: true },
    system: {
      platform: os.platform(),
      arch: os.arch(),
      node: process.version,
      cpuCount: os.cpus().length,
      totalMemoryMB: Math.floor(os.totalmem() / 1024 / 1024),
      freeMemoryMB: Math.floor(os.freemem() / 1024 / 1024),
      uptime: os.uptime(),
    },
  });
});

// -- Logs (paged) -------------------------------------------------------------
router.get('/logs', (req, res) => {
  try {
    // Support both 'cursor' (new) and 'since' (legacy) query params
    const since = req.query.since !== undefined ? parseInt(req.query.since, 10) || 0 : null;
    const cursor = since !== null ? since : (parseInt(req.query.cursor, 10) || 0);
    const limit = normalizeLimit(req.query.limit, 200, 1, 1000);
    const slice = logBuffer.slice(cursor, cursor + limit);
    const logs = slice.map(entry =>
      entry && typeof entry === 'object' && Object.prototype.hasOwnProperty.call(entry, 'line')
        ? entry.line
        : entry
    );
    res.json({ logs, offset: cursor + slice.length });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

// -- Logs stream (SSE) --------------------------------------------------------
router.get('/logs/stream', (req, res) => {
  res.set({
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    Connection: 'keep-alive',
  });
  res.flushHeaders();
  res.write('event: hello\ndata: "ok"\n\n');
  sseClients.add(res);
  req.on('close', () => sseClients.delete(res));
});

// -- History ------------------------------------------------------------------
router.get('/history', (req, res) => {
  try {
    if (!credentialHistory) return res.json({ entries: [], total: 0, page: 1, totalPages: 0 });

    credentialHistory.reload();
    const { status, search, sort = 'date_desc', page = 1, limit = 50 } = req.query;
    let entries = credentialHistory.getAll();

    if (status && status !== 'all') {
      entries = entries.filter(e => e.status === status);
    }

    if (search) {
      const lowerSearch = search.toLowerCase();
      entries = entries.filter(e =>
        e.username.toLowerCase().includes(lowerSearch) ||
        e.password.toLowerCase().includes(lowerSearch) ||
        e.status.toLowerCase().includes(lowerSearch) ||
        (e.method && e.method.toLowerCase().includes(lowerSearch))
      );
    }

    const [sortField, sortDir] = (sort || 'date_desc').split('_');
    const direction = sortDir === 'asc' ? 1 : -1;

    entries.sort((a, b) => {
      switch (sortField) {
        case 'points': {
          const aPts = parseFloat(a.pointsBalance) || 0;
          const bPts = parseFloat(b.pointsBalance) || 0;
          if (aPts === 0 && bPts === 0) return 0;
          if (aPts === 0) return direction;
          if (bPts === 0) return -direction;
          return direction * (aPts - bPts);
        }
        case 'money': {
          const aMon = parseFloat(a.moneyBalance) || 0;
          const bMon = parseFloat(b.moneyBalance) || 0;
          if (aMon === 0 && bMon === 0) return 0;
          if (aMon === 0) return direction;
          if (bMon === 0) return -direction;
          return direction * (aMon - bMon);
        }
        case 'confidence':
          return direction * ((a.confidence || 0) - (b.confidence || 0));
        case 'username':
          return direction * a.username.localeCompare(b.username);
        default:
          return direction * (new Date(a.timestamp) - new Date(b.timestamp));
      }
    });

    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const startIdx = (pageNum - 1) * limitNum;
    const paginatedEntries = entries.slice(startIdx, startIdx + limitNum);

    res.json({
      entries: paginatedEntries,
      total: entries.length,
      page: pageNum,
      totalPages: Math.ceil(entries.length / limitNum)
    });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.get('/history/stats', (req, res) => {
  try {
    if (!credentialHistory) {
      return res.json({ total: 0, success: 0, failed: 0, blocked: 0, captcha: 0, other: 0 });
    }
    credentialHistory.reload();
    res.json(credentialHistory.getStats());
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.post('/history/compact', (req, res) => {
  try {
    if (!credentialHistory) return res.status(400).json({ error: 'History not enabled' });
    credentialHistory.compact();
    res.json({ success: true, message: 'History file compacted' });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

// History: export (GET with query params - exports are read operations)
router.get('/history/export', (req, res) => {
  try {
    if (!credentialHistory) return res.status(400).json({ error: 'History not enabled' });

    credentialHistory.reload();
    const { format = 'jsonl', status, gzip: wantGzip } = req.query;
    let entries = credentialHistory.getAll();
    if (status && status !== 'all') entries = entries.filter(e => e.status === status);

    const timestamp = new Date().toISOString().split('T')[0];
    let content = '';
    let filename = '';
    let contentType = '';

    if (format === 'txt') {
      content = entries.map(e => `${e.username}:${e.password}`).join('\n');
      if (content) content += '\n';
      filename = `history_export_${timestamp}.txt`;
      contentType = 'text/plain';
    } else if (format === 'csv') {
      const header = 'username,password,status,method,confidence,pointsBalance,moneyBalance,timestamp\n';
      const rows = entries.map(e =>
        [e.username, e.password, e.status, e.method || '', e.confidence || '',
          e.pointsBalance || '', e.moneyBalance || '', e.timestamp]
          .map(escapeCsvField).join(',')
      ).join('\n');
      content = header + rows + (rows ? '\n' : '');
      filename = `history_export_${timestamp}.csv`;
      contentType = 'text/csv';
    } else if (format === 'json') {
      content = JSON.stringify(entries, null, 2);
      filename = `history_export_${timestamp}.json`;
      contentType = 'application/json';
    } else {
      content = entries.map(e => JSON.stringify({ u: e.username, p: e.password, s: e.status, t: e.timestamp })).join('\n');
      if (content) content += '\n';
      filename = `history_export_${timestamp}.jsonl`;
      contentType = 'application/x-ndjson';
    }

    const useGzip = wantGzip === 'true' || wantGzip === true;
    if (useGzip) {
      const compressed = zlib.gzipSync(content);
      res.setHeader('Content-Encoding', 'gzip');
      res.setHeader('Content-Type', 'application/octet-stream');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}.gz"`);
      return res.send(compressed);
    }
    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(content);
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.post('/history/import', (req, res) => {
  try {
    if (!credentialHistory) return res.status(400).json({ error: 'History not enabled' });

    const { content, format, mode = 'merge' } = req.body;
    if (!content) return res.status(400).json({ error: 'Content is required' });
    if (!format) return res.status(400).json({ error: 'Format is required' });

    let imported = 0;
    let skipped = 0;

    if (mode === 'replace') credentialHistory.history.clear();

    if (format === 'txt') {
      for (const line of content.split('\n').filter(l => l.trim())) {
        const colonIdx = line.indexOf(':');
        if (colonIdx === -1) continue;
        const username = line.substring(0, colonIdx).trim();
        const password = line.substring(colonIdx + 1).trim();
        if (!username || !password) continue;
        const key = credentialHistory._key(username, password);
        if (mode === 'merge' && credentialHistory.history.has(key)) {
          skipped++;
        } else {
          credentialHistory.record(username, password, 'success', {});
          imported++;
        }
      }
    } else if (format === 'jsonl') {
      for (const line of content.split('\n').filter(l => l.trim())) {
        try {
          const entry = JSON.parse(line);
          const u = entry.u || entry.username;
          const p = entry.p || entry.password;
          const s = entry.s || entry.status;
          if (u && p && s) {
            const key = credentialHistory._key(u, p);
            if (mode === 'merge' && credentialHistory.history.has(key)) {
              skipped++;
            } else {
              const details = {};
              if (entry.m || entry.method) details.method = entry.m || entry.method;
              if (entry.c !== undefined) details.confidence = entry.c;
              else if (entry.confidence !== undefined) details.confidence = entry.confidence;
              if (entry.r || entry.reason) details.reason = entry.r || entry.reason;
              if (entry.pts || entry.pointsBalance) details.pointsBalance = entry.pts || entry.pointsBalance;
              if (entry.chf || entry.moneyBalance) details.moneyBalance = entry.chf || entry.moneyBalance;
              credentialHistory.record(u, p, s, details);
              const origTimestamp = entry.t || entry.timestamp;
              if (origTimestamp) {
                const k = credentialHistory._key(u, p);
                const stored = credentialHistory.history.get(k);
                if (stored) stored.t = origTimestamp;
              }
              imported++;
            }
          }
        } catch (e) {
          // skip invalid lines
        }
      }
    }

    res.json({ success: true, imported, skipped, mode });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.post('/history/import-logs', (req, res) => {
  try {
    if (!credentialHistory) return res.status(400).json({ error: 'History not enabled' });

    const { mode = 'merge', logsDir: logsDirParam } = req.body || {};
    if (logsDirParam != null && typeof logsDirParam !== 'string') {
      return res.status(400).json({ error: 'logsDir must be a string' });
    }
    if (logsDirParam && logsDirParam.indexOf('\0') !== -1) {
      return res.status(400).json({ error: 'logsDir contains invalid characters' });
    }
    const logsDir = path.resolve(logsDirParam || path.join(process.cwd(), 'logs'));

    if (!fs.existsSync(logsDir)) {
      return res.status(400).json({ error: `Logs directory not found: ${logsDir}` });
    }

    let stats;
    try {
      stats = fs.statSync(logsDir);
    } catch (err) {
      if (err && (err.code === 'EACCES' || err.code === 'EPERM')) {
        return res.status(403).json({ error: `Cannot access logs directory: ${logsDir}` });
      }
      return res.status(400).json({ error: `Invalid logs directory: ${logsDir}` });
    }

    if (!stats.isDirectory()) {
      return res.status(400).json({ error: `Path is not a directory: ${logsDir}` });
    }

    if (mode === 'replace') credentialHistory.history.clear();

    // Map of subdirectory → history status + field extractor
    const dirConfigs = {
      successful: {
        status: 'success',
        extract: e => ({
          method: e.method,
          confidence: e.confidence,
          pointsBalance: e.pointsBalance,
          moneyBalance: e.moneyBalance
        })
      },
      failed: {
        status: 'failed',
        extract: e => ({ reason: e.reason })
      },
      blocked: {
        status: 'blocked',
        extract: e => ({ reason: e.reason })
      },
      captcha: {
        status: 'captcha',
        extract: () => ({})
      },
      errors: {
        status: 'failed',
        extract: e => ({ reason: e.error })
      }
    };

    let totalImported = 0;
    let totalSkipped = 0;
    let totalErrors = 0;
    let filesProcessed = 0;
    const breakdown = {};

    for (const [subdir, cfg] of Object.entries(dirConfigs)) {
      const dirPath = path.join(logsDir, subdir);
      breakdown[subdir] = { files: 0, imported: 0, skipped: 0, errors: 0 };

      if (!fs.existsSync(dirPath)) continue;

      const files = fs.readdirSync(dirPath).filter(f => f.endsWith('.jsonl'));
      breakdown[subdir].files = files.length;
      filesProcessed += files.length;

      for (const file of files) {
        const filePath = path.join(dirPath, file);
        let content;
        try {
          content = fs.readFileSync(filePath, 'utf8');
        } catch (e) {
          breakdown[subdir].errors++;
          totalErrors++;
          continue;
        }

        for (const line of content.split('\n').filter(l => l.trim())) {
          try {
            const entry = JSON.parse(line);
            const username = entry.username || entry.u;
            const password = entry.password || entry.p;
            if (!username || !password) continue;

            const key = credentialHistory._key(username, password);
            if (mode === 'merge' && credentialHistory.history.has(key)) {
              breakdown[subdir].skipped++;
              totalSkipped++;
            } else {
              const details = cfg.extract(entry);
              credentialHistory.record(username, password, cfg.status, details);
              const origTimestamp = entry.timestamp || entry.t;
              if (origTimestamp) {
                const stored = credentialHistory.history.get(key);
                if (stored) stored.t = origTimestamp;
              }
              breakdown[subdir].imported++;
              totalImported++;
            }
          } catch (e) {
            breakdown[subdir].errors++;
            totalErrors++;
          }
        }
      }
    }

    credentialHistory.compact();

    res.json({
      success: true,
      logsDir,
      mode,
      filesProcessed,
      totalImported,
      totalSkipped,
      totalErrors,
      breakdown
    });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

// -- Used Entries -------------------------------------------------------------
router.get('/history/used', (req, res) => {
  try {
    if (!usedEntries) return res.json({ entries: [] });
    res.json({ entries: usedEntries.getAll() });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.post('/history/mark-used', (req, res) => {
  try {
    if (!usedEntries) return res.status(503).json({ error: 'Used entries not available' });
    const { username, password, notes, status, method, pointsBalance, moneyBalance } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'username and password are required' });
    }
    const entry = usedEntries.markUsed(username, password, { notes, status, method, pointsBalance, moneyBalance });
    res.json({ success: true, entry: {
      username: entry.u,
      password: entry.p,
      status: entry.s,
      method: entry.m,
      pointsBalance: entry.pts,
      moneyBalance: entry.chf,
      usedAt: entry.usedAt,
      notes: entry.notes
    }});
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.post('/history/unmark-used', (req, res) => {
  try {
    if (!usedEntries) return res.status(503).json({ error: 'Used entries not available' });
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'username and password are required' });
    }
    const existed = usedEntries.unmarkUsed(username, password);
    res.json({ success: true, existed });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.put('/history/update-note', (req, res) => {
  try {
    if (!usedEntries) return res.status(503).json({ error: 'Used entries not available' });
    const { username, password, notes } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'username and password are required' });
    }
    if (notes === undefined) {
      return res.status(400).json({ error: 'notes is required' });
    }
    const updated = usedEntries.updateNote(username, password, notes);
    if (!updated) {
      return res.status(404).json({ error: 'Entry not found in used list' });
    }
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

// -- Queue --------------------------------------------------------------------
router.get('/queue', (req, res) => {
  try {
    if (!comboQueue) return res.status(503).json({ error: 'Queue is not enabled' });
    res.json({ stats: comboQueue.getStats(), files: comboQueue.getFiles() });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.get('/queue/stats', (req, res) => {
  try {
    if (!comboQueue) return res.status(503).json({ error: 'Queue is not enabled' });
    res.json(comboQueue.getStats());
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.post('/queue/add', (req, res) => {
  try {
    if (!comboQueue) return res.status(503).json({ error: 'Queue is not enabled' });
    const { content, sourceName, priority } = req.body;
    if (!content) return res.status(400).json({ error: 'Content is required' });
    if (!sourceName) return res.status(400).json({ error: 'Source name is required' });
    const stats = comboQueue.addCombos(content.split('\n'), sourceName, { priority: priority || 3 });
    res.json({ success: true, stats });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

// Queue: import (csv/jsonl/json) with dry-run & optional gzip input (base64 string)
router.post('/queue/import', (req, res) => {
  if (!comboQueue) return res.status(503).json({ error: 'Queue not enabled' });

  const { format = 'csv', priority = 3, dryRun = false, data, sourceName, gzip = false } = req.body;
  if (!data) return res.status(400).json({ error: 'data is required' });
  const priorityNum = Number(priority);
  if (!Number.isInteger(priorityNum) || priorityNum < 1 || priorityNum > 5) {
    return res.status(400).json({ error: 'priority must be an integer between 1 and 5' });
  }

  // Validate encoded payload size before decoding to avoid excessive memory use
  const MAX_DECODED_BYTES = 10 * 1024 * 1024;
  if (data.length > Math.ceil(MAX_DECODED_BYTES * 4 / 3)) {
    return res.status(400).json({ error: 'Data payload too large' });
  }

  let text;
  try {
    const buf = gzip ? zlib.gunzipSync(Buffer.from(data, 'base64')) : Buffer.from(data, 'base64');
    if (buf.length > MAX_DECODED_BYTES) {
      return res.status(400).json({ error: 'Decoded data exceeds maximum allowed size' });
    }
    text = buf.toString('utf8');
  } catch (e) {
    return res.status(400).json({ error: 'Failed to decode/gunzip data' });
  }

  let combos = [];
  if (format === 'csv') {
    combos = parseCsvLines(text).map(c => ({ ...c, priority: priorityNum }));
  } else if (format === 'jsonl') {
    combos = text
      .split('\n')
      .map(l => l.trim())
      .filter(Boolean)
      .map(l => {
        try {
          const o = JSON.parse(l);
          if (o.u && o.p) return { username: o.u, password: o.p, priority: o.pr || priorityNum };
          if (o.username && o.password) return { username: o.username, password: o.password, priority: o.priority || priorityNum };
          return null;
        } catch (_) { return null; }
      })
      .filter(Boolean);
  } else if (format === 'json') {
    try {
      const arr = JSON.parse(text);
      if (Array.isArray(arr)) {
        combos = arr
          .map(o => {
            if (o.u && o.p) return { username: o.u, password: o.p, priority: o.pr || priorityNum };
            if (o.username && o.password) return { username: o.username, password: o.password, priority: o.priority || priorityNum };
            return null;
          })
          .filter(Boolean);
      }
    } catch (e) {
      return res.status(400).json({ error: 'Invalid JSON' });
    }
  } else {
    return res.status(400).json({ error: 'Unsupported format' });
  }

  if (!combos.length) return res.status(400).json({ error: 'No combos parsed' });

  if (dryRun) {
    return res.json({ success: true, dryRun: true, parsed: combos.length });
  }

  const lines = combos.map(c => `${c.username}:${c.password}`);
  const stats = comboQueue.addCombos(lines, sourceName || 'import', { priority: priorityNum });
  return res.json({ success: true, stats, parsed: combos.length });
});

// Queue: export (json|csv|jsonl) optional gzip
router.get('/queue/export', (req, res) => {
  try {
    if (!comboQueue) return res.status(503).json({ error: 'Queue not enabled' });

  const { format = 'csv', gzip: wantGzip = false } = req.query || {};
  const combos = Array.from(comboQueue.combos.values());
  const timestamp = new Date().toISOString().split('T')[0];

    let content = '';
    let filename = '';
    if (format === 'csv' || format === 'txt') {
      content = combos.map(c => `${c.username}:${c.password}`).join('\n');
      if (content) content += '\n';
      filename = `queue_export_${timestamp}.txt`;
    } else if (format === 'json') {
      content = JSON.stringify(combos, null, 2);
      filename = `queue_export_${timestamp}.json`;
    } else if (format === 'jsonl') {
      content = combos.map(c => JSON.stringify({ u: c.username, p: c.password, pr: c.priority || 3 })).join('\n');
      filename = `queue_export_${timestamp}.jsonl`;
    } else {
      return res.status(400).json({ error: 'Unsupported format' });
    }

    const useGzip = wantGzip === 'true' || wantGzip === true;
    if (useGzip) {
      const compressed = zlib.gzipSync(content);
      res.setHeader('Content-Encoding', 'gzip');
      res.setHeader('Content-Type', 'application/octet-stream');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}.gz"`);
      return res.send(compressed);
    }
    res.setHeader('Content-Type', 'text/plain');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(content);
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.put('/queue/priority', (req, res) => {
  try {
    if (!comboQueue) return res.status(503).json({ error: 'Queue is not enabled' });
    const { filename, priority } = req.body;
    if (!filename) return res.status(400).json({ error: 'Filename is required' });
    if (priority === undefined || priority < 1 || priority > 5) {
      return res.status(400).json({ error: 'Priority must be between 1 and 5' });
    }
    if (!comboQueue.setPriority(filename, priority)) {
      return res.status(404).json({ error: 'File not found in queue' });
    }
    res.json({ success: true, message: 'Priority updated successfully' });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.delete('/queue/file', (req, res) => {
  try {
    if (!comboQueue) return res.status(503).json({ error: 'Queue is not enabled' });
    const { filename } = req.body;
    if (!filename) return res.status(400).json({ error: 'Filename is required' });
    if (!comboQueue.removeFile(filename)) {
      return res.status(404).json({ error: 'File not found in queue' });
    }
    res.json({ success: true, message: 'File removed successfully' });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.post('/queue/clear', (req, res) => {
  try {
    if (!comboQueue) return res.status(503).json({ error: 'Queue is not enabled' });
    res.json({ success: true, cleared: comboQueue.clearCompleted() });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.post('/queue/shuffle', (req, res) => {
  try {
    if (!comboQueue) return res.status(503).json({ error: 'Queue is not enabled' });
    comboQueue.shuffle();
    res.json({ success: true, message: 'Queue shuffled successfully' });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.post('/queue/pause', (req, res) => {
  try {
    if (!comboQueue) return res.status(503).json({ error: 'Queue is not enabled' });
    comboQueue.pause();
    res.json({ success: true, message: 'Queue paused' });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.post('/queue/resume', (req, res) => {
  try {
    if (!comboQueue) return res.status(503).json({ error: 'Queue is not enabled' });
    comboQueue.resume();
    res.json({ success: true, message: 'Queue resumed' });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});




// -- Controller ---------------------------------------------------------------

/**
 * Attach stdout, stderr, error, and exit handlers to a controller process.
 * Ensures SSE timestamps are consistent with log buffer timestamps.
 */
function _attachControllerHandlers(proc) {
  proc.stdout.on('data', (data) => {
    data.toString().split('\n').forEach(line => {
      if (line.trim()) {
        const ts = addToLogBuffer(line);
        broadcastSse('log', { ts, line });
      }
    });
  });
  proc.stderr.on('data', (data) => {
    data.toString().split('\n').forEach(line => {
      if (line.trim() && isActualError(line)) {
        const msg = '[ERROR] ' + line;
        const ts = addToLogBuffer(msg);
        broadcastSse('log', { ts, line: msg });
      }
    });
  });
  proc.on('error', (err) => {
    const msg = `[ERROR] Controller process error: ${err.message}`;
    const ts = addToLogBuffer(msg);
    broadcastSse('log', { ts, line: msg });
    controllerProcess = null;
  });
  proc.on('exit', (code, signal) => {
    const msg = `[GUI] Controller exited with code ${code}, signal ${signal}`;
    const ts = addToLogBuffer(msg);
    broadcastSse('log', { ts, line: msg });
    controllerProcess = null;
  });
}

router.get('/controller/status', (req, res) => {
  res.json({
    running: !!controllerProcess,
    pid: controllerProcess ? controllerProcess.pid : null
  });
});

// Controller: start/stop/restart
function spawnController() {
  const controllerPath = path.join(__dirname, '..', 'play_version2_controller.js');
  controllerProcess = spawn('node', [controllerPath, '--no-interactive'], {
    cwd: path.join(__dirname, '..'),
    stdio: ['ignore', 'pipe', 'pipe']
  });
  controllerProcess.startTime = Date.now();
  _attachControllerHandlers(controllerProcess);

  return controllerProcess;
}

router.post('/controller/start', (req, res) => {
  try {
    if (controllerProcess && !controllerProcess.killed) {
      return res.status(400).json({ error: 'Controller already running' });
    }

    // Auto-create Lightning_Proxies.txt if missing to prevent validation errors
    const proxyPath = path.join(__dirname, '..', 'Lightning_Proxies.txt');
    if (!fs.existsSync(proxyPath)) {
      fs.writeFileSync(proxyPath,
        '# Add proxies here, one per line\n# Format: host:port or host:port:user:pass\n', 'utf8');
    }

    logBuffer.splice(0, logBuffer.length);
    addToLogBuffer('[GUI] Starting controller process...');

    const proc = spawnController();
    return res.json({ success: true, pid: proc.pid, message: 'Controller started' });
  } catch (error) {
    return res.status(500).json({ error: safeError(error) });
  }
});

router.post('/controller/stop', (req, res) => {
  try {
    if (!controllerProcess || controllerProcess.killed) {
      return res.status(400).json({ error: 'Controller not running' });
    }
    addToLogBuffer('[GUI] Stopping controller process...');
    controllerProcess.kill('SIGTERM');
    res.json({ success: true, message: 'Stop signal sent to controller' });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

// Proper atomic restart: wait for the existing process to exit then spawn a new one
router.post('/controller/restart', (req, res) => {
  try {
    addToLogBuffer('[GUI] Restarting controller process...');
    if (controllerProcess && !controllerProcess.killed) {
      controllerProcess.once('exit', () => {
        const proc = spawnController();
        broadcastSse('status', { running: true, pid: proc.pid });
        addToLogBuffer('[GUI] Controller restarted successfully');
      });
      controllerProcess.kill('SIGTERM');
    } else {
      spawnController();
    }
    return res.json({ success: true, message: 'Controller restart initiated' });
  } catch (error) {
    return res.status(500).json({ error: safeError(error) });
  }
});

// Re-check a single credential
router.post('/recheck', (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || typeof username !== 'string') {
      return res.status(400).json({ error: 'username is required' });
    }
    if (!password || typeof password !== 'string') {
      return res.status(400).json({ error: 'password is required' });
    }
    if (controllerProcess && !controllerProcess.killed) {
      return res.status(400).json({ error: 'Controller already running' });
    }

    const testPath = path.join(__dirname, '..', 'test.txt');
    fs.writeFileSync(testPath, `${username}:${password}\n`, 'utf8');

    const proxyPath = path.join(__dirname, '..', 'Lightning_Proxies.txt');
    if (!fs.existsSync(proxyPath)) {
      fs.writeFileSync(proxyPath,
        '# Add proxies here, one per line\n# Format: host:port or host:port:user:pass\n', 'utf8');
    }

    logBuffer.splice(0, logBuffer.length);
    addToLogBuffer(`[GUI] Re-check started for ${username}`);

    spawnController();
    return res.json({ success: true, message: `Re-check started for ${username}` });
  } catch (error) {
    return res.status(500).json({ error: safeError(error) });
  }
});

// Re-check all entries by status
router.post('/recheck-all', (req, res) => {
  try {
    const { status = 'success' } = req.body;

    if (!credentialHistory) {
      return res.status(400).json({ error: 'History not enabled' });
    }
    if (controllerProcess && !controllerProcess.killed) {
      return res.status(400).json({ error: 'Controller already running' });
    }

    const entries = credentialHistory.getByStatus(status);
    if (!entries || entries.length === 0) {
      return res.status(400).json({ error: `No entries found with status: ${status}` });
    }

    const testPath = path.join(__dirname, '..', 'test.txt');
    const lines = entries.map(e => `${e.username}:${e.password}`).join('\n');
    fs.writeFileSync(testPath, lines + '\n', 'utf8');

    const proxyPath = path.join(__dirname, '..', 'Lightning_Proxies.txt');
    if (!fs.existsSync(proxyPath)) {
      fs.writeFileSync(proxyPath,
        '# Add proxies here, one per line\n# Format: host:port or host:port:user:pass\n', 'utf8');
    }

    logBuffer.splice(0, logBuffer.length);
    addToLogBuffer(`[GUI] Re-check started for ${entries.length} combos`);

    spawnController();
    return res.json({ success: true, message: `Re-check started for ${entries.length} combos`, count: entries.length });
  } catch (error) {
    return res.status(500).json({ error: safeError(error) });
  }
});

// POST /api/reverify — Manual verification mode: opens visible browser, fills credentials, waits for user
router.post('/reverify', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || typeof username !== 'string') {
      return res.status(400).json({ error: 'username is required' });
    }
    if (!password || typeof password !== 'string') {
      return res.status(400).json({ error: 'password is required' });
    }

    // Respond immediately — browser launch is fire-and-forget
    res.json({ success: true, message: `Reverify browser opening for ${username}` });

    (async () => {
      const ProxyChain = require('proxy-chain');
      let anonymizedProxyUrl = null;
      try {
        const { chromium } = require('patchright');

        // Determine proxy from proxy file and normalise to a full URL
        const proxyPath = path.join(__dirname, '..', 'Lightning_Proxies.txt');
        let proxyUrl = null;   // full upstream URL  e.g. http://user:pass@host:port
        if (fs.existsSync(proxyPath)) {
          const proxyLines = fs.readFileSync(proxyPath, 'utf8')
            .split('\n')
            .map(l => l.trim())
            .filter(l => l && !l.startsWith('#'));
          if (proxyLines.length > 0) {
            const randomProxy = proxyLines[Math.floor(Math.random() * proxyLines.length)];
            if (randomProxy.match(/^(https?|socks5?):\/\//i)) {
              proxyUrl = randomProxy;
            } else {
              const parts = randomProxy.split(':');
              if (parts.length >= 4) {
                const host = parts[0];
                const port = parts[1];
                const user = parts[2];
                const pass = parts.slice(3).join(':');
                proxyUrl = `http://${encodeURIComponent(user)}:${encodeURIComponent(pass)}@${host}:${port}`;
              } else if (parts.length >= 2) {
                proxyUrl = `http://${parts[0]}:${parts[1]}`;
              }
            }
          }
        }

        // Use ProxyChain to anonymise the proxy so the browser never sees a
        // credential challenge (same approach as the main worker).
        let browserProxyUrl = null;
        if (proxyUrl) {
          if (/^socks/i.test(proxyUrl)) {
            // SOCKS proxies are passed directly — ProxyChain does not handle them
            browserProxyUrl = proxyUrl;
          } else {
            anonymizedProxyUrl = await ProxyChain.anonymizeProxy(proxyUrl);
            browserProxyUrl = anonymizedProxyUrl;
          }
        }

        const launchArgs = ['--start-maximized'];
        if (browserProxyUrl) {
          launchArgs.push(`--proxy-server=${browserProxyUrl}`);
        }

        const launchOptions = {
          headless: false,
          channel: config.browser && config.browser.channel ? config.browser.channel : 'chrome',
          viewport: null,
          args: launchArgs
        };

        const browser = await chromium.launch(launchOptions);
        const context = await browser.newContext({ viewport: null });
        const page = await context.newPage();

        // Navigate to login page
        const loginUrl = (config.login && config.login.url) ? config.login.url : 'https://login.supercard.ch/';
        await page.goto(loginUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });

        // Dismiss cookie popup if present
        try {
          const cookieSelector = (config.login && config.login.onetrust) ? config.login.onetrust : '#onetrust-accept-btn-handler';
          const cookieBtn = await page.$(cookieSelector);
          if (cookieBtn) {
            await cookieBtn.click();
            await page.waitForTimeout(500);
          }
        } catch (_) {}

        // Wait for page to fully render
        await page.waitForTimeout(1000);

        // Fill credentials but do NOT submit
        const usernameSelector = (config.login && config.login.usernameSelector) ? config.login.usernameSelector : '#username';
        const passwordSelector = (config.login && config.login.passwordSelector) ? config.login.passwordSelector : '#password';

        await page.click(usernameSelector);
        await page.type(usernameSelector, username, { delay: 50 });

        await page.click(passwordSelector);
        await page.type(passwordSelector, password, { delay: 50 });

        addToLogBuffer(`[GUI] Reverify browser opened for ${username} — waiting for manual login`);

        // Keep browser open — user closes it manually
        browser.on('disconnected', () => {
          addToLogBuffer(`[GUI] Reverify browser closed for ${username}`);
          // Clean up the local anonymised proxy server
          if (anonymizedProxyUrl) {
            ProxyChain.closeAnonymizedProxy(anonymizedProxyUrl, true).catch(() => {});
          }
        });

      } catch (err) {
        addToLogBuffer(`[GUI] Reverify browser error for ${username}: ${err.message}`);
        // Clean up the local anonymised proxy server on error
        if (anonymizedProxyUrl) {
          ProxyChain.closeAnonymizedProxy(anonymizedProxyUrl, true).catch(() => {});
        }
      }
    })();
  } catch (error) {
    return res.status(500).json({ error: safeError(error) });
  }
});

// Legacy start/stop endpoints (backward compatibility)
router.post('/start', (req, res) => {
  try {
    if (controllerProcess && !controllerProcess.killed) {
      return res.status(400).json({ error: 'Controller already running' });
    }
    logBuffer.splice(0, logBuffer.length);
    addToLogBuffer('[GUI] Starting controller process...');

    const proxyFile = path.join(__dirname, '..', 'Lightning_Proxies.txt');
    if (!fs.existsSync(proxyFile)) {
      fs.writeFileSync(proxyFile,
        '# Add proxies here, one per line\n# Format: host:port or host:port:user:pass\n', 'utf8');
    }

    const controllerPath = path.join(__dirname, '..', 'play_version2_controller.js');
    controllerProcess = spawn('node', [controllerPath, '--no-interactive'], {
      cwd: path.join(__dirname, '..'),
      stdio: ['ignore', 'pipe', 'pipe']
    });
    controllerProcess.startTime = Date.now();
    _attachControllerHandlers(controllerProcess);

    res.json({ success: true, pid: controllerProcess.pid, message: 'Controller started' });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.post('/stop', (req, res) => {
  try {
    if (!controllerProcess || controllerProcess.killed) {
      return res.status(400).json({ error: 'Controller not running' });
    }
    addToLogBuffer('[GUI] Stopping controller process...');
    controllerProcess.kill('SIGTERM');
    res.json({ success: true, message: 'Stop signal sent to controller' });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});


// -- Backup -------------------------------------------------------------------
const ROOT_DIR = path.join(__dirname, '..');
const BACKUP_FILES = ['test.txt', 'Lightning_Proxies.txt', 'combo_queue.json'];
const BACKUP_DIRS  = ['RetryQueue', 'FailedCombos', 'Logs', 'Queue'];
const BACKUP_FILE_SIZE_LIMIT = 10 * 1024 * 1024; // 10 MB per file

function collectBackupData() {
  const files = {};
  for (const name of BACKUP_FILES) {
    const fp = path.join(ROOT_DIR, name);
    if (fs.existsSync(fp)) {
      const stat = fs.lstatSync(fp);
      if (!stat.isSymbolicLink() && stat.isFile() && stat.size <= BACKUP_FILE_SIZE_LIMIT) {
        files[name] = fs.readFileSync(fp, 'utf8');
      }
    }
  }
  for (const dir of BACKUP_DIRS) {
    const dp = path.join(ROOT_DIR, dir);
    if (!fs.existsSync(dp)) continue;
    const dirStat = fs.lstatSync(dp);
    if (!dirStat.isDirectory() || dirStat.isSymbolicLink()) continue;
    for (const entry of fs.readdirSync(dp)) {
      const ep = path.join(dp, entry);
      const eStat = fs.lstatSync(ep);
      if (!eStat.isSymbolicLink() && eStat.isFile() && eStat.size <= BACKUP_FILE_SIZE_LIMIT) {
        files[`${dir}/${entry}`] = fs.readFileSync(ep, 'utf8');
      }
    }
  }
  return files;
}

router.get('/backup/create', async (req, res) => {
  try {
    const manifest = { created: new Date().toISOString(), files: collectBackupData() };
    const json = JSON.stringify(manifest);
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').split('T').join('_').slice(0, 19);
    const filename = `spm_backup_${timestamp}.json.gz`;
    const compressed = await zlib.promises.gzip(json);
    res.setHeader('Content-Type', 'application/gzip');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(compressed);
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.post('/backup/restore', async (req, res) => {
  try {
    const { data } = req.body; // base64-encoded gzip content
    if (!data) return res.status(400).json({ error: 'No backup data provided' });
    const compressed = Buffer.from(data, 'base64');
    let decompressed;
    try {
      decompressed = await zlib.promises.gunzip(compressed);
    } catch (e) {
      return res.status(400).json({ error: 'Invalid backup file: ' + e.message });
    }
    let manifest;
    try { manifest = JSON.parse(decompressed.toString()); } catch (e) {
      return res.status(400).json({ error: 'Corrupt backup file' });
    }
    const restored = [];
    const resolvedRoot = path.resolve(ROOT_DIR);
    for (const [relPath, fileContent] of Object.entries(manifest.files || {})) {
      const absPath = path.resolve(ROOT_DIR, relPath);
      // Prevent path traversal attacks
      if (!absPath.startsWith(resolvedRoot + path.sep) && absPath !== resolvedRoot) {
        return res.status(400).json({ error: `Invalid path in backup: ${relPath}` });
      }
      const dir = path.dirname(absPath);
      await fs.promises.mkdir(dir, { recursive: true });
      await fs.promises.writeFile(absPath, fileContent, 'utf8');
      restored.push(relPath);
    }
    res.json({ success: true, restored, created: manifest.created });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

// -- Cookie Exports -----------------------------------------------------------
const cookieExporter = new CookieExporter({
  exportDir: path.join(__dirname, '..', (config.cookieExport && config.cookieExport.exportDir) || 'CookieExports'),
  enabled: true // always allow listing/downloading regardless of feature flag
});

router.get('/cookie-exports', (req, res) => {
  try {
    res.json({ exports: cookieExporter.listExports() });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.get('/cookie-exports/:filename', (req, res) => {
  try {
    const data = cookieExporter.readExport(req.params.filename);
    if (!data) return res.status(404).json({ error: 'Export not found' });
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="${path.basename(req.params.filename)}"`);
    res.send(JSON.stringify(data, null, 2));
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.delete('/cookie-exports/:filename', (req, res) => {
  try {
    const safe = path.basename(req.params.filename);
    const fp = path.join(cookieExporter.exportDir, safe);
    if (!fs.existsSync(fp)) return res.status(404).json({ error: 'Export not found' });
    fs.unlinkSync(fp);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

// -- Bulk Cookie Generation ---------------------------------------------------

/** Tracks the single active (or last completed) bulk generation job. */
let bulkCookieJob = null;

router.post('/cookie-exports/generate-bulk', (req, res) => {
  try {
    // Validate concurrency
    let concurrency = parseInt((req.body && req.body.concurrency) || 1, 10);
    const maxConc = (config.bulkCookieGenerator && config.bulkCookieGenerator.maxConcurrency) || 5;
    if (isNaN(concurrency) || concurrency < 1) concurrency = 1;
    if (concurrency > maxConc) concurrency = maxConc;

    // Validate amount — must be a positive integer, max 2000
    // Optionally constrain to allowedAmounts if configured
    let amount = parseInt((req.body && req.body.amount) || 100, 10);
    if (isNaN(amount) || amount < 1) amount = 100;
    if (amount > 2000) {
      return res.status(400).json({ error: 'amount must be between 1 and 2000' });
    }
    const allowedAmounts = config.bulkCookieGenerator && config.bulkCookieGenerator.allowedAmounts;
    if (Array.isArray(allowedAmounts) && allowedAmounts.length > 0 && !allowedAmounts.includes(amount)) {
      return res.status(400).json({ error: `amount must be one of: ${allowedAmounts.join(', ')}` });
    }

    const headless = !!(req.body && req.body.headless);

    // Only one job at a time
    if (bulkCookieJob && bulkCookieJob.running) {
      return res.status(409).json({ error: 'A bulk generation job is already running' });
    }

    const jobId = crypto.randomBytes(8).toString('hex');
    const outputDir = path.join(
      __dirname, '..',
      (config.bulkCookieGenerator && config.bulkCookieGenerator.outputDir) || 'CookieExports'
    );

    bulkCookieJob = {
      id:         jobId,
      running:    true,
      progress:   { current: 0, total: amount, successful: 0, failed: 0 },
      startedAt:  new Date().toISOString(),
      outputPath: null
    };

    const generator = new BulkCookieGenerator({ amount, outputDir, concurrency, headless });

    generator.on('progress', ({ current, total, successful, failed }) => {
      if (bulkCookieJob && bulkCookieJob.id === jobId) {
        bulkCookieJob.progress = { current, total, successful, failed };
      }
      addToLogBuffer(`[BulkCookieGenerator] Progress: ${current}/${total}  ✓ ${successful}  ✗ ${failed}`);
    });

    generator.on('done', ({ outputPath, totalSets, successful, failed }) => {
      if (bulkCookieJob && bulkCookieJob.id === jobId) {
        bulkCookieJob.running    = false;
        bulkCookieJob.outputPath = outputPath;
        bulkCookieJob.progress   = { current: totalSets, total: totalSets, successful, failed };
      }
      addToLogBuffer(`[BulkCookieGenerator] Done — ${successful}/${totalSets} sets written to ${path.basename(outputPath)}`);
    });

    generator.on('error', err => {
      if (bulkCookieJob && bulkCookieJob.id === jobId) {
        bulkCookieJob.running = false;
      }
      addToLogBuffer(`[BulkCookieGenerator] Error: ${err.message}`);
    });

    // Start asynchronously — do NOT await
    generator.generate().catch(err => {
      if (bulkCookieJob && bulkCookieJob.id === jobId) {
        bulkCookieJob.running = false;
      }
      addToLogBuffer(`[BulkCookieGenerator] Fatal: ${err.message}`);
    });

    res.status(202).json({
      success: true,
      message: 'Bulk generation started',
      amount,
      jobId
    });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

router.get('/cookie-exports/generate-bulk/status', (req, res) => {
  try {
    if (!bulkCookieJob) {
      return res.json({ running: false });
    }
    const responseJob = { ...bulkCookieJob };
    if (typeof responseJob.outputPath === 'string' && responseJob.outputPath.length > 0) {
      responseJob.outputPath = path.basename(responseJob.outputPath);
    }
    res.json(responseJob);
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

// -- System -------------------------------------------------------------------
router.get('/system', (req, res) => {
  try {
    const cpus = os.cpus();
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    res.json({
      platform: os.platform(),
      arch: os.arch(),
      nodeVersion: process.version,
      cpuCount: cpus.length,
      cpuModel: cpus[0].model,
      totalMemoryMB: Math.floor(totalMem / 1024 / 1024),
      freeMemoryMB: Math.floor(freeMem / 1024 / 1024),
      uptime: os.uptime()
    });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

// -- Proxies Status -----------------------------------------------------------

/** Strip scheme and user:pass@ from a proxy string, returning only host:port. */
function sanitizeProxyAddr(raw) {
  let s = raw;
  // Remove scheme (http:// https:// socks5://)
  const schemeEnd = s.indexOf('://');
  if (schemeEnd !== -1) s = s.slice(schemeEnd + 3);
  // Remove user:pass@ credentials
  const atIdx = s.lastIndexOf('@');
  if (atIdx !== -1) s = s.slice(atIdx + 1);
  // Keep only host:port (drop trailing path/slash)
  const slashIdx = s.indexOf('/');
  if (slashIdx !== -1) s = s.slice(0, slashIdx);
  return s;
}

/** Extract log text from a logBuffer entry ({ ts, line } or plain string). */
function extractLogText(entry) {
  if (entry && typeof entry === 'object') return entry.line || '';
  return typeof entry === 'string' ? entry : '';
}

router.get('/proxies/status', (req, res) => {
  try {
    // Parse proxy health from the log buffer
    const proxyMap = new Map();

    for (const entry of logBuffer) {
      const text = extractLogText(entry);
      if (!text) continue;

      // Match proxy addresses (host:port patterns) in log lines
      const proxyMatch = text.match(/proxy[:\s]+(\S+:\d+)/i) || text.match(/(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d+)/);
      if (!proxyMatch) continue;

      // Sanitize to host:port only — never expose credentials
      const addr = sanitizeProxyAddr(proxyMatch[1]);
      if (!addr || !addr.includes(':')) continue;

      if (!proxyMap.has(addr)) {
        proxyMap.set(addr, { address: addr, successCount: 0, failCount: 0, blockCount: 0, healthy: true });
      }
      const pEntry = proxyMap.get(addr);

      if (/success|hit|logged.in/i.test(text)) pEntry.successCount++;
      else if (/fail|error|timeout|refused/i.test(text)) pEntry.failCount++;
      if (/block|ban|captcha|proxy.blocked/i.test(text)) {
        pEntry.blockCount++;
        pEntry.healthy = false;
      }
    }

    // If no proxy data from logs, try to read the proxies file to list known proxies
    if (proxyMap.size === 0) {
      try {
        const proxyFile = config.proxyFile || 'Lightning_Proxies.txt';
        const proxyPath = path.resolve(proxyFile);
        if (fs.existsSync(proxyPath)) {
          const lines = fs.readFileSync(proxyPath, 'utf8').split('\n').filter(l => l.trim() && !l.trim().startsWith('#'));
          lines.forEach(line => {
            const trimmed = line.trim();
            // Handle user:pass@host:port URL format
            const atIdx = trimmed.lastIndexOf('@');
            let hostPort;
            if (atIdx !== -1) {
              hostPort = trimmed.slice(atIdx + 1);
            } else {
              // host:port or host:port:user:pass format — take first two segments
              hostPort = trimmed.split(':').slice(0, 2).join(':');
            }
            if (hostPort) proxyMap.set(hostPort, { address: hostPort, successCount: 0, failCount: 0, blockCount: 0, healthy: true });
          });
        }
      } catch (e) {
        console.error('[GUI] Failed to read proxy file for status:', e.message);
      }
    }

    res.json({ proxies: Array.from(proxyMap.values()) });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

// -- Workers ------------------------------------------------------------------
router.get('/workers', (req, res) => {
  try {
    // Derive worker activity from the last 500 log lines.
    // Prefer identifiers that match this repo's log formats:
    //   [BATCH] [Batch #N] ...
    //   [WORKER] ... pid 1234 ...
    // Keep the legacy numeric "worker N" parsing as a fallback.
    const workerMap = new Map();
    const recentLines = logBuffer.slice(-500);

    for (const entry of recentLines) {
      const text = extractLogText(entry);
      if (!text) continue;

      const batchMatch = text.match(/\[Batch\s*#(\d+)\]/i) || text.match(/\bbatch[:\s#]+(\d+)\b/i);
      const pidMatch = text.match(/\bpid[:=\s#]+(\d+)\b/i);
      const workerNumberMatch =
        text.match(/\[Worker[:\s#]*(\d+)\]/i) || text.match(/\bworker[:\s#]+(\d+)\b/i);

      let workerKey = null;
      let workerLabel = null;

      if (batchMatch) {
        workerKey = `batch-${batchMatch[1]}`;
        workerLabel = `Batch #${batchMatch[1]}`;
      } else if (pidMatch) {
        workerKey = `pid-${pidMatch[1]}`;
        workerLabel = `Worker PID ${pidMatch[1]}`;
      } else if (workerNumberMatch) {
        workerKey = `worker-${workerNumberMatch[1]}`;
        workerLabel = `Worker ${workerNumberMatch[1]}`;
      }

      if (!workerKey) continue;

      if (!workerMap.has(workerKey)) {
        workerMap.set(workerKey, {
          id: workerKey,
          label: workerLabel,
          status: 'active',
          lastAction: ''
        });
      }
      const w = workerMap.get(workerKey);
      // Determine last action from the log line
      if (/exit|killed|stopped|died/i.test(text)) w.status = 'stopped';
      else if (/spawn|start|launch/i.test(text)) w.status = 'active';
      w.lastAction = text.slice(0, 120);
    }

    res.json({ workers: Array.from(workerMap.values()) });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

// -- History Timeseries -------------------------------------------------------
router.get('/history/timeseries', (req, res) => {
  try {
    // Build 5-minute buckets from history data
    const buckets = [];
    const now = Date.now();
    const BUCKET_SIZE = 5 * 60 * 1000; // 5 minutes
    const NUM_BUCKETS = 12; // last 60 minutes

    // Initialise empty buckets
    for (let i = NUM_BUCKETS - 1; i >= 0; i--) {
      const bucketStart = now - (i + 1) * BUCKET_SIZE;
      const bucketEnd = now - i * BUCKET_SIZE;
      const d = new Date(bucketEnd);
      buckets.push({
        label: d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0'),
        start: bucketStart,
        end: bucketEnd,
        count: 0,
        failureCategories: { credential: 0, infrastructure: 0, detection: 0 }
      });
    }

    // Populate from credential history if available
    if (credentialHistory) {
      try {
        const allEntries = credentialHistory.getAll ? credentialHistory.getAll() : [];
        const oldestBucket = buckets[0].start;
        allEntries.forEach(entry => {
          const ts = entry.timestamp ? new Date(entry.timestamp).getTime() : 0;
          // Skip entries outside the window
          if (ts < oldestBucket || ts >= now) return;
          // Compute bucket index arithmetically instead of scanning all buckets
          const idx = Math.floor((ts - oldestBucket) / BUCKET_SIZE);
          if (idx < 0 || idx >= NUM_BUCKETS) return;
          const bucket = buckets[idx];
          bucket.count++;
          if (entry.status !== 'success') {
            const reason = (entry.reason || entry.status || '').toLowerCase();
            if (/credential|wrong|invalid|incorrect/i.test(reason)) bucket.failureCategories.credential++;
            else if (/timeout|network|proxy|refused|infra/i.test(reason)) bucket.failureCategories.infrastructure++;
            else if (/block|ban|captcha|detect/i.test(reason)) bucket.failureCategories.detection++;
          }
        });
      } catch (e) {
        console.error('[GUI] Failed to process credential history for timeseries:', e.message);
      }
    }

    // Strip internal fields before responding
    res.json({
      buckets: buckets.map(b => ({
        label: b.label,
        count: b.count,
        failureCategories: b.failureCategories
      }))
    });
  } catch (error) {
    res.status(500).json({ error: safeError(error) });
  }
});

// --- Mount Router ------------------------------------------------------------
// Mount at /api/v1 (versioned) and /api (backward compatibility for frontend)
app.use('/api/v1', router);
app.use('/api', router);

// --- Fallback ----------------------------------------------------------------
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// --- Start -------------------------------------------------------------------
if (require.main === module) {
  const server = app.listen(PORT, () => {
    console.log(`[GUI] Server running at http://localhost:${PORT} (${IS_PRODUCTION ? 'production' : 'development'})`);
  });

  // Graceful shutdown
  function gracefulShutdown(signal) {
    console.log(`[GUI] ${signal} received – shutting down gracefully…`);
    server.close(() => {
      if (controllerProcess) {
        controllerProcess.kill();
        controllerProcess = null;
      }
      console.log('[GUI] Server closed.');
      process.exit(0);
    });
    // Force exit after 10 s if connections linger
    setTimeout(() => {
      console.warn('[GUI] Forced shutdown – lingering connections after 10 s.');
      process.exit(1);
    }, 10000).unref();
  }
  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
}

module.exports = app;
