/**
 * ============================================================================
 * CREDENTIAL HISTORY - Persistent Deduplication Engine
 * ============================================================================
 * 
 * Stores every tested combo in cleartext (JSONL format) to prevent retesting
 * across runs, saving proxy traffic and time.
 * 
 * Features:
 * ✅ Cleartext storage (no hashing)
 * ✅ Append-only JSONL for crash safety
 * ✅ In-memory Map for O(1) lookups
 * ✅ Configurable skip rules (successful/failed/blocked)
 * ✅ Time-based retry for failed/blocked combos
 * ✅ GUI integration (search, filter, stats)
 */

const fs = require('fs');
const path = require('path');
const { readTextFile } = require('./fileHelper');

// Module-level registry: one shared 'exit' listener for all active instances.
// This avoids MaxListenersExceededWarning when multiple instances are created
// (e.g. in tests or when the controller and GUI both hold a reference).
const _activeInstances = new Set();
let _moduleExitHandlerRegistered = false;
function _moduleExitHandler() {
  for (const instance of _activeInstances) {
    instance.cleanupSync();
  }
}

class CredentialHistory {
  constructor(options = {}) {
    this.enabled = options.enabled !== false;
    this.historyFile = options.historyFile || 'combo_history.jsonl';
    this.skipSuccessful = options.skipSuccessful !== false;
    this.skipFailed = options.skipFailed !== false;
    this.skipBlocked = options.skipBlocked !== false;
    this.failedRetestAfterDays = options.failedRetestAfterDays || 0;
    this.blockedRetestAfterDays = options.blockedRetestAfterDays || 0;
    
    // In-memory storage: Map of "username\tpassword" -> entry object
    this.history = new Map();

    // Track file modification time and size to detect external changes
    this._lastMtimeMs = 0;
    this._lastSize = 0;

    // Async write stream (lazy-initialized on first write)
    this._writeStream = null;

    // Lines written to stream but not yet confirmed flushed to disk.
    // cleanupSync() uses these for a best-effort synchronous flush on exit.
    this._pendingLines = [];
    
    // Ensure history file path is absolute
    if (!path.isAbsolute(this.historyFile)) {
      this.historyFile = path.join(process.cwd(), this.historyFile);
    }

    // Register this instance in the module-level registry so that the single
    // shared 'exit' handler will call cleanupSync() on it.
    // Only enabled instances write data, so only they need shutdown cleanup.
    if (this.enabled) {
      _activeInstances.add(this);
      if (!_moduleExitHandlerRegistered) {
        process.on('exit', _moduleExitHandler);
        _moduleExitHandlerRegistered = true;
      }
    }
  }

  /**
   * Lazily create (or recreate) the append write stream.
   * @private
   */
  _getWriteStream() {
    if (!this._writeStream || this._writeStream.destroyed) {
      this._writeStream = fs.createWriteStream(this.historyFile, { flags: 'a' });
      this._writeStream.on('error', (err) => {
        console.error('[HISTORY] Write stream error:', err.message);
      });
    }
    return this._writeStream;
  }

  /**
   * Async cleanup — flush and close the write stream, remove from registry.
   */
  async cleanup() {
    _activeInstances.delete(this);
    if (this._writeStream && !this._writeStream.destroyed) {
      await new Promise((resolve) => {
        this._writeStream.end(resolve);
      });
      this._writeStream = null;
    }
    this._pendingLines = [];
  }

  /**
   * Synchronous cleanup for process exit handlers (mirrors logger.js cleanupSync).
   * Flushes any lines that were written to the stream but not yet confirmed as
   * flushed to disk, then destroys the stream.
   */
  cleanupSync() {
    _activeInstances.delete(this);
    // Best-effort sync flush of any lines still buffered in the stream
    if (this._pendingLines.length > 0) {
      try {
        fs.appendFileSync(this.historyFile, this._pendingLines.join(''), 'utf8');
      } catch (_) {}
      this._pendingLines = [];
    }
    if (this._writeStream && !this._writeStream.destroyed) {
      try {
        this._writeStream.destroy();
      } catch (_) {}
      this._writeStream = null;
    }
  }

  /**
   * Generate key for Map storage (tab-separated, case-sensitive)
   */
  _key(username, password) {
    return `${username}\t${password}`;
  }

  /**
   * Load history from JSONL file
   */
  load() {
    if (!this.enabled) {
      return;
    }

    const content = readTextFile(this.historyFile);
    if (!content) {
      console.log('[HISTORY] No existing history file, starting fresh');
      return;
    }

    const lines = content.split('\n').filter(line => line.trim());

    for (const line of lines) {
      try {
        const entry = JSON.parse(line);
        if (entry.u && entry.p) {
          const key = this._key(entry.u, entry.p);
          // Later entries overwrite earlier ones (deduplication on load)
          this.history.set(key, entry);
        }
      } catch (e) {
        console.warn('[HISTORY] Failed to parse line:', line);
      }
    }

    // Track the file modification time so reload() can detect external changes
    this._updateMtime();

    const stats = this._breakdown();
    console.log('[HISTORY] ✅ Loaded history:');
    console.log(`  Total entries: ${this.history.size}`);
    console.log(`  Successful: ${stats.success} | Failed: ${stats.failed} | Blocked: ${stats.blocked} | Captcha: ${stats.captcha}`);
  }

  /**
   * Update the cached file modification time and size
   */
  _updateMtime() {
    try {
      const stat = fs.statSync(this.historyFile);
      this._lastMtimeMs = stat.mtimeMs;
      this._lastSize = stat.size;
    } catch (_) {
      // Ignore stat errors (file may not exist yet)
    }
  }

  /**
   * Return the file fingerprint (mtime and size) that was recorded at the last
   * successful load/reload. Callers can compare two snapshots to detect whether
   * a reload actually picked up new data without accessing internal fields.
   * @returns {{ mtimeMs: number, size: number }}
   */
  getFileFingerprint() {
    return { mtimeMs: this._lastMtimeMs, size: this._lastSize };
  }

  /**
   * Reload history from file if it has been modified externally
   * (e.g. by the controller process writing new results).
   * This is a no-op if the file has not changed since the last load/reload.
   */
  reload() {
    if (!this.enabled) {
      return;
    }

    try {
      if (!fs.existsSync(this.historyFile)) {
        return;
      }

      const stat = fs.statSync(this.historyFile);
      if (stat.mtimeMs === this._lastMtimeMs && stat.size === this._lastSize) {
        return; // File unchanged — skip reload
      }

      // File was modified — read new content first
      const content = readTextFile(this.historyFile);
      if (!content) {
        // Failed to read or empty content: keep existing in-memory history
        // and do not advance mtime so a future reload can retry.
        return;
      }

      // Parse all lines into a temporary collection before mutating history
      const lines = content.split('\n').filter(line => line.trim());
      const newEntries = [];

      for (const line of lines) {
        try {
          const entry = JSON.parse(line);
          if (entry.u && entry.p) {
            newEntries.push({
              key: this._key(entry.u, entry.p),
              entry,
            });
          }
        } catch (_) {
          // Skip unparseable lines
        }
      }

      // Only now replace the in-memory history
      this.history.clear();
      for (const { key, entry } of newEntries) {
        this.history.set(key, entry);
      }

      this._lastMtimeMs = stat.mtimeMs;
      this._lastSize = stat.size;
    } catch (_) {
      // Ignore errors — the in-memory data remains as-is
    }
  }

  /**
   * Count entries by status
   */
  _breakdown() {
    const breakdown = { success: 0, failed: 0, blocked: 0, captcha: 0, other: 0 };
    
    for (const entry of this.history.values()) {
      if (entry.s === 'success') breakdown.success++;
      else if (entry.s === 'failed') breakdown.failed++;
      else if (entry.s === 'blocked') breakdown.blocked++;
      else if (entry.s === 'captcha') breakdown.captcha++;
      else breakdown.other++;
    }
    
    return breakdown;
  }

  /**
   * Check if a credential should be skipped
   * Returns { skip: boolean, reason: string }
   */
  shouldSkip(username, password) {
    if (!this.enabled) {
      return { skip: false, reason: '' };
    }

    const key = this._key(username, password);
    const entry = this.history.get(key);

    if (!entry) {
      return { skip: false, reason: '' };
    }

    const status = entry.s;

    // Never skip captcha results (inconclusive)
    if (status === 'captcha') {
      return { skip: false, reason: '' };
    }

    // Check successful
    if (status === 'success' && this.skipSuccessful) {
      return { skip: true, reason: 'already_successful' };
    }

    // Check failed with time-based retry
    if (status === 'failed' && this.skipFailed) {
      if (this.failedRetestAfterDays === 0) {
        return { skip: true, reason: 'already_failed' };
      }
      
      // Check if enough time has passed
      const entryTime = new Date(entry.t);
      const now = new Date();
      const daysPassed = (now - entryTime) / (1000 * 60 * 60 * 24);
      
      if (daysPassed < this.failedRetestAfterDays) {
        return { skip: true, reason: `failed_recently (${Math.floor(daysPassed)} days ago)` };
      }
    }

    // Check blocked with time-based retry
    if (status === 'blocked' && this.skipBlocked) {
      if (this.blockedRetestAfterDays === 0) {
        return { skip: true, reason: 'already_blocked' };
      }
      
      // Check if enough time has passed
      const entryTime = new Date(entry.t);
      const now = new Date();
      const daysPassed = (now - entryTime) / (1000 * 60 * 60 * 24);
      
      if (daysPassed < this.blockedRetestAfterDays) {
        return { skip: true, reason: `blocked_recently (${Math.floor(daysPassed)} days ago)` };
      }
    }

    return { skip: false, reason: '' };
  }

  /**
   * Filter credentials array, return only untested ones
   * Main entry point from controller
   */
  filterCredentials(credentials) {
    if (!this.enabled) {
      return credentials;
    }

    const filtered = [];
    const skipped = {
      already_successful: 0,
      already_failed: 0,
      already_blocked: 0,
      failed_recently: 0,
      blocked_recently: 0
    };

    for (const cred of credentials) {
      const result = this.shouldSkip(cred.username, cred.password);
      
      if (result.skip) {
        // Track skip reason
        const baseReason = result.reason.split(' ')[0]; // Extract base reason
        if (skipped[baseReason] !== undefined) {
          skipped[baseReason]++;
        }
      } else {
        filtered.push(cred);
      }
    }

    const totalSkipped = Object.values(skipped).reduce((a, b) => a + b, 0);
    const trafficSaved = credentials.length > 0 
      ? ((totalSkipped / credentials.length) * 100).toFixed(1)
      : '0.0';

    console.log('[HISTORY] ════════════════════════════════════════');
    console.log('[HISTORY] Credential Filtering Summary:');
    console.log(`[HISTORY]   Total in file: ${credentials.length}`);
    console.log(`[HISTORY]   To test: ${filtered.length}`);
    console.log(`[HISTORY]   Skipped: ${totalSkipped} (${trafficSaved}% traffic saved)`);
    
    if (skipped.already_successful > 0) {
      console.log(`[HISTORY]     - Already successful: ${skipped.already_successful}`);
    }
    if (skipped.already_failed > 0) {
      console.log(`[HISTORY]     - Already failed: ${skipped.already_failed}`);
    }
    if (skipped.already_blocked > 0) {
      console.log(`[HISTORY]     - Already blocked: ${skipped.already_blocked}`);
    }
    if (skipped.failed_recently > 0) {
      console.log(`[HISTORY]     - Failed recently: ${skipped.failed_recently}`);
    }
    if (skipped.blocked_recently > 0) {
      console.log(`[HISTORY]     - Blocked recently: ${skipped.blocked_recently}`);
    }
    console.log('[HISTORY] ════════════════════════════════════════');

    return filtered;
  }

  /**
   * Record a credential result (updates Map and appends to file)
   */
  record(username, password, status, details = {}) {
    if (!this.enabled) {
      return;
    }

    const entry = {
      u: username,
      p: password,
      s: status,
      t: new Date().toISOString()
    };

    // Add optional fields
    if (details.method) entry.m = details.method;
    if (details.confidence !== undefined) entry.c = details.confidence;
    if (details.reason) entry.r = details.reason;
    if (details.pointsBalance) entry.pts = details.pointsBalance;
    if (details.moneyBalance) entry.chf = details.moneyBalance;

    // Update in-memory Map
    const key = this._key(username, password);
    this.history.set(key, entry);

    // Append to file via async write stream
    try {
      const line = JSON.stringify(entry) + '\n';
      this._pendingLines.push(line);
      this._getWriteStream().write(line, 'utf8', () => {
        // Line successfully flushed to OS — remove from pending buffer
        const idx = this._pendingLines.indexOf(line);
        if (idx !== -1) this._pendingLines.splice(idx, 1);
      });
      this._updateMtime();
    } catch (error) {
      console.error('[HISTORY] Failed to append to file:', error.message);
    }
  }

  /**
   * Record successful authentication
   */
  recordSuccess(username, password, method, confidence, pointsBalance = null, moneyBalance = null) {
    this.record(username, password, 'success', {
      method,
      confidence,
      pointsBalance,
      moneyBalance
    });
  }

  /**
   * Record failed authentication
   */
  recordFailed(username, password, reason) {
    this.record(username, password, 'failed', { reason });
  }

  /**
   * Record blocked authentication
   */
  recordBlocked(username, password, reason) {
    this.record(username, password, 'blocked', { reason });
  }

  /**
   * Record captcha encounter
   */
  recordCaptcha(username, password) {
    this.record(username, password, 'captcha', {});
  }

  /**
   * Compact the JSONL file (deduplicate and rewrite)
   */
  compact() {
    if (!this.enabled) {
      return;
    }

    try {
      // Close the stream before rewriting the file to avoid stale handles.
      // Any pending lines are already committed to the in-memory Map so they
      // will be included in the compacted file below — no data loss.
      if (this._writeStream && !this._writeStream.destroyed) {
        this._writeStream.destroy();
        this._writeStream = null;
      }
      this._pendingLines = [];

      const tempFile = this.historyFile + '.tmp';
      const entries = Array.from(this.history.values());

      // Write all entries to temp file
      const content = entries.map(e => JSON.stringify(e)).join('\n') + '\n';
      fs.writeFileSync(tempFile, content, 'utf8');

      // Atomic rename
      fs.renameSync(tempFile, this.historyFile);

      console.log(`[HISTORY] ✅ Compacted history file: ${entries.length} entries`);
      return true;
    } catch (error) {
      console.error('[HISTORY] Failed to compact:', error.message);
      return false;
    }
  }

  /**
   * Get all entries as array (for GUI)
   */
  getAll() {
    return Array.from(this.history.values()).map(entry => ({
      username: entry.u,
      password: entry.p,
      status: entry.s,
      method: entry.m || null,
      confidence: entry.c || null,
      reason: entry.r || null,
      pointsBalance: entry.pts || null,
      moneyBalance: entry.chf || null,
      timestamp: entry.t,
      timeAgo: this._ago(entry.t)
    }));
  }

  /**
   * Filter entries by status (for GUI)
   */
  getByStatus(status) {
    return this.getAll().filter(e => e.status === status);
  }

  /**
   * Get statistics (for GUI)
   */
  getStats() {
    const breakdown = this._breakdown();
    return {
      total: this.history.size,
      ...breakdown,
      historyFile: this.historyFile,
      fileExists: fs.existsSync(this.historyFile),
      fileSize: fs.existsSync(this.historyFile) 
        ? fs.statSync(this.historyFile).size 
        : 0
    };
  }

  /**
   * Check if any entry exists for a credential combo (O(1) lookup).
   * Unlike hasSucceeded(), this returns true regardless of the entry's status.
   * @param {string} username
   * @param {string} password
   * @returns {boolean} True if any history entry exists for this credential
   */
  hasEntry(username, password) {
    if (!this.enabled || !this.history) return false;
    return this.history.has(this._key(username, password));
  }

  /**
   * Check if a credential combo has already succeeded (O(1) lookup)
   * @param {string} username
   * @param {string} password
   * @returns {boolean} True if this exact username+password combo has a success entry
   */
  hasSucceeded(username, password) {
    if (!this.enabled || !this.history) return false;
    const entry = this.history.get(this._key(username, password));
    return !!(entry && entry.s === 'success');
  }

  /**
   * Search entries by substring (for GUI)
   */
  search(query) {
    const lowerQuery = query.toLowerCase();
    return this.getAll().filter(entry => 
      entry.username.toLowerCase().includes(lowerQuery) ||
      entry.password.toLowerCase().includes(lowerQuery) ||
      entry.status.toLowerCase().includes(lowerQuery) ||
      (entry.method && entry.method.toLowerCase().includes(lowerQuery))
    );
  }

  /**
   * Delete a specific entry and recompact (for GUI)
   */
  deleteEntry(username, password) {
    if (!this.enabled) {
      return false;
    }

    const key = this._key(username, password);
    const existed = this.history.has(key);
    
    if (existed) {
      this.history.delete(key);
      this.compact();
      console.log(`[HISTORY] Deleted entry: ${username}`);
      return true;
    }
    
    return false;
  }

  /**
   * Human-readable time ago string
   */
  _ago(timestamp) {
    const now = new Date();
    const then = new Date(timestamp);
    const seconds = Math.floor((now - then) / 1000);

    if (seconds < 60) return `${seconds}s ago`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
  }
}

module.exports = CredentialHistory;
