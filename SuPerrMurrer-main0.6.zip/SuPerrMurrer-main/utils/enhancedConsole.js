/**
 * ============================================================================
 * ENHANCED CONSOLE OUTPUT - Phase 1, Task 1
 * ============================================================================
 * 
 * Implements:
 * ✅ Standardized color coding (Success: Green, Warnings: Yellow, Errors: Red, Info: Blue, Progress: Cyan)
 * ✅ Improved progress bars with ETA, processing rate, and detailed stats
 * ✅ Enhanced error messages with suggestions and remediation steps
 * ✅ Visual grouping with box-drawing characters
 * ✅ Consistent typography and spacing
 * ✅ Icons for common operations (✓ success, ✗ failure, ⚠ warning, ℹ info, ⏱ in progress)
 */

const chalk = require('chalk');
const cliProgress = require('cli-progress');
const boxen = require('boxen');
const ora = require('ora');

/**
 * Enhanced Console Output Manager
 */
class EnhancedConsole {
  constructor(options = {}) {
    this.verbose = options.verbose !== false;
    this.useColors = options.useColors !== false;
    this.useIcons = options.useIcons !== false;
    
    // Icon set for common operations
    this.icons = {
      success: '✓',
      failure: '✗',
      warning: '⚠',
      info: 'ℹ',
      inProgress: '⏱',
      blocked: '🚫',
      captcha: '🔐',
      retry: '↻',
      batch: '📦',
      complete: '🎉'
    };
    
    // Progress bar instances
    this.progressBars = new Map();
  }

  // ============ STANDARDIZED COLOR CODING ============

  /**
   * Success message (Green)
   */
  success(message, details = null) {
    const icon = this.useIcons ? `${this.icons.success} ` : '';
    const msg = this.useColors ? chalk.green(`${icon}${message}`) : `${icon}${message}`;
    console.log(msg);
    if (details) {
      console.log(chalk.gray(this.formatDetails(details)));
    }
  }

  /**
   * Warning message (Yellow/Amber)
   */
  warning(message, details = null) {
    const icon = this.useIcons ? `${this.icons.warning} ` : '';
    const msg = this.useColors ? chalk.yellow(`${icon}${message}`) : `${icon}${message}`;
    console.log(msg);
    if (details) {
      console.log(chalk.gray(this.formatDetails(details)));
    }
  }

  /**
   * Error message (Red)
   */
  error(message, details = null) {
    const icon = this.useIcons ? `${this.icons.failure} ` : '';
    const msg = this.useColors ? chalk.red(`${icon}${message}`) : `${icon}${message}`;
    console.log(msg);
    if (details) {
      console.log(chalk.gray(this.formatDetails(details)));
    }
  }

  /**
   * Informational message (Blue)
   */
  info(message, details = null) {
    const icon = this.useIcons ? `${this.icons.info} ` : '';
    const msg = this.useColors ? chalk.blue(`${icon}${message}`) : `${icon}${message}`;
    console.log(msg);
    if (details) {
      console.log(chalk.gray(this.formatDetails(details)));
    }
  }

  /**
   * Progress/in-progress message (Cyan)
   */
  progress(message, details = null) {
    const icon = this.useIcons ? `${this.icons.inProgress} ` : '';
    const msg = this.useColors ? chalk.cyan(`${icon}${message}`) : `${icon}${message}`;
    console.log(msg);
    if (details) {
      console.log(chalk.gray(this.formatDetails(details)));
    }
  }

  // ============ ENHANCED ERROR MESSAGES ============

  /**
   * Enhanced error message with suggestions and remediation steps
   */
  enhancedError(errorInfo) {
    const {
      message,
      cause = null,
      suggestions = [],
      errorCode = null,
      context = null
    } = errorInfo;

    // Build error box content
    let content = chalk.red.bold(`${this.icons.failure} Error: ${message}`);
    
    if (errorCode) {
      content += `\n${chalk.gray(`Error Code: ${errorCode}`)}`;
    }
    
    if (cause) {
      content += `\n\n${chalk.yellow('Possible Cause:')}\n  ${cause}`;
    }
    
    if (suggestions.length > 0) {
      content += `\n\n${chalk.green('Suggested Actions:')}`;
      suggestions.forEach((suggestion, index) => {
        content += `\n  ${index + 1}. ${suggestion}`;
      });
    }
    
    if (context) {
      content += `\n\n${chalk.gray('Context:')}\n${chalk.gray(this.formatDetails(context))}`;
    }

    // Display in box for visibility
    console.log(boxen(content, {
      padding: 1,
      margin: 1,
      borderStyle: 'round',
      borderColor: 'red'
    }));
  }

  // ============ VISUAL GROUPING & BOXES ============

  /**
   * Display a section with box-drawing characters
   */
  section(title, content, options = {}) {
    const {
      borderColor = 'cyan',
      borderStyle = 'round',
      padding = 1,
      margin = 0
    } = options;

    const boxContent = typeof content === 'string' ? content : this.formatDetails(content);
    
    console.log(boxen(boxContent, {
      title,
      padding,
      margin,
      borderStyle,
      borderColor,
      titleAlignment: 'left'
    }));
  }

  /**
   * Display a header with decorative border
   */
  header(text, options = {}) {
    const {
      color = 'cyan',
      char = '═',
      length = 80
    } = options;

    const border = char.repeat(length);
    const padding = Math.max(0, Math.floor((length - text.length - 2) / 2));
    const centeredText = ' '.repeat(padding) + text + ' '.repeat(padding);
    
    if (this.useColors) {
      console.log(chalk[color](border));
      console.log(chalk[color].bold(centeredText));
      console.log(chalk[color](border));
    } else {
      console.log(border);
      console.log(centeredText);
      console.log(border);
    }
  }

  /**
   * Display a separator line
   */
  separator(length = 80, char = '─', color = 'gray') {
    const line = char.repeat(length);
    console.log(this.useColors ? chalk[color](line) : line);
  }

  // ============ ENHANCED PROGRESS BARS ============

  /**
   * Create an advanced progress bar with ETA and processing rate
   */
  createProgressBar(name, total, options = {}) {
    const {
      format = '{bar} {percentage}% | {value}/{total} | ETA: {eta_formatted} | Rate: {rate} items/min',
      barCompleteChar = '█',
      barIncompleteChar = '░',
      hideCursor = true,
      barsize = 40,
      stopOnComplete = false
    } = options;

    const bar = new cliProgress.SingleBar({
      format: this.useColors 
        ? chalk.cyan('{bar}') + ' ' + chalk.yellow('{percentage}%') + ' | {value}/{total} | ' + chalk.gray('ETA: {eta_formatted}') + ' | ' + chalk.green('Rate: {rate} items/min')
        : format,
      barCompleteChar,
      barIncompleteChar,
      hideCursor,
      barsize,
      stopOnComplete,
      clearOnComplete: false,
      formatBar: function(progress, options) {
        const completeSize = Math.round(progress * options.barsize);
        const incompleteSize = options.barsize - completeSize;
        return options.barCompleteChar.repeat(completeSize) + 
               options.barIncompleteChar.repeat(incompleteSize);
      }
    }, cliProgress.Presets.shades_classic);

    bar.start(total, 0, {
      rate: '0',
      startTime: Date.now()
    });

    // Store with tracking info
    this.progressBars.set(name, {
      bar,
      total,
      current: 0,
      startTime: Date.now(),
      successCount: 0,
      failureCount: 0
    });

    return name;
  }

  /**
   * Update progress bar with enhanced stats
   */
  updateProgressBar(name, current, stats = {}) {
    const progressInfo = this.progressBars.get(name);
    if (!progressInfo) return;

    const { bar, total, startTime } = progressInfo;
    const { successCount = 0, failureCount = 0 } = stats;

    // Calculate processing rate (items per minute)
    const elapsed = Date.now() - startTime;
    const rate = current > 0 ? ((current / elapsed) * 60000).toFixed(1) : '0';

    // Update progress bar
    bar.update(current, { 
      rate,
      success: successCount,
      failed: failureCount
    });

    // Update stored info
    progressInfo.current = current;
    progressInfo.successCount = successCount;
    progressInfo.failureCount = failureCount;
  }

  /**
   * Stop and display final progress bar stats
   */
  stopProgressBar(name, finalStats = {}) {
    const progressInfo = this.progressBars.get(name);
    if (!progressInfo) return;

    const { bar, total, startTime, successCount, failureCount } = progressInfo;
    const elapsed = Date.now() - startTime;
    const rate = total > 0 ? ((total / elapsed) * 60000).toFixed(1) : '0';

    bar.update(total, { rate });
    bar.stop();

    // Display completion summary
    const duration = this.formatDuration(elapsed);
    this.success(`Completed ${total} items in ${duration} (${rate} items/min)`);
    
    if (finalStats.showDetails !== false) {
      console.log(chalk.gray(`  ${this.icons.success} Success: ${successCount}`));
      console.log(chalk.gray(`  ${this.icons.failure} Failed: ${failureCount}`));
    }

    this.progressBars.delete(name);
  }

  // ============ SPINNERS ============

  /**
   * Create a spinner for long-running operations
   */
  spinner(text, options = {}) {
    const { 
      color = 'cyan',
      spinner = 'dots'
    } = options;

    return ora({
      text,
      color,
      spinner
    }).start();
  }

  // ============ TABLES ============

  /**
   * Display data in a formatted ASCII table
   */
  table(headers, rows, options = {}) {
    const {
      columnWidths = null,
      align = 'left',
      headerColor = 'cyan',
      borderColor = 'gray'
    } = options;

    // Calculate column widths if not provided
    const widths = columnWidths || this.calculateColumnWidths(headers, rows);

    // Format functions
    const formatCell = (value, width, alignment = align) => {
      const str = String(value);
      if (alignment === 'right') {
        return str.padStart(width);
      } else if (alignment === 'center') {
        const padding = width - str.length;
        const leftPad = Math.floor(padding / 2);
        const rightPad = padding - leftPad;
        return ' '.repeat(leftPad) + str + ' '.repeat(rightPad);
      }
      return str.padEnd(width);
    };

    const separator = (char = '─', junction = '┼') => {
      return '├' + widths.map(w => char.repeat(w + 2)).join(junction) + '┤';
    };

    // Top border
    console.log('┌' + widths.map(w => '─'.repeat(w + 2)).join('┬') + '┐');

    // Headers
    const headerRow = '│ ' + headers.map((h, i) => formatCell(h, widths[i])).join(' │ ') + ' │';
    console.log(this.useColors ? chalk[headerColor].bold(headerRow) : headerRow);

    // Separator
    console.log(separator());

    // Rows
    rows.forEach(row => {
      const rowStr = '│ ' + row.map((cell, i) => formatCell(cell, widths[i])).join(' │ ') + ' │';
      console.log(rowStr);
    });

    // Bottom border
    console.log('└' + widths.map(w => '─'.repeat(w + 2)).join('┴') + '┘');
  }

  /**
   * Calculate optimal column widths for table
   */
  calculateColumnWidths(headers, rows) {
    const widths = headers.map(h => String(h).length);
    
    rows.forEach(row => {
      row.forEach((cell, i) => {
        const cellLength = String(cell).length;
        if (cellLength > widths[i]) {
          widths[i] = cellLength;
        }
      });
    });

    return widths;
  }

  // ============ HELPER METHODS ============

  /**
   * Format object/array as indented JSON
   */
  formatDetails(details) {
    if (typeof details === 'string') return details;
    if (typeof details === 'object') {
      return JSON.stringify(details, null, 2);
    }
    return String(details);
  }

  /**
   * Format duration in human-readable format
   */
  formatDuration(ms) {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    if (hours > 0) {
      return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
    } else if (minutes > 0) {
      return `${minutes}m ${seconds % 60}s`;
    } else {
      return `${seconds}s`;
    }
  }

  /**
   * Clear screen (optional, for full-screen UIs)
   */
  clear() {
    console.clear();
  }

  /**
   * Add blank lines for spacing
   */
  spacing(lines = 1) {
    console.log('\n'.repeat(lines - 1));
  }
}

// ============ EXPORTS ============

module.exports = EnhancedConsole;
