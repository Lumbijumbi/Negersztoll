/**
 * Random Mouse Movement Module
 * Simulates human-like mouse behavior to avoid bot detection
 */

const config = require('../config');

/**
 * Generate random coordinates within viewport
 */
function getRandomCoordinates(width = 1920, height = 1080) {
  // Avoid edges - stay within 10% to 90% of the viewport
  const minX = Math.floor(width * 0.1);
  const maxX = Math.floor(width * 0.9);
  const minY = Math.floor(height * 0.1);
  const maxY = Math.floor(height * 0.9);

  return {
    x: Math.floor(Math.random() * (maxX - minX) + minX),
    y: Math.floor(Math.random() * (maxY - minY) + minY)
  };
}

/**
 * Move mouse along a bezier curve for more natural movement
 */
async function moveMouseAlongPath(page, fromX, fromY, toX, toY, steps = 10) {
  // Generate control points for bezier curve
  const cp1x = fromX + (toX - fromX) * 0.25 + (Math.random() - 0.5) * 100;
  const cp1y = fromY + (toY - fromY) * 0.25 + (Math.random() - 0.5) * 100;
  const cp2x = fromX + (toX - fromX) * 0.75 + (Math.random() - 0.5) * 100;
  const cp2y = fromY + (toY - fromY) * 0.75 + (Math.random() - 0.5) * 100;

  // Move along the curve
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const mt = 1 - t;
    const mt2 = mt * mt;
    const mt3 = mt2 * mt;
    const t2 = t * t;
    const t3 = t2 * t;

    const x = mt3 * fromX + 3 * mt2 * t * cp1x + 3 * mt * t2 * cp2x + t3 * toX;
    const y = mt3 * fromY + 3 * mt2 * t * cp1y + 3 * mt * t2 * cp2y + t3 * toY;

    await page.mouse.move(x, y);
    await new Promise(r => setTimeout(r, 10 + Math.random() * 20));
  }
}

/**
 * Perform random mouse movements
 * @param {Page} page - Playwright page object
 * @param {number} numMovements - Number of random movements to perform
 * @param {number} delayMin - Minimum delay between movements (ms)
 * @param {number} delayMax - Maximum delay between movements (ms)
 */
async function performRandomMouseMovements(page, numMovements = 3, delayMin = 50, delayMax = 200) {
  try {
    const viewport = page.viewportSize() || { width: 1920, height: 1080 };
    
    // Get current mouse position or start at center
    let currentX = Math.floor(viewport.width / 2);
    let currentY = Math.floor(viewport.height / 2);

    for (let i = 0; i < numMovements; i++) {
      const target = getRandomCoordinates(viewport.width, viewport.height);
      
      // Move mouse along a curved path
      await moveMouseAlongPath(page, currentX, currentY, target.x, target.y);
      
      currentX = target.x;
      currentY = target.y;

      // Random delay between movements
      if (i < numMovements - 1) {
        const delay = Math.floor(Math.random() * (delayMax - delayMin) + delayMin);
        await new Promise(r => setTimeout(r, delay));
      }
    }
  } catch (error) {
    // Silently fail - mouse movement is optional for bot detection avoidance
    console.debug(`[mouse] Movement error: ${error.message}`);
  }
}

/**
 * Perform mouse movements before form fill
 */
async function mouseMovementBeforeFormFill(page) {
  const behaviorConfig = config.userBehavior?.randomMouseMovement;
  if (!behaviorConfig?.enabled || !behaviorConfig?.beforeFormFill?.enabled) {
    return;
  }

  const beforeConfig = behaviorConfig.beforeFormFill;
  await performRandomMouseMovements(
    page,
    beforeConfig.movements || 3,
    beforeConfig.delayMin || 50,
    beforeConfig.delayMax || 200
  );
}

/**
 * Perform mouse movements during form fill
 */
async function mouseMovementDuringFormFill(page) {
  const behaviorConfig = config.userBehavior?.randomMouseMovement;
  if (!behaviorConfig?.enabled || !behaviorConfig?.duringFormFill?.enabled) {
    return;
  }

  const duringConfig = behaviorConfig.duringFormFill;
  await performRandomMouseMovements(
    page,
    duringConfig.movements || 2,
    duringConfig.delayMin || 100,
    duringConfig.delayMax || 300
  );
}

/**
 * Perform mouse movements after form submit
 */
async function mouseMovementAfterSubmit(page) {
  const behaviorConfig = config.userBehavior?.randomMouseMovement;
  if (!behaviorConfig?.enabled || !behaviorConfig?.afterSubmit?.enabled) {
    return;
  }

  const afterConfig = behaviorConfig.afterSubmit;
  await performRandomMouseMovements(
    page,
    afterConfig.movements || 2,
    afterConfig.delayMin || 150,
    afterConfig.delayMax || 400
  );
}

module.exports = {
  performRandomMouseMovements,
  mouseMovementBeforeFormFill,
  mouseMovementDuringFormFill,
  mouseMovementAfterSubmit
};
