/**
 * ============================================================================
 * HEALTH CHECK SYSTEM - Comprehensive Monitoring
 * ============================================================================
 * 
 * Features:
 * - Extensible health check registry
 * - Configurable check intervals
 * - Overall health score calculation
 * - Health history tracking
 * - Default checks for common issues
 */

const os = require('os');
const fs = require('fs').promises;

class HealthCheckSystem {
  constructor() {
    this.checks = new Map(); // name -> { checkFn, interval, lastRun, lastResult }
    this.history = []; // Last 100 health check results
    this.maxHistorySize = 100;
  }

  /**
   * Register a health check
   */
  register(name, checkFn, interval = 30000) {
    this.checks.set(name, {
      checkFn,
      interval,
      lastRun: 0,
      lastResult: null
    });
  }

  /**
   * Run all health checks
   */
  async runAll() {
    const now = Date.now();
    const results = {};

    for (const [name, check] of this.checks.entries()) {
      // Check if enough time has passed since last run
      if (now - check.lastRun >= check.interval) {
        try {
          const result = await check.checkFn();
          
          check.lastRun = now;
          check.lastResult = {
            healthy: result.healthy,
            message: result.message,
            details: result.details,
            timestamp: now
          };

          results[name] = check.lastResult;
        } catch (error) {
          check.lastResult = {
            healthy: false,
            message: `Check failed: ${error.message}`,
            details: { error: error.message },
            timestamp: now
          };

          results[name] = check.lastResult;
        }
      } else {
        // Use last result
        if (check.lastResult) {
          results[name] = check.lastResult;
        }
      }
    }

    // Add to history
    this.history.push({
      timestamp: now,
      results
    });

    // Trim history
    if (this.history.length > this.maxHistorySize) {
      this.history.shift();
    }

    return results;
  }

  /**
   * Get overall health status
   */
  getOverallHealth() {
    if (this.checks.size === 0) {
      return {
        healthy: true,
        score: 100,
        message: 'No checks configured'
      };
    }

    let totalChecks = 0;
    let healthyChecks = 0;
    const failingChecks = [];

    for (const [name, check] of this.checks.entries()) {
      if (check.lastResult) {
        totalChecks++;
        
        if (check.lastResult.healthy) {
          healthyChecks++;
        } else {
          failingChecks.push(`${name}: ${check.lastResult.message}`);
        }
      }
    }

    const score = totalChecks > 0 
      ? (healthyChecks / totalChecks) * 100 
      : 100;

    return {
      healthy: failingChecks.length === 0,
      score: score.toFixed(1),
      totalChecks,
      healthyChecks,
      failingChecks,
      message: failingChecks.length === 0 
        ? 'All systems operational'
        : `${failingChecks.length} check(s) failing`
    };
  }

  /**
   * Get health check history
   */
  getHistory(limit = 10) {
    return this.history.slice(-limit);
  }

  /**
   * Create default health checks
   */
  static createDefaultChecks(context = {}) {
    const checks = {};

    // Proxy health check
    checks.proxyHealth = async () => {
      if (!context.proxyManager) {
        return { healthy: true, message: 'No proxy manager' };
      }

      // Check proxy failure rate
      const failureRate = context.proxyFailureRate || 0;
      
      if (failureRate > 50) {
        return {
          healthy: false,
          message: `Proxy failure rate too high: ${failureRate.toFixed(1)}%`,
          details: { failureRate }
        };
      }

      return {
        healthy: true,
        message: `Proxy health OK (${failureRate.toFixed(1)}% failure rate)`,
        details: { failureRate }
      };
    };

    // Worker health check
    checks.workerHealth = async () => {
      const workerStarts = context.workerStarts || 0;
      const workerCrashes = context.workerCrashes || 0;

      if (workerStarts === 0) {
        return { healthy: true, message: 'No workers started yet' };
      }

      const crashRate = (workerCrashes / workerStarts) * 100;

      if (crashRate > 30) {
        return {
          healthy: false,
          message: `Worker crash rate too high: ${crashRate.toFixed(1)}%`,
          details: { workerStarts, workerCrashes, crashRate }
        };
      }

      return {
        healthy: true,
        message: `Worker health OK (${crashRate.toFixed(1)}% crash rate)`,
        details: { workerStarts, workerCrashes, crashRate }
      };
    };

    // Memory health check
    checks.memoryHealth = async () => {
      const totalMemory = os.totalmem();
      const freeMemory = os.freemem();
      const usedPercent = ((totalMemory - freeMemory) / totalMemory) * 100;

      if (usedPercent > 90) {
        return {
          healthy: false,
          message: `Memory usage critical: ${usedPercent.toFixed(1)}%`,
          details: {
            usedPercent: usedPercent.toFixed(1),
            freeGB: (freeMemory / (1024 ** 3)).toFixed(2)
          }
        };
      }

      return {
        healthy: true,
        message: `Memory usage OK: ${usedPercent.toFixed(1)}%`,
        details: {
          usedPercent: usedPercent.toFixed(1),
          freeGB: (freeMemory / (1024 ** 3)).toFixed(2)
        }
      };
    };

    // File system health check
    checks.fileSystemHealth = async () => {
      try {
        const testFile = '/tmp/health_check_test.txt';
        await fs.writeFile(testFile, 'test');
        await fs.unlink(testFile);

        return {
          healthy: true,
          message: 'File system access OK'
        };
      } catch (error) {
        return {
          healthy: false,
          message: `File system access failed: ${error.message}`,
          details: { error: error.message }
        };
      }
    };

    // Retry queue health check
    checks.retryQueueHealth = async () => {
      if (!context.retryQueue) {
        return { healthy: true, message: 'Retry queue not enabled' };
      }

      const stats = context.retryQueue.getStats ? context.retryQueue.getStats() : {};
      const queueSize = stats.currentQueueSize || 0;

      if (queueSize > 100) {
        return {
          healthy: false,
          message: `Retry queue backlog: ${queueSize} items`,
          details: { queueSize }
        };
      }

      return {
        healthy: true,
        message: `Retry queue OK (${queueSize} items)`,
        details: { queueSize }
      };
    };

    return checks;
  }

  /**
   * Export health report
   */
  exportReport() {
    const overall = this.getOverallHealth();
    const checkDetails = {};

    for (const [name, check] of this.checks.entries()) {
      if (check.lastResult) {
        checkDetails[name] = {
          healthy: check.lastResult.healthy,
          message: check.lastResult.message,
          details: check.lastResult.details,
          lastChecked: new Date(check.lastResult.timestamp).toISOString()
        };
      }
    }

    return {
      overall,
      checks: checkDetails,
      timestamp: new Date().toISOString()
    };
  }
}

module.exports = HealthCheckSystem;
