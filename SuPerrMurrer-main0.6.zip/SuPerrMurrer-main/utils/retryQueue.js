/**
 * ============================================================================
 * RETRY QUEUE SYSTEM - Intelligent Failed Credential Management
 * ============================================================================
 * 
 * Features:
 * ✅ Tracks failed credentials with retry count
 * ✅ Configurable max retries (default: 3)
 * ✅ Records failure reason for each attempt
 * ✅ Persists queue to disk (retry_queue.json)
 * ✅ Filters out credentials that exceeded max retries
 * ✅ Tracks timestamp of each retry attempt
 * ✅ Exports retry statistics
 */

const fs = require('fs');
const path = require('path');
const { writeJSONFileAtomic, readJSONFile } = require('./fileHelper');

class RetryQueue {
  constructor(options = {}) {
    this.maxRetries = options.maxRetries || 3;
    this.queueFile = options.queueFile || 'retry_queue.json';
    this.queueFilePath = path.join(process.cwd(), this.queueFile);
    
    // Map: "username\tpassword" -> retry entry
    this.queue = new Map();
    
    // Statistics
    this.stats = {
      totalAdded: 0,
      totalRetried: 0,
      totalExhausted: 0,
      totalSucceeded: 0
    };
  }

  /**
   * Generate composite Map key (tab-separated, mirrors credentialHistory.js pattern)
   * @param {string} username
   * @param {string} password
   * @returns {string}
   */
  _key(username, password) {
    return `${username}\t${password}`;
  }

  /**
   * Add a failed credential to the retry queue
   * @param {Object} credential - { username, password }
   * @param {string} reason - Failure reason
   */
  add(credential, reason) {
    if (!credential || !credential.username || !credential.password) {
      throw new Error('Invalid credential: username and password required');
    }

    const { username, password } = credential;
    const key = this._key(username, password);
    const existing = this.queue.get(key);

    if (existing) {
      // Credential already in queue, increment retry count
      existing.retryCount++;
      existing.attempts.push({
        timestamp: new Date().toISOString(),
        reason: reason || 'unknown'
      });
      existing.lastAttempt = new Date().toISOString();
    } else {
      // New credential to queue
      const entry = {
        username,
        password,
        retryCount: 0,
        maxRetries: this.maxRetries,
        attempts: [{
          timestamp: new Date().toISOString(),
          reason: reason || 'unknown'
        }],
        addedAt: new Date().toISOString(),
        lastAttempt: new Date().toISOString()
      };
      this.queue.set(key, entry);
      this.stats.totalAdded++;
    }
  }

  /**
   * Get credentials eligible for retry (haven't exceeded max retries)
   * Pure getter — does not mutate stats.
   * @returns {Array} Array of retry-eligible credentials
   */
  getRetryable() {
    const retryable = [];
    
    for (const [username, entry] of this.queue.entries()) {
      if (entry.retryCount < this.maxRetries) {
        retryable.push({
          username: entry.username,
          password: entry.password,
          retryCount: entry.retryCount,
          lastReason: entry.attempts[entry.attempts.length - 1].reason
        });
      }
    }

    return retryable;
  }

  /**
   * Increment totalRetried by the given count.
   * Call this when a retry batch is actually dispatched.
   * @param {number} count - Number of credentials being retried
   */
  markRetried(count) {
    this.stats.totalRetried += count || 0;
  }

  /**
   * Get retry-eligible credentials sorted by priority (reason-aware)
   * High-priority reasons (proxy blocks, bot checks) are processed first
   * @returns {Array} Sorted array of retry-eligible credentials
   */
  getRetryablePrioritized() {
    const PRIORITY = {
      'proxy_blocked': 1,
      'proxy_blocked_before_test': 1,
      'bot_check_before_test': 1,
      'bot_check_after_login': 1,
      'captcha_before_test': 1,
      'http_403': 1,
      'http_429': 1,
      'suspicious_behavior': 1,
      'inconclusive_timeout': 2,
      'detection_timeout': 2,
      'timeout_retry': 2,
      'worker_crash': 2,
      'worker_no_response': 2,
      'worker_shutdown_interrupted': 2,
      'relaunch_failed': 2,
      'tunnel_failed': 3,
      'submit_failed': 4,
      'unknown': 5
    };

    return this.getRetryable().sort((a, b) => {
      const pa = PRIORITY[a.lastReason] || 5;
      const pb = PRIORITY[b.lastReason] || 5;
      if (pa !== pb) return pa - pb;
      return a.retryCount - b.retryCount;
    });
  }

  /**
   * Check if credential has reached max retries
   * @param {Object} credential - { username }
   * @returns {boolean} True if max retries reached
   */
  isMaxRetriesReached(credential) {
    if (!credential || !credential.username) {
      return false;
    }

    const password = credential.password;
    const key = password != null
      ? this._key(credential.username, password)
      : null;

    // Try composite key first; fall back to scanning by username for backward compat
    const entry = key
      ? this.queue.get(key)
      : this._findByUsername(credential.username);

    if (!entry) {
      return false;
    }

    return entry.retryCount >= this.maxRetries;
  }

  /**
   * Mark a credential as successfully retried (remove from queue)
   * @param {Object} credential - { username, password? }
   */
  markSuccess(credential) {
    if (!credential || !credential.username) {
      return;
    }

    const password = credential.password;
    const key = password != null
      ? this._key(credential.username, password)
      : null;

    if (key && this.queue.has(key)) {
      this.queue.delete(key);
      this.stats.totalSucceeded++;
    } else if (!key) {
      // Backward-compat: remove by username scan
      for (const [k, entry] of this.queue.entries()) {
        if (entry.username === credential.username) {
          this.queue.delete(k);
          this.stats.totalSucceeded++;
          break;
        }
      }
    }
  }

  /**
   * Remove credentials that have exhausted retries
   * @returns {number} Number of entries removed
   */
  cleanExhausted() {
    let removed = 0;
    
    for (const [key, entry] of this.queue.entries()) {
      if (entry.retryCount >= this.maxRetries) {
        this.queue.delete(key);
        this.stats.totalExhausted++;
        removed++;
      }
    }
    
    return removed;
  }

  /**
   * Get current queue size
   * @returns {number} Number of entries in queue
   */
  size() {
    return this.queue.size;
  }

  /**
   * Get statistics about retry queue
   * @returns {Object} Statistics object
   */
  getStats() {
    const retryable = this.getRetryable().length;
    const exhausted = this.size() - retryable;

    return {
      ...this.stats,
      currentQueueSize: this.size(),
      retryableCredentials: retryable,
      exhaustedCredentials: exhausted
    };
  }

  /**
   * Save queue to disk (atomic write)
   */
  save() {
    const data = {
      version: '1.0',
      savedAt: new Date().toISOString(),
      maxRetries: this.maxRetries,
      stats: this.stats,
      queue: Array.from(this.queue.entries()).map(([username, entry]) => entry)
    };

    const success = writeJSONFileAtomic(this.queueFilePath, data);
    if (!success) {
      console.error('[RetryQueue] Failed to save queue');
    }
    return success;
  }

  /**
   * Load queue from disk
   */
  load() {
    // Check if file exists but is unreadable/corrupted
    const fileExists = fs.existsSync(this.queueFilePath);
    
    const data = readJSONFile(this.queueFilePath);
    
    if (!data && !fileExists) {
      console.log('[RetryQueue] No existing queue file found, starting fresh');
      return false;
    }

    // File exists but couldn't be parsed (corrupted)
    if (!data && fileExists) {
      console.error('[RetryQueue] Invalid queue file format');
      // If corrupted, backup and start fresh
      const backupPath = `${this.queueFilePath}.corrupted.${Date.now()}`;
      try {
        fs.renameSync(this.queueFilePath, backupPath);
        console.log(`[RetryQueue] Corrupted file backed up to ${backupPath}`);
      } catch (err) {
        console.error(`[RetryQueue] Failed to backup corrupted file: ${err.message}`);
      }
      return false;
    }

    // Validate data structure
    if (!data.queue || !Array.isArray(data.queue)) {
      console.error('[RetryQueue] Invalid queue file format - missing queue array');
      const backupPath = `${this.queueFilePath}.corrupted.${Date.now()}`;
      try {
        fs.renameSync(this.queueFilePath, backupPath);
        console.log(`[RetryQueue] Corrupted file backed up to ${backupPath}`);
      } catch (err) {
        console.error(`[RetryQueue] Failed to backup corrupted file: ${err.message}`);
      }
      return false;
    }

    // Load queue entries
    this.queue.clear();
    for (const entry of data.queue) {
      if (entry.username && entry.password) {
        this.queue.set(this._key(entry.username, entry.password), entry);
      } else if (entry.username) {
        console.warn(`[RetryQueue] Skipping legacy entry without password: ${entry.username}`);
      }
    }

    // Load stats
    if (data.stats) {
      this.stats = { ...this.stats, ...data.stats };
    }

    console.log(`[RetryQueue] Loaded ${this.queue.size} entries from disk`);
    return true;
  }

  /**
   * Clear the entire queue
   */
  clear() {
    this.queue.clear();
    this.stats = {
      totalAdded: 0,
      totalRetried: 0,
      totalExhausted: 0,
      totalSucceeded: 0
    };
  }

  /**
   * Export queue to array for iteration
   * @returns {Array} Array of all queue entries
   */
  toArray() {
    return Array.from(this.queue.values());
  }

  /**
   * Find first entry matching username (backward-compat scan)
   * @private
   */
  _findByUsername(username) {
    for (const entry of this.queue.values()) {
      if (entry.username === username) return entry;
    }
    return null;
  }
}

module.exports = RetryQueue;
