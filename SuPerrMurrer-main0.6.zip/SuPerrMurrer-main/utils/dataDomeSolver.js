/**
 * DataDome CAPTCHA Solver using DeathByCaptcha
 */
const axios = require('axios');
const config = require('../config');

async function solveDataDome(page) {
  try {
    // 1. Detect the DataDome iframe
    const frameElement = await page.waitForSelector('iframe[src*="captcha-delivery.com"]', { timeout: 10000 });
    const frame = await frameElement.contentFrame();
    const frameUrl = await frameElement.getAttribute('src');

    // 2. Extract the SiteKey
    const siteKey = await frame.evaluate(() => {
      const el = document.querySelector('.g-recaptcha');
      return el ? el.getAttribute('data-sitekey') : null;
    });

    if (!siteKey) throw new Error('Could not find DataDome sitekey');

    console.log(`[DATADOME] Solving CAPTCHA (SiteKey: ${siteKey})...`);

    // 3. Request solve from DeathByCaptcha
    const submitRes = await axios.post('http://api.dbcapi.me/api/captcha', {
      username: config.captcha.username,
      password: config.captcha.password,
      type: 4,
      token_params: JSON.stringify({ 
        googlekey: siteKey, 
        pageurl: frameUrl 
      })
    });

    const captchaId = submitRes.data.captcha;
    let token = null;

    // 4. Poll for solution
    for (let i = 0; i < 24; i++) {
      await new Promise(r => setTimeout(r, 5000));
      const statusRes = await axios.get(`http://api.dbcapi.me/api/captcha/${captchaId}`);
      if (statusRes.data.text) {
        token = statusRes.data.text;
        break;
      }
    }

    if (!token) throw new Error('DBC Solving Timeout');

    // 5. Inject the token
    await frame.evaluate((t) => {
      const responseField = document.querySelector('#g-recaptcha-response') || 
                            document.querySelector('[name="g-recaptcha-response"]');
      if (responseField) {
        responseField.value = t;
        if (typeof window.onSuccess === 'function') {
          window.onSuccess(t);
        } else {
          const form = responseField.closest('form');
          if (form) form.submit();
        }
      }
    }, token);

    console.log('[DATADOME] Token injected, waiting for redirect...');
    await page.waitForNavigation({ waitUntil: 'networkidle', timeout: 30000 });
    return true;

  } catch (error) {
    console.error(`[DATADOME] Solve Error: ${error.message}`);
    return false;
  }
}

module.exports = { solveDataDome };