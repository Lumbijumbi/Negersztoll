/**
 * ============================================================================
 * CONFIGURATION PROFILES - Predefined Settings
 * ============================================================================
 * 
 * Predefined performance profiles for different use cases.
 * Note: browser.headless is managed independently via the Browser settings
 * section and is NOT part of any profile definition.
 */

const PROFILES = {
  /**
   * Fast profile - High speed
   * - More workers
   * - Less delay
   */
  fast: {
    browser: {
      timeout: 120 * 1000, // 2 minutes
    },
    batch: {
      maxParallelWorkers: 8,
      credentialsPerProxy: 10,
      pauseBetweenBatchMin: 500,
      pauseBetweenBatchMax: 2000
    },
    form: {
      typeDelayMin: 2,
      typeDelayMax: 5,
      pauseBetweenCredsMin: 50,
      pauseBetweenCredsMax: 150
    },
    navigation: {
      timeout: 10 * 1000
    }
  },

  /**
   * Turbo profile - Maximum throughput for huge lists
   * - Maximum workers
   * - Minimum delay
   */
  turbo: {
    browser: {
      timeout: 90 * 1000, // 90 seconds
    },
    batch: {
      maxParallelWorkers: 12,
      credentialsPerProxy: 15,
      pauseBetweenBatchMin: 200,
      pauseBetweenBatchMax: 800
    },
    form: {
      typeDelayMin: 1,
      typeDelayMax: 3,
      pauseBetweenCredsMin: 30,
      pauseBetweenCredsMax: 100
    },
    navigation: {
      timeout: 8 * 1000
    }
  },

  /**
   * Aggressive profile - High-speed with slightly more caution
   * - Many workers
   * - Very short delays
   */
  aggressive: {
    browser: {
      timeout: 100 * 1000, // 100 seconds
    },
    batch: {
      maxParallelWorkers: 10,
      credentialsPerProxy: 12,
      pauseBetweenBatchMin: 300,
      pauseBetweenBatchMax: 1200
    },
    form: {
      typeDelayMin: 1,
      typeDelayMax: 4,
      pauseBetweenCredsMin: 40,
      pauseBetweenCredsMax: 120
    },
    navigation: {
      timeout: 9 * 1000
    }
  },

  /**
   * Balanced profile - Recommended default
   * - Moderate workers
   * - Balanced delays
   * - Good detection avoidance
   */
  balanced: {
    browser: {
      timeout: 180 * 1000, // 3 minutes
    },
    batch: {
      maxParallelWorkers: 4,
      credentialsPerProxy: 4,
      pauseBetweenBatchMin: 1000,
      pauseBetweenBatchMax: 5000
    },
    form: {
      typeDelayMin: 4,
      typeDelayMax: 10,
      pauseBetweenCredsMin: 100,
      pauseBetweenCredsMax: 350
    },
    navigation: {
      timeout: 12 * 1000
    }
  },

  /**
   * Conservative profile - Careful, low-risk approach
   * - Few workers
   * - Longer delays
   */
  conservative: {
    browser: {
      timeout: 200 * 1000, // ~3.3 minutes
    },
    batch: {
      maxParallelWorkers: 3,
      credentialsPerProxy: 3,
      pauseBetweenBatchMin: 2000,
      pauseBetweenBatchMax: 6000
    },
    form: {
      typeDelayMin: 8,
      typeDelayMax: 15,
      pauseBetweenCredsMin: 150,
      pauseBetweenCredsMax: 400
    },
    navigation: {
      timeout: 14 * 1000
    }
  },

  /**
   * Stealth profile - Maximum stealth
   * - Fewer workers
   * - Human-like delays
   * - Better detection avoidance
   */
  stealth: {
    browser: {
      timeout: 240 * 1000, // 4 minutes
    },
    batch: {
      maxParallelWorkers: 2,
      credentialsPerProxy: 2,
      pauseBetweenBatchMin: 3000,
      pauseBetweenBatchMax: 8000
    },
    form: {
      typeDelayMin: 10,
      typeDelayMax: 20,
      pauseBetweenCredsMin: 200,
      pauseBetweenCredsMax: 500
    },
    navigation: {
      timeout: 15 * 1000
    }
  },

  /**
   * Night Owl profile - Long unattended overnight runs
   * - Minimal workers
   * - Very long, human-like delays
   */
  nightowl: {
    browser: {
      timeout: 300 * 1000, // 5 minutes
    },
    batch: {
      maxParallelWorkers: 2,
      credentialsPerProxy: 2,
      pauseBetweenBatchMin: 5000,
      pauseBetweenBatchMax: 15000
    },
    form: {
      typeDelayMin: 15,
      typeDelayMax: 30,
      pauseBetweenCredsMin: 300,
      pauseBetweenCredsMax: 800
    },
    navigation: {
      timeout: 18 * 1000
    }
  },

  /**
   * Low Resource profile - Minimal CPU/RAM usage
   * - Single worker
   * - Conservative delays
   */
  lowresource: {
    browser: {
      timeout: 180 * 1000, // 3 minutes
    },
    batch: {
      maxParallelWorkers: 1,
      credentialsPerProxy: 2,
      pauseBetweenBatchMin: 1000,
      pauseBetweenBatchMax: 3000
    },
    form: {
      typeDelayMin: 5,
      typeDelayMax: 12,
      pauseBetweenCredsMin: 100,
      pauseBetweenCredsMax: 300
    },
    navigation: {
      timeout: 12 * 1000
    }
  },

  /**
   * Debug profile - For testing
   * - Single worker
   * - Long timeouts
   * - Verbose output
   */
  debug: {
    browser: {
      timeout: 300 * 1000, // 5 minutes
      dumpio: true
    },
    batch: {
      maxParallelWorkers: 1,
      credentialsPerProxy: 1,
      pauseBetweenBatchMin: 2000,
      pauseBetweenBatchMax: 4000
    },
    form: {
      typeDelayMin: 50,
      typeDelayMax: 150,
      pauseBetweenCredsMin: 500,
      pauseBetweenCredsMax: 1000
    },
    navigation: {
      timeout: 20 * 1000
    }
  }
};

/**
 * Apply profile to config
 */
function applyProfile(config, profileName) {
  const profile = PROFILES[profileName];
  
  if (!profile) {
    throw new Error(`Unknown profile: ${profileName}`);
  }

  // Deep merge profile into config
  const mergedConfig = JSON.parse(JSON.stringify(config));

  for (const section in profile) {
    if (mergedConfig[section]) {
      Object.assign(mergedConfig[section], profile[section]);
    }
  }

  return mergedConfig;
}

/**
 * Get profile list
 */
function getProfileList() {
  return Object.keys(PROFILES);
}

/**
 * Get profile details
 */
function getProfile(profileName) {
  return PROFILES[profileName] || null;
}

/**
 * Get profile descriptions
 */
function getProfileDescriptions() {
  return {
    fast: '🚀 Fast — 8 workers, 2-5ms typing — Best for large batches',
    turbo: '⚡ Turbo — 12 workers, 1-3ms typing — Maximum throughput for huge lists',
    aggressive: '🔥 Aggressive — 10 workers, 1-4ms typing — High-speed with slightly more caution',
    balanced: '⚖️  Balanced — 4 workers, 4-10ms typing — Recommended good-all-rounder',
    conservative: '🐢 Conservative — 3 workers, 8-15ms typing — Careful low-risk approach',
    stealth: '🥷 Stealth — 2 workers, 10-20ms typing — Best detection avoidance',
    nightowl: '🦉 Night Owl — 2 workers, 15-30ms typing — Long unattended overnight runs',
    lowresource: '💻 Low Resource — 1 worker, 5-12ms typing — Minimal CPU/RAM usage',
    debug: '🐛 Debug — 1 worker, verbose output — For testing & troubleshooting'
  };
}

/**
 * Get detailed, user-friendly descriptions for each profile (plain language, no coding knowledge required)
 */
function getProfileDetailedDescriptions() {
  return {
    fast: {
      tagline: '8 workers, 2-5ms typing',
      whatItDoes: 'Runs 8 browser windows simultaneously with very fast keystroke timing. Designed to push through credential lists as quickly as possible.',
      whenToUse: 'You have a large list (5,000–50,000+ entries) and need results fast. Your machine has enough RAM (8 GB+) and you have a reliable set of proxies.',
      tradeoffs: 'Very fast but more likely to trigger bot-detection systems. Uses significant CPU and memory. Proxies rotate frequently.',
      recommendedFor: 'Power users with good hardware and proxies who prioritise throughput over stealth.'
    },
    turbo: {
      tagline: '12 workers, 1-3ms typing',
      whatItDoes: 'Pushes the absolute maximum — 12 parallel browser windows with near-instant typing. Squeezes every bit of performance from your hardware.',
      whenToUse: 'You have a massive list (50,000+ entries), a very powerful machine (16 GB+ RAM), and many rotating proxies that can handle the load.',
      tradeoffs: 'Highest throughput but also the highest chance of being flagged as a bot. Needs strong hardware; running this on a weak machine will cause slowdowns or crashes.',
      recommendedFor: 'Advanced users with high-end hardware and large rotating proxy pools.'
    },
    aggressive: {
      tagline: '10 workers, 1-4ms typing',
      whatItDoes: 'Almost as fast as Turbo but with a slightly longer typing delay to reduce obvious bot signatures. Still very high speed overall.',
      whenToUse: 'You want near-maximum speed but with a tiny bit more caution than Turbo. Good for large lists (20,000+ entries).',
      tradeoffs: 'Very fast and slightly more resilient than Turbo, but still heavily resource-intensive and may trigger bot detection on strict targets.',
      recommendedFor: 'Users who found Turbo too aggressive but still want maximum speed.'
    },
    balanced: {
      tagline: '4 workers, 4-10ms typing',
      whatItDoes: 'Runs 4 browser windows at the same time with moderate typing speed. A good middle ground between speed and staying undetected.',
      whenToUse: 'You want decent speed without getting blocked too often. Works well for medium-sized lists (500–5,000 entries).',
      tradeoffs: 'Slower than Fast but much less likely to trigger bot detection. Uses moderate system resources.',
      recommendedFor: 'Most users — this is the default for a reason!'
    },
    conservative: {
      tagline: '3 workers, 8-15ms typing',
      whatItDoes: 'Runs 3 browser windows with longer pauses and slightly slower typing. Prioritises avoiding detection over raw speed.',
      whenToUse: 'The target site has stricter bot detection, or you want a safer run that is less likely to get your proxies banned.',
      tradeoffs: 'Slower than Balanced but noticeably safer. Good for sites that block fast traffic.',
      recommendedFor: 'Users dealing with sites that have moderate bot protection or whose proxies are getting flagged on Balanced.'
    },
    stealth: {
      tagline: '2 workers, 10-20ms typing',
      whatItDoes: 'Only 2 browser windows, with human-like typing speed and generous pauses. Mimics real user behaviour as closely as possible.',
      whenToUse: 'The target site has strong bot detection, or you are getting blocked even on Balanced/Conservative. Use for difficult targets.',
      tradeoffs: 'Slowest of the standard profiles but the hardest to detect as a bot. Takes a long time on large lists.',
      recommendedFor: 'Users dealing with heavily protected sites or when other profiles keep getting blocked.'
    },
    nightowl: {
      tagline: '2 workers, 15-30ms typing',
      whatItDoes: 'Designed for long overnight runs — very slow and gentle, with extended pauses between batches so the process runs quietly for many hours without overloading proxies.',
      whenToUse: 'You want to leave the tool running overnight (8–12+ hours) without babysitting it. Best for slow, steady processing of medium lists.',
      tradeoffs: 'Very slow throughput — not suitable when you need results quickly. On the positive side, extremely low proxy ban rate.',
      recommendedFor: 'Users who prefer to set-and-forget and check results the next morning.'
    },
    lowresource: {
      tagline: '1 worker, 5-12ms typing',
      whatItDoes: 'Runs only a single browser window at a time, keeping CPU and RAM usage to a minimum. Everything else runs normally just much more lightly.',
      whenToUse: 'Your PC is low-powered (4 GB RAM or less), or you want to run the tool in the background while doing other work.',
      tradeoffs: 'Slowest overall throughput since only one credential is processed at a time. Very gentle on system resources.',
      recommendedFor: 'Users with older or low-spec machines, or anyone who needs the PC for other tasks while the tool runs.'
    },
    debug: {
      tagline: '1 worker, 50-150ms typing',
      whatItDoes: 'Single worker with very slow, deliberate typing and full verbose browser output (dumpio). Every action is easy to watch and trace. Designed purely for diagnosing problems.',
      whenToUse: 'Something is going wrong and you want to see exactly what the browser is doing. Not intended for production runs.',
      tradeoffs: 'Very slow and outputs a lot of console noise. Not useful for processing real lists — use it only for testing and debugging.',
      recommendedFor: 'Developers and advanced users troubleshooting issues.'
    }
  };
}

/**
 * Get detailed settings for a profile with human-readable labels, descriptions, and ranges.
 * Note: browser.headless is intentionally excluded — it is managed independently via the
 * Browser settings section and is not tied to any performance profile.
 */
function getProfileSettings(profileName) {
  const profile = PROFILES[profileName];
  if (!profile) return null;
  
  return {
    name: profileName,
    description: getProfileDescriptions()[profileName],
    settings: [
      // Browser settings
      {
        section: 'Browser',
        key: 'browser.timeout',
        label: 'Worker Timeout (ms)',
        type: 'number',
        value: profile.browser.timeout,
        min: 30000,
        max: 600000,
        step: 10000,
        description: 'How long a single browser worker is allowed to run before it is force-stopped. Think of this as a safety net — if a worker gets stuck (e.g., a page never loads), it will be killed after this time. 1000ms = 1 second. Recommended: 90,000–300,000ms (90 seconds to 5 minutes). Increase if you have very slow proxies or a slow internet connection.'
      },
      // Batch settings
      {
        section: 'Workers & Batching',
        key: 'batch.maxParallelWorkers',
        label: 'Max Parallel Workers',
        type: 'number',
        value: profile.batch.maxParallelWorkers,
        min: 1,
        max: 16,
        description: 'How many browser windows run at the same time. More workers = faster processing, but uses more RAM and CPU. Each worker needs roughly 200–400 MB of RAM. If your PC has 8 GB RAM, try 3–4 workers. With 16 GB, you can safely go up to 8–10. Setting this too high will slow everything down or cause crashes. Recommended: 2–4 for most PCs, 6–12 for high-end machines.'
      },
      {
        section: 'Workers & Batching',
        key: 'batch.credentialsPerProxy',
        label: 'Credentials per Proxy',
        type: 'number',
        value: profile.batch.credentialsPerProxy,
        min: 1,
        max: 20,
        description: 'How many username/password pairs are tested through one proxy before switching to the next. Using too many per proxy increases the risk of that proxy getting banned or rate-limited. Recommended: 2–4 for stealth, 8–15 for speed. If your proxies keep getting blocked, lower this value.'
      },
      {
        section: 'Workers & Batching',
        key: 'batch.pauseBetweenBatchMin',
        label: 'Min Batch Pause (ms)',
        type: 'number',
        value: profile.batch.pauseBetweenBatchMin,
        min: 0,
        max: 60000,
        step: 500,
        description: 'The shortest pause the tool will wait between processing one batch and starting the next. 1000ms = 1 second. A pause helps cool down proxies and avoid triggering rate limits. The actual pause will be a random value between Min and Max. Recommended: 500–2,000ms for speed profiles, 3,000–8,000ms for stealth profiles.'
      },
      {
        section: 'Workers & Batching',
        key: 'batch.pauseBetweenBatchMax',
        label: 'Max Batch Pause (ms)',
        type: 'number',
        value: profile.batch.pauseBetweenBatchMax,
        min: 0,
        max: 120000,
        step: 500,
        description: 'The longest pause the tool will wait between batches. The actual pause is randomly chosen between Min and Max to look more human-like. 1000ms = 1 second. Must be greater than or equal to Min Batch Pause. Recommended: 2,000–5,000ms for speed, 8,000–20,000ms for stealth/overnight profiles.'
      },
      // Form / Typing settings
      {
        section: 'Human Simulation',
        key: 'form.typeDelayMin',
        label: 'Min Typing Delay (ms)',
        type: 'number',
        value: profile.form.typeDelayMin,
        min: 0,
        max: 200,
        description: 'The shortest time (in milliseconds) between each keystroke when the tool types into a form field. Lower = faster but looks more robotic. Real human typing is usually 80–200ms per key. Values below 5ms are extremely fast and may trigger bot detection on sensitive sites. Recommended: 1–5ms for max speed, 50–150ms for stealth.'
      },
      {
        section: 'Human Simulation',
        key: 'form.typeDelayMax',
        label: 'Max Typing Delay (ms)',
        type: 'number',
        value: profile.form.typeDelayMax,
        min: 1,
        max: 500,
        description: 'The longest time between keystrokes when typing. The actual delay per keystroke is randomly chosen between Min and Max, making the typing pattern vary naturally. Must be greater than Min Typing Delay. Recommended: 5–20ms for speed profiles, 100–300ms for stealth profiles. A wider range (e.g., 10–150ms) looks more human than a narrow one (e.g., 10–12ms).'
      },
      {
        section: 'Human Simulation',
        key: 'form.pauseBetweenCredsMin',
        label: 'Min Cred Pause (ms)',
        type: 'number',
        value: profile.form.pauseBetweenCredsMin,
        min: 0,
        max: 5000,
        description: 'The minimum pause between finishing one credential attempt and starting the next. This simulates the natural gap between a human\'s login attempts. 1000ms = 1 second. Recommended: 50–200ms for speed, 300–1,000ms for stealth. Increase if the target site is rate-limiting individual login attempts.'
      },
      {
        section: 'Human Simulation',
        key: 'form.pauseBetweenCredsMax',
        label: 'Max Cred Pause (ms)',
        type: 'number',
        value: profile.form.pauseBetweenCredsMax,
        min: 0,
        max: 10000,
        description: 'The maximum pause between credential attempts. The actual pause is randomly chosen between Min and Max. A wider random range looks more human. 1000ms = 1 second. Must be greater than or equal to Min Cred Pause. Recommended: 150–500ms for speed, 500–2,000ms for stealth profiles.'
      },
      // Navigation
      {
        section: 'Navigation',
        key: 'navigation.timeout',
        label: 'Navigation Timeout (ms)',
        type: 'number',
        value: profile.navigation.timeout,
        min: 5000,
        max: 60000,
        step: 1000,
        description: 'How long to wait for a webpage to fully load before giving up and marking it as a timeout. 1000ms = 1 second. If pages load slowly (slow VPN, slow proxy, slow target site), increase this value. If pages load quickly, a lower value will speed things up. Recommended: 8,000–12,000ms (8–12 seconds) for fast profiles, 14,000–20,000ms (14–20 seconds) for stealth/overnight profiles.'
      },
    ]
  };
}

/**
 * Create a custom profile from user-modified values
 * @param {string} baseName - Base profile name to start from
 * @param {Object} overrides - Key-value pairs of settings to override (e.g., { 'batch.maxParallelWorkers': 6 })
 * @returns {Object} The customized profile object
 */
function createCustomProfile(baseName, overrides) {
  const base = JSON.parse(JSON.stringify(PROFILES[baseName] || PROFILES.balanced));
  
  for (const [path, value] of Object.entries(overrides)) {
    const keys = path.split('.');
    let obj = base;
    for (let i = 0; i < keys.length - 1; i++) {
      if (!obj[keys[i]]) obj[keys[i]] = {};
      obj = obj[keys[i]];
    }
    obj[keys[keys.length - 1]] = value;
  }
  
  return base;
}

module.exports = {
  PROFILES,
  applyProfile,
  getProfileList,
  getProfile,
  getProfileDescriptions,
  getProfileDetailedDescriptions,
  getProfileSettings,
  createCustomProfile
};
