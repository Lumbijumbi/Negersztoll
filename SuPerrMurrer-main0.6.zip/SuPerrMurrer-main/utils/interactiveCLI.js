/**
 * ============================================================================
 * INTERACTIVE CLI - Beautiful User Experience
 * ============================================================================
 * 
 * Provides an interactive startup wizard with:
 * - ASCII art banner
 * - Multiple choice selection
 * - Configuration prompts
 * - User preferences
 */

const readline = require('readline');
const fs = require('fs').promises;
const path = require('path');

class InteractiveCLI {
  constructor() {
    this.rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });
  }

  /**
   * Print ASCII art banner
   */
  printBanner() {
    const banner = `
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   ███████╗██╗   ██╗██████╗ ███████╗██████╗ ██████╗           ║
║   ██╔════╝██║   ██║██╔══██╗██╔════╝██╔══██╗██╔══██╗          ║
║   ███████╗██║   ██║██████╔╝█████╗  ██████╔╝██████╔╝          ║
║   ╚════██║██║   ██║██╔═══╝ ██╔══╝  ██╔══██╗██╔══██╗          ║
║   ███████║╚██████╔╝██║     ███████╗██║  ██║██║  ██║          ║
║   ╚══════╝ ╚═════╝ ╚═╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝          ║
║                                                               ║
║              🚀 SuPerrMurrer - Credential Tester 🚀           ║
║                  Production-Ready Edition                     ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
`;
    console.log(banner);
  }

  /**
   * Ask a simple question
   */
  question(prompt) {
    return new Promise(resolve => {
      this.rl.question(prompt, answer => {
        resolve(answer.trim());
      });
    });
  }

  /**
   * Ask a yes/no confirmation
   */
  async confirm(question, defaultYes = true) {
    const defaultText = defaultYes ? '[Y/n]' : '[y/N]';
    const answer = await this.question(`${question} ${defaultText}: `);
    
    if (!answer) return defaultYes;
    
    const normalized = answer.toLowerCase();
    return normalized === 'y' || normalized === 'yes';
  }

  /**
   * Present multiple choice selection
   */
  async choice(question, choices) {
    console.log(`\n${question}`);
    choices.forEach((choice, index) => {
      console.log(`  ${index + 1}. ${choice}`);
    });
    
    while (true) {
      const answer = await this.question('\nSelect option (number): ');
      const num = parseInt(answer, 10);
      
      if (num >= 1 && num <= choices.length) {
        return num - 1; // Return 0-based index
      }
      
      console.log('❌ Invalid selection. Please try again.');
    }
  }

  /**
   * Run the startup wizard
   */
  async runStartupWizard() {
    this.printBanner();
    
    console.log('Welcome to SuPerrMurrer Interactive Mode!\n');
    
    // Main menu
    const mainChoice = await this.choice(
      '🎯 What would you like to do?',
      [
        '🚀 Start new session',
        '⏸️  Resume previous session',
        '📊 View previous results',
        '🧪 Run tests (dry run)',
        '⚙️  Configure settings',
        '🚪 Exit'
      ]
    );

    // Handle main menu selection
    switch (mainChoice) {
      case 0: // Start new session
        return await this.configureNewSession();
      
      case 1: // Resume session
        console.log('\n⏸️  Resume session feature coming soon!');
        console.log('For now, starting a new session...\n');
        return await this.configureNewSession();
      
      case 2: // View results
        console.log('\n📊 Results viewer feature coming soon!');
        console.log('For now, starting a new session...\n');
        return await this.configureNewSession();
      
      case 3: // Run tests
        console.log('\n🧪 Test mode enabled\n');
        return await this.configureNewSession(true);
      
      case 4: // Configure settings
        return await this.configureNewSession();
      
      case 5: // Exit
        console.log('\n👋 Goodbye!\n');
        this.close();
        return null;
      
      default:
        console.log('\n❌ Invalid selection\n');
        this.close();
        return null;
    }
  }

  /**
   * Configure a new session
   */
  async configureNewSession(testMode = false) {
    const config = {
      testMode,
      profile: 'balanced',
      features: {},
      overrides: {}
    };

    // Performance profile selection
    console.log('\n⚡ Choose a performance profile:\n');
    const profileChoice = await this.choice(
      'Performance profiles balance speed vs stealth',
      [
        '🚀 Fast - Maximum speed (headless, 8 workers)',
        '⚖️  Balanced - Recommended (4 workers, moderate delays)',
        '🥷 Stealth - Maximum stealth (2 workers, human-like)',
        '🔧 Custom - I\'ll configure manually'
      ]
    );

    const profiles = ['fast', 'balanced', 'stealth', 'custom'];
    config.profile = profiles[profileChoice];

    // Feature toggles
    console.log('\n🎛️  Feature Configuration:\n');
    
    config.features.sessionReuse = await this.confirm(
      '🔐 Enable session cookie reuse? (faster, but may be detected)',
      true
    );

    config.features.retryQueue = await this.confirm(
      '🔄 Enable automatic retry queue? (retry failed credentials)',
      true
    );

    config.features.webhooks = await this.confirm(
      '📢 Enable webhook notifications? (Discord/Slack)',
      false
    );

    config.features.screenshots = await this.confirm(
      '📸 Enable screenshots? (helpful for debugging)',
      true
    );

    config.features.connectionPool = await this.confirm(
      '🔗 Enable connection pooling? (30-40% faster)',
      true
    );

    config.features.autoTuneWorkers = await this.confirm(
      '🎚️  Enable auto-tune workers? (automatic resource adjustment)',
      true
    );

    config.features.healthChecks = await this.confirm(
      '🏥 Enable health monitoring? (detect issues early)',
      true
    );

    config.features.autoRecovery = await this.confirm(
      '🛡️  Enable auto-recovery? (self-healing on errors)',
      true
    );

    // Custom configuration
    if (config.profile === 'custom') {
      console.log('\n🔧 Custom Configuration:\n');
      
      const workersStr = await this.question('Number of parallel workers (1-16): ');
      const workers = parseInt(workersStr, 10);
      if (workers >= 1 && workers <= 16) {
        config.overrides.maxParallelWorkers = workers;
      }

      const headless = await this.confirm('Run in headless mode?', false);
      config.overrides.headless = headless;

      const credsPerProxyStr = await this.question('Credentials per proxy (1-20): ');
      const credsPerProxy = parseInt(credsPerProxyStr, 10);
      if (credsPerProxy >= 1 && credsPerProxy <= 20) {
        config.overrides.credentialsPerProxy = credsPerProxy;
      }
    }

    // Display summary
    console.log('\n📋 Configuration Summary:');
    console.log('═'.repeat(60));
    console.log(`  Profile: ${config.profile.toUpperCase()}`);
    console.log(`  Session Reuse: ${config.features.sessionReuse ? '✅' : '❌'}`);
    console.log(`  Retry Queue: ${config.features.retryQueue ? '✅' : '❌'}`);
    console.log(`  Webhooks: ${config.features.webhooks ? '✅' : '❌'}`);
    console.log(`  Screenshots: ${config.features.screenshots ? '✅' : '❌'}`);
    console.log(`  Connection Pool: ${config.features.connectionPool ? '✅' : '❌'}`);
    console.log(`  Auto-tune Workers: ${config.features.autoTuneWorkers ? '✅' : '❌'}`);
    console.log(`  Health Checks: ${config.features.healthChecks ? '✅' : '❌'}`);
    console.log(`  Auto-recovery: ${config.features.autoRecovery ? '✅' : '❌'}`);
    if (Object.keys(config.overrides).length > 0) {
      console.log('  Custom Overrides:');
      Object.entries(config.overrides).forEach(([key, value]) => {
        console.log(`    - ${key}: ${value}`);
      });
    }
    console.log('═'.repeat(60));

    // Confirmation
    const proceed = await this.confirm('\n✅ Start with this configuration?', true);
    
    if (!proceed) {
      console.log('\n❌ Configuration cancelled. Exiting...\n');
      this.close();
      return null;
    }

    // Save preferences
    await this.savePreferences(config);

    console.log('\n🚀 Starting SuPerrMurrer...\n');
    
    return config;
  }

  /**
   * Save user preferences to file
   */
  async savePreferences(config) {
    try {
      const configPath = path.join(process.cwd(), '.supeconfig.json');
      await fs.writeFile(configPath, JSON.stringify(config, null, 2));
    } catch (error) {
      // Silent fail - not critical
    }
  }

  /**
   * Load saved preferences
   */
  async loadPreferences() {
    try {
      const configPath = path.join(process.cwd(), '.supeconfig.json');
      const content = await fs.readFile(configPath, 'utf8');
      return JSON.parse(content);
    } catch (error) {
      return null;
    }
  }

  /**
   * Close the readline interface
   */
  close() {
    this.rl.close();
  }
}

module.exports = InteractiveCLI;
