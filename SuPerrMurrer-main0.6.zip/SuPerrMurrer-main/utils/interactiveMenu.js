/**
 * ============================================================================
 * INTERACTIVE MAIN MENU - Phase 1, Task 2
 * ============================================================================
 * 
 * Implements:
 * ✅ Main menu with Inquirer.js for intuitive navigation
 * ✅ Access to all major functions (credential testing, configuration, results, etc.)
 * ✅ Quick actions menu for frequent operations
 * ✅ Keyboard shortcuts for common operations
 * ✅ Context-sensitive help and documentation
 */

// Node.js built-in modules
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

// Third-party modules
const inquirer = require('inquirer');

// Local modules
const EnhancedConsole = require('./enhancedConsole');
const { readJSONFile, readTextFile } = require('./fileHelper');

// Constants
const CONFIG_PREVIEW_LENGTH = 500;  // Characters to show when previewing imported config

class InteractiveMenu {
  constructor(options = {}) {
    this.console = new EnhancedConsole();
    this.configPath = options.configPath || path.join(process.cwd(), 'config.js');
    this.logsDir = options.logsDir || path.join(process.cwd(), 'logs');
    this.credentialsFile = options.credentialsFile || path.join(process.cwd(), 'test.txt');
    this.proxiesFile = options.proxiesFile || path.join(process.cwd(), 'Lightning_Proxies.txt');
  }

  /**
   * Display the main menu header
   */
  displayHeader() {
    this.console.clear();
    this.console.header('SuPerrMurrer - Automated Credential Testing System', {
      color: 'cyan',
      char: '═',
      length: 80
    });
    this.console.spacing(1);
  }

  /**
   * Main menu
   */
  async showMainMenu() {
    this.displayHeader();

    const choices = [
      { name: '🚀 Start Credential Testing', value: 'test' },
      { name: '📦 Queue Management', value: 'queue' },
      { name: '⚙️  Configuration Management', value: 'config' },
      { name: '📊 View Results & Analysis', value: 'results' },
      { name: '⚡ Quick Actions', value: 'quick' },
      { name: '🔍 System Status & Metrics', value: 'status' },
      { name: '📖 Help & Documentation', value: 'help' },
      new inquirer.Separator(),
      { name: '🚪 Exit', value: 'exit' }
    ];

    this.console.info('Select an option (Use ↑/↓ arrows and Enter):');
    this.console.spacing(1);

    const { action } = await inquirer.prompt([
      {
        type: 'list',
        name: 'action',
        message: 'Main Menu:',
        choices,
        pageSize: 10
      }
    ]);

    await this.handleMainMenuAction(action);
  }

  /**
   * Handle main menu action
   */
  async handleMainMenuAction(action) {
    switch (action) {
      case 'test':
        await this.credentialTestingMenu();
        break;
      case 'queue':
        await this.queueManagementMenu();
        break;
      case 'config':
        await this.configurationMenu();
        break;
      case 'results':
        await this.resultsMenu();
        break;
      case 'quick':
        await this.quickActionsMenu();
        break;
      case 'status':
        await this.systemStatusMenu();
        break;
      case 'help':
        await this.helpMenu();
        break;
      case 'exit':
        this.console.success('Thank you for using SuPerrMurrer. Goodbye!');
        process.exit(0);
        break;
    }
  }

  /**
   * Credential Testing Menu
   */
  async credentialTestingMenu() {
    this.displayHeader();
    this.console.section('Credential Testing', 'Start automated credential testing with various options', {
      borderColor: 'green'
    });
    this.console.spacing(1);

    const choices = [
      { name: '▶️  Start Testing (Current Configuration)', value: 'start' },
      { name: '⚙️  Configure & Start', value: 'configure_start' },
      { name: '🔄 Retry Failed Credentials', value: 'retry' },
      { name: '📝 View/Edit Credentials File', value: 'view_credentials' },
      { name: '🌐 View/Edit Proxies File', value: 'view_proxies' },
      new inquirer.Separator(),
      { name: '⬅️  Back to Main Menu', value: 'back' }
    ];

    const { action } = await inquirer.prompt([
      {
        type: 'list',
        name: 'action',
        message: 'Credential Testing:',
        choices
      }
    ]);

    switch (action) {
      case 'start':
        await this.startTesting();
        break;
      case 'configure_start':
        await this.configureAndStart();
        break;
      case 'retry':
        await this.retryFailed();
        break;
      case 'view_credentials':
        await this.viewFile(this.credentialsFile, 'Credentials');
        break;
      case 'view_proxies':
        await this.viewFile(this.proxiesFile, 'Proxies');
        break;
      case 'back':
        await this.showMainMenu();
        break;
    }
  }

  /**
   * Queue Management Menu
   */
  async queueManagementMenu() {
    const ComboQueue = require('./comboQueue');
    const CredentialHistory = require('./credentialHistory');
    const config = require('../config');
    
    // Initialize queue
    const history = new CredentialHistory(config.history);
    history.load();
    
    const queue = new ComboQueue({
      queueFile: config.queue.queueFile,
      historyInstance: history,
      ...config.queue
    });

    this.displayHeader();
    this.console.section('Queue Management', 'Manage combo file queue and backlog', {
      borderColor: 'yellow'
    });
    this.console.spacing(1);

    const choices = [
      { name: '📥 Add Combo File to Queue', value: 'add' },
      { name: '📋 View Queue / Backlog', value: 'view' },
      { name: '🔀 Shuffle Queue', value: 'shuffle' },
      { name: '⏱️  Set List Timer / Delay', value: 'timer' },
      { name: '🏷️  Set File Priority', value: 'priority' },
      { name: '🗑️  Remove File from Queue', value: 'remove' },
      { name: '🧹 Clear Completed Files', value: 'clear' },
      { name: '▶️  Start Processing Queue', value: 'start' },
      { name: '⏸️  Pause / Resume Queue', value: 'pause' },
      new inquirer.Separator(),
      { name: '⬅️  Back to Main Menu', value: 'back' }
    ];

    const { action } = await inquirer.prompt([
      {
        type: 'list',
        name: 'action',
        message: 'Queue Management:',
        choices
      }
    ]);

    switch (action) {
      case 'add':
        await this.queueAddFile(queue);
        break;
      case 'view':
        await this.queueViewBacklog(queue);
        break;
      case 'shuffle':
        await this.queueShuffle(queue);
        break;
      case 'timer':
        await this.queueSetTimer(queue, config);
        break;
      case 'priority':
        await this.queueSetPriority(queue);
        break;
      case 'remove':
        await this.queueRemoveFile(queue);
        break;
      case 'clear':
        await this.queueClearCompleted(queue);
        break;
      case 'start':
        await this.queueStartProcessing();
        break;
      case 'pause':
        await this.queuePauseResume(queue);
        break;
      case 'back':
        await this.showMainMenu();
        break;
    }
  }

  /**
   * Add file to queue
   */
  async queueAddFile(queue) {
    const { filepath } = await inquirer.prompt([
      {
        type: 'input',
        name: 'filepath',
        message: 'Enter path to combo file:',
        validate: (input) => {
          if (!input) return 'Please enter a file path';
          const fs = require('fs');
          if (!fs.existsSync(input)) return 'File not found';
          return true;
        }
      }
    ]);

    const { priority } = await inquirer.prompt([
      {
        type: 'list',
        name: 'priority',
        message: 'Select priority (1=highest, 5=lowest):',
        choices: [
          { name: '★☆☆☆☆ - Priority 1 (Highest)', value: 1 },
          { name: '★★☆☆☆ - Priority 2', value: 2 },
          { name: '★★★☆☆ - Priority 3 (Default)', value: 3 },
          { name: '★★★★☆ - Priority 4', value: 4 },
          { name: '★★★★★ - Priority 5 (Lowest)', value: 5 }
        ],
        default: 3
      }
    ]);

    try {
      const stats = queue.addFile(filepath, { priority });
      const path = require('path');
      this.console.success(`✅ Added file: ${path.basename(filepath)}`);
      this.console.info(`   Total lines: ${stats.added}`);
      this.console.info(`   Duplicates removed: ${stats.duplicatesRemoved}`);
      this.console.info(`   Already processed: ${stats.alreadyProcessed}`);
      this.console.info(`   New combos queued: ${stats.queued}`);
      this.console.spacing(1);

      const { addAnother } = await inquirer.prompt([
        {
          type: 'confirm',
          name: 'addAnother',
          message: 'Add another file?',
          default: false
        }
      ]);

      if (addAnother) {
        await this.queueAddFile(queue);
      } else {
        await this.queueManagementMenu();
      }
    } catch (error) {
      this.console.error(`Error: ${error.message}`);
      await this.pressAnyKey();
      await this.queueManagementMenu();
    }
  }

  /**
   * View queue/backlog
   */
  async queueViewBacklog(queue) {
    const stats = queue.getStats();
    const files = queue.getFiles();

    this.console.clear();
    this.console.header('Queue Status', { color: 'yellow' });
    this.console.spacing(1);

    this.console.info(`Total Files: ${stats.totalFiles}`);
    this.console.info(`Total Combos in Queue: ${stats.totalCombos}`);
    this.console.info(`Pending: ${stats.pending} | Processing: ${stats.processing} | Completed: ${stats.completed}`);
    this.console.info(`Paused: ${stats.paused ? 'Yes' : 'No'}`);
    this.console.spacing(1);

    if (files.length === 0) {
      this.console.warning('No files in queue.');
    } else {
      console.log('═══════════════════════════════════════════════════════════════════════════');
      console.log('# | File                  | Priority  | Status     | Total | Queued | Processed | Added');
      console.log('───────────────────────────────────────────────────────────────────────────');
      
      files.forEach((file, index) => {
        const priorityStars = '★'.repeat(file.priority) + '☆'.repeat(5 - file.priority);
        const filename = file.filename.length > 20 ? file.filename.substring(0, 17) + '...' : file.filename.padEnd(20);
        const status = file.status.padEnd(10);
        const added = new Date(file.addedAt).toLocaleDateString();
        
        console.log(`${(index + 1).toString().padStart(2)} | ${filename} | ${priorityStars} | ${status} | ${file.lineCount.toString().padStart(5)} | ${file.queuedCount.toString().padStart(6)} | ${file.processedCount.toString().padStart(9)} | ${added}`);
      });
      console.log('═══════════════════════════════════════════════════════════════════════════');
    }

    this.console.spacing(1);
    await this.pressAnyKey();
    await this.queueManagementMenu();
  }

  /**
   * Shuffle queue
   */
  async queueShuffle(queue) {
    queue.shuffle();
    this.console.success('✅ Queue shuffled successfully');
    await this.pressAnyKey();
    await this.queueManagementMenu();
  }

  /**
   * Set list timer/delay
   */
  async queueSetTimer(queue, config) {
    const { delay } = await inquirer.prompt([
      {
        type: 'number',
        name: 'delay',
        message: 'Enter delay between lists (milliseconds, 0 = no delay):',
        default: config.queue.listDelay || 0,
        validate: (input) => {
          if (input < 0) return 'Delay must be 0 or greater';
          return true;
        }
      }
    ]);

    const { jitter } = await inquirer.prompt([
      {
        type: 'number',
        name: 'jitter',
        message: 'Enter random jitter (milliseconds, 0 = no jitter):',
        default: config.queue.listDelayJitter || 0,
        validate: (input) => {
          if (input < 0) return 'Jitter must be 0 or greater';
          return true;
        }
      }
    ]);

    queue.listDelay = delay;
    queue.listDelayJitter = jitter;
    queue.save();

    this.console.success(`✅ List delay set to ${delay}ms with ${jitter}ms jitter`);
    await this.pressAnyKey();
    await this.queueManagementMenu();
  }

  /**
   * Set file priority
   */
  async queueSetPriority(queue) {
    const files = queue.getFiles();
    
    if (files.length === 0) {
      this.console.warning('No files in queue.');
      await this.pressAnyKey();
      await this.queueManagementMenu();
      return;
    }

    const fileChoices = files.map(f => ({
      name: `${f.filename} (Current: ${'★'.repeat(f.priority)}${'☆'.repeat(5 - f.priority)})`,
      value: f.filename
    }));

    const { filename } = await inquirer.prompt([
      {
        type: 'list',
        name: 'filename',
        message: 'Select file to change priority:',
        choices: fileChoices
      }
    ]);

    const { priority } = await inquirer.prompt([
      {
        type: 'list',
        name: 'priority',
        message: 'Select new priority:',
        choices: [
          { name: '★☆☆☆☆ - Priority 1 (Highest)', value: 1 },
          { name: '★★☆☆☆ - Priority 2', value: 2 },
          { name: '★★★☆☆ - Priority 3 (Default)', value: 3 },
          { name: '★★★★☆ - Priority 4', value: 4 },
          { name: '★★★★★ - Priority 5 (Lowest)', value: 5 }
        ]
      }
    ]);

    queue.setPriority(filename, priority);
    this.console.success(`✅ Priority updated for ${filename}`);
    await this.pressAnyKey();
    await this.queueManagementMenu();
  }

  /**
   * Remove file from queue
   */
  async queueRemoveFile(queue) {
    const files = queue.getFiles();
    
    if (files.length === 0) {
      this.console.warning('No files in queue.');
      await this.pressAnyKey();
      await this.queueManagementMenu();
      return;
    }

    const fileChoices = files.map(f => ({
      name: `${f.filename} (${f.queuedCount} queued)`,
      value: f.filename
    }));

    const { filename } = await inquirer.prompt([
      {
        type: 'list',
        name: 'filename',
        message: 'Select file to remove:',
        choices: fileChoices
      }
    ]);

    const { confirm } = await inquirer.prompt([
      {
        type: 'confirm',
        name: 'confirm',
        message: `Are you sure you want to remove ${filename}?`,
        default: false
      }
    ]);

    if (confirm) {
      queue.removeFile(filename);
      this.console.success(`✅ Removed ${filename} from queue`);
    } else {
      this.console.info('Cancelled');
    }

    await this.pressAnyKey();
    await this.queueManagementMenu();
  }

  /**
   * Clear completed files
   */
  async queueClearCompleted(queue) {
    const cleared = queue.clearCompleted();
    
    if (cleared > 0) {
      this.console.success(`✅ Cleared ${cleared} completed file(s)`);
    } else {
      this.console.info('No completed files to clear');
    }

    await this.pressAnyKey();
    await this.queueManagementMenu();
  }

  /**
   * Start processing queue
   */
  async queueStartProcessing() {
    this.console.info('Starting queue processing...');
    this.console.info('This will launch the credential testing controller.');
    
    const { confirm } = await inquirer.prompt([
      {
        type: 'confirm',
        name: 'confirm',
        message: 'Start testing now?',
        default: true
      }
    ]);

    if (confirm) {
      await this.startTesting();
    } else {
      await this.queueManagementMenu();
    }
  }

  /**
   * Pause/Resume queue
   */
  async queuePauseResume(queue) {
    const isPaused = queue.isPaused();
    
    if (isPaused) {
      queue.resume();
      this.console.success('✅ Queue resumed');
    } else {
      queue.pause();
      this.console.success('✅ Queue paused');
    }

    await this.pressAnyKey();
    await this.queueManagementMenu();
  }

  /**
   * Configuration Menu
   */
  async configurationMenu() {
    this.displayHeader();
    this.console.section('Configuration Management', 'Manage system configuration and settings', {
      borderColor: 'blue'
    });
    this.console.spacing(1);

    const choices = [
      { name: '👀 View Current Configuration', value: 'view' },
      { name: '✏️  Edit Configuration File', value: 'edit' },
      { name: '🔄 Reload Configuration', value: 'reload' },
      { name: '📋 Export Configuration', value: 'export' },
      { name: '📥 Import Configuration', value: 'import' },
      new inquirer.Separator(),
      { name: '⬅️  Back to Main Menu', value: 'back' }
    ];

    const { action } = await inquirer.prompt([
      {
        type: 'list',
        name: 'action',
        message: 'Configuration:',
        choices
      }
    ]);

    switch (action) {
      case 'view':
        await this.viewConfiguration();
        break;
      case 'edit':
        await this.editConfiguration();
        break;
      case 'reload':
        await this.reloadConfiguration();
        break;
      case 'export':
        await this.exportConfiguration();
        break;
      case 'import':
        await this.importConfiguration();
        break;
      case 'back':
        await this.showMainMenu();
        break;
    }
  }

  /**
   * Results & Analysis Menu
   */
  async resultsMenu() {
    this.displayHeader();
    this.console.section('Results & Analysis', 'View and analyze testing results', {
      borderColor: 'yellow'
    });
    this.console.spacing(1);

    const choices = [
      { name: '📈 View Latest Results', value: 'latest' },
      { name: '📊 Generate Summary Report', value: 'summary' },
      { name: '✅ View Successful Logins', value: 'successful' },
      { name: '❌ View Failed Logins', value: 'failed' },
      { name: '🚫 View Blocked Accounts', value: 'blocked' },
      { name: '📁 Browse Logs Directory', value: 'browse' },
      { name: '💾 Export Results (CSV/JSON)', value: 'export' },
      new inquirer.Separator(),
      { name: '⬅️  Back to Main Menu', value: 'back' }
    ];

    const { action } = await inquirer.prompt([
      {
        type: 'list',
        name: 'action',
        message: 'Results & Analysis:',
        choices
      }
    ]);

    switch (action) {
      case 'latest':
        await this.viewLatestResults();
        break;
      case 'summary':
        await this.generateSummary();
        break;
      case 'successful':
        await this.viewResultCategory('successful');
        break;
      case 'failed':
        await this.viewResultCategory('failed');
        break;
      case 'blocked':
        await this.viewResultCategory('blocked');
        break;
      case 'browse':
        await this.browseLogs();
        break;
      case 'export':
        await this.exportResults();
        break;
      case 'back':
        await this.showMainMenu();
        break;
    }
  }

  /**
   * Quick Actions Menu
   */
  async quickActionsMenu() {
    this.displayHeader();
    this.console.section('Quick Actions', 'Frequent operations for power users', {
      borderColor: 'magenta'
    });
    this.console.spacing(1);

    this.console.info('💡 Keyboard Shortcuts:');
    console.log('  Ctrl+T - Start Testing');
    console.log('  Ctrl+R - View Results');
    console.log('  Ctrl+S - System Status');
    console.log('  Ctrl+Q - Quick Actions');
    this.console.spacing(1);

    const choices = [
      { name: '🚀 Quick Start (Default Settings)', value: 'quick_start' },
      { name: '🔄 Retry Last Failed Batch', value: 'retry_last' },
      { name: '📊 Show Latest Summary', value: 'show_summary' },
      { name: '🧹 Clear Old Logs', value: 'clear_logs' },
      { name: '♻️  Reset Retry Queue', value: 'reset_queue' },
      { name: '🗑️  Delete Session Files', value: 'delete_sessions' },
      new inquirer.Separator(),
      { name: '⬅️  Back to Main Menu', value: 'back' }
    ];

    const { action } = await inquirer.prompt([
      {
        type: 'list',
        name: 'action',
        message: 'Quick Actions:',
        choices
      }
    ]);

    switch (action) {
      case 'quick_start':
        await this.startTesting();
        break;
      case 'retry_last':
        await this.retryFailed();
        break;
      case 'show_summary':
        await this.generateSummary();
        break;
      case 'clear_logs':
        await this.clearOldLogs();
        break;
      case 'reset_queue':
        await this.resetRetryQueue();
        break;
      case 'delete_sessions':
        await this.deleteSessions();
        break;
      case 'back':
        await this.showMainMenu();
        break;
    }
  }

  /**
   * System Status Menu
   */
  async systemStatusMenu() {
    this.displayHeader();
    this.console.section('System Status & Metrics', 'View system health and statistics', {
      borderColor: 'cyan'
    });
    this.console.spacing(1);

    // Check system status
    const status = await this.getSystemStatus();

    // Display status table
    const headers = ['Component', 'Status', 'Details'];
    const rows = [
      ['Credentials File', status.credentials.exists ? '✓' : '✗', `${status.credentials.count} credentials`],
      ['Proxies File', status.proxies.exists ? '✓' : '✗', `${status.proxies.count} proxies`],
      ['Configuration', status.config.exists ? '✓' : '✗', status.config.valid ? 'Valid' : 'Invalid'],
      ['Logs Directory', status.logs.exists ? '✓' : '✗', `${status.logs.fileCount} files`],
      ['Retry Queue', status.retryQueue.exists ? '✓' : '✗', `${status.retryQueue.count} items`],
      ['Sessions', status.sessions.exists ? '✓' : '✗', `${status.sessions.count} sessions`]
    ];

    this.console.table(headers, rows);
    this.console.spacing(1);

    const { action } = await inquirer.prompt([
      {
        type: 'list',
        name: 'action',
        message: 'What would you like to do?',
        choices: [
          { name: '🔄 Refresh Status', value: 'refresh' },
          { name: '⬅️  Back to Main Menu', value: 'back' }
        ]
      }
    ]);

    if (action === 'refresh') {
      await this.systemStatusMenu();
    } else {
      await this.showMainMenu();
    }
  }

  /**
   * Help Menu
   */
  async helpMenu() {
    this.displayHeader();
    this.console.section('Help & Documentation', 'Learn how to use SuPerrMurrer', {
      borderColor: 'blue'
    });
    this.console.spacing(1);

    const choices = [
      { name: '📖 Quick Start Guide', value: 'quickstart' },
      { name: '📚 Full Documentation', value: 'docs' },
      { name: '❓ FAQ', value: 'faq' },
      { name: '🐛 Troubleshooting', value: 'troubleshoot' },
      { name: '📝 View README', value: 'readme' },
      new inquirer.Separator(),
      { name: '⬅️  Back to Main Menu', value: 'back' }
    ];

    const { action } = await inquirer.prompt([
      {
        type: 'list',
        name: 'action',
        message: 'Help & Documentation:',
        choices
      }
    ]);

    switch (action) {
      case 'quickstart':
        await this.showQuickStart();
        break;
      case 'docs':
        await this.showDocumentation();
        break;
      case 'faq':
        await this.showFAQ();
        break;
      case 'troubleshoot':
        await this.showTroubleshooting();
        break;
      case 'readme':
        await this.showReadme();
        break;
      case 'back':
        await this.showMainMenu();
        break;
    }
  }

  // ============ ACTION IMPLEMENTATIONS ============

  /**
   * Start credential testing
   */
  async startTesting() {
    this.console.info('Starting credential testing...');
    this.console.spacing(1);
    
    const spinner = this.console.spinner('Launching controller...', { color: 'cyan' });
    
    // Give visual feedback
    setTimeout(() => {
      spinner.succeed('Controller launched successfully!');
      this.console.spacing(1);
      this.console.info('The controller is now running in a separate process.');
      this.console.info('Check the console output for progress and results.');
      this.console.spacing(1);
      
      // Actually spawn the controller
      const controller = spawn('node', ['play_version2_controller.js'], {
        stdio: 'inherit',
        cwd: process.cwd()
      });
      
      controller.on('close', async (code) => {
        this.console.spacing(1);
        if (code === 0) {
          this.console.success(`Testing completed successfully!`);
        } else {
          this.console.error(`Testing exited with code ${code}`);
        }
        this.console.spacing(1);
        
        await this.pressAnyKey();
        await this.showMainMenu();
      });
    }, 1000);
  }

  /**
   * Configure and start testing
   */
  async configureAndStart() {
    this.displayHeader();
    this.console.section('Configure & Start', 'Select a profile and adjust settings', { borderColor: 'green' });

    // Step 1: Select profile
    const { applyProfile, getProfileDescriptions, getProfile } = require('./configProfiles');
    const descriptions = getProfileDescriptions();
    
    // Load current config to read headless and other settings not owned by profiles
    delete require.cache[require.resolve(this.configPath)];
    const currentConfigForDisplay = require(this.configPath);
    
    const profileChoices = Object.entries(descriptions).map(([name, desc]) => ({
      name: desc,
      value: name
    }));
    profileChoices.push(new inquirer.Separator());
    profileChoices.push({ name: '⬅️  Back', value: 'back' });

    const { selectedProfile } = await inquirer.prompt([{
      type: 'list',
      name: 'selectedProfile',
      message: 'Select a performance profile:',
      choices: profileChoices
    }]);

    if (selectedProfile === 'back') {
      return await this.credentialTestingMenu();
    }

    // Show selected profile details
    const profile = getProfile(selectedProfile);
    this.console.section(`Profile: ${selectedProfile.toUpperCase()}`, '', { borderColor: 'cyan' });
    
    const headers = ['Setting', 'Value'];
    const rows = [
      ['Headless', currentConfigForDisplay.browser && currentConfigForDisplay.browser.headless ? 'Yes' : 'No'],
      ['Workers', String(profile.batch.maxParallelWorkers)],
      ['Creds/Proxy', String(profile.batch.credentialsPerProxy)],
      ['Batch Pause', `${profile.batch.pauseBetweenBatchMin}-${profile.batch.pauseBetweenBatchMax}ms`],
      ['Type Delay', `${profile.form.typeDelayMin}-${profile.form.typeDelayMax}ms`],
      ['Cred Pause', `${profile.form.pauseBetweenCredsMin}-${profile.form.pauseBetweenCredsMax}ms`],
      ['Nav Timeout', `${profile.navigation.timeout / 1000}s`],
      ['Browser Timeout', `${profile.browser.timeout / 1000}s`],
    ];
    this.console.table(headers, rows);

    // Step 2: Ask if they want to customize
    const { customize } = await inquirer.prompt([{
      type: 'confirm',
      name: 'customize',
      message: 'Would you like to adjust individual settings?',
      default: false
    }]);

    let overrides = {};

    if (customize) {
      // Let them tweak key values
      const { workers } = await inquirer.prompt([{
        type: 'number',
        name: 'workers',
        message: 'Max Parallel Workers:',
        default: profile.batch.maxParallelWorkers,
        validate: v => v >= 1 && v <= 16 ? true : 'Must be 1-16'
      }]);
      if (workers !== profile.batch.maxParallelWorkers) overrides['batch.maxParallelWorkers'] = workers;

      const { credsPerProxy } = await inquirer.prompt([{
        type: 'number',
        name: 'credsPerProxy',
        message: 'Credentials per Proxy:',
        default: profile.batch.credentialsPerProxy,
        validate: v => v >= 1 && v <= 20 ? true : 'Must be 1-20'
      }]);
      if (credsPerProxy !== profile.batch.credentialsPerProxy) overrides['batch.credentialsPerProxy'] = credsPerProxy;

      const { headless } = await inquirer.prompt([{
        type: 'confirm',
        name: 'headless',
        message: 'Run in headless mode?',
        default: currentConfigForDisplay.browser ? currentConfigForDisplay.browser.headless : false
      }]);
      if (headless !== (currentConfigForDisplay.browser ? currentConfigForDisplay.browser.headless : false)) overrides['browser.headless'] = headless;

      const { typeDelayMin } = await inquirer.prompt([{
        type: 'number',
        name: 'typeDelayMin',
        message: 'Min Typing Delay (ms):',
        default: profile.form.typeDelayMin
      }]);
      if (typeDelayMin !== profile.form.typeDelayMin) overrides['form.typeDelayMin'] = typeDelayMin;

      const { typeDelayMax } = await inquirer.prompt([{
        type: 'number',
        name: 'typeDelayMax',
        message: 'Max Typing Delay (ms):',
        default: profile.form.typeDelayMax
      }]);
      if (typeDelayMax !== profile.form.typeDelayMax) overrides['form.typeDelayMax'] = typeDelayMax;

      const { batchPauseMin } = await inquirer.prompt([{
        type: 'number',
        name: 'batchPauseMin',
        message: 'Min Batch Pause (ms):',
        default: profile.batch.pauseBetweenBatchMin
      }]);
      if (batchPauseMin !== profile.batch.pauseBetweenBatchMin) overrides['batch.pauseBetweenBatchMin'] = batchPauseMin;

      const { batchPauseMax } = await inquirer.prompt([{
        type: 'number',
        name: 'batchPauseMax',
        message: 'Max Batch Pause (ms):',
        default: profile.batch.pauseBetweenBatchMax
      }]);
      if (batchPauseMax !== profile.batch.pauseBetweenBatchMax) overrides['batch.pauseBetweenBatchMax'] = batchPauseMax;

      // Show customizations summary
      if (Object.keys(overrides).length > 0) {
        this.console.info(`📝 ${Object.keys(overrides).length} custom overrides applied`);
      }
    }

    // Step 3: Apply and confirm
    const { proceed } = await inquirer.prompt([{
      type: 'confirm',
      name: 'proceed',
      message: `Apply "${selectedProfile}" profile${Object.keys(overrides).length > 0 ? ' (with customizations)' : ''} and start testing?`,
      default: true
    }]);

    if (proceed) {
      // Apply the profile to config.js runtime
      try {
        delete require.cache[require.resolve(this.configPath)];
        let currentConfig = require(this.configPath);
        currentConfig = applyProfile(currentConfig, selectedProfile);
        currentConfig.activeProfile = selectedProfile;
        
        // Apply overrides
        for (const [path, value] of Object.entries(overrides)) {
          const keys = path.split('.');
          let obj = currentConfig;
          for (let i = 0; i < keys.length - 1; i++) {
            if (!obj[keys[i]]) obj[keys[i]] = {};
            obj = obj[keys[i]];
          }
          obj[keys[keys.length - 1]] = value;
        }
        
        // Save to disk with backup
        const { generateConfigFile } = require('./configHelper');
        const configStr = generateConfigFile(currentConfig);
        
        // Create a backup of the existing config before overwriting
        if (fs.existsSync(this.configPath)) {
          const backupPath = this.configPath + '.backup.' + Date.now();
          fs.copyFileSync(this.configPath, backupPath);
          this.console.info(`Backup created: ${backupPath}`);
        }
        
        fs.writeFileSync(this.configPath, configStr, 'utf8');
        
        this.console.success('Configuration saved!');
      } catch (e) {
        this.console.error(`Failed to save config: ${e.message}`);
      }

      this.console.success('Starting with profile configuration...');
      await this.startTesting();
    } else {
      await this.credentialTestingMenu();
    }
  }

  /**
   * Retry failed credentials
   */
  async retryFailed() {
    const queueFile = path.join(process.cwd(), 'retry_queue.json');
    
    const data = readJSONFile(queueFile);
    if (!data) {
      this.console.warning('No retry queue found. No failed credentials to retry.');
      await this.pressAnyKey();
      await this.credentialTestingMenu();
      return;
    }

    try {
      const count = data.queue ? Object.keys(data.queue).length : 0;
      
      this.console.info(`Found ${count} credentials in retry queue.`);
      this.console.spacing(1);
      
      const { confirm } = await inquirer.prompt([
        {
          type: 'confirm',
          name: 'confirm',
          message: 'Would you like to retry these credentials now?',
          default: true
        }
      ]);
      
      if (confirm) {
        await this.startTesting();
      } else {
        await this.credentialTestingMenu();
      }
    } catch (e) {
      this.console.error(`Error reading retry queue: ${e.message}`);
      await this.pressAnyKey();
      await this.credentialTestingMenu();
    }
  }

  /**
   * View a file
   */
  async viewFile(filepath, name) {
    const content = readTextFile(filepath);
    if (!content) {
      this.console.error(`${name} file not found or empty: ${filepath}`);
      await this.pressAnyKey();
      await this.credentialTestingMenu();
      return;
    }

    const lines = content.split('\n');
    const preview = lines.slice(0, 20).join('\n');
    
    this.console.section(`${name} File Preview`, `File: ${filepath}\nTotal Lines: ${lines.length}\n\n${preview}${lines.length > 20 ? '\n...(truncated)' : ''}`, {
      borderColor: 'gray'
    });
    this.console.spacing(1);
    
    await this.pressAnyKey();
    await this.credentialTestingMenu();
  }

  /**
   * View configuration
   */
  async viewConfiguration() {
    if (!fs.existsSync(this.configPath)) {
      this.console.error(`Configuration file not found: ${this.configPath}`);
      await this.pressAnyKey();
      await this.configurationMenu();
      return;
    }

    try {
      delete require.cache[require.resolve(this.configPath)];
      const config = require(this.configPath);
      
      this.console.section('Current Configuration', JSON.stringify(config, null, 2), {
        borderColor: 'blue'
      });
      this.console.spacing(1);
      
      await this.pressAnyKey();
      await this.configurationMenu();
    } catch (e) {
      this.console.error(`Error loading configuration: ${e.message}`);
      await this.pressAnyKey();
      await this.configurationMenu();
    }
  }

  /**
   * Edit configuration
   */
  async editConfiguration() {
    this.console.info('Opening configuration file in default editor...');
    this.console.warning('Configuration editor coming in next update!');
    this.console.info(`File location: ${this.configPath}`);
    this.console.spacing(1);
    
    await this.pressAnyKey();
    await this.configurationMenu();
  }

  /**
   * Reload configuration
   */
  async reloadConfiguration() {
    const spinner = this.console.spinner('Reloading configuration...');
    
    setTimeout(() => {
      delete require.cache[require.resolve(this.configPath)];
      spinner.succeed('Configuration reloaded successfully!');
      this.console.spacing(1);
      
      this.pressAnyKey().then(() => this.configurationMenu());
    }, 500);
  }

  /**
   * Export configuration
   */
  async exportConfiguration() {
    const config = require('../config');
    
    const { filepath } = await inquirer.prompt([
      {
        type: 'input',
        name: 'filepath',
        message: 'Enter path to save config (e.g., config_export.json):',
        default: 'config_export.json'
      }
    ]);

    try {
      const exportPath = path.isAbsolute(filepath) ? filepath : path.join(process.cwd(), filepath);
      fs.writeFileSync(exportPath, JSON.stringify(config, null, 2), 'utf8');
      this.console.success(`✅ Configuration exported to: ${exportPath}`);
    } catch (error) {
      this.console.error(`Error exporting configuration: ${error.message}`);
    }

    await this.pressAnyKey();
    await this.configurationMenu();
  }

  /**
   * Import configuration
   */
  async importConfiguration() {
    const { filepath } = await inquirer.prompt([
      {
        type: 'input',
        name: 'filepath',
        message: 'Enter path to config file to import:',
        validate: (input) => {
          if (!input) return 'Please enter a file path';
          if (!fs.existsSync(input)) return 'File not found';
          return true;
        }
      }
    ]);

    const importedConfig = readJSONFile(filepath);
    if (!importedConfig) {
      this.console.error('Failed to read configuration file.');
      await this.pressAnyKey();
      await this.configurationMenu();
      return;
    }

    try {
      this.console.info('Preview of imported configuration:');
      console.log(JSON.stringify(importedConfig, null, 2).substring(0, CONFIG_PREVIEW_LENGTH) + '...');
      this.console.spacing(1);

      const { confirm } = await inquirer.prompt([
        {
          type: 'confirm',
          name: 'confirm',
          message: 'Are you sure you want to merge this configuration?',
          default: false
        }
      ]);

      if (confirm) {
        const config = require('../config');
        Object.assign(config, importedConfig);
        this.console.success('✅ Configuration imported successfully');
        this.console.warning('Note: Changes are runtime only. To persist, update config.js manually.');
      } else {
        this.console.info('Import cancelled');
      }
    } catch (error) {
      this.console.error(`Error importing configuration: ${error.message}`);
    }

    await this.pressAnyKey();
    await this.configurationMenu();
  }

  /**
   * View latest results
   */
  async viewLatestResults() {
    const reportsDir = path.join(this.logsDir, 'reports');
    
    if (!fs.existsSync(reportsDir)) {
      this.console.warning('No reports directory found.');
      await this.pressAnyKey();
      await this.resultsMenu();
      return;
    }

    const files = fs.readdirSync(reportsDir)
      .filter(f => f.endsWith('.json'))
      .map(f => ({
        name: f,
        time: fs.statSync(path.join(reportsDir, f)).mtime.getTime()
      }))
      .sort((a, b) => b.time - a.time);

    if (files.length === 0) {
      this.console.warning('No result files found.');
      await this.pressAnyKey();
      await this.resultsMenu();
      return;
    }

    const latestFile = files[0].name;
    const latestPath = path.join(reportsDir, latestFile);
    const data = readJSONFile(latestPath);
    
    if (!data) {
      this.console.error('Failed to read latest result file.');
      await this.pressAnyKey();
      await this.resultsMenu();
      return;
    }
    
    this.console.section('Latest Results', JSON.stringify(data, null, 2).substring(0, 1000) + '...', {
      borderColor: 'green'
    });
    this.console.spacing(1);
    
    await this.pressAnyKey();
    await this.resultsMenu();
  }

  /**
   * Generate summary
   */
  async generateSummary() {
    this.console.clear();
    this.console.header('Generate Summary Report', { color: 'blue' });
    this.console.spacing(1);

    const historyFile = path.join(process.cwd(), 'combo_history.jsonl');
    
    const content = readTextFile(historyFile);
    if (!content) {
      this.console.warning('No history file found. Run tests first.');
      await this.pressAnyKey();
      await this.resultsMenu();
      return;
    }

    try {
      const lines = content.split('\n').filter(line => line.trim());
      
      const stats = {
        total: 0,
        success: 0,
        failed: 0,
        blocked: 0,
        captcha: 0,
        other: 0
      };

      for (const line of lines) {
        try {
          const entry = JSON.parse(line);
          stats.total++;
          
          if (entry.s === 'success') stats.success++;
          else if (entry.s === 'failed') stats.failed++;
          else if (entry.s === 'blocked') stats.blocked++;
          else if (entry.s === 'captcha') stats.captcha++;
          else stats.other++;
        } catch (e) {
          // Skip malformed lines
        }
      }

      const successRate = stats.total > 0 ? ((stats.success / stats.total) * 100).toFixed(2) : 0;

      this.console.info('═══════════════════════════════════════════════════════════');
      this.console.info('  CREDENTIAL TESTING SUMMARY');
      this.console.info('═══════════════════════════════════════════════════════════');
      this.console.spacing(1);
      this.console.info(`Total Credentials Tested: ${stats.total}`);
      this.console.spacing(1);
      this.console.success(`✓ Successful: ${stats.success} (${((stats.success / stats.total) * 100).toFixed(1)}%)`);
      this.console.error(`✗ Failed: ${stats.failed} (${((stats.failed / stats.total) * 100).toFixed(1)}%)`);
      this.console.warning(`⊘ Blocked: ${stats.blocked} (${((stats.blocked / stats.total) * 100).toFixed(1)}%)`);
      this.console.info(`⚠ Captcha: ${stats.captcha} (${((stats.captcha / stats.total) * 100).toFixed(1)}%)`);
      if (stats.other > 0) {
        this.console.info(`? Other: ${stats.other} (${((stats.other / stats.total) * 100).toFixed(1)}%)`);
      }
      this.console.spacing(1);
      this.console.info(`Overall Success Rate: ${successRate}%`);
      this.console.info('═══════════════════════════════════════════════════════════');

      const { saveReport } = await inquirer.prompt([
        {
          type: 'confirm',
          name: 'saveReport',
          message: 'Save report to file?',
          default: true
        }
      ]);

      if (saveReport) {
        const reportPath = path.join(process.cwd(), `summary_${Date.now()}.txt`);
        const report = `
CREDENTIAL TESTING SUMMARY
Generated: ${new Date().toLocaleString()}
═══════════════════════════════════════════════════════════

Total Credentials Tested: ${stats.total}

✓ Successful: ${stats.success} (${((stats.success / stats.total) * 100).toFixed(1)}%)
✗ Failed: ${stats.failed} (${((stats.failed / stats.total) * 100).toFixed(1)}%)
⊘ Blocked: ${stats.blocked} (${((stats.blocked / stats.total) * 100).toFixed(1)}%)
⚠ Captcha: ${stats.captcha} (${((stats.captcha / stats.total) * 100).toFixed(1)}%)
${stats.other > 0 ? `? Other: ${stats.other} (${((stats.other / stats.total) * 100).toFixed(1)}%)` : ''}

Overall Success Rate: ${successRate}%
═══════════════════════════════════════════════════════════
`;
        fs.writeFileSync(reportPath, report, 'utf8');
        this.console.success(`Report saved to: ${reportPath}`);
      }
    } catch (error) {
      this.console.error(`Error generating summary: ${error.message}`);
    }

    this.console.spacing(1);
    await this.pressAnyKey();
    await this.resultsMenu();
  }

  /**
   * View result category
   */
  async viewResultCategory(category) {
    const categoryDir = path.join(this.logsDir, category);
    
    if (!fs.existsSync(categoryDir)) {
      this.console.warning(`No ${category} directory found.`);
      await this.pressAnyKey();
      await this.resultsMenu();
      return;
    }

    const files = fs.readdirSync(categoryDir).filter(f => f.endsWith('.jsonl'));
    
    if (files.length === 0) {
      this.console.warning(`No ${category} results found.`);
      await this.pressAnyKey();
      await this.resultsMenu();
      return;
    }

    this.console.info(`Found ${files.length} ${category} log file(s):`);
    files.forEach(f => console.log(`  - ${f}`));
    this.console.spacing(1);
    
    await this.pressAnyKey();
    await this.resultsMenu();
  }

  /**
   * Browse logs
   */
  async browseLogs() {
    if (!fs.existsSync(this.logsDir)) {
      this.console.warning('Logs directory does not exist.');
      await this.pressAnyKey();
      await this.resultsMenu();
      return;
    }

    const dirs = fs.readdirSync(this.logsDir)
      .filter(f => fs.statSync(path.join(this.logsDir, f)).isDirectory());
    
    this.console.info('Logs directory structure:');
    dirs.forEach(dir => {
      const files = fs.readdirSync(path.join(this.logsDir, dir));
      console.log(`  📁 ${dir}/ (${files.length} files)`);
    });
    this.console.spacing(1);
    
    await this.pressAnyKey();
    await this.resultsMenu();
  }

  /**
   * Export results
   */
  async exportResults() {
    const { format } = await inquirer.prompt([
      {
        type: 'list',
        name: 'format',
        message: 'Select export format:',
        choices: [
          { name: 'CSV (Comma-Separated Values)', value: 'csv' },
          { name: 'JSON (JavaScript Object Notation)', value: 'json' }
        ]
      }
    ]);

    const { filepath } = await inquirer.prompt([
      {
        type: 'input',
        name: 'filepath',
        message: 'Enter output file path:',
        default: `export_${Date.now()}.${format}`
      }
    ]);

    const historyFile = path.join(process.cwd(), 'combo_history.jsonl');
    
    const content = readTextFile(historyFile);
    if (!content) {
      this.console.warning('No history file found. Run tests first.');
      await this.pressAnyKey();
      await this.resultsMenu();
      return;
    }

    try {
      const lines = content.split('\n').filter(line => line.trim());
      const entries = [];

      for (const line of lines) {
        try {
          const entry = JSON.parse(line);
          entries.push(entry);
        } catch (e) {
          // Skip malformed lines
        }
      }

      const exportPath = path.isAbsolute(filepath) ? filepath : path.join(process.cwd(), filepath);

      if (format === 'csv') {
        // Export as CSV
        let csv = 'Username,Password,Status,Timestamp,Detection Method\n';
        for (const entry of entries) {
          const username = entry.u || '';
          const password = entry.p || '';
          const status = entry.s || '';
          const timestamp = entry.t || '';
          const method = entry.m || '';
          csv += `"${username}","${password}","${status}","${timestamp}","${method}"\n`;
        }
        fs.writeFileSync(exportPath, csv, 'utf8');
      } else {
        // Export as JSON
        fs.writeFileSync(exportPath, JSON.stringify(entries, null, 2), 'utf8');
      }

      this.console.success(`✅ Exported ${entries.length} entries to: ${exportPath}`);
    } catch (error) {
      this.console.error(`Error exporting results: ${error.message}`);
    }

    await this.pressAnyKey();
    await this.resultsMenu();
  }

  /**
   * Clear old logs
   */
  async clearOldLogs() {
    const { days } = await inquirer.prompt([
      {
        type: 'number',
        name: 'days',
        message: 'Delete logs older than how many days?',
        default: 7,
        validate: (input) => {
          if (input < 1) return 'Days must be at least 1';
          return true;
        }
      }
    ]);

    const cutoffTime = Date.now() - (days * 24 * 60 * 60 * 1000);
    let deletedCount = 0;

    if (fs.existsSync(this.logsDir)) {
      const deleteOldFiles = (dir) => {
        const items = fs.readdirSync(dir, { withFileTypes: true });
        
        for (const item of items) {
          const itemPath = path.join(dir, item.name);
          
          if (item.isDirectory()) {
            deleteOldFiles(itemPath);
          } else {
            const stats = fs.statSync(itemPath);
            if (stats.mtimeMs < cutoffTime) {
              fs.unlinkSync(itemPath);
              deletedCount++;
            }
          }
        }
      };

      try {
        deleteOldFiles(this.logsDir);
        this.console.success(`✅ Deleted ${deletedCount} old log file(s)`);
      } catch (error) {
        this.console.error(`Error clearing logs: ${error.message}`);
      }
    } else {
      this.console.info('Logs directory does not exist.');
    }

    await this.pressAnyKey();
    await this.quickActionsMenu();
  }

  /**
   * Reset retry queue
   */
  async resetRetryQueue() {
    const queueFile = path.join(process.cwd(), 'retry_queue.json');
    
    if (!fs.existsSync(queueFile)) {
      this.console.info('Retry queue file does not exist.');
      await this.pressAnyKey();
      await this.quickActionsMenu();
      return;
    }

    const { confirm } = await inquirer.prompt([
      {
        type: 'confirm',
        name: 'confirm',
        message: 'Are you sure you want to reset the retry queue? This cannot be undone.',
        default: false
      }
    ]);

    if (confirm) {
      fs.unlinkSync(queueFile);
      this.console.success('Retry queue has been reset.');
    } else {
      this.console.info('Operation cancelled.');
    }
    
    await this.pressAnyKey();
    await this.quickActionsMenu();
  }

  /**
   * Delete sessions
   */
  async deleteSessions() {
    const sessionsDir = path.join(process.cwd(), 'sessions');
    
    if (!fs.existsSync(sessionsDir)) {
      this.console.info('Sessions directory does not exist.');
      await this.pressAnyKey();
      await this.quickActionsMenu();
      return;
    }

    const files = fs.readdirSync(sessionsDir);
    
    if (files.length === 0) {
      this.console.info('No session files found.');
      await this.pressAnyKey();
      await this.quickActionsMenu();
      return;
    }

    const { confirm } = await inquirer.prompt([
      {
        type: 'confirm',
        name: 'confirm',
        message: `Delete ${files.length} session file(s)? This cannot be undone.`,
        default: false
      }
    ]);

    if (confirm) {
      files.forEach(f => fs.unlinkSync(path.join(sessionsDir, f)));
      this.console.success(`Deleted ${files.length} session file(s).`);
    } else {
      this.console.info('Operation cancelled.');
    }
    
    await this.pressAnyKey();
    await this.quickActionsMenu();
  }

  /**
   * Show quick start guide
   */
  async showQuickStart() {
    const guide = `
🚀 Quick Start Guide

1. Prepare Input Files:
   - test.txt: List of credentials (username:password format)
   - Lightning_Proxies.txt: List of proxies

2. Configure Settings:
   - Edit config.js to customize behavior
   - Set retry limits, timeouts, proxy settings, etc.

3. Start Testing:
   - Select "Start Credential Testing" from main menu
   - Monitor progress in real-time
   - View results in logs/ directory

4. Review Results:
   - Check logs/successful/ for valid credentials
   - Check logs/failed/ for invalid credentials
   - Check logs/blocked/ for blocked accounts

For more information, see README.md
    `;
    
    this.console.section('Quick Start Guide', guide.trim(), { borderColor: 'blue' });
    this.console.spacing(1);
    
    await this.pressAnyKey();
    await this.helpMenu();
  }

  /**
   * Show documentation
   */
  async showDocumentation() {
    this.console.info('Full documentation available in:');
    console.log('  - README.md');
    console.log('  - docs/QUICKSTART.md');
    console.log('  - docs/ARCHITECTURE.md');
    console.log('  - docs/API.md');
    console.log('  - DEVELOPMENT_PLAN.md');
    this.console.spacing(1);
    
    await this.pressAnyKey();
    await this.helpMenu();
  }

  /**
   * Show FAQ
   */
  async showFAQ() {
    this.console.warning('FAQ section coming in next update!');
    await this.pressAnyKey();
    await this.helpMenu();
  }

  /**
   * Show troubleshooting
   */
  async showTroubleshooting() {
    this.console.info('Troubleshooting guide available in docs/TROUBLESHOOTING.md');
    await this.pressAnyKey();
    await this.helpMenu();
  }

  /**
   * Show README
   */
  async showReadme() {
    const readmePath = path.join(process.cwd(), 'README.md');
    
    const content = readTextFile(readmePath);
    if (!content) {
      this.console.error('README.md not found or empty.');
      await this.pressAnyKey();
      await this.helpMenu();
      return;
    }

    const preview = content.substring(0, 2000);
    
    this.console.section('README.md', preview + '\n...(truncated)', { borderColor: 'blue' });
    this.console.spacing(1);
    
    await this.pressAnyKey();
    await this.helpMenu();
  }

  // ============ HELPER METHODS ============

  /**
   * Get system status
   */
  async getSystemStatus() {
    const status = {
      credentials: {
        exists: fs.existsSync(this.credentialsFile),
        count: 0
      },
      proxies: {
        exists: fs.existsSync(this.proxiesFile),
        count: 0
      },
      config: {
        exists: fs.existsSync(this.configPath),
        valid: true
      },
      logs: {
        exists: fs.existsSync(this.logsDir),
        fileCount: 0
      },
      retryQueue: {
        exists: false,
        count: 0
      },
      sessions: {
        exists: false,
        count: 0
      }
    };

    // Count credentials
    if (status.credentials.exists) {
      const content = readTextFile(this.credentialsFile);
      if (content) {
        status.credentials.count = content.split('\n').filter(l => l.trim() && !l.startsWith('#')).length;
      }
    }

    // Count proxies
    if (status.proxies.exists) {
      const content = readTextFile(this.proxiesFile);
      if (content) {
        status.proxies.count = content.split('\n').filter(l => l.trim()).length;
      }
    }

    // Count log files
    if (status.logs.exists) {
      const countFiles = (dir) => {
        let count = 0;
        fs.readdirSync(dir).forEach(item => {
          const fullPath = path.join(dir, item);
          if (fs.statSync(fullPath).isDirectory()) {
            count += countFiles(fullPath);
          } else {
            count++;
          }
        });
        return count;
      };
      status.logs.fileCount = countFiles(this.logsDir);
    }

    // Check retry queue
    const queueFile = path.join(process.cwd(), 'retry_queue.json');
    const queueData = readJSONFile(queueFile);
    if (queueData) {
      status.retryQueue.exists = true;
      status.retryQueue.count = queueData.queue ? Object.keys(queueData.queue).length : 0;
    }

    // Check sessions
    const sessionsDir = path.join(process.cwd(), 'sessions');
    if (fs.existsSync(sessionsDir)) {
      status.sessions.exists = true;
      status.sessions.count = fs.readdirSync(sessionsDir).length;
    }

    return status;
  }

  /**
   * Wait for user to press any key
   */
  async pressAnyKey() {
    await inquirer.prompt([
      {
        type: 'input',
        name: 'continue',
        message: 'Press Enter to continue...',
        prefix: ''
      }
    ]);
  }

  /**
   * Start the interactive menu
   */
  async start() {
    try {
      await this.showMainMenu();
    } catch (error) {
      if (error.isTtyError) {
        this.console.error('Interactive menu not supported in this environment.');
        this.console.info('Running in non-interactive mode. Use command-line arguments.');
      } else {
        this.console.error(`Menu error: ${error.message}`);
      }
      process.exit(1);
    }
  }
}

// ============ EXPORTS ============

module.exports = InteractiveMenu;
