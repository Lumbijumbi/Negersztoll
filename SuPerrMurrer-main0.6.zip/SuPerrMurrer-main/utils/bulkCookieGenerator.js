/**
 * ============================================================================
 * BULK COOKIE GENERATOR
 * ============================================================================
 *
 * Opens browser windows to https://login.supercard.ch, fills random
 * credentials, submits the form, and captures all cookies from the
 * browser context.  Results are aggregated into a single JSON file.
 *
 * Usage (standalone):
 *   node scripts/generateBulkCookies.js --amount 100 --concurrency 1
 *
 * Usage (programmatic):
 *   const gen = new BulkCookieGenerator({ amount: 100 });
 *   gen.on('progress', ({ current, total }) => console.log(current, '/', total));
 *   const result = await gen.generate();
 */

'use strict';

const EventEmitter = require('events');
const fs           = require('fs');
const path         = require('path');
const crypto       = require('crypto');

const { chromium }  = require('patchright');
const { fastFill }  = require('../formFill');
const config        = require('../config');

// ── helpers ──────────────────────────────────────────────────────────────────

const BCG_DEFAULTS = config.bulkCookieGenerator || {};

/** First-name-like word list for random email generation (no external deps). */
const WORD_LIST = [
  'anna', 'bela', 'carlo', 'dani', 'elena', 'felix', 'gabi', 'hans',
  'irene', 'jakob', 'karin', 'leon', 'marta', 'nino', 'olga', 'peter',
  'reto', 'sara', 'tomas', 'urs', 'vera', 'walter', 'xenia', 'yves', 'zora'
];

const EMAIL_DOMAINS = ['gmail.com', 'hotmail.com', 'yahoo.com', 'gmx.ch', 'bluewin.ch'];

const ALPHANUM = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

// ── class ────────────────────────────────────────────────────────────────────

class BulkCookieGenerator extends EventEmitter {
  /**
   * @param {object}  opts
   * @param {number}  [opts.amount=100]            How many cookie-sets to generate.
   * @param {string}  [opts.outputDir='CookieExports'] Directory for output files.
   * @param {string|null} [opts.outputFile=null]   Override output filename.
   * @param {number}  [opts.concurrency=1]         Parallel browser instances (1–5).
   * @param {boolean} [opts.headless=false]        Run browsers headless.
   */
  constructor(opts = {}) {
    super();

    const defaultAmount      = BCG_DEFAULTS.defaultAmount ?? 100;
    const parsedAmount       = parseInt(opts.amount ?? defaultAmount, 10);
    const normalizedAmount   = Number.isNaN(parsedAmount) ? defaultAmount : parsedAmount;

    const defaultConcurrency = 1;
    const maxConcurrency     = BCG_DEFAULTS.maxConcurrency ?? 5;
    const parsedConcurrency  = parseInt(opts.concurrency ?? defaultConcurrency, 10);
    const normalizedConc     = Number.isNaN(parsedConcurrency) ? defaultConcurrency : parsedConcurrency;

    this.amount      = Math.max(1, normalizedAmount);
    this.outputDir   = opts.outputDir  ?? BCG_DEFAULTS.outputDir  ?? 'CookieExports';
    this.outputFile  = opts.outputFile ?? null;
    this.concurrency = Math.min(Math.max(1, normalizedConc), maxConcurrency);
    this.headless    = opts.headless   ?? BCG_DEFAULTS.headless ?? false;

    // Read shared config values, fall back to sensible defaults.
    this._loginUrl          = (config.login && config.login.url)              || 'https://login.supercard.ch/';
    this._usernameSelector  = (config.login && config.login.usernameSelector) || '#username';
    this._passwordSelector  = (config.login && config.login.passwordSelector) || '#password';
    this._navigationTimeout = BCG_DEFAULTS.navigationTimeout ?? 12000;
    this._delayBetween      = BCG_DEFAULTS.delayBetweenCaptures ?? 500;
  }

  // ── private helpers ─────────────────────────────────────────────────────────

  /**
   * Generate a random email address inline — no external faker.
   * Uses crypto.randomBytes for uniform randomness.
   * @returns {string}
   */
  _randomEmail() {
    const wordIdx   = crypto.randomBytes(1)[0] % WORD_LIST.length;
    const num       = (crypto.randomBytes(2).readUInt16BE(0) % 90000) + 1000;
    const domainIdx = crypto.randomBytes(1)[0] % EMAIL_DOMAINS.length;
    return `${WORD_LIST[wordIdx]}${num}@${EMAIL_DOMAINS[domainIdx]}`;
  }

  /**
   * Generate a random alphanumeric password (10–14 chars).
   * Uses crypto.randomBytes for uniform randomness.
   * @returns {string}
   */
  _randomPassword() {
    const len = (crypto.randomBytes(1)[0] % 5) + 10; // 10–14
    const buf = crypto.randomBytes(len);
    let pw = '';
    for (let i = 0; i < len; i++) {
      pw += ALPHANUM[buf[i] % ALPHANUM.length];
    }
    return pw;
  }

  /**
   * Capture cookies from one browser session.
   * @param {number} index  Zero-based iteration index.
   * @returns {Promise<{ index: number, capturedAt: string, cookies: object[] }>}
   */
  async _captureOne(index) {
    const browserArgs = (config.browser && config.browser.args)
      ? config.browser.args.filter(a => !a.startsWith('--proxy-server='))
      : [];

    let browser = null;
    try {
      browser = await chromium.launch({
        channel:  'chrome',
        headless: this.headless,
        args:     browserArgs,
        ignoreDefaultArgs: config.browser?.ignoreDefaultArgs || ['--enable-automation']
      });

      const context = await browser.newContext({
        locale:             'de-CH',
        timezoneId:         'Europe/Zurich',
        ignoreHTTPSErrors:  true,
        viewport:           null    // use native window size — avoids Playwright's 1280×720 fingerprint
      });

      // Patchright suppresses navigator.webdriver and automation signals natively.
      // Do NOT inject addInitScript overrides — they create detectable artifacts.

      const page = await context.newPage();

      page.setDefaultTimeout(this._navigationTimeout);

      await page.goto(this._loginUrl, { waitUntil: 'domcontentloaded' });

      // Dismiss cookie-consent popup if present
      await page.click((config.login && config.login.onetrust) || '#onetrust-accept-btn-handler').catch(() => {});

      const email    = this._randomEmail();
      const password = this._randomPassword();

      await fastFill(page, this._usernameSelector, email);
      await fastFill(page, this._passwordSelector, password);

      // Submit — do NOT await navigation
      await page.press(this._passwordSelector, 'Enter').catch(() => {});

      // Wait for cookies to be set by the server response
      await page.waitForTimeout(1500);

      const rawCookies = await page.context().cookies().catch(() => []);
      const cookies = rawCookies.map(c => ({
        name:     c.name,
        value:    c.value,
        domain:   c.domain  || '',
        path:     c.path    || '/',
        secure:   !!c.secure,
        httpOnly: !!c.httpOnly,
        sameSite: c.sameSite || 'Lax'
      }));

      return { index, capturedAt: new Date().toISOString(), cookies };
    } finally {
      if (browser) {
        await browser.close().catch(() => {});
      }
    }
  }

  // ── public API ───────────────────────────────────────────────────────────────

  /**
   * Run the full bulk generation.
   *
   * Emits:
   *   'progress'  { current, total, successful, failed }
   *   'done'      { outputPath, totalSets, successful, failed }
   *   'error'     Error  (fatal — e.g. cannot create output dir)
   *
   * @returns {Promise<{ outputPath: string, totalSets: number, successful: number, failed: number }>}
   */
  async generate() {
    // 1. Ensure output directory exists.
    try {
      fs.mkdirSync(this.outputDir, { recursive: true });
    } catch (err) {
      this.emit('error', err);
      throw err;
    }

    const cookieSets = [];
    let successful   = 0;
    let failed       = 0;
    const total      = this.amount;

    // 2. Process all iterations, respecting concurrency.
    let cursor = 0;

    while (cursor < total) {
      const batchSize  = Math.min(this.concurrency, total - cursor);
      const batchStart = cursor;
      const promises   = [];

      for (let i = 0; i < batchSize; i++) {
        promises.push(
          this._captureOne(batchStart + i)
            .then(result => {
              cookieSets[batchStart + i] = result;
              successful++;
              return result;
            })
            .catch(err => {
              console.warn(`[BulkCookieGenerator] Capture #${batchStart + i} failed:`, err.message);
              cookieSets[batchStart + i] = {
                index:       batchStart + i,
                capturedAt:  new Date().toISOString(),
                cookies:     []
              };
              failed++;
              return null;
            })
        );
      }

      await Promise.all(promises);
      cursor += batchSize;

      this.emit('progress', { current: cursor, total, successful, failed });

      // Small delay between batches to avoid hammering the target
      if (cursor < total && this._delayBetween > 0) {
        await new Promise(r => setTimeout(r, this._delayBetween));
      }
    }

    // 3. Build output structure.
    const generatedAt  = new Date().toISOString();
    const outputData   = {
      generatedAt,
      targetUrl:  this._loginUrl,
      totalSets:  total,
      cookieSets: cookieSets.filter(Boolean)
    };

    // 4. Determine output file name.
    let filename = this.outputFile;
    if (!filename) {
      // e.g. bulk_cookies_2026-04-08_12-00-00_100.json
      const ts = generatedAt
        .replace('T', '_')
        .replace(/\.\d+Z$/, '')
        .replace(/:/g, '-');
      filename = `bulk_cookies_${ts}_${total}.json`;
    }

    const outputPath = path.join(this.outputDir, filename);

    // 5. Write atomically (tmp → rename).
    const tmpPath = outputPath + '.tmp';
    try {
      fs.writeFileSync(tmpPath, JSON.stringify(outputData, null, 2), 'utf8');
      fs.renameSync(tmpPath, outputPath);
    } catch (err) {
      // Clean up tmp on failure
      try { fs.unlinkSync(tmpPath); } catch (_) {}
      this.emit('error', err);
      throw err;
    }

    const result = { outputPath, totalSets: total, successful, failed };
    this.emit('done', result);
    return result;
  }
}

module.exports = BulkCookieGenerator;
