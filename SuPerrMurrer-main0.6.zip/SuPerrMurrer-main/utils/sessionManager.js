/**
 * ============================================================================
 * SESSION MANAGER - Cookie Reuse for Re-authentication Optimization
 * ============================================================================
 * 
 * Features:
 * ✅ Save successful login cookies to sessions/ directory
 * ✅ One file per username: sessions/{username_sanitized}.json
 * ✅ Store cookies, timestamp, expiration, domain, path
 * ✅ Validate session before reuse (expiration, max age)
 * ✅ Clean up expired sessions
 * ✅ Integration with worker for login skip
 */

const fs = require('fs');
const path = require('path');
const { ensureDirectory, writeJSONFileAtomic, readJSONFile } = require('./fileHelper');

class SessionManager {
  constructor(options = {}) {
    this.sessionDir = options.sessionDir || path.join(process.cwd(), 'sessions');
    this.maxAge = options.maxAge || 24 * 60 * 60 * 1000; // 24 hours default
    this.cleanupOnStart = options.cleanupOnStart !== false; // Default true

    // In-memory validity cache: username -> { valid: boolean, expiresAt: number }
    this._cache = new Map();
    this._cacheTTL = 30000; // 30 seconds
    
    // Ensure sessions directory exists
    this.ensureSessionDir();
    
    // Clean expired sessions on startup if enabled
    if (this.cleanupOnStart) {
      this.clearExpiredSessions();
    }
  }

  /**
   * Ensure sessions directory exists
   */
  ensureSessionDir() {
    const success = ensureDirectory(this.sessionDir);
    if (success) {
      console.log(`[SessionManager] Sessions directory ready: ${this.sessionDir}`);
    } else {
      throw new Error('Failed to create sessions directory');
    }
  }

  /**
   * Sanitize username for use in filename
   * @param {string} username - Username to sanitize
   * @returns {string} Sanitized username
   */
  sanitizeUsername(username) {
    if (!username || typeof username !== 'string') {
      return 'unknown';
    }
    
    // Replace unsafe characters with underscore (comprehensive list for cross-platform compatibility)
    return username
      .replace(/[\/\\\?\%\*\|"<>\n\r\t:\s]/g, '_')
      .substring(0, 100);
  }

  /**
   * Get session file path for username
   * @param {string} username - Username
   * @returns {string} Full path to session file
   */
  getSessionFilePath(username) {
    const sanitized = this.sanitizeUsername(username);
    return path.join(this.sessionDir, `${sanitized}.json`);
  }

  /**
   * Save session cookies after successful login
   * @param {Object} page - Playwright page object
   * @param {string} username - Username for this session
   * @returns {Promise<boolean>} True if save successful
   */
  async saveSession(page, username) {
    try {
      if (!page || !username) {
        throw new Error('Invalid page or username');
      }

      // Get all cookies from the page context
      const cookies = await page.context().cookies().catch(async () => {
        // Fallback: try getting cookies directly from page
        return await page.evaluate(() => {
          return document.cookie.split(';').map(c => {
            const [name, value] = c.trim().split('=');
            return { name, value };
          });
        }).catch(() => []);
      });

      if (!cookies || cookies.length === 0) {
        console.warn(`[SessionManager] No cookies found for ${username}`);
        return false;
      }

      const sessionData = {
        username,
        savedAt: new Date().toISOString(),
        savedTimestamp: Date.now(),
        maxAge: this.maxAge,
        cookies: cookies.map(cookie => ({
          name: cookie.name,
          value: cookie.value,
          domain: cookie.domain || '',
          path: cookie.path || '/',
          expires: cookie.expires || -1,
          httpOnly: cookie.httpOnly || false,
          secure: cookie.secure || false,
          sameSite: cookie.sameSite || 'Lax'
        }))
      };

      const filepath = this.getSessionFilePath(username);
      
      // Atomic write using fileHelper
      const success = writeJSONFileAtomic(filepath, sessionData);
      if (success) {
        console.log(`[SessionManager] Session saved for ${username} (${cookies.length} cookies)`);
        this._cache.delete(username);
      }
      return success;
    } catch (error) {
      console.error(`[SessionManager] Failed to save session for ${username}: ${error.message}`);
      return false;
    }
  }

  /**
   * Load and apply session cookies before navigation
   * @param {Object} page - Playwright page object
   * @param {string} username - Username for this session
   * @returns {Promise<boolean>} True if load successful
   */
  async loadSession(page, username) {
    try {
      if (!page || !username) {
        throw new Error('Invalid page or username');
      }

      const filepath = this.getSessionFilePath(username);
      
      const sessionData = readJSONFile(filepath);
      if (!sessionData) {
        return false;
      }

      // Validate session data
      if (!sessionData.cookies || !Array.isArray(sessionData.cookies)) {
        console.warn(`[SessionManager] Invalid session data for ${username}`);
        return false;
      }

      // Check if session is expired
      if (!this.isSessionValid(sessionData)) {
        console.log(`[SessionManager] Session expired for ${username}`);
        // Delete expired session file
        fs.unlinkSync(filepath);
        return false;
      }

      // Apply cookies to page context
      await page.context().addCookies(sessionData.cookies).catch((error) => {
        console.error(`[SessionManager] Failed to add cookies via context: ${error.message}`);
        throw error;
      });

      console.log(`[SessionManager] Session loaded for ${username} (${sessionData.cookies.length} cookies)`);
      return true;
    } catch (error) {
      console.error(`[SessionManager] Failed to load session for ${username}: ${error.message}`);
      return false;
    }
  }

  /**
   * Check if session exists and is valid
   * @param {string} username - Username
   * @returns {boolean} True if valid session exists
   */
  hasValidSession(username) {
    try {
      // Check cache first
      const cached = this._cache.get(username);
      if (cached && Date.now() < cached.expiresAt) {
        return cached.valid;
      }

      const filepath = this.getSessionFilePath(username);
      
      const sessionData = readJSONFile(filepath);
      const valid = sessionData ? this.isSessionValid(sessionData) : false;

      // Compute cache expiry: the earlier of (now + TTL) and the session's own expiry
      // so that a near-expiry session is never served as valid after it actually expires.
      let cacheExpiresAt = Date.now() + this._cacheTTL;
      if (valid && sessionData) {
        const sessionExpiryMs = this._computeSessionExpiry(sessionData);
        if (sessionExpiryMs !== null) {
          cacheExpiresAt = Math.min(cacheExpiresAt, sessionExpiryMs);
        }
      }

      this._cache.set(username, { valid, expiresAt: cacheExpiresAt });

      return valid;
    } catch (error) {
      console.error(`[SessionManager] Failed to check session for ${username}: ${error.message}`);
      return false;
    }
  }

  /**
   * Compute the absolute timestamp (ms) at which this session will expire.
   * Returns null if expiry cannot be determined.
   * @private
   */
  _computeSessionExpiry(sessionData) {
    if (!sessionData || !sessionData.savedTimestamp) return null;

    const maxAge = sessionData.maxAge || this.maxAge;
    let expiryMs = sessionData.savedTimestamp + maxAge;

    // Also account for the earliest expiring cookie
    if (sessionData.cookies && Array.isArray(sessionData.cookies)) {
      for (const cookie of sessionData.cookies) {
        if (cookie.expires && cookie.expires > 0) {
          const cookieExpiresMs = cookie.expires > 10000000000
            ? cookie.expires
            : cookie.expires * 1000;
          expiryMs = Math.min(expiryMs, cookieExpiresMs);
        }
      }
    }

    return expiryMs;
  }

  /**
   * Validate session data (check expiration and max age)
   * @param {Object} sessionData - Session data object
   * @returns {boolean} True if session is valid
   */
  isSessionValid(sessionData) {
    if (!sessionData || !sessionData.savedTimestamp) {
      return false;
    }

    const now = Date.now();
    const age = now - sessionData.savedTimestamp;

    // Check if session has exceeded max age
    const maxAge = sessionData.maxAge || this.maxAge;
    if (age > maxAge) {
      return false;
    }

    // Check individual cookie expiration
    if (sessionData.cookies && Array.isArray(sessionData.cookies)) {
      for (const cookie of sessionData.cookies) {
        if (cookie.expires && cookie.expires > 0) {
          // Cookie expires is in seconds since epoch for some browsers
          const expiresMs = cookie.expires > 10000000000 ? cookie.expires : cookie.expires * 1000;
          if (expiresMs < now) {
            return false; // At least one cookie expired
          }
        }
      }
    }

    return true;
  }

  /**
   * Clear expired sessions from disk
   * @returns {number} Number of sessions cleared
   */
  clearExpiredSessions() {
    let cleared = 0;

    try {
      if (!fs.existsSync(this.sessionDir)) {
        return 0;
      }

      const files = fs.readdirSync(this.sessionDir);

      for (const file of files) {
        if (!file.endsWith('.json')) {
          continue;
        }

        const filepath = path.join(this.sessionDir, file);

        const sessionData = readJSONFile(filepath);
        if (!sessionData) {
          // If we can't read/parse, delete it
          console.warn(`[SessionManager] Removing corrupted session file: ${file}`);
          fs.unlinkSync(filepath);
          cleared++;
          continue;
        }

        if (!this.isSessionValid(sessionData)) {
          fs.unlinkSync(filepath);
          cleared++;
          console.log(`[SessionManager] Cleared expired session: ${file}`);
        }
      }

      if (cleared > 0) {
        console.log(`[SessionManager] Cleared ${cleared} expired/corrupted sessions`);
      }
    } catch (error) {
      console.error(`[SessionManager] Error clearing expired sessions: ${error.message}`);
    }

    return cleared;
  }

  /**
   * Delete session for specific username
   * @param {string} username - Username
   * @returns {boolean} True if deletion successful
   */
  deleteSession(username) {
    try {
      const filepath = this.getSessionFilePath(username);
      
      if (fs.existsSync(filepath)) {
        fs.unlinkSync(filepath);
        this._cache.delete(username);
        console.log(`[SessionManager] Deleted session for ${username}`);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error(`[SessionManager] Failed to delete session for ${username}: ${error.message}`);
      return false;
    }
  }

  /**
   * Get statistics about sessions
   * @returns {Object} Session statistics
   */
  getStats() {
    let total = 0;
    let valid = 0;
    let expired = 0;

    try {
      if (!fs.existsSync(this.sessionDir)) {
        return { total: 0, valid: 0, expired: 0 };
      }

      const files = fs.readdirSync(this.sessionDir);

      for (const file of files) {
        if (!file.endsWith('.json')) {
          continue;
        }

        total++;
        const filepath = path.join(this.sessionDir, file);

        const sessionData = readJSONFile(filepath);
        if (!sessionData) {
          expired++;
          continue;
        }

        if (this.isSessionValid(sessionData)) {
          valid++;
        } else {
          expired++;
        }
      }
    } catch (error) {
      console.error(`[SessionManager] Error getting stats: ${error.message}`);
    }

    return { total, valid, expired };
  }
}

module.exports = SessionManager;
