'use strict';

/**
 * UsedEntries - Persistence for "marked as used" credential entries
 *
 * Stores each marked entry as a JSON line in `used_entries.jsonl`.
 * Keyed by "username\tpassword" for O(1) lookups.
 */

const fs = require('fs');
const path = require('path');

class UsedEntries {
  constructor(options = {}) {
    this.usedFile = options.usedFile || 'used_entries.jsonl';
    if (!path.isAbsolute(this.usedFile)) {
      this.usedFile = path.join(process.cwd(), this.usedFile);
    }
    // In-memory Map: "username\tpassword" -> entry object
    this.entries = new Map();
    this._load();
  }

  _key(username, password) {
    return `${username}\t${password}`;
  }

  _load() {
    if (!fs.existsSync(this.usedFile)) return;
    try {
      const content = fs.readFileSync(this.usedFile, 'utf8');
      for (const line of content.split('\n').filter(l => l.trim())) {
        try {
          const entry = JSON.parse(line);
          if (entry.u && entry.p) {
            this.entries.set(this._key(entry.u, entry.p), entry);
          }
        } catch (e) {
          // skip invalid lines
        }
      }
    } catch (error) {
      console.error('[USED] Failed to load used entries:', error.message);
    }
  }

  _rewrite() {
    try {
      const lines = Array.from(this.entries.values()).map(e => JSON.stringify(e)).join('\n');
      const tmpFile = this.usedFile + '.tmp';
      fs.writeFileSync(tmpFile, lines ? lines + '\n' : '', 'utf8');
      fs.renameSync(tmpFile, this.usedFile);
    } catch (error) {
      console.error('[USED] Failed to rewrite used entries file:', error.message);
    }
  }

  /**
   * Mark an entry as used.
   * @param {string} username
   * @param {string} password
   * @param {object} details  - { status, method, pointsBalance, moneyBalance, notes }
   * @returns {object} the created entry
   */
  markUsed(username, password, details = {}) {
    const key = this._key(username, password);
    const existing = this.entries.get(key);
    const entry = {
      u: username,
      p: password,
      s: details.status || (existing && existing.s) || '',
      m: details.method || (existing && existing.m) || null,
      pts: details.pointsBalance !== undefined ? details.pointsBalance : (existing ? existing.pts : null),
      chf: details.moneyBalance !== undefined ? details.moneyBalance : (existing ? existing.chf : null),
      usedAt: existing ? existing.usedAt : new Date().toISOString(),
      // notes: allow empty string; preserve existing notes if not provided
      notes: details.notes !== undefined ? details.notes : (existing ? existing.notes : '')
    };
    this.entries.set(key, entry);
    this._rewrite();
    return entry;
  }

  /**
   * Unmark an entry (remove from used list).
   * @param {string} username
   * @param {string} password
   * @returns {boolean} whether the entry existed
   */
  unmarkUsed(username, password) {
    const key = this._key(username, password);
    const existed = this.entries.has(key);
    if (existed) {
      this.entries.delete(key);
      this._rewrite();
    }
    return existed;
  }

  /**
   * Update the notes for a used entry.
   * @param {string} username
   * @param {string} password
   * @param {string} notes
   * @returns {boolean} whether the entry existed
   */
  updateNote(username, password, notes) {
    const key = this._key(username, password);
    const entry = this.entries.get(key);
    if (!entry) return false;
    entry.notes = notes;
    this.entries.set(key, entry);
    this._rewrite();
    return true;
  }

  /**
   * Check if a credential is marked as used.
   * @param {string} username
   * @param {string} password
   * @returns {boolean}
   */
  isUsed(username, password) {
    return this.entries.has(this._key(username, password));
  }

  /**
   * Return all used entries as an array (for GUI).
   */
  getAll() {
    return Array.from(this.entries.values()).map(e => ({
      username: e.u,
      password: e.p,
      status: e.s ?? '',
      method: e.m ?? null,
      pointsBalance: e.pts ?? null,
      moneyBalance: e.chf ?? null,
      usedAt: e.usedAt,
      notes: e.notes ?? ''
    }));
  }
}

module.exports = UsedEntries;
