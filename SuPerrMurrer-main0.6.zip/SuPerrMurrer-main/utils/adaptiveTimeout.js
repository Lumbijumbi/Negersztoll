/**
 * Adaptive Detection Timeout
 * Dynamically adjusts CAS detection timeout based on historical success timings
 * Uses p95 latency with buffer multiplier for optimal timeout values
 */

class AdaptiveDetectionTimeout {
  constructor(baseTimeout = 12000, options = {}) {
    this.baseTimeout = baseTimeout;
    this.minTimeout = options.minTimeout || 3000;
    this.maxSamples = options.maxSamples || 20;
    this.bufferMultiplier = options.bufferMultiplier || 1.5;
    this.successTimings = [];
    // Cache for computed timeout — invalidated whenever new timings are recorded
    this._cachedTimeout = null;
    this._dirty = true;
  }

  /**
   * Record a successful detection timing
   * @param {number} durationMs - Duration in milliseconds
   */
  recordSuccess(durationMs) {
    if (typeof durationMs !== 'number' || durationMs < 0) {
      return;
    }
    this.successTimings.push(durationMs);
    if (this.successTimings.length > this.maxSamples) {
      this.successTimings.shift();
    }
    this._dirty = true;
  }

  /**
   * Get the current adaptive timeout value
   * @returns {number} Timeout in milliseconds
   */
  getTimeout() {
    if (this.successTimings.length < 3) {
      return this.baseTimeout;
    }
    if (!this._dirty && this._cachedTimeout !== null) {
      return this._cachedTimeout;
    }
    const sorted = [...this.successTimings].sort((a, b) => a - b);
    const p95Index = Math.min(Math.floor(sorted.length * 0.95), sorted.length - 1);
    const p95 = sorted[p95Index];
    const adaptive = Math.ceil(p95 * this.bufferMultiplier);
    this._cachedTimeout = Math.max(this.minTimeout, Math.min(adaptive, this.baseTimeout));
    this._dirty = false;
    return this._cachedTimeout;
  }

  /**
   * Get statistics about current timings and timeout
   * @returns {object} Statistics object
   */
  getStats() {
    if (this.successTimings.length === 0) {
      return { samples: 0, currentTimeout: this.baseTimeout };
    }
    const sorted = [...this.successTimings].sort((a, b) => a - b);
    const p95Index = Math.min(Math.floor(sorted.length * 0.95), sorted.length - 1);
    return {
      samples: this.successTimings.length,
      min: sorted[0],
      max: sorted[sorted.length - 1],
      median: sorted[Math.floor(sorted.length / 2)],
      p95: sorted[p95Index],
      currentTimeout: this.getTimeout()
    };
  }
}

module.exports = AdaptiveDetectionTimeout;
