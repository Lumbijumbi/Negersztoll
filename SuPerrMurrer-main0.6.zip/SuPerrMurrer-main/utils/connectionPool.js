/**
 * =========================================================================
 * CONNECTION POOL - Browser Instance Reuse
 * =========================================================================
 * 
 * Features:
 * - Configurable pool size
 * - Proxy-aware connection matching
 * - Idle connection timeout
 * - Use count limiting (prevents overuse)
 * - Automatic cleanup
 * - Connection statistics
 * - Optimized for bot detection avoidance
 */

class ConnectionPool {
  constructor(options = {}) {
    // Optimized defaults for bot detection avoidance
    this.maxPoolSize = options.maxPoolSize || 20; // Increased from 4 to 20
    this.maxIdleTime = options.maxIdleTime || 300000; // 5 minutes (increased from 60s)
    this.maxUseCount = options.maxUseCount || 50; // Max requests per browser instance
    this.maxConnectionAge = options.maxConnectionAge || 1800000; // 30 minutes max lifetime
    
    this.pool = new Map(); // connectionId -> connection
    this.available = new Set(); // Set of available connection IDs
    this.inUse = new Set(); // Set of in-use connection IDs
    this._proxyIndex = new Map(); // proxy string -> Set<connectionId>
    
    this.nextId = 1;
    this.stats = {
      created: 0,
      reused: 0,
      closed: 0,
      expired: 0,
      maxUseReached: 0,
      maxAgeReached: 0
    };

    // Auto-cleanup interval
    this.cleanupInterval = setInterval(() => {
      this.cleanup().catch(err => {
        console.error('Cleanup error:', err);
      });
    }, 60000); // Clean every minute
  }

  /**
   * Acquire a connection from the pool
   */
  async acquire(proxy) {
    // Use proxy index for O(1) lookup instead of iterating all available connections
    const proxySet = this._proxyIndex.get(proxy);
    if (proxySet) {
      for (const connectionId of proxySet) {
        if (!this.available.has(connectionId)) continue;
        const connection = this.pool.get(connectionId);

        if (connection && connection.proxy === proxy) {
          // Check if expired, overused, or too old
          if (this.shouldRetire(connection)) {
            await this.removeConnection(connectionId);
            continue;
          }

          // Move to in-use
          this.available.delete(connectionId);
          this.inUse.add(connectionId);

          connection.lastUsed = Date.now();
          connection.useCount++;

          this.stats.reused++;

          return {
            id: connectionId,
            browser: connection.browser,
            proxy: connection.proxy
          };
        }
      }
    }

    // No matching connection available, create new if under limit
    if (this.pool.size < this.maxPoolSize) {
      return await this.createConnection(proxy);
    }

    // Pool is full, try to remove oldest available connection
    const oldestAvailable = this.findOldestAvailable();
    if (oldestAvailable) {
      await this.removeConnection(oldestAvailable);
      return await this.createConnection(proxy);
    }

    // If all connections are in use, create new one anyway (overflow)
    console.warn(`Pool overflow: creating connection beyond maxPoolSize (${this.maxPoolSize})`);
    return await this.createConnection(proxy);
  }

  /**
   * Release a connection back to the pool
   */
  release(connectionId) {
    if (!this.pool.has(connectionId)) {
      return;
    }

    const connection = this.pool.get(connectionId);
    connection.lastUsed = Date.now();

    // Check if connection should be retired after this use
    if (this.shouldRetire(connection)) {
      this.removeConnection(connectionId).catch(err => {
        console.error('Error removing connection:', err);
      });
      return;
    }

    this.inUse.delete(connectionId);
    this.available.add(connectionId);
  }

  /**
   * Create a new browser connection
   */
  async createConnection(proxy) {
    const connectionId = this.nextId++;
    
    // Note: Actual browser creation is handled by caller
    // This is a placeholder that tracks the connection
    const connection = {
      id: connectionId,
      proxy,
      browser: null, // Will be set by caller
      created: Date.now(),
      lastUsed: Date.now(),
      useCount: 1
    };

    this.pool.set(connectionId, connection);
    this.inUse.add(connectionId);
    this.stats.created++;

    // Register in proxy index
    if (!this._proxyIndex.has(proxy)) {
      this._proxyIndex.set(proxy, new Set());
    }
    this._proxyIndex.get(proxy).add(connectionId);

    return {
      id: connectionId,
      browser: null, // Caller must set this
      proxy,
      _connection: connection // Return connection object for caller to update
    };
  }

  /**
   * Set browser instance for a connection
   */
  setBrowser(connectionId, browser) {
    const connection = this.pool.get(connectionId);
    if (connection) {
      connection.browser = browser;
    }
  }

  /**
   * Check if connection should be retired
   * Enhanced with use count and age limits
   */
  shouldRetire(connection) {
    const idleTime = Date.now() - connection.lastUsed;
    const age = Date.now() - connection.created;
    
    const tooIdle = idleTime > this.maxIdleTime;
    const tooManyUses = connection.useCount >= this.maxUseCount;
    const tooOld = age > this.maxConnectionAge;

    if (tooManyUses) this.stats.maxUseReached++;
    if (tooOld) this.stats.maxAgeReached++;

    return tooIdle || tooManyUses || tooOld;
  }

  /**
   * Check if connection is expired (backwards compatibility)
   */
  isExpired(connection) {
    return this.shouldRetire(connection);
  }

  /**
   * Find oldest available connection
   */
  findOldestAvailable() {
    let oldest = null;
    let oldestTime = Infinity;

    for (const connectionId of this.available) {
      const connection = this.pool.get(connectionId);
      if (connection && connection.created < oldestTime) {
        oldestTime = connection.created;
        oldest = connectionId;
      }
    }

    return oldest;
  }

  /**
   * Remove a connection from the pool
   */
  async removeConnection(connectionId) {
    const connection = this.pool.get(connectionId);
    
    if (connection && connection.browser) {
      try {
        await connection.browser.close();
        this.stats.closed++;
      } catch (error) {
        // Ignore close errors
      }
    }

    this.pool.delete(connectionId);
    this.available.delete(connectionId);
    this.inUse.delete(connectionId);

    // Remove from proxy index
    if (connection) {
      const proxySet = this._proxyIndex.get(connection.proxy);
      if (proxySet) {
        proxySet.delete(connectionId);
        if (proxySet.size === 0) {
          this._proxyIndex.delete(connection.proxy);
        }
      }
    }
  }

  /**
   * Clean up expired connections
   */
  async cleanup() {
    const toRemove = [];

    for (const [connectionId, connection] of this.pool.entries()) {
      // Only clean up available connections
      if (this.available.has(connectionId) && this.shouldRetire(connection)) {
        toRemove.push(connectionId);
      }
    }

    for (const connectionId of toRemove) {
      await this.removeConnection(connectionId);
      this.stats.expired++;
    }

    if (toRemove.length > 0) {
      console.log(`Cleaned up ${toRemove.length} expired connections`);
    }

    return toRemove.length;
  }

  /**
   * Close all connections and stop cleanup interval
   */
  async closeAll() {
    // Stop auto-cleanup
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }

    const allIds = Array.from(this.pool.keys());
    
    for (const connectionId of allIds) {
      await this.removeConnection(connectionId);
    }

    this.pool.clear();
    this.available.clear();
    this.inUse.clear();
    this._proxyIndex.clear();
  }

  /**
   * Get pool statistics
   */
  getStats() {
    return {
      poolSize: this.pool.size,
      available: this.available.size,
      inUse: this.inUse.size,
      maxPoolSize: this.maxPoolSize,
      maxUseCount: this.maxUseCount,
      maxIdleTime: this.maxIdleTime,
      maxConnectionAge: this.maxConnectionAge,
      stats: { ...this.stats },
      utilization: this.pool.size > 0 
        ? ((this.inUse.size / this.pool.size) * 100).toFixed(1)
        : 0
    };
  }

  /**
   * Get connection details
   */
  getConnectionDetails() {
    const details = [];

    for (const [connectionId, connection] of this.pool.entries()) {
      const age = Date.now() - connection.created;
      const idleTime = Date.now() - connection.lastUsed;
      
      details.push({
        id: connectionId,
        proxy: connection.proxy,
        status: this.inUse.has(connectionId) ? 'in-use' : 'available',
        useCount: connection.useCount,
        age: age,
        ageMinutes: (age / 60000).toFixed(1),
        idleTime: idleTime,
        idleMinutes: (idleTime / 60000).toFixed(1),
        shouldRetire: this.shouldRetire(connection),
        health: this.getConnectionHealth(connection)
      });
    }

    return details;
  }

  /**
   * Get connection health status
   */
  getConnectionHealth(connection) {
    const usePercentage = (connection.useCount / this.maxUseCount) * 100;
    const agePercentage = ((Date.now() - connection.created) / this.maxConnectionAge) * 100;
    
    if (usePercentage > 90 || agePercentage > 90) return 'critical';
    if (usePercentage > 70 || agePercentage > 70) return 'warning';
    return 'healthy';
  }

  /**
   * Force cleanup of a specific connection
   */
  async forceRemove(connectionId) {
    if (this.pool.has(connectionId)) {
      await this.removeConnection(connectionId);
      return true;
    }
    return false;
  }

  /**
   * Get configuration
   */
  getConfig() {
    return {
      maxPoolSize: this.maxPoolSize,
      maxIdleTime: this.maxIdleTime,
      maxUseCount: this.maxUseCount,
      maxConnectionAge: this.maxConnectionAge
    };
  }
}

module.exports = ConnectionPool;