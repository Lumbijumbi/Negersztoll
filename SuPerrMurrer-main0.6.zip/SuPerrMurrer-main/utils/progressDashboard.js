/**
 * ============================================================================
 * PROGRESS DASHBOARD - Real-Time Terminal UI
 * ============================================================================
 * 
 * Beautiful live dashboard with:
 * - Progress bar
 * - Statistics table
 * - Worker status
 * - Recent results
 * - Proxy health
 */

class ProgressDashboard {
  constructor() {
    this.stats = {
      total: 0,
      processed: 0,
      successful: 0,
      failed: 0,
      blocked: 0,
      captcha: 0,
      inProgress: 0,
      startTime: Date.now()
    };

    this.workers = new Map();
    this.recentResults = [];
    this.proxyHealth = new Map();
    this.lastRender = 0;
    this.isRendering = false;
  }

  /**
   * Update statistics
   */
  updateStats(data) {
    Object.assign(this.stats, data);
    this.render();
  }

  /**
   * Add a result to recent results feed
   */
  addResult(result) {
    this.recentResults.unshift({
      username: result.username,
      success: result.success,
      reason: result.reason,
      timestamp: Date.now()
    });

    // Keep only last 5
    if (this.recentResults.length > 5) {
      this.recentResults = this.recentResults.slice(0, 5);
    }

    this.render();
  }

  /**
   * Update worker status
   */
  updateWorker(id, status) {
    this.workers.set(id, {
      active: status.active || false,
      current: status.current || null,
      timestamp: Date.now()
    });

    this.render();
  }

  /**
   * Update proxy health
   */
  updateProxy(proxy, successRate, attempts) {
    this.proxyHealth.set(proxy, {
      successRate: successRate || 0,
      attempts: attempts || 0,
      timestamp: Date.now()
    });

    this.render();
  }

  /**
   * Create a progress bar
   */
  createProgressBar(percent, width = 50) {
    const filled = Math.floor((percent / 100) * width);
    const empty = width - filled;
    
    const filledBar = '█'.repeat(filled);
    const emptyBar = '░'.repeat(empty);
    
    return `[${filledBar}${emptyBar}] ${percent.toFixed(1)}%`;
  }

  /**
   * Format time duration
   */
  formatTime(minutes) {
    if (!isFinite(minutes) || minutes < 0) {
      return '--:--';
    }
    
    const hours = Math.floor(minutes / 60);
    const mins = Math.floor(minutes % 60);
    
    if (hours > 0) {
      return `${hours}:${mins.toString().padStart(2, '0')}`;
    }
    
    return `${mins}m`;
  }

  /**
   * Calculate ETA
   */
  calculateETA() {
    const elapsed = (Date.now() - this.stats.startTime) / 1000; // seconds
    const processed = this.stats.processed;
    const remaining = this.stats.total - processed;

    if (processed === 0 || remaining === 0) {
      return '--:--';
    }

    const rate = processed / elapsed; // items per second
    const etaSeconds = remaining / rate;
    const etaMinutes = etaSeconds / 60;

    return this.formatTime(etaMinutes);
  }

  /**
   * Calculate rate (per minute)
   */
  calculateRate() {
    const elapsed = (Date.now() - this.stats.startTime) / 1000; // seconds
    const processed = this.stats.processed;

    if (processed === 0 || elapsed === 0) {
      return '0.0';
    }

    const rate = (processed / elapsed) * 60; // per minute
    return rate.toFixed(1);
  }

  /**
   * Mini progress bar for proxy health
   */
  miniProgressBar(percent, width = 10) {
    const filled = Math.floor((percent / 100) * width);
    const empty = width - filled;
    
    let color = '';
    if (percent >= 80) color = '🟢';
    else if (percent >= 50) color = '🟡';
    else color = '🔴';
    
    return `${color} ${'▓'.repeat(filled)}${'░'.repeat(empty)} ${percent.toFixed(0)}%`;
  }

  /**
   * Clear console (cross-platform)
   */
  clearConsole() {
    // Use ANSI escape codes to clear and move cursor to top
    process.stdout.write('\x1Bc');
  }

  /**
   * Render the dashboard
   */
  render() {
    // Throttle rendering to every 500ms
    const now = Date.now();
    if (this.isRendering || now - this.lastRender < 500) {
      return;
    }

    this.isRendering = true;
    this.lastRender = now;

    try {
      this.clearConsole();

      const percent = this.stats.total > 0 
        ? (this.stats.processed / this.stats.total) * 100 
        : 0;

      // Header
      console.log('╔═══════════════════════════════════════════════════════════════╗');
      console.log('║              LIVE TESTING DASHBOARD                           ║');
      console.log('╚═══════════════════════════════════════════════════════════════╝');
      console.log('');

      // Progress bar
      const progressBar = this.createProgressBar(percent);
      console.log(progressBar + ` ${this.stats.processed}/${this.stats.total}`);
      console.log('');

      // Statistics table
      console.log('┌─────────────────┬─────────────────┬─────────────────┐');
      console.log(`│ ✅ Success: ${String(this.stats.successful).padStart(4)} │ ❌ Failed: ${String(this.stats.failed).padStart(5)} │ 🚫 Blocked: ${String(this.stats.blocked).padStart(4)} │`);
      console.log('├─────────────────┼─────────────────┼─────────────────┤');
      
      const rate = this.calculateRate();
      const eta = this.calculateETA();
      
      console.log(`│ 🤖 Captcha: ${String(this.stats.captcha).padStart(4)} │ ⚡ Rate: ${String(rate).padStart(5)}/m │ ⏱️  ETA: ${String(eta).padStart(7)} │`);
      console.log('└─────────────────┴─────────────────┴─────────────────┘');
      console.log('');

      // Worker status
      if (this.workers.size > 0) {
        console.log('👷 Workers:');
        
        const workerArray = Array.from(this.workers.entries());
        workerArray.forEach(([id, status]) => {
          const icon = status.active ? '🟢' : '⚫';
          const text = status.active && status.current 
            ? `Processing ${status.current}`
            : 'Idle';
          
          console.log(`  ${icon} Worker ${id}: ${text}`);
        });
        
        console.log('');
      }

      // Recent results
      if (this.recentResults.length > 0) {
        console.log('📊 Recent Results:');
        
        this.recentResults.forEach(result => {
          const icon = result.success ? '✅' : '❌';
          const username = result.username.padEnd(20);
          const reason = result.reason || 'Unknown';
          
          console.log(`  ${icon} ${username} - ${reason}`);
        });
        
        console.log('');
      }

      // Proxy health (top 5)
      if (this.proxyHealth.size > 0) {
        console.log('🌐 Proxy Health (Top 5):');
        
        const sortedProxies = Array.from(this.proxyHealth.entries())
          .sort((a, b) => b[1].successRate - a[1].successRate)
          .slice(0, 5);
        
        sortedProxies.forEach(([proxy, health]) => {
          const displayProxy = proxy.substring(0, 30).padEnd(30);
          const bar = this.miniProgressBar(health.successRate);
          const attempts = `(${health.attempts} attempts)`;
          
          console.log(`  ${displayProxy} ${bar} ${attempts}`);
        });
        
        console.log('');
      }

    } finally {
      this.isRendering = false;
    }
  }

  /**
   * Render final summary
   */
  renderFinalSummary() {
    this.clearConsole();

    console.log('╔═══════════════════════════════════════════════════════════════╗');
    console.log('║              FINAL TESTING SUMMARY                            ║');
    console.log('╚═══════════════════════════════════════════════════════════════╝');
    console.log('');

    const elapsed = (Date.now() - this.stats.startTime) / 1000; // seconds
    const minutes = (elapsed / 60).toFixed(1);
    const rate = this.calculateRate();

    console.log(`📊 Results:`);
    console.log(`   Total Processed: ${this.stats.processed}/${this.stats.total}`);
    console.log(`   ✅ Successful: ${this.stats.successful}`);
    console.log(`   ❌ Failed: ${this.stats.failed}`);
    console.log(`   🚫 Blocked: ${this.stats.blocked}`);
    console.log(`   🤖 Captcha: ${this.stats.captcha}`);
    console.log('');
    
    console.log(`⏱️  Performance:`);
    console.log(`   Time: ${minutes} minutes`);
    console.log(`   Rate: ${rate} credentials/minute`);
    console.log('');

    const successRate = this.stats.processed > 0
      ? ((this.stats.successful / this.stats.processed) * 100).toFixed(1)
      : 0;

    console.log(`📈 Success Rate: ${successRate}%`);
    console.log('');
  }
}

module.exports = ProgressDashboard;
