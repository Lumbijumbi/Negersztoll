/**
 * ============================================================================
 * CONFIGURATION VALIDATOR - Catch Errors Early
 * ============================================================================
 * 
 * Validates all configuration sections:
 * - Browser settings
 * - Proxy settings
 * - Batch/worker settings
 * - Form input settings
 * - Navigation settings
 * - Login settings
 * - File access
 */

const fs = require('fs').promises;
const path = require('path');

class ConfigValidator {
  constructor() {
    this.errors = [];
    this.warnings = [];
  }

  /**
   * Add error
   */
  addError(section, message) {
    this.errors.push({ section, message });
  }

  /**
   * Add warning
   */
  addWarning(section, message) {
    this.warnings.push({ section, message });
  }

  /**
   * Validate entire configuration
   */
  validate(config) {
    this.errors = [];
    this.warnings = [];

    if (!config) {
      this.addError('general', 'Configuration object is null or undefined');
      return false;
    }

    // Validate each section
    this.validateBrowser(config.browser);
    this.validateProxy(config.proxy);
    this.validateBatch(config.batch);
    this.validateForm(config.form);
    this.validateNavigation(config.navigation);
    this.validateLogin(config.login);
    this.validateRetry(config.retry);
    this.validateSession(config.session);
    this.validateNotifications(config.notifications);

    return this.errors.length === 0;
  }

  /**
   * Validate browser configuration
   */
  validateBrowser(browser) {
    if (!browser) {
      this.addError('browser', 'Browser configuration is missing');
      return;
    }

    // Timeout validation
    if (typeof browser.timeout !== 'number') {
      this.addError('browser', 'timeout must be a number');
    } else {
      if (browser.timeout < 10000) {
        this.addError('browser', 'timeout must be at least 10 seconds (10000ms)');
      }
      if (browser.timeout > 600000) {
        this.addWarning('browser', 'timeout > 10 minutes may cause delays');
      }
    }

    // Channel validation
    const validChannels = ['chrome', 'msedge', 'chromium'];
    if (browser.channel && !validChannels.includes(browser.channel)) {
      this.addError('browser', `channel must be one of: ${validChannels.join(', ')}`);
    }

    // Headless warning
    if (browser.headless === false) {
      this.addWarning('browser', 'headless=false increases resource usage');
    }
  }

  /**
   * Validate proxy configuration
   */
  validateProxy(proxy) {
    if (!proxy) {
      this.addWarning('proxy', 'Proxy configuration is missing');
      return;
    }

    if (typeof proxy.blacklistTTL === 'number' && proxy.blacklistTTL < 0) {
      this.addError('proxy', 'blacklistTTL cannot be negative');
    }

    if (typeof proxy.tcpTimeout === 'number' && proxy.tcpTimeout < 1000) {
      this.addWarning('proxy', 'tcpTimeout < 1s may cause false negatives');
    }
  }

  /**
   * Validate batch configuration
   */
  validateBatch(batch) {
    if (!batch) {
      this.addError('batch', 'Batch configuration is missing');
      return;
    }

    // Workers validation
    if (typeof batch.maxParallelWorkers !== 'number') {
      this.addError('batch', 'maxParallelWorkers must be a number');
    } else {
      if (batch.maxParallelWorkers < 1) {
        this.addError('batch', 'maxParallelWorkers must be at least 1');
      }
      if (batch.maxParallelWorkers > 16) {
        this.addWarning('batch', 'maxParallelWorkers > 16 may overload system');
      }
    }

    // Credentials per proxy validation
    if (typeof batch.credentialsPerProxy === 'number') {
      if (batch.credentialsPerProxy < 1) {
        this.addError('batch', 'credentialsPerProxy must be at least 1');
      }
      if (batch.credentialsPerProxy > 20) {
        this.addWarning('batch', 'credentialsPerProxy > 20 increases detection risk');
      }
    }
  }

  /**
   * Validate form configuration
   */
  validateForm(form) {
    if (!form) {
      this.addWarning('form', 'Form configuration is missing');
      return;
    }

    if (typeof form.typeDelayMin === 'number' && typeof form.typeDelayMax === 'number') {
      if (form.typeDelayMin > form.typeDelayMax) {
        this.addError('form', 'typeDelayMin cannot be greater than typeDelayMax');
      }
      if (form.typeDelayMin < 0) {
        this.addError('form', 'typeDelayMin cannot be negative');
      }
    }
  }

  /**
   * Validate navigation configuration
   */
  validateNavigation(navigation) {
    if (!navigation) {
      this.addWarning('navigation', 'Navigation configuration is missing');
      return;
    }

    if (typeof navigation.timeout === 'number' && navigation.timeout < 5000) {
      this.addWarning('navigation', 'navigation timeout < 5s may cause failures');
    }

    const validWaitUntil = ['load', 'domcontentloaded', 'networkidle'];
    if (navigation.domWaitUntil && !validWaitUntil.includes(navigation.domWaitUntil)) {
      this.addWarning('navigation', `domWaitUntil should be one of: ${validWaitUntil.join(', ')}`);
    }
  }

  /**
   * Validate login configuration
   */
  validateLogin(login) {
    if (!login) {
      this.addError('login', 'Login configuration is missing');
      return;
    }

    // URL validation
    if (!login.url) {
      this.addError('login', 'url is required');
    } else {
      if (!login.url.startsWith('https://')) {
        this.addWarning('login', 'url should start with https:// for security');
      }
    }

    // Selector validation
    if (!login.usernameSelector) {
      this.addError('login', 'usernameSelector is required');
    }

    if (!login.passwordSelector) {
      this.addError('login', 'passwordSelector is required');
    }

    if (!login.submitSelectors || login.submitSelectors.length === 0) {
      this.addWarning('login', 'submitSelectors should have at least one entry');
    }
  }

  /**
   * Validate retry configuration
   */
  validateRetry(retry) {
    if (!retry) {
      return; // Optional
    }

    if (retry.enabled && typeof retry.maxRetries === 'number') {
      if (retry.maxRetries < 1) {
        this.addError('retry', 'maxRetries must be at least 1 when enabled');
      }
      if (retry.maxRetries > 10) {
        this.addWarning('retry', 'maxRetries > 10 may cause long delays');
      }
    }
  }

  /**
   * Validate session configuration
   */
  validateSession(session) {
    if (!session) {
      return; // Optional
    }

    if (session.enabled && typeof session.maxAge === 'number') {
      if (session.maxAge < 60000) {
        this.addWarning('session', 'maxAge < 1 minute may not be useful');
      }
    }
  }

  /**
   * Validate notifications configuration
   */
  validateNotifications(notifications) {
    if (!notifications) {
      return; // Optional
    }

    if (notifications.enabled && notifications.webhook) {
      if (!notifications.webhook.url) {
        this.addWarning('notifications', 'Notifications enabled but webhook URL is missing');
      }

      const validTypes = ['discord', 'slack', 'generic'];
      if (notifications.webhook.type && !validTypes.includes(notifications.webhook.type)) {
        this.addWarning('notifications', `webhook type should be one of: ${validTypes.join(', ')}`);
      }
    }
  }

  /**
   * Validate file access
   */
  async validateFiles(credPath, proxyPath) {
    // Credentials file
    try {
      await fs.access(credPath, fs.constants.R_OK);
    } catch (error) {
      this.addError('files', `Cannot read credentials file: ${credPath}`);
    }

    // Proxies file
    try {
      await fs.access(proxyPath, fs.constants.R_OK);
    } catch (error) {
      this.addError('files', `Cannot read proxies file: ${proxyPath}`);
    }
  }

  /**
   * Print validation report
   */
  printReport() {
    if (this.errors.length === 0 && this.warnings.length === 0) {
      console.log('✅ Configuration validation passed!\n');
      return true;
    }

    console.log('\n📋 Configuration Validation Report:');
    console.log('═'.repeat(60));

    if (this.errors.length > 0) {
      console.log('\n❌ ERRORS (must be fixed):');
      this.errors.forEach(({ section, message }) => {
        console.log(`   [${section}] ${message}`);
        console.log(`[CONFIG] VALIDATION ERROR [${section}]: ${message}`);
      });
    }

    if (this.warnings.length > 0) {
      console.log('\n⚠️  WARNINGS (recommended to fix):');
      this.warnings.forEach(({ section, message }) => {
        console.log(`   [${section}] ${message}`);
        console.log(`[CONFIG] VALIDATION WARNING [${section}]: ${message}`);
      });
    }

    console.log('\n═'.repeat(60));

    if (this.errors.length > 0) {
      console.log('❌ Validation failed. Please fix errors before proceeding.\n');
      console.log(`[CONFIG] Validation failed with ${this.errors.length} error(s) and ${this.warnings.length} warning(s)`);
      return false;
    }

    console.log('⚠️  Validation passed with warnings. You may proceed.\n');
    console.log(`[CONFIG] Validation passed with ${this.warnings.length} warning(s)`);
    return true;
  }

  /**
   * Get structured validation report (for GUI log viewer)
   */
  getReport() {
    const valid = this.errors.length === 0;
    const summary = valid
      ? `Validation passed with ${this.warnings.length} warning(s)`
      : `Validation failed with ${this.errors.length} error(s) and ${this.warnings.length} warning(s)`;
    return {
      valid,
      errors: [...this.errors],
      warnings: [...this.warnings],
      summary
    };
  }

  /**
   * Get validation summary
   */
  getSummary() {
    return {
      valid: this.errors.length === 0,
      errors: this.errors,
      warnings: this.warnings,
      errorCount: this.errors.length,
      warningCount: this.warnings.length
    };
  }
}

module.exports = ConfigValidator;
