/**
 * Helper utilities for config file operations
 */

const CONFIG_FILE_HEADER = `/**
 * Centralized Configuration for play_version2_improved.js
 * All magic numbers and settings in one place
 */`;

/**
 * Generate config.js file content from config object
 * @param {Object} config - Configuration object
 * @returns {string} Formatted config file content
 */
function generateConfigFile(config) {
  return `${CONFIG_FILE_HEADER}

module.exports = ${JSON.stringify(config, null, 2)};
`;
}

module.exports = {
  CONFIG_FILE_HEADER,
  generateConfigFile
};
