/**
 * ============================================================================
 * CONFIG APPLIER - Apply User Selections to System Config
 * ============================================================================
 * 
 * Helper to apply interactive CLI selections to runtime configuration
 */

const { applyProfile } = require('./configProfiles');

/**
 * Apply user configuration from interactive CLI to system config
 */
function applyUserConfig(systemConfig, userConfig) {
  if (!userConfig) {
    return systemConfig;
  }

  // Apply profile if specified
  if (userConfig.profile && userConfig.profile !== 'custom') {
    try {
      const profiledConfig = applyProfile(systemConfig, userConfig.profile);
      Object.assign(systemConfig, profiledConfig);
    } catch (error) {
      console.warn(`Failed to apply profile ${userConfig.profile}: ${error.message}`);
    }
  }

  // Apply feature toggles
  if (userConfig.features) {
    // Session reuse
    if (typeof userConfig.features.sessionReuse === 'boolean') {
      if (!systemConfig.session) {
        systemConfig.session = {};
      }
      systemConfig.session.enabled = userConfig.features.sessionReuse;
    }

    // Retry queue
    if (typeof userConfig.features.retryQueue === 'boolean') {
      if (!systemConfig.retry) {
        systemConfig.retry = {};
      }
      systemConfig.retry.enabled = userConfig.features.retryQueue;
    }

    // Connection pool
    if (typeof userConfig.features.connectionPool === 'boolean') {
      if (!systemConfig.performance) {
        systemConfig.performance = {};
      }
      systemConfig.performance.enableConnectionPool = userConfig.features.connectionPool;
    }

    // Auto-tune workers
    if (typeof userConfig.features.autoTuneWorkers === 'boolean') {
      if (!systemConfig.performance) {
        systemConfig.performance = {};
      }
      systemConfig.performance.autoTuneWorkers = userConfig.features.autoTuneWorkers;
    }

    // Health checks
    if (typeof userConfig.features.healthChecks === 'boolean') {
      if (!systemConfig.stability) {
        systemConfig.stability = {};
      }
      systemConfig.stability.enableHealthChecks = userConfig.features.healthChecks;
    }

    // Auto-recovery
    if (typeof userConfig.features.autoRecovery === 'boolean') {
      if (!systemConfig.stability) {
        systemConfig.stability = {};
      }
      systemConfig.stability.enableAutoRecovery = userConfig.features.autoRecovery;
    }
  }

  // Apply custom overrides
  if (userConfig.overrides) {
    if (typeof userConfig.overrides.maxParallelWorkers === 'number') {
      systemConfig.batch.maxParallelWorkers = userConfig.overrides.maxParallelWorkers;
    }

    if (typeof userConfig.overrides.headless === 'boolean') {
      systemConfig.browser.headless = userConfig.overrides.headless;
    }

    if (typeof userConfig.overrides.credentialsPerProxy === 'number') {
      systemConfig.batch.credentialsPerProxy = userConfig.overrides.credentialsPerProxy;
    }
  }

  return systemConfig;
}

module.exports = { applyUserConfig };
