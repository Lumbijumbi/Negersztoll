/**
 * ============================================================================
 * RESOURCE MANAGER - Intelligent System Resource Monitoring
 * ============================================================================
 * 
 * Features:
 * - Detect optimal worker count
 * - Monitor CPU and memory usage
 * - Provide performance recommendations
 * - Auto-tuning support
 */

const os = require('os');

class ResourceManager {
  constructor() {
    this.cpuUsageHistory = [];
    this.memoryUsageHistory = [];
    this.maxHistorySize = 10;
    this.workerPerformance = new Map();
  }

  /**
   * Get optimal worker count based on system resources
   */
  getOptimalWorkerCount() {
    const cpuCount = os.cpus().length;
    const totalMemoryGB = os.totalmem() / (1024 ** 3);
    const freeMemoryGB = os.freemem() / (1024 ** 3);

    // Reserve 1 CPU core for system
    const availableCores = Math.max(1, cpuCount - 1);

    // Estimate 500MB per worker (browser + overhead)
    const memoryBasedWorkers = Math.floor(freeMemoryGB / 0.5);

    // Use the lower of CPU-based or memory-based workers
    let recommended = Math.min(availableCores, memoryBasedWorkers);

    // Cap at reasonable maximum
    recommended = Math.min(recommended, 16);
    recommended = Math.max(recommended, 1);

    // Determine reason
    let reason;
    if (availableCores < memoryBasedWorkers) {
      reason = `CPU limited (${cpuCount} cores)`;
    } else {
      reason = `Memory limited (${freeMemoryGB.toFixed(1)}GB free)`;
    }

    return {
      recommended,
      reason,
      cpuCount,
      totalMemoryGB: totalMemoryGB.toFixed(1),
      freeMemoryGB: freeMemoryGB.toFixed(1),
      availableCores,
      memoryBasedWorkers
    };
  }

  /**
   * Get current CPU usage percentage
   */
  async getCPUUsage() {
    const startUsage = process.cpuUsage();
    const startTime = Date.now();

    // Wait 100ms to measure
    await new Promise(resolve => setTimeout(resolve, 100));

    const endUsage = process.cpuUsage(startUsage);
    const endTime = Date.now();

    const elapsedTime = endTime - startTime;
    const elapsedMicroseconds = elapsedTime * 1000;

    // Calculate percentage
    const totalUsage = (endUsage.user + endUsage.system) / elapsedMicroseconds;
    const percentage = totalUsage * 100;

    return Math.min(100, Math.max(0, percentage));
  }

  /**
   * Get current memory usage
   */
  getMemoryUsage() {
    const totalMemory = os.totalmem();
    const freeMemory = os.freemem();
    const usedMemory = totalMemory - freeMemory;

    const usedPercent = (usedMemory / totalMemory) * 100;
    const freePercent = (freeMemory / totalMemory) * 100;

    return {
      totalGB: (totalMemory / (1024 ** 3)).toFixed(2),
      usedGB: (usedMemory / (1024 ** 3)).toFixed(2),
      freeGB: (freeMemory / (1024 ** 3)).toFixed(2),
      usedPercent: usedPercent.toFixed(1),
      freePercent: freePercent.toFixed(1)
    };
  }

  /**
   * Monitor resources and provide recommendations
   */
  async monitorResources() {
    const cpuUsage = await this.getCPUUsage();
    const memoryUsage = this.getMemoryUsage();

    // Add to history
    this.cpuUsageHistory.push(cpuUsage);
    this.memoryUsageHistory.push(parseFloat(memoryUsage.usedPercent));

    // Trim history
    if (this.cpuUsageHistory.length > this.maxHistorySize) {
      this.cpuUsageHistory.shift();
    }
    if (this.memoryUsageHistory.length > this.maxHistorySize) {
      this.memoryUsageHistory.shift();
    }

    // Calculate averages
    const avgCPU = this.cpuUsageHistory.reduce((a, b) => a + b, 0) / this.cpuUsageHistory.length;
    const avgMemory = this.memoryUsageHistory.reduce((a, b) => a + b, 0) / this.memoryUsageHistory.length;

    // Determine if system is strained (lower threshold for earlier detection)
    const shouldThrottle = avgCPU > 90 || avgMemory > 80;

    return {
      current: {
        cpu: cpuUsage.toFixed(1),
        memory: memoryUsage.usedPercent,
        freeCPU: (100 - cpuUsage).toFixed(1),
        freeMemoryPercent: memoryUsage.freePercent,
        freeMemoryGB: memoryUsage.freeGB
      },
      average: {
        cpu: avgCPU.toFixed(1),
        memory: avgMemory.toFixed(1)
      },
      shouldThrottle,
      timestamp: Date.now()
    };
  }

  /**
   * Get performance recommendations
   */
  getRecommendations() {
    if (this.cpuUsageHistory.length === 0 || this.memoryUsageHistory.length === 0) {
      return [];
    }

    const recommendations = [];

    const avgCPU = this.cpuUsageHistory.reduce((a, b) => a + b, 0) / this.cpuUsageHistory.length;
    const avgMemory = this.memoryUsageHistory.reduce((a, b) => a + b, 0) / this.memoryUsageHistory.length;

    // High CPU usage
    if (avgCPU > 90) {
      recommendations.push({
        type: 'critical',
        category: 'cpu',
        message: 'CPU usage is very high (>90%). Reduce worker count.',
        action: 'reduce_workers'
      });
    } else if (avgCPU > 75) {
      recommendations.push({
        type: 'warning',
        category: 'cpu',
        message: 'CPU usage is high (>75%). Consider reducing workers.',
        action: 'reduce_workers'
      });
    }

    // High memory usage
    if (avgMemory > 90) {
      recommendations.push({
        type: 'critical',
        category: 'memory',
        message: 'Memory usage is very high (>90%). Enable headless mode and reduce workers.',
        action: 'enable_headless_reduce_workers'
      });
    } else if (avgMemory > 80) {
      recommendations.push({
        type: 'warning',
        category: 'memory',
        message: 'Memory usage is high (>80%). Consider enabling headless mode.',
        action: 'enable_headless'
      });
    }

    // Underutilized resources
    if (avgCPU < 40 && avgMemory < 50) {
      recommendations.push({
        type: 'info',
        category: 'performance',
        message: 'System is underutilized. You can increase worker count for better performance.',
        action: 'increase_workers'
      });
    }

    return recommendations;
  }

  /**
   * Track worker performance
   */
  trackWorkerPerformance(workerId, metrics) {
    this.workerPerformance.set(workerId, {
      ...metrics,
      timestamp: Date.now()
    });
  }

  /**
   * Attempt to reclaim memory by suggesting garbage collection.
   * Only effective when Node.js is started with --expose-gc flag.
   * When the flag is absent, global.gc is undefined and this method is a no-op —
   * no warning is emitted because GC unavailability is the common case and would
   * produce noisy logs. Callers should not rely on this for guaranteed cleanup.
   * @returns {boolean} true if GC was triggered, false if --expose-gc is not set
   */
  triggerGarbageCollection() {
    if (typeof global.gc === 'function') {
      try {
        global.gc();
        return true;
      } catch (_) {}
    }
    return false;
  }

  /**
   * Check if memory pressure is critical (>90%) and attempt a GC cycle.
   * Useful for proactive cleanup between worker batches.
   * Note: GC is only triggered when Node.js is started with --expose-gc.
   * @returns {number} Current system memory usage percentage (0–100)
   */
  checkMemoryPressure() {
    const memory = this.getMemoryUsage();
    const usedPercent = parseFloat(memory.usedPercent);
    if (usedPercent > 90) {
      this.triggerGarbageCollection();
    }
    return usedPercent;
  }

  /**
   * Export system report
   */
  exportSystemReport() {
    const optimal = this.getOptimalWorkerCount();
    const memory = this.getMemoryUsage();
    const recommendations = this.getRecommendations();

    let avgCPU = 0;
    let avgMemory = 0;

    if (this.cpuUsageHistory.length > 0) {
      avgCPU = this.cpuUsageHistory.reduce((a, b) => a + b, 0) / this.cpuUsageHistory.length;
    }

    if (this.memoryUsageHistory.length > 0) {
      avgMemory = this.memoryUsageHistory.reduce((a, b) => a + b, 0) / this.memoryUsageHistory.length;
    }

    return {
      system: {
        cpuCount: optimal.cpuCount,
        totalMemoryGB: optimal.totalMemoryGB,
        platform: os.platform(),
        arch: os.arch(),
        nodeVersion: process.version
      },
      optimal: {
        recommendedWorkers: optimal.recommended,
        reason: optimal.reason
      },
      current: {
        cpu: avgCPU.toFixed(1),
        memory: avgMemory.toFixed(1),
        freeCPU: (100 - avgCPU).toFixed(1),
        freeMemoryPercent: memory.freePercent,
        freeMemoryGB: memory.freeGB
      },
      recommendations,
      timestamp: new Date().toISOString()
    };
  }
}

module.exports = ResourceManager;
