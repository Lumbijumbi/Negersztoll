/**
 * ============================================================================
 * AUTO-RECOVERY SYSTEM - Self-Healing
 * ============================================================================
 * 
 * Features:
 * - Error classification
 * - Pluggable recovery strategies
 * - Recovery history tracking
 * - Success rate tracking per error type
 */

class AutoRecovery {
  constructor(options = {}) {
    this.config = options.config || {};
    this.proxyManager = options.proxyManager || null;
    
    this.strategies = new Map(); // errorType -> recovery function
    this.history = []; // Recovery attempt history
    this.stats = {
      total: 0,
      successful: 0,
      failed: 0,
      byType: {}
    };

    // Register default strategies
    this.registerDefaultStrategies();
  }

  /**
   * Register a recovery strategy
   */
  register(errorType, strategy) {
    this.strategies.set(errorType, strategy);
  }

  /**
   * Classify error type
   */
  classifyError(error) {
    if (!error) {
      return 'UNKNOWN';
    }

    const message = error.message || String(error);
    const code = error.code || '';

    // Network errors
    if (
      message.includes('ECONNREFUSED') ||
      message.includes('ECONNRESET') ||
      message.includes('ETIMEDOUT') ||
      message.includes('net::') ||
      code === 'ECONNREFUSED' ||
      code === 'ECONNRESET' ||
      code === 'ETIMEDOUT'
    ) {
      return 'NETWORK';
    }

    // Timeout errors
    if (
      message.includes('timeout') ||
      message.includes('Timeout') ||
      message.includes('TIMEOUT')
    ) {
      return 'TIMEOUT';
    }

    // Browser crash
    if (
      message.includes('Target closed') ||
      message.includes('Browser closed') ||
      message.includes('Connection closed') ||
      message.includes('crashed')
    ) {
      return 'BROWSER_CRASH';
    }

    // Memory errors
    if (
      message.includes('out of memory') ||
      message.includes('OOM') ||
      message.includes('heap')
    ) {
      return 'MEMORY';
    }

    // Disk space errors
    if (
      message.includes('ENOSPC') ||
      message.includes('no space') ||
      code === 'ENOSPC'
    ) {
      return 'DISK';
    }

    return 'UNKNOWN';
  }

  /**
   * Attempt recovery
   */
  async recover(error, context = {}) {
    const errorType = this.classifyError(error);
    const strategy = this.strategies.get(errorType);

    this.stats.total++;

    if (!this.stats.byType[errorType]) {
      this.stats.byType[errorType] = {
        total: 0,
        successful: 0,
        failed: 0
      };
    }

    this.stats.byType[errorType].total++;

    if (!strategy) {
      // No recovery strategy available
      this.recordRecovery(errorType, false, 'No strategy available');
      return {
        recovered: false,
        errorType,
        action: 'No strategy available'
      };
    }

    try {
      const result = await strategy(error, context);
      
      const success = result.recovered || false;
      
      if (success) {
        this.stats.successful++;
        this.stats.byType[errorType].successful++;
      } else {
        this.stats.failed++;
        this.stats.byType[errorType].failed++;
      }

      this.recordRecovery(errorType, success, result.action);

      return {
        recovered: success,
        errorType,
        action: result.action,
        details: result.details
      };
    } catch (recoveryError) {
      // Recovery itself failed
      this.stats.failed++;
      this.stats.byType[errorType].failed++;
      
      this.recordRecovery(errorType, false, `Recovery failed: ${recoveryError.message}`);

      return {
        recovered: false,
        errorType,
        action: `Recovery failed: ${recoveryError.message}`
      };
    }
  }

  /**
   * Record recovery attempt
   */
  recordRecovery(errorType, success, action) {
    this.history.push({
      errorType,
      success,
      action,
      timestamp: Date.now()
    });

    // Keep last 100 entries
    if (this.history.length > 100) {
      this.history.shift();
    }
  }

  /**
   * Register default recovery strategies
   */
  registerDefaultStrategies() {
    // Network error recovery
    this.register('NETWORK', async (error, context) => {
      // Try switching proxy
      if (context.proxy && this.proxyManager) {
        const newProxy = this.proxyManager.getNextProxy ? 
          this.proxyManager.getNextProxy() : null;
        
        if (newProxy && newProxy !== context.proxy) {
          return {
            recovered: true,
            action: `Switched proxy from ${context.proxy} to ${newProxy}`,
            details: { newProxy }
          };
        }
      }

      // Wait and retry
      await new Promise(resolve => setTimeout(resolve, 5000));
      
      return {
        recovered: true,
        action: 'Waited 5 seconds, ready to retry',
        details: { waitTime: 5000 }
      };
    });

    // Timeout error recovery
    this.register('TIMEOUT', async (error, context) => {
      // Increase timeout threshold
      const currentTimeout = context.config?.browser?.timeout || 180000;
      const newTimeout = Math.floor(currentTimeout * 1.5);

      if (context.config?.browser) {
        context.config.browser.timeout = newTimeout;
      }

      return {
        recovered: true,
        action: `Increased timeout from ${currentTimeout}ms to ${newTimeout}ms`,
        details: { oldTimeout: currentTimeout, newTimeout }
      };
    });

    // Browser crash recovery
    this.register('BROWSER_CRASH', async (error, context) => {
      // Close browser if available
      if (context.browser) {
        try {
          await context.browser.close();
        } catch (e) {
          // Ignore
        }
      }

      // Suggest reducing workers
      return {
        recovered: true,
        action: 'Closed crashed browser, recommend reducing worker count',
        details: { suggestion: 'reduce_workers' }
      };
    });

    // Memory error recovery
    this.register('MEMORY', async (error, context) => {
      // Force garbage collection if available
      if (global.gc) {
        global.gc();
      }

      // Enable headless if not already
      const wasHeadless = context.config?.browser?.headless;
      
      if (context.config?.browser && !wasHeadless) {
        context.config.browser.headless = true;
      }

      return {
        recovered: true,
        action: `Memory recovery: GC forced, headless=${!wasHeadless ? 'enabled' : 'already on'}`,
        details: {
          gcForced: !!global.gc,
          headlessEnabled: !wasHeadless,
          suggestion: 'reduce_workers'
        }
      };
    });

    // Disk space error recovery
    this.register('DISK', async (error, context) => {
      return {
        recovered: false,
        action: 'No automatic disk cleanup available',
        details: { filesRemoved: 0 }
      };
    });
  }

  /**
   * Get recovery statistics
   */
  getStats() {
    const successRate = this.stats.total > 0
      ? ((this.stats.successful / this.stats.total) * 100).toFixed(1)
      : 0;

    return {
      total: this.stats.total,
      successful: this.stats.successful,
      failed: this.stats.failed,
      successRate: `${successRate}%`,
      byType: this.stats.byType
    };
  }

  /**
   * Get recovery history
   */
  getHistory(limit = 20) {
    return this.history.slice(-limit);
  }

  /**
   * Export recovery report
   */
  exportReport() {
    const stats = this.getStats();
    const history = this.getHistory(50);

    return {
      stats,
      recentHistory: history,
      timestamp: new Date().toISOString()
    };
  }
}

module.exports = AutoRecovery;
