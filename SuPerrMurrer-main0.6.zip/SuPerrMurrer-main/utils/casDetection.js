/**
 * CAS Detection Module
 * Prioritizes CAS Ticket Redirect detection with OAuth2.0 callbackAuthorize URL pattern matching
 * Last Updated: 2026-01-08
 */

const config = require('../config');

// Pre-normalize detection phrases at module load for performance
const INVALID_CREDENTIALS_PHRASE_NORMALIZED = config.detection.invalidCredentialsPhrase
  .replace(/\s+/g, ' ')
  .trim()
  .toLowerCase();
const ACCOUNT_LOCK_PHRASE_NORMALIZED = (config.detection.accountLockPhrase || '')
  .replace(/\s+/g, ' ')
  .trim()
  .toLowerCase();
const BLOCK_PHRASES_NORMALIZED = (config.detection.blockPhrases || [])
  .map(p => p.replace(/\s+/g, ' ').trim().toLowerCase());
const SUSPICIOUS_BEHAVIOR_PHRASE_NORMALIZED = (config.detection.suspiciousBehaviorPhrase || '')
  .replace(/\s+/g, ' ')
  .trim()
  .toLowerCase();
const BOT_CHECK_PHRASE_NORMALIZED = (config.detection.botCheckPhrase || '')
  .replace(/\s+/g, ' ')
  .trim()
  .toLowerCase();
const CAPTCHA_PHRASE_NORMALIZED = (config.detection.captchaPhrase || '')
  .replace(/\s+/g, ' ')
  .trim()
  .toLowerCase();

class CASDetector {
  constructor() {
    // OAuth Code Redirect Pattern (PRIMARY SUCCESS INDICATOR)
    // Note: Detection pattern is permissive to catch any OAuth code format,
    // while validation (isValidOAuthCodeFormat) enforces strict format requirements.
    // This follows the principle: "be liberal in what you accept, strict in what you validate"
    this.oauthCodePattern = /^https?:\/\/(?:www\.)?supercard\.ch\/[a-z]{2}\.nocache\.html\?code=(OC-\d{6}-[A-Za-z0-9\-_]+)(?:&|$)/i;
    
    // OAuth Code extraction pattern
    this.oauthCodeExtractPattern = /[?&]code=(OC-\d{6}-[A-Za-z0-9\-_]+)(?:&|$)/i;
    
    // Pattern for CAS OAuth2.0 callbackAuthorize URLs with ticket parameter
    this.casTicketPattern = /https:\/\/login\.supercard\.ch\/cas\/oauth2\.0\/callbackAuthorize\?[^#]*ticket=([^&\s]+)/i;
    
    // Pattern for extracting ticket value from URL
    this.ticketExtractPattern = /[?&]ticket=([^&\s]+)/i;
    
    // Pattern for detecting CAS redirect endpoints
    this.casRedirectPattern = /https:\/\/login\.supercard\.ch\/cas\/oauth2\.0\/callbackAuthorize/i;
    
    // Callback authorize URL parameter pattern
    this.callbackAuthorizePattern = /callbackAuthorize\?[^#]*(?:client_id|scope|redirect_uri|response_type|ticket)/i;
    
    // TGC cookie pattern (fallback)
    this.tgcCookiePattern = /CASTGC=[^;\s]+/i;
  }

  /**
   * PRIMARY detection method: OAuth Authorization Code Redirect
   * Detects redirects to supercard.ch with OAuth code parameter
   * @param {string} url - The URL to check for OAuth code
   * @returns {object|null} - Returns code object if detected, null otherwise
   */
  detectOAuthCodeRedirect(url) {
    if (!url || typeof url !== 'string') {
      return null;
    }

    const codeMatch = url.match(this.oauthCodePattern);
    if (codeMatch && codeMatch[1]) {
      return {
        type: 'oauth_code_redirect',
        code: codeMatch[1],
        method: 'oauth_authorization_code',
        priority: 'primary',
        url: url
      };
    }
    return null;
  }

  /**
   * Validates OAuth code format
   * @param {string} code - The code to validate
   * @returns {boolean} - True if code matches OAuth format (OC-XXXXXX-...)
   */
  isValidOAuthCodeFormat(code) {
    if (!code || typeof code !== 'string') {
      return false;
    }
    // OAuth Code format: OC-XXXXXX-XXXXXXXXXXXXXXXXXXXXXXXX-cas-XXXXXXXXXXXX-XXXXX
    return /^OC-\d{6}-[A-Za-z0-9\-_]+-cas-[A-Za-z0-9]+-[A-Za-z0-9]+$/i.test(code);
  }

  /**
   * Extracts OAuth code parameter from URL
   * @param {string} url - The URL containing code parameter
   * @returns {string|null} - The code value or null
   */
  extractOAuthCode(url) {
    if (!url || typeof url !== 'string') {
      return null;
    }

    const match = url.match(this.oauthCodeExtractPattern);
    return match ? match[1] : null;
  }

  /**
   * SECONDARY detection method: CAS Ticket from redirect URL
   * @param {string} url - The URL to check for CAS ticket
   * @returns {object|null} - Returns ticket object if detected, null otherwise
   */
  detectCASTicketRedirect(url) {
    if (!url || typeof url !== 'string') {
      return null;
    }

    const ticketMatch = url.match(this.casTicketPattern);
    if (ticketMatch && ticketMatch[1]) {
      return {
        type: 'cas_ticket_redirect',
        ticket: ticketMatch[1],
        method: 'ticket_parameter',
        priority: 'secondary',
        url: url
      };
    }
    return null;
  }

  /**
   * Validates callback authorize URL format
   * @param {string} url - The URL to validate
   * @returns {boolean} - True if URL matches callbackAuthorize pattern
   */
  isCallbackAuthorizeURL(url) {
    if (!url || typeof url !== 'string') {
      return false;
    }
    return this.casRedirectPattern.test(url) && this.callbackAuthorizePattern.test(url);
  }

  /**
   * Extracts ticket parameter from URL
   * @param {string} url - The URL containing ticket parameter
   * @returns {string|null} - The ticket value or null
   */
  extractTicket(url) {
    if (!url || typeof url !== 'string') {
      return null;
    }

    const match = url.match(this.ticketExtractPattern);
    return match ? match[1] : null;
  }

  /**
   * Validates ticket format
   * @param {string} ticket - The ticket to validate
   * @returns {boolean} - True if ticket matches CAS format (ST-XXXXXX-XXXXXXXXXXXXXX)
   */
  isValidTicketFormat(ticket) {
    if (!ticket || typeof ticket !== 'string') {
      return false;
    }
    // CAS Service Ticket format: ST-XXXXXX-XXXXXXXXXXXXXXXXXXXXXXXXX
    return /^ST-[a-zA-Z0-9\-]+$/.test(ticket);
  }

  /**
   * FALLBACK detection method: TGC Cookie
   * @param {string} cookieString - The cookie string to check
   * @returns {object|null} - Returns TGC object if detected, null otherwise
   */
  detectTGCCookie(cookieString) {
    if (!cookieString || typeof cookieString !== 'string') {
      return null;
    }

    const tgcMatch = cookieString.match(this.tgcCookiePattern);
    if (tgcMatch) {
      return {
        type: 'cas_tgc_cookie',
        cookie: tgcMatch[0],
        method: 'tgc_cookie',
        priority: 'fallback'
      };
    }
    return null;
  }

  /**
   * Main detection method: Checks for CAS in priority order
   * 1. OAuth Code Redirect (PRIMARY)
   * 2. CAS Ticket Redirect (SECONDARY)
   * 3. TGC Cookie (FALLBACK)
   * 
   * @param {object} detectionContext - Context object with url and cookies
   * @returns {object|null} - Returns detection result or null
   */
  detect(detectionContext) {
    if (!detectionContext || typeof detectionContext !== 'object') {
      return null;
    }

    // PRIORITY 1: Check for OAuth Code Redirect (PRIMARY)
    if (detectionContext.url) {
      const oauthCodeDetection = this.detectOAuthCodeRedirect(detectionContext.url);
      if (oauthCodeDetection) {
        // Use the code already extracted by detectOAuthCodeRedirect
        if (oauthCodeDetection.code && this.isValidOAuthCodeFormat(oauthCodeDetection.code)) {
          return {
            ...oauthCodeDetection,
            validated: true,
            authenticated: true
          };
        }
        return oauthCodeDetection;
      }
    }

    // PRIORITY 2: Check for CAS Ticket Redirect (SECONDARY)
    if (detectionContext.url) {
      const ticketDetection = this.detectCASTicketRedirect(detectionContext.url);
      if (ticketDetection) {
        // Validate ticket format
        const ticket = this.extractTicket(detectionContext.url);
        if (ticket && this.isValidTicketFormat(ticket)) {
          return {
            ...ticketDetection,
            validated: true,
            authenticated: true
          };
        }
        return ticketDetection;
      }
    }

    // PRIORITY 3: Check for TGC Cookie (FALLBACK)
    if (detectionContext.cookies) {
      const tgcDetection = this.detectTGCCookie(detectionContext.cookies);
      if (tgcDetection) {
        return tgcDetection;
      }
    }

    return null;
  }

  /**
   * Parses and extracts parameters from callbackAuthorize URL
   * @param {string} url - The callback authorize URL
   * @returns {object} - Extracted parameters
   */
  parseCallbackAuthorizeURL(url) {
    if (!this.isCallbackAuthorizeURL(url)) {
      return null;
    }

    const params = new URL(url).searchParams;
    return {
      client_id: params.get('client_id'),
      scope: params.get('scope'),
      redirect_uri: params.get('redirect_uri'),
      response_type: params.get('response_type'),
      idpv: params.get('idpv'),
      locale: params.get('locale'),
      client_name: params.get('client_name'),
      ticket: params.get('ticket')
    };
  }
}

/**
 * Main detection function wrapper for integration with worker processes
 * Prioritizes OAuth Code Redirect as PRIMARY detection method
 * 
 * @param {Page} page - Playwright/Puppeteer page object
 * @param {string} username - Username for logging purposes
 * @param {string} password - Password for logging purposes
 * @param {object} options - Detection options
 * @returns {Promise<object>} Detection result with confidence score
 */
async function submitAndDetectCasFlow(page, username, password, options = {}) {
  const {
    casLoginPath = '/cas/login',
    accountHost = 'www.supercard.ch',
    timeoutMs = 12000,
    tgcCookieNames = ['TGC'],
    verbose = false,
    enableTGCDetection = true
  } = options;

  const detector = new CASDetector();
  const startTime = Date.now();
  const endTime = startTime + timeoutMs;
  let tgcDisabledLogged = false;

  // Helper to log if verbose
  const log = (msg) => verbose && console.log(`[CAS Detection] ${msg}`);

  log('Starting CAS authentication detection...');

  // Wait for page to stabilize after form submission
  await new Promise(resolve => setTimeout(resolve, 500));

  // Monitor for success indicators
  while (Date.now() < endTime) {
    try {
      const currentUrl = await page.url();
      
      // PRIMARY DETECTION: OAuth Code Redirect - 99% Confidence
      log('Checking for OAuth Code Redirect (PRIMARY)...');
      const oauthCodeDetection = detector.detectOAuthCodeRedirect(currentUrl);
      if (oauthCodeDetection) {
        log(`✓ OAuth Code Redirect detected with 99% confidence`);
        return {
          ok: true,
          type: 'success',
          reason: 'oauth_code_redirect',
          confidence: 0.99,
          method: 'oauth_code_redirect',
          detectionMethod: 'oauth_code_redirect',
          code: oauthCodeDetection.code,
          url: currentUrl,
          details: `OAuth authorization code detected: ${oauthCodeDetection.code}`,
          duration: Date.now() - startTime
        };
      }

      // SECONDARY DETECTION: CAS Ticket Redirect - 95% Confidence
      log('Checking for CAS Ticket Redirect (SECONDARY)...');
      const ticketRedirect = detector.detectCASTicketRedirect(currentUrl);
      if (ticketRedirect) {
        log(`✓ CAS Ticket Redirect detected with 95% confidence`);
        return {
          ok: true,
          type: 'success',
          reason: 'cas_ticket_redirect',
          confidence: 0.95,
          method: 'cas_ticket_redirect',
          detectionMethod: 'cas_ticket_redirect',
          details: `CAS OAuth2.0 callbackAuthorize redirect detected with ticket: ${ticketRedirect.ticket}`,
          ticket: ticketRedirect.ticket,
          url: currentUrl,
          duration: Date.now() - startTime
        };
      }

      if (enableTGCDetection) {
        // TERTIARY DETECTION: TGC Cookie - 99% Confidence
        log('Checking for TGC Cookie (TERTIARY)...');
        
        try {
          // Check if cookies method exists
          if (typeof page.cookies !== 'function') {
            log('⚠️ Warning: page.cookies() method not available, skipping TGC detection');
          } else {
            const cookies = await page.cookies();
            const cookieString = cookies.map(c => `${c.name}=${c.value}`).join('; ');
            const tgcDetection = detector.detectTGCCookie(cookieString);
            
            if (tgcDetection) {
              // Find the actual cookie object for detailed info
              const tgcCookie = cookies.find(c => tgcCookieNames.includes(c.name));
              log(`✓ TGC Cookie detected with 99% confidence`);
              return {
                ok: true,
                type: 'success',
                reason: 'tgc_cookie_detected',
                confidence: 0.99,
                method: 'tgc_cookie',
                detectionMethod: 'tgc_cookie',
                details: `CAS Ticket Granting Cookie (TGC) detected: ${tgcCookie?.name || 'TGC'}`,
                cookie: {
                  name: tgcCookie?.name || 'TGC',
                  domain: tgcCookie?.domain || '',
                  secure: tgcCookie?.secure || false,
                  valueLength: tgcCookie?.value?.length || 0
                },
                duration: Date.now() - startTime
              };
            }
          }
        } catch (cookieError) {
          log(`⚠️ TGC Cookie detection error (non-fatal): ${cookieError.message}`);
          // Continue to next detection method instead of failing
        }
      } else if (!tgcDisabledLogged) {
        log('TGC Cookie detection is disabled');
        tgcDisabledLogged = true;
      }
      
      // QUATERNARY DETECTION: Account domain navigation with DOM verification - 92% Confidence
      // This catches cases where the user successfully authenticated and reached the account page
      // Lower priority than TGC cookie detection
      log('Checking for account domain navigation (QUATERNARY)...');
      const CAS_PATH = '/cas/'; // CAS authentication path to exclude
      if (currentUrl.includes(accountHost) && !currentUrl.includes(CAS_PATH)) {
        // Verify we're actually logged in by checking for auth indicators
        let isVerified = false;
        try {
          isVerified = await page.evaluate(() => {
            const logoutBtn = document.querySelector('[href*="logout"], [data-action="logout"], .logout, a[href*="abmelden"]');
            const userMenu = document.querySelector('.user-menu, .account-menu, [data-user], .myAccount');
            const greetingText = document.body?.innerText?.match(/willkommen|mein konto|my account/i);
            return !!(logoutBtn || userMenu || greetingText);
          }).catch(() => false);
        } catch (_) {}
        
        if (isVerified) {
          log(`✓ Account domain navigation VERIFIED with 92% confidence`);
          return {
            ok: true,
            type: 'success',
            reason: 'account_domain_verified',
            confidence: 0.92,
            method: 'account_domain_verified',
            detectionMethod: 'account_domain_verified',
            details: `Verified logged-in state on ${accountHost}`,
            url: currentUrl,
            duration: Date.now() - startTime
          };
        } else {
          log(`⚠ Account domain reached but no auth indicators — skipping`);
          // Don't return success — continue detection loop
        }
      }

      // EARLY FAILURE DETECTION: Check for invalid credentials, blocks, captcha
      const earlyFailure = await checkForEarlyFailure(page);
      if (earlyFailure) {
        log(`✗ Early failure detected: ${earlyFailure.reason}`);
        return { ...earlyFailure, duration: Date.now() - startTime };
      }

      // Wait before next check
      await new Promise(resolve => setTimeout(resolve, 300));
    } catch (error) {
      log(`Detection error: ${error.message}`);
    }
  }

  // Before timeout - check for invalid credentials message
  try {
    const bodyText = await page.evaluate(() =>
      document.body && document.body.innerText ? document.body.innerText : ''
    ).catch(() => '');
    
    if (bodyText) {
      const normalized = bodyText.replace(/\s+/g, ' ').trim().toLowerCase();
      
      if (normalized.includes(INVALID_CREDENTIALS_PHRASE_NORMALIZED)) {
        log('✗ Invalid credentials detected');
        return {
          ok: false,
          type: 'failure',
          reason: 'invalid_credentials',
          confidence: 0.95, // High confidence that credentials are wrong
          method: 'error_message_detection',
          detectionMethod: 'invalid_credentials_phrase',
          details: 'Invalid credentials error message detected on page',
          duration: Date.now() - startTime
        };
      }
    }
  } catch (error) {
    log(`Error checking for invalid credentials: ${error.message}`);
  }

  // Timeout - no success detected
  log('✗ No success indicator detected within timeout');
  return {
    ok: false,
    type: 'failure',
    reason: 'no_success_indicator',
    confidence: 0.0,
    method: 'none',
    detectionMethod: 'none',
    details: 'No OAuth code or CAS authentication indicator detected within timeout period',
    duration: Date.now() - startTime
  };
}

/**
 * Checks page body text for early failure conditions (invalid credentials, blocks, captcha).
 * Called periodically during detection to avoid waiting for full timeout on obvious failures.
 *
 * @param {Page} page - Playwright page object
 * @returns {Promise<object|null>} Failure result object or null if no failure detected
 */
async function checkForEarlyFailure(page) {
  try {
    const failText = await page.evaluate((selectors) => {
      for (const sel of selectors) {
        const el = document.querySelector(sel);
        if (el) return el.textContent.replace(/\s+/g, ' ').trim().toLowerCase();
      }
      // Narrow fallback: first 2000 chars of body textContent (no layout recalculation).
      // 2000 chars is enough to capture any visible error message while avoiding
      // scanning the entire page body on every 600ms interval call.
      const body = document.body;
      return body ? (body.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase().slice(0, 2000) : '';
    }, ['.alert.alert-danger', '.error', '[role="alert"]', '#error', '.login-error', '.errorMessage']).catch(() => '');

    if (!failText) return null;
    // Apply normalization in JS too so that test mocks returning raw text work correctly
    const normalized = failText.replace(/\s+/g, ' ').trim().toLowerCase();

    if (normalized.includes(INVALID_CREDENTIALS_PHRASE_NORMALIZED)) {
      return {
        ok: false, type: 'failure', reason: 'invalid_credentials',
        confidence: 0.95, method: 'error_message_detection',
        detectionMethod: 'invalid_credentials_early'
      };
    }

    if (ACCOUNT_LOCK_PHRASE_NORMALIZED && normalized.includes(ACCOUNT_LOCK_PHRASE_NORMALIZED)) {
      return {
        ok: false, type: 'account_locked', reason: 'account_lock_unlockable',
        confidence: 0.98, method: 'error_message_detection',
        detectionMethod: 'account_lock_password_reset_available',
        details: 'Account locked (too many attempts) — password reset can unlock it'
      };
    }

    for (const phrase of BLOCK_PHRASES_NORMALIZED) {
      if (normalized.includes(phrase)) {
        return { ok: false, type: 'blocked', reason: 'proxy_blocked', confidence: 1.0, retryOnDifferentProxy: true };
      }
    }

    if (SUSPICIOUS_BEHAVIOR_PHRASE_NORMALIZED && normalized.includes(SUSPICIOUS_BEHAVIOR_PHRASE_NORMALIZED)) {
      return { ok: false, type: 'blocked', reason: 'suspicious_behavior', confidence: 1.0, retryOnDifferentProxy: true };
    }

    if (BOT_CHECK_PHRASE_NORMALIZED && normalized.includes(BOT_CHECK_PHRASE_NORMALIZED)) {
      return { ok: false, type: 'captcha', reason: 'bot_verification', confidence: 1.0, retryOnDifferentProxy: true };
    }

    if (CAPTCHA_PHRASE_NORMALIZED && normalized.includes(CAPTCHA_PHRASE_NORMALIZED)) {
      return { ok: false, type: 'captcha', reason: 'bot_verification', confidence: 1.0, retryOnDifferentProxy: true };
    }
  } catch (_) {}
  return null;
}

/**
 * Optimized unified CAS detection — event-driven with early failure detection.
 * Uses page.on('response') and page.on('framenavigated') for instant success detection,
 * a 1-second TGC cookie polling interval, and a ~600ms early failure detection interval.
 *
 * @param {Page} page - Playwright page object
 * @param {string} username - Username for logging purposes
 * @param {string} password - Password for logging purposes
 * @param {object} options - Detection options
 * @returns {Promise<object>} Detection result with confidence score
 */
async function submitAndDetectCasFlowOptimized(page, username, password, options = {}) {
  const {
    casLoginPath = '/cas/login',
    accountHost = 'www.supercard.ch',
    timeoutMs = 10000,
    tgcCookieNames = ['TGC'],
    verbose = false,
    enableTGCDetection = true
  } = options;

  const detector = new CASDetector();
  const startTime = Date.now();
  const log = (msg) => verbose && console.log(`[CAS Detection Optimized] ${msg}`);

  log('Starting optimized CAS authentication detection...');

  // Reduced stabilization wait: 200ms (down from 500ms)
  await new Promise(resolve => setTimeout(resolve, 200));

  return new Promise((resolve) => {
    let resolved = false;
    let tgcInterval = null;
    let failureInterval = null;
    const listeners = [];

    // Helper to resolve only once and cleanup
    const resolveOnce = (result) => {
      if (resolved) return;
      resolved = true;
      clearTimeout(timeoutId);  // Properly clear the timeout (not via listeners array)
      listeners.forEach(({ event, handler }) => {
        try { page.off(event, handler); } catch (_) {}
      });
      if (tgcInterval) clearInterval(tgcInterval);
      if (failureInterval) clearInterval(failureInterval);
      resolve(result);
    };

    // Timeout handler — NOT pushed into listeners array, cleaned up via clearTimeout()
    const timeoutId = setTimeout(async () => {
      if (resolved) return;
      // ✅ FIX: Guard against closed page at timeout
      try {
        if (page.isClosed && page.isClosed()) {
          resolveOnce({ ok: false, type: 'timeout', reason: 'page_closed_at_timeout', confidence: 0.0, method: 'none', duration: Date.now() - startTime });
          return;
        }
      } catch (_) {
        resolveOnce({ ok: false, type: 'timeout', reason: 'page_invalid_at_timeout', confidence: 0.0, method: 'none', duration: Date.now() - startTime });
        return;
      }
      log('Timeout reached, performing final failure check...');

      const earlyFailure = await checkForEarlyFailure(page);
      if (earlyFailure) {
        log(`✗ Failure detected at timeout: ${earlyFailure.reason}`);
        resolveOnce({ ...earlyFailure, duration: Date.now() - startTime });
        return;
      }

      // ✅ FALLBACK: At timeout check whether we are on the account domain.
      // This handles the case where framenavigated DOM verification was too strict
      // (page not fully loaded yet) but authentication actually succeeded.
      try {
        const currentUrl = page.url();
        const CAS_PATH = '/cas/';
        if (currentUrl && currentUrl.includes(accountHost) && !currentUrl.includes(CAS_PATH)) {
          log('On account domain at timeout — attempting final DOM verification...');
          const isVerified = await page.evaluate(() => {
            const logoutBtn = document.querySelector('[href*="logout"], [data-action="logout"], .logout, a[href*="abmelden"]');
            const userMenu = document.querySelector('.user-menu, .account-menu, [data-user], .myAccount');
            const greetingText = document.body?.innerText?.match(/willkommen|mein konto|my account/i);
            const balanceEl = document.querySelector('.myPointBalance-value, .myMoneyBalance-value, [class*="points-balance"], [class*="money-balance"]');
            return !!(logoutBtn || userMenu || greetingText || balanceEl);
          }).catch(() => false);

          if (isVerified) {
            log(`✓ Account domain navigation VERIFIED at timeout with 85% confidence`);
            resolveOnce({
              ok: true,
              type: 'success',
              reason: 'account_domain_verified',
              confidence: 0.85,
              method: 'account_domain_verified',
              detectionMethod: 'account_domain_verified_timeout_fallback',
              details: `Verified logged-in state on ${accountHost} at detection timeout`,
              url: currentUrl,
              duration: Date.now() - startTime
            });
            return;
          }
        }
      } catch (_) {}

      log('✗ No success or failure indicator detected within timeout');
      resolveOnce({
        ok: false,
        type: 'timeout',
        reason: 'detection_timeout',
        confidence: 0.0,
        method: 'none',
        retryOnDifferentProxy: true,
        details: 'No success or failure indicator detected — may indicate slow proxy or page load issue',
        duration: Date.now() - startTime
      });
    }, timeoutMs);

    // PRIMARY DETECTION: HTTP status code + URL pattern matching via response events
    const responseHandler = async (response) => {
      if (resolved) return;
      try {
        const responseUrl = response.url();
        const status = response.status();

        // Detect DataDome / WAF blocks via HTTP status on the CAS login endpoint
        // casLoginPath is already destructured from options at the top of submitAndDetectCasFlowOptimized
        const casLoginIdentifier = casLoginPath || config.detection?.cas?.loginPath || 'login.supercard.ch/cas';
        if (casLoginIdentifier && responseUrl.includes(casLoginIdentifier) && [403, 429].includes(status)) {
          log(`✗ HTTP ${status} on CAS endpoint — DataDome/WAF block detected`);
          resolveOnce({
            ok: false, type: 'blocked', reason: 'http_' + status,
            confidence: 1.0, method: 'http_status_detection',
            detectionMethod: 'http_status_code',
            retryOnDifferentProxy: true,
            details: `HTTP ${status} on CAS endpoint — DataDome/WAF block detected`,
            duration: Date.now() - startTime
          });
          return;
        }

        // Check for OAuth code redirect
        const oauthCodeDetection = detector.detectOAuthCodeRedirect(responseUrl);
        if (oauthCodeDetection) {
          log(`✓ OAuth Code Redirect detected via response event with 99% confidence`);
          resolveOnce({
            ok: true, type: 'success', reason: 'oauth_code_redirect',
            confidence: 0.99, method: 'oauth_code_redirect',
            detectionMethod: 'oauth_code_redirect_event',
            code: oauthCodeDetection.code, url: responseUrl,
            details: `OAuth authorization code detected via event: ${oauthCodeDetection.code}`,
            duration: Date.now() - startTime
          });
          return;
        }

        // Check for CAS ticket redirect
        const ticketRedirect = detector.detectCASTicketRedirect(responseUrl);
        if (ticketRedirect) {
          log(`✓ CAS Ticket Redirect detected via response event with 95% confidence`);
          resolveOnce({
            ok: true, type: 'success', reason: 'cas_ticket_redirect',
            confidence: 0.95, method: 'cas_ticket_redirect',
            detectionMethod: 'cas_ticket_redirect_event',
            details: `CAS OAuth2.0 callbackAuthorize redirect detected via event with ticket: ${ticketRedirect.ticket}`,
            ticket: ticketRedirect.ticket, url: responseUrl,
            duration: Date.now() - startTime
          });
          return;
        }
      } catch (error) {
        log(`Response handler error: ${error.message}`);
      }
    };

    page.on('response', responseHandler);
    listeners.push({ event: 'response', handler: responseHandler });

    // SECONDARY DETECTION: Frame navigation events
    const frameNavigatedHandler = async (frame) => {
      if (resolved) return;
      try {
        const frameUrl = frame.url();

        const oauthCodeDetection = detector.detectOAuthCodeRedirect(frameUrl);
        if (oauthCodeDetection) {
          log(`✓ OAuth Code Redirect detected via frame navigation with 99% confidence`);
          resolveOnce({
            ok: true, type: 'success', reason: 'oauth_code_redirect',
            confidence: 0.99, method: 'oauth_code_redirect',
            detectionMethod: 'oauth_code_redirect_frame_event',
            code: oauthCodeDetection.code, url: frameUrl,
            details: `OAuth authorization code detected via frame event: ${oauthCodeDetection.code}`,
            duration: Date.now() - startTime
          });
          return;
        }

        const CAS_PATH = '/cas/';
        if (frameUrl.includes(accountHost) && !frameUrl.includes(CAS_PATH)) {
          try {
            const isVerified = await page.evaluate(() => {
              const logoutBtn = document.querySelector('[href*="logout"], [data-action="logout"], .logout, a[href*="abmelden"]');
              const userMenu = document.querySelector('.user-menu, .account-menu, [data-user], .myAccount');
              const greetingText = document.body?.innerText?.match(/willkommen|mein konto|my account/i);
              const balanceEl = document.querySelector('.myPointBalance-value, .myMoneyBalance-value, [class*="points-balance"], [class*="money-balance"]');
              return !!(logoutBtn || userMenu || greetingText || balanceEl);
            }).catch(() => false);

            if (isVerified) {
              log(`✓ Account domain navigation VERIFIED via frame event with 92% confidence`);
              resolveOnce({
                ok: true, type: 'success', reason: 'account_domain_verified',
                confidence: 0.92, method: 'account_domain_verified',
                detectionMethod: 'account_domain_verified_frame_event',
                details: `Verified logged-in state on ${accountHost} via frame event`,
                url: frameUrl, duration: Date.now() - startTime
              });
            }
          } catch (e) {
            log(`Frame verification error: ${e.message}`);
          }
        }
      } catch (error) {
        log(`Frame navigated handler error: ${error.message}`);
      }
    };

    page.on('framenavigated', frameNavigatedHandler);
    listeners.push({ event: 'framenavigated', handler: frameNavigatedHandler });

    // TERTIARY DETECTION: TGC cookie polling at 1-second intervals
    if (enableTGCDetection) {
      let tgcCheckInFlight = false;
      tgcInterval = setInterval(async () => {
        if (resolved || tgcCheckInFlight) return;
        // ✅ FIX: Guard against closed/invalid page
        try {
          if (page.isClosed && page.isClosed()) return;
        } catch (_) { return; }
        tgcCheckInFlight = true;
        try {
          if (typeof page.cookies === 'function') {
            const cookies = await page.cookies();
            const cookieString = cookies.map(c => `${c.name}=${c.value}`).join('; ');
            const tgcDetection = detector.detectTGCCookie(cookieString);
            if (tgcDetection) {
              const tgcCookie = cookies.find(c => tgcCookieNames.includes(c.name));
              log(`✓ TGC Cookie detected via interval with 99% confidence`);
              resolveOnce({
                ok: true, type: 'success', reason: 'tgc_cookie_detected',
                confidence: 0.99, method: 'tgc_cookie',
                detectionMethod: 'tgc_cookie_interval',
                details: `CAS Ticket Granting Cookie (TGC) detected via interval: ${tgcCookie?.name || 'TGC'}`,
                cookie: {
                  name: tgcCookie?.name || 'TGC',
                  domain: tgcCookie?.domain || '',
                  secure: tgcCookie?.secure || false,
                  valueLength: tgcCookie?.value?.length || 0
                },
                duration: Date.now() - startTime
              });
            }
          }
        } catch (error) {
          log(`TGC check error: ${error.message}`);
        } finally {
          tgcCheckInFlight = false;
        }
      }, 1000);
    }

    // EARLY FAILURE DETECTION: Poll page body for failure conditions every ~600ms
    let failureCheckInFlight = false;
    failureInterval = setInterval(async () => {
      if (resolved || failureCheckInFlight) return;
      // ✅ FIX: Guard against closed/invalid page
      try {
        if (page.isClosed && page.isClosed()) return;
      } catch (_) { return; }
      failureCheckInFlight = true;
      try {
        const earlyFailure = await checkForEarlyFailure(page);
        if (earlyFailure) {
          log(`✗ Early failure detected: ${earlyFailure.reason}`);
          resolveOnce({ ...earlyFailure, duration: Date.now() - startTime });
        }
      } finally {
        failureCheckInFlight = false;
      }
    }, 600);
  });
}

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    CASDetector,
    submitAndDetectCasFlow,
    submitAndDetectCasFlowOptimized,
    checkForEarlyFailure,
    AdaptiveDetectionTimeout: require('./adaptiveTimeout')
  };
}

// Browser environment support
if (typeof window !== 'undefined') {
  window.CASDetector = CASDetector;
  window.submitAndDetectCasFlow = submitAndDetectCasFlow;
  window.submitAndDetectCasFlowOptimized = submitAndDetectCasFlowOptimized;
}
