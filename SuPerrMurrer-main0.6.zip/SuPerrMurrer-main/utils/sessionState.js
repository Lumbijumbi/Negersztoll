/**
 * ============================================================================
 * SESSION STATE PERSISTENCE - Resume Sessions
 * ============================================================================
 * 
 * Save and restore session state for resume functionality
 */

const fs = require('fs').promises;
const path = require('path');

class SessionState {
  constructor(stateFile = '.session_state.json') {
    this.stateFile = stateFile;
  }

  /**
   * Save current session state
   */
  async save(state) {
    const data = {
      version: '1.0',
      timestamp: Date.now(),
      timestampISO: new Date().toISOString(),
      credentials: {
        total: state.total || 0,
        processed: state.processed || 0,
        remaining: state.remaining || 0
      },
      results: {
        successful: state.successful || 0,
        failed: state.failed || 0,
        blocked: state.blocked || 0,
        captcha: state.captcha || 0
      },
      queue: state.retryQueue || [],
      processedCredentials: state.processedCredentials || [],
      startTime: state.startTime || Date.now()
    };

    try {
      await fs.writeFile(
        this.stateFile,
        JSON.stringify(data, null, 2),
        'utf8'
      );
      
      return true;
    } catch (error) {
      console.error(`Failed to save session state: ${error.message}`);
      return false;
    }
  }

  /**
   * Load saved session state
   */
  async load() {
    try {
      const content = await fs.readFile(this.stateFile, 'utf8');
      const data = JSON.parse(content);
      
      // Check if state is recent (within 24 hours)
      const age = Date.now() - data.timestamp;
      const maxAge = 24 * 60 * 60 * 1000; // 24 hours
      
      if (age > maxAge) {
        console.log('Session state is too old (>24h), ignoring');
        return null;
      }

      return data;
    } catch (error) {
      if (error.code !== 'ENOENT') {
        console.error(`Failed to load session state: ${error.message}`);
      }
      return null;
    }
  }

  /**
   * Clear session state
   */
  async clear() {
    try {
      await fs.unlink(this.stateFile);
      return true;
    } catch (error) {
      if (error.code !== 'ENOENT') {
        console.error(`Failed to clear session state: ${error.message}`);
      }
      return false;
    }
  }

  /**
   * Check if session state exists
   */
  async exists() {
    try {
      await fs.access(this.stateFile);
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Get session state info without loading
   */
  async getInfo() {
    try {
      const content = await fs.readFile(this.stateFile, 'utf8');
      const data = JSON.parse(content);
      
      const age = Date.now() - data.timestamp;
      const ageHours = (age / (1000 * 60 * 60)).toFixed(1);
      
      return {
        exists: true,
        timestamp: data.timestampISO,
        ageHours,
        credentials: data.credentials,
        results: data.results
      };
    } catch {
      return {
        exists: false
      };
    }
  }
}

module.exports = SessionState;
