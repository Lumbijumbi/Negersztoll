/**
 * Project Status Tracker Utility
 * 
 * This utility helps manage updates to PROJECT_STATUS.md by providing
 * helper functions to update team assignments, milestones, and status.
 * 
 * Usage:
 *   node utils/projectTracker.js <command> [options]
 * 
 * Commands:
 *   status              - Display current project status summary
 *   update-approval     - Update stakeholder approval status
 *   assign-resource     - Assign team member to role
 *   complete-milestone  - Mark milestone as complete
 *   add-meeting-note    - Add notes from a review meeting
 *   update-setup        - Update environment setup checklist item
 */

const fs = require('fs');
const path = require('path');

// Configuration
const PROJECT_STATUS_FILE = path.join(__dirname, '..', 'PROJECT_STATUS.md');

/**
 * Escape special regex characters in a string
 */
function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Read the PROJECT_STATUS.md file
 */
function readProjectStatus() {
  try {
    return fs.readFileSync(PROJECT_STATUS_FILE, 'utf-8');
  } catch (error) {
    console.error('Error reading PROJECT_STATUS.md:', error.message);
    process.exit(1);
  }
}

/**
 * Write updated content to PROJECT_STATUS.md
 */
function writeProjectStatus(content) {
  try {
    fs.writeFileSync(PROJECT_STATUS_FILE, content, 'utf-8');
    console.log('✅ PROJECT_STATUS.md updated successfully');
  } catch (error) {
    console.error('Error writing PROJECT_STATUS.md:', error.message);
    process.exit(1);
  }
}

/**
 * Update the last updated timestamp
 */
function updateTimestamp(content) {
  const now = new Date().toISOString().split('T')[0];
  return content.replace(
    /\*\*Last Updated\*\*:.*$/m,
    `**Last Updated**: ${now}`
  );
}

/**
 * Display current project status summary
 */
function displayStatus() {
  const content = readProjectStatus();
  
  console.log('\n📊 PROJECT STATUS SUMMARY\n');
  console.log('='.repeat(60));
  
  // Extract current phase
  const phaseMatch = content.match(/\*\*Phase\*\*: (.+)/);
  if (phaseMatch) {
    console.log(`\n🎯 Current Phase: ${phaseMatch[1]}`);
  }
  
  // Count pending approvals
  const pendingApprovals = (content.match(/⏳ Pending/g) || []).length;
  console.log(`\n📋 Stakeholder Approvals: ${pendingApprovals} pending`);
  
  // Count resources to be assigned
  const resourceMatches = content.match(/\| \*\*.*?\*\* \| TBD/g) || [];
  console.log(`👥 Resources to Assign: ${resourceMatches.length}`);
  
  // Count environment setup items
  const setupPending = (content.match(/- \[ \]/g) || []).length;
  console.log(`🔧 Environment Setup Items: ${setupPending} pending`);
  
  console.log('\n' + '='.repeat(60));
  console.log('\n💡 Use other commands to update specific sections.');
  console.log('   Run with --help to see all available commands.\n');
}

/**
 * Update stakeholder approval status
 */
function updateApproval(stakeholderRole, status, date = null) {
  let content = readProjectStatus();
  
  const validStatuses = ['✅ Approved', '⏳ Pending', '🔄 In Review', '❌ Rejected', '🔴 Blocked'];
  if (!validStatuses.includes(status)) {
    console.error(`Invalid status. Must be one of: ${validStatuses.join(', ')}`);
    process.exit(1);
  }
  
  // Find the stakeholder row and update it
  const dateStr = date || new Date().toISOString().split('T')[0];
  const escapedRole = escapeRegex(stakeholderRole);
  const regex = new RegExp(
    `(\\| ${escapedRole} \\|.*?\\|) [^|]+ (\\| [^|]+ \\|)`,
    'g'
  );
  
  const newDate = status === '✅ Approved' ? dateStr : '-';
  
  content = content.replace(regex, `$1 ${status} | ${newDate} $2`);
  content = updateTimestamp(content);
  
  writeProjectStatus(content);
  console.log(`✅ Updated ${stakeholderRole} approval status to: ${status}`);
}

/**
 * Assign a team member to a role
 */
function assignResource(phase, role, teamMember, startDate = null, endDate = null) {
  let content = readProjectStatus();
  
  // Find the resource table for the specified phase and role
  const phaseRegex = new RegExp(`#### Phase ${phase}:.*?\\n\\n([\\s\\S]*?)(?=####|###|---)`);
  const phaseMatch = content.match(phaseRegex);
  
  if (!phaseMatch) {
    console.error(`Phase ${phase} not found`);
    process.exit(1);
  }
  
  // Update the TBD entry for the role
  const escapedRole = escapeRegex(role);
  const rolePattern = `(\\| \\*\\*${escapedRole}\\*\\* \\|) TBD (\\|.*?\\|) TBD (\\|) TBD (\\|)`;
  const roleRegex = new RegExp(rolePattern);
  
  const start = startDate || 'TBD';
  const end = endDate || 'TBD';
  
  content = content.replace(roleRegex, `$1 ${teamMember} $2 ${start} $3 ${end} $4`);
  content = updateTimestamp(content);
  
  writeProjectStatus(content);
  console.log(`✅ Assigned ${teamMember} to ${role} in Phase ${phase}`);
}

/**
 * Mark a milestone as complete
 */
function completeMilestone(milestoneName, actualDate = null) {
  let content = readProjectStatus();
  
  const date = actualDate || new Date().toISOString().split('T')[0];
  
  // Find milestone row and update status and date
  const escapedName = escapeRegex(milestoneName);
  const regex = new RegExp(
    `(\\| \\*\\*${escapedName}\\*\\*.*?\\|.*?\\|) ⏳ Pending (\\|) - (\\|)`,
    'g'
  );
  
  content = content.replace(regex, `$1 ✅ Complete $2 ${date} $3`);
  content = updateTimestamp(content);
  
  writeProjectStatus(content);
  console.log(`✅ Marked milestone "${milestoneName}" as complete (${date})`);
}

/**
 * Add notes from a review meeting
 */
function addMeetingNote(meetingName, outcome, actionItems) {
  let content = readProjectStatus();
  
  const date = new Date().toISOString().split('T')[0];
  
  // Find the meeting row and update outcome
  const escapedName = escapeRegex(meetingName);
  const regex = new RegExp(
    `(\\| ${escapedName} \\|) TBD (\\|.*?\\|) ⏳ [^|]+ (\\|).*?\\|`,
    'g'
  );
  
  const actionItemsList = actionItems.split(';').map(item => `- ${item.trim()}`).join('<br>');
  
  content = content.replace(regex, `$1 ${date} $2 ✅ ${outcome} $3 ${actionItemsList} |`);
  content = updateTimestamp(content);
  
  writeProjectStatus(content);
  console.log(`✅ Added notes for "${meetingName}" meeting`);
}

/**
 * Update environment setup checklist item
 */
function updateSetupItem(itemText, checked = true) {
  let content = readProjectStatus();
  
  const checkbox = checked ? '[x]' : '[ ]';
  const escapedText = escapeRegex(itemText);
  
  // Find and update the checkbox
  const regex = new RegExp(`(- )\\[ \\]( \\*\\*${escapedText}\\*\\*:)`, 'g');
  content = content.replace(regex, `$1${checkbox}$2`);
  
  content = updateTimestamp(content);
  
  writeProjectStatus(content);
  console.log(`✅ ${checked ? 'Checked' : 'Unchecked'} setup item: ${itemText}`);
}

/**
 * Display help information
 */
function displayHelp() {
  console.log(`
📊 Project Status Tracker Utility

USAGE:
  node utils/projectTracker.js <command> [options]

COMMANDS:
  status
      Display current project status summary
      
  update-approval <role> <status>
      Update stakeholder approval status
      Example: node utils/projectTracker.js update-approval "Project Owner" "✅ Approved"
      
  assign-resource <phase> <role> <name> [startDate] [endDate]
      Assign team member to a role in a specific phase
      Example: node utils/projectTracker.js assign-resource 1 "Lead Developer" "John Doe" "2026-02-01" "2026-03-15"
      
  complete-milestone <name> [date]
      Mark a milestone as complete
      Example: node utils/projectTracker.js complete-milestone "M1" "2026-03-15"
      
  add-meeting-note <meeting> <outcome> <actions>
      Add notes from a review meeting
      Example: node utils/projectTracker.js add-meeting-note "Kickoff Meeting" "Approved" "Present plan;Discuss timeline"
      
  update-setup <item> [checked]
      Update environment setup checklist item
      Example: node utils/projectTracker.js update-setup "Node.js Environment" true

EXAMPLES:
  # Display status summary
  node utils/projectTracker.js status
  
  # Approve the plan from Technical Lead
  node utils/projectTracker.js update-approval "Technical Lead" "✅ Approved"
  
  # Assign a lead developer for Phase 1
  node utils/projectTracker.js assign-resource 1 "Lead Developer" "Alice Smith" "2026-02-01"
  
  # Mark Phase 1 as complete
  node utils/projectTracker.js complete-milestone "M1" "2026-03-15"
  
  # Check off Node.js setup
  node utils/projectTracker.js update-setup "Node.js Environment" true

For more information, see PROJECT_STATUS.md
`);
}

// Main CLI handler
function main() {
  const args = process.argv.slice(2);
  
  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') {
    displayHelp();
    return;
  }
  
  const command = args[0];
  
  try {
    switch (command) {
      case 'status':
        displayStatus();
        break;
        
      case 'update-approval':
        if (args.length < 3) {
          console.error('Usage: update-approval <role> <status>');
          process.exit(1);
        }
        updateApproval(args[1], args[2], args[3]);
        break;
        
      case 'assign-resource':
        if (args.length < 4) {
          console.error('Usage: assign-resource <phase> <role> <name> [startDate] [endDate]');
          process.exit(1);
        }
        assignResource(args[1], args[2], args[3], args[4], args[5]);
        break;
        
      case 'complete-milestone':
        if (args.length < 2) {
          console.error('Usage: complete-milestone <name> [date]');
          process.exit(1);
        }
        completeMilestone(args[1], args[2]);
        break;
        
      case 'add-meeting-note':
        if (args.length < 4) {
          console.error('Usage: add-meeting-note <meeting> <outcome> <actions>');
          process.exit(1);
        }
        addMeetingNote(args[1], args[2], args[3]);
        break;
        
      case 'update-setup':
        if (args.length < 2) {
          console.error('Usage: update-setup <item> [checked]');
          process.exit(1);
        }
        const checked = args[2] !== 'false';
        updateSetupItem(args[1], checked);
        break;
        
      default:
        console.error(`Unknown command: ${command}`);
        console.log('Run with --help to see available commands');
        process.exit(1);
    }
  } catch (error) {
    console.error('Error:', error.message);
    process.exit(1);
  }
}

// Run if called directly
if (require.main === module) {
  main();
}

// Export functions for use as a module
module.exports = {
  readProjectStatus,
  writeProjectStatus,
  updateApproval,
  assignResource,
  completeMilestone,
  addMeetingNote,
  updateSetupItem,
  displayStatus
};
