/**
 * ============================================================================
 * ADVANCED LOGGING SYSTEM - Production Grade (Enhanced Phase 1)
 * ============================================================================
 * 
 * Features:
 * ✅ Colored console output
 * ✅ Structured file logging
 * ✅ Real-time progress tracking
 * ✅ Organized result storage
 * ✅ Beautiful tables and reports
 * ✅ Easy filtering and sorting
 * ✅ Confidence-based success filtering (>= 0.85)
 * ✅ CAS Ticket Redirect priority categorization
 * ✅ Phase 1 Enhancements:
 *    - Enhanced progress bars with ETA and processing rate
 *    - Visual grouping with box-drawing characters
 *    - Enhanced error messages with suggestions
 *    - Consistent icons and color coding
 */

const fs = require('fs');
const path = require('path');
const config = require('../config');
const EnhancedConsole = require('./enhancedConsole');
const { ensureDirectories } = require('./fileHelper');

// ANSI Color Codes
const Colors = {
  Reset: '\x1b[0m',
  Bright: '\x1b[1m',
  Dim: '\x1b[2m',
  Underscore: '\x1b[4m',
  
  // Foreground
  Black: '\x1b[30m',
  Red: '\x1b[31m',
  Green: '\x1b[32m',
  Yellow: '\x1b[33m',
  Blue: '\x1b[34m',
  Magenta: '\x1b[35m',
  Cyan: '\x1b[36m',
  White: '\x1b[37m',
  Gray: '\x1b[90m',
  
  // Bright Foreground
  BrightRed: '\x1b[91m',
  BrightGreen: '\x1b[92m',
  BrightYellow: '\x1b[93m',
  BrightBlue: '\x1b[94m',
  BrightMagenta: '\x1b[95m',
  BrightCyan: '\x1b[96m',
  BrightWhite: '\x1b[97m',
  
  // Background
  BgRed: '\x1b[41m',
  BgGreen: '\x1b[42m',
  BgYellow:  '\x1b[43m',
  BgBlue: '\x1b[44m',
};

class AdvancedLogger {
  constructor(options = {}) {
    this.logDir = options.logDir || path.join(process.cwd(), 'logs');
    this.level = options.level || 'info';
    this.levels = { debug: 0, info: 1, warn: 2, error: 3 };
    this.currentLevel = this.levels[this.level];
    
    // ⚡ PERFORMANCE: Configurable pretty-printing (compact by default for performance)
    this.prettyPrint = options.prettyPrint !== undefined ? options.prettyPrint : false;
    
    // Initialize Enhanced Console (Phase 1 enhancement)
    this.console = new EnhancedConsole({
      verbose: options.verbose !== false,
      useColors: options.useColors !== false,
      useIcons: options.useIcons !== false
    });
    
    // Create logs directory
    this.ensureLogDir();
    
    // ⚡ PERFORMANCE OPTIMIZATION: Buffered writes instead of unbounded arrays
    this.bufferSize = options.bufferSize || 100;
    this.flushInterval = options.flushInterval || 5000; // 5 seconds
    this.writeBuffers = {
      successful: [],
      failed: [],
      blocked: [],
      captcha: [],
      errors: []
    };
    
    // ⚡ PERFORMANCE: Keep limited results for reporting (prevent unbounded growth)
    this.maxResultsInMemory = options.maxResultsInMemory || 1000;
    this.results = {
      successful: [],
      failed: [],
      blocked: [],
      captcha: [],
      errors: []
    };
    
    // Cache daily filenames to avoid repeated date parsing
    this.cachedFilenames = {
      successful: null,
      failed: null,
      blocked: null,
      captcha: null,
      errors: null,
      date: null
    };
    
    // Start auto-flush timer (async safe)
    this.flushTimer = setInterval(() => {
      this.flushAllBuffers().catch(err => {
        console.error('[LOG] Auto-flush error:', err.message);
      });
    }, this.flushInterval);
    
    this.stats = {
      totalProcessed: 0,
      successful: 0,
      failed: 0,
      blocked: 0,
      captcha: 0,
      oauthCodeRedirect: 0,
      casTicketRedirect: 0,
      tgcSuccess: 0,
      redirect302Success: 0,
      otherSuccess: 0,
      startTime: Date.now()
    };
    
    // Track active progress bars
    this.activeProgressBars = new Map();
  }

  ensureLogDir() {
    const dirs = [
      this.logDir,
      path.join(this.logDir, 'successful'),
      path.join(this.logDir, 'failed'),
      path.join(this.logDir, 'blocked'),
      path.join(this.logDir, 'captcha'),
      path.join(this.logDir, 'reports'),
      path.join(this.logDir, 'errors')
    ];

    ensureDirectories(dirs);
  }

  /**
   * ⚡ PERFORMANCE: Cleanup and flush all buffers on shutdown (async)
   */
  async cleanup() {
    if (this.flushTimer) {
      clearInterval(this.flushTimer);
      this.flushTimer = null;
    }
    await this.flushAllBuffers();
  }

  /**
   * ⚡ PERFORMANCE: Synchronous cleanup for process exit handlers
   * Uses sync I/O as a fallback when async is not available
   */
  cleanupSync() {
    if (this.flushTimer) {
      clearInterval(this.flushTimer);
      this.flushTimer = null;
    }
    
    // Flush all buffers synchronously for process exit
    for (const type of ['successful', 'failed', 'blocked', 'captcha', 'errors']) {
      const buffer = this.writeBuffers[type];
      if (buffer.length === 0) continue;

      const typeToDir = {
        successful: 'successful',
        failed: 'failed',
        blocked: 'blocked',
        captcha: 'captcha',
        errors: 'errors'
      };

      const dir = path.join(this.logDir, typeToDir[type]);
      const filename = this.getCachedFilename(type);
      const filepath = path.join(dir, filename);

      try {
        const lines = buffer.map(entry => JSON.stringify(entry)).join('\n') + '\n';
        fs.appendFileSync(filepath, lines, 'utf8');
        this.writeBuffers[type] = [];
      } catch (e) {
        console.error(`[LOG] Failed to flush ${type} buffer: ${e.message}`);
      }
    }
  }

  // ============ CONSOLE LOGGING ============

  log(level, prefix, message, data = null) {
    if (this.levels[level] < this.currentLevel) return;

    const timestamp = new Date().toISOString();
    const levelColors = {
      debug: Colors.Dim + Colors.Gray,
      info: Colors.BrightCyan,
      warn: Colors.BrightYellow,
      error: Colors.BrightRed,
      success: Colors.BrightGreen
    };

    const color = levelColors[level] || Colors.Reset;
    const levelStr = level.toUpperCase().padEnd(7);
    
    let output = `${Colors.Gray}[${timestamp}]${Colors.Reset} ${color}${levelStr}${Colors.Reset} ${prefix} ${message}${Colors.Reset}`;
    
    console.log(output);

    // ⚡ PERFORMANCE: Configurable pretty-printing (compact by default for performance)
    if (data) {
      const jsonStr = this.prettyPrint 
        ? JSON.stringify(data, null, 2) 
        : JSON.stringify(data);
      console.log(`${Colors.Gray}${jsonStr}${Colors.Reset}`);
    }
  }

  debug(prefix, message, data) { this.log('debug', prefix, message, data); }
  info(prefix, message, data) { this.log('info', prefix, message, data); }
  warn(prefix, message, data) { this.log('warn', prefix, message, data); }
  error(prefix, message, data) { this.log('error', prefix, message, data); }
  success(prefix, message, data) { this.log('success', prefix, message, data); }

  // ============ PROGRESS BAR ============

  progressBar(current, total, prefix = '', barLength = 40) {
    const percent = (current / total) * 100;
    const filled = Math.round((barLength * current) / total);
    const empty = barLength - filled;
    
    const bar = `${'█'.repeat(filled)}${'░'.repeat(empty)}`;
    const status = `${current.toString().padStart(String(total).length)}/${total}`;
    
    process.stdout.write(
      `\r${Colors.BrightCyan}${prefix}${Colors.Reset} [${bar}] ${percent.toFixed(1).padStart(5)}% ${status}`
    );
  }

  clearProgressBar() {
    process.stdout.write('\r' + ' '.repeat(120) + '\r');
  }

  // ============ ENHANCED PROGRESS BARS (Phase 1) ============

  /**
   * Create an enhanced progress bar with ETA and processing rate
   * @param {string} name - Unique name for the progress bar
   * @param {number} total - Total number of items to process
   * @param {object} options - Progress bar options
   * @returns {string} Progress bar name
   */
  createEnhancedProgressBar(name, total, options = {}) {
    const barName = this.console.createProgressBar(name, total, options);
    this.activeProgressBars.set(name, { name: barName, total, current: 0 });
    return barName;
  }

  /**
   * Update enhanced progress bar
   * @param {string} name - Progress bar name
   * @param {number} current - Current progress
   * @param {object} stats - Statistics (successCount, failureCount, etc.)
   */
  updateEnhancedProgressBar(name, current, stats = {}) {
    const progressInfo = this.activeProgressBars.get(name);
    if (progressInfo) {
      this.console.updateProgressBar(name, current, stats);
      progressInfo.current = current;
    }
  }

  /**
   * Stop enhanced progress bar and display final stats
   * @param {string} name - Progress bar name
   * @param {object} finalStats - Final statistics
   */
  stopEnhancedProgressBar(name, finalStats = {}) {
    this.console.stopProgressBar(name, finalStats);
    this.activeProgressBars.delete(name);
  }

  // ============ RESULT TRACKING ============

  /**
   * ⚡ PERFORMANCE: Add to results array with bounded size
   * Keeps only the most recent N results to prevent unbounded memory growth
   */
  addToResults(type, entry) {
    this.results[type].push(entry);
    
    // Trim array if it exceeds max size (keep most recent)
    if (this.results[type].length > this.maxResultsInMemory) {
      this.results[type] = this.results[type].slice(-this.maxResultsInMemory);
    }
  }

  // ============ RESULT LOGGING ============

  logSuccess(username, password, method, confidence, duration, pointsBalance = null, moneyBalance = null) {
    // ⭐ FILTER:   Only log if confidence >= minimum threshold
    const minConfidence = config.detection.minimumSuccessConfidence || 0.85;

    if (confidence < minConfidence) {
      this.warn('[FILTER]', `Skipped low-confidence result: ${method} (${(confidence * 100).toFixed(0)}%)`);
      return;
    }

    const entry = {
      timestamp: new Date().toISOString(),
      username,
      password,
      method,
      confidence,
      duration,
      category: this.categorizeSuccess(method)
    };

    // Add balance values if provided
    if (pointsBalance !== null) {
      entry.pointsBalance = pointsBalance;
    }
    if (moneyBalance !== null) {
      entry.moneyBalance = moneyBalance;
    }

    // ⚡ PERFORMANCE: Add to results with size limit (keep only recent results)
    this.addToResults('successful', entry);
    this.stats.successful++;
    this.stats.totalProcessed++;

    // ⭐ Track by method (OAuth Code Redirect PRIORITY)
    if (method === 'oauth_code_redirect') {
      this.stats.oauthCodeRedirect++;
    } else if (method === 'cas_ticket_redirect') {
      this.stats.casTicketRedirect++;
    } else if (method === 'tgc_cookie') {
      this.stats.tgcSuccess++;
    } else if (method.includes('redirect') || method.includes('302') || method.includes('oidc')) {
      this.stats.redirect302Success++;
    } else {
      this.stats.otherSuccess++;
    }

    this.writeSuccessFile(entry);
    this.success('[SUCCESS]', `${username} - ${method} (${(confidence * 100).toFixed(0)}%)`);
  }

  logFailed(username, password, reason, details = '') {
    const entry = {
      timestamp: new Date().toISOString(),
      username,
      password,
      reason,
      details
    };

    // ⚡ PERFORMANCE: Use bounded results array
    this.addToResults('failed', entry);
    this.stats.failed++;
    this.stats.totalProcessed++;

    this.writeFailedFile(entry);
    this.warn('[FAILED]', `${username} - ${reason}`, details ? { details } : null);
  }

  logBlocked(username, password, reason, batchNum = 0) {
    const entry = {
      timestamp: new Date().toISOString(),
      username,
      password,
      reason,
      batchNum
    };

    // ⚡ PERFORMANCE: Use bounded results array
    this.addToResults('blocked', entry);
    this.stats.blocked++;
    this.stats.totalProcessed++;

    this.writeBlockedFile(entry);
    this.error('[BLOCKED]', `${username} - ${reason}`);
  }

  logCaptcha(username, password, version = 'v2', batchNum = 0) {
    const entry = {
      timestamp: new Date().toISOString(),
      username,
      password,
      version,
      batchNum
    };

    // ⚡ PERFORMANCE: Use bounded results array
    this.addToResults('captcha', entry);
    this.stats.captcha++;
    this.stats.totalProcessed++;

    this.writeCaptchaFile(entry);
    this.warn('[CAPTCHA]', `${username} - reCAPTCHA ${version}`);
  }

  logError(username, password, error, context = '') {
    const entry = {
      timestamp: new Date().toISOString(),
      username,
      password,
      error: error.message,
      stack: error.stack,
      context
    };

    // ⚡ PERFORMANCE: Use bounded results array
    this.addToResults('errors', entry);
    this.stats.totalProcessed++;

    this.writeErrorFile(entry);
    this.error('[ERROR]', `${username} - ${error.message}`);
  }

  // ============ FILE WRITING (BUFFERED & OPTIMIZED) ============

  /**
   * ⚡ PERFORMANCE: Get cached filename or generate new one (reduces date parsing)
   */
  getCachedFilename(type, prefix) {
    const today = new Date().toISOString().split('T')[0];
    
    // Check if we need to update cache (new day or first call)
    if (this.cachedFilenames.date !== today) {
      this.cachedFilenames.date = today;
      this.cachedFilenames.successful = `successes_${today}.jsonl`;
      this.cachedFilenames.failed = `failures_${today}.jsonl`;
      this.cachedFilenames.blocked = `blocked_${today}.jsonl`;
      this.cachedFilenames.captcha = `captchas_${today}.jsonl`;
      this.cachedFilenames.errors = `errors_${today}.jsonl`;
    }
    
    return this.cachedFilenames[type];
  }

  /**
   * ⚡ PERFORMANCE: Buffered write - adds to buffer and flushes when full
   */
  addToBuffer(type, entry) {
    this.writeBuffers[type].push(entry);
    
    // Flush buffer if it reaches the threshold
    if (this.writeBuffers[type].length >= this.bufferSize) {
      this.flushBuffer(type);
    }
  }

  /**
   * ⚡ PERFORMANCE: Flush a specific buffer to disk (async)
   */
  async flushBuffer(type) {
    const buffer = this.writeBuffers[type];
    if (buffer.length === 0) return;

    const typeToDir = {
      successful: 'successful',
      failed: 'failed',
      blocked: 'blocked',
      captcha: 'captcha',
      errors: 'errors'
    };

    const dir = path.join(this.logDir, typeToDir[type]);
    const filename = this.getCachedFilename(type);
    const filepath = path.join(dir, filename);

    try {
      // Batch all entries into a single write operation
      const lines = buffer.map(entry => JSON.stringify(entry)).join('\n') + '\n';
      
      // Use async write to avoid blocking event loop
      await fs.promises.appendFile(filepath, lines, 'utf8');
      
      // Clear the buffer after successful write
      this.writeBuffers[type] = [];
    } catch (e) {
      // Log error but don't throw to avoid crashing
      console.error(`[LOG] Failed to flush ${type} buffer: ${e.message}`);
    }
  }

  /**
   * ⚡ PERFORMANCE: Flush all buffers to disk (async)
   */
  async flushAllBuffers() {
    await Promise.all([
      this.flushBuffer('successful'),
      this.flushBuffer('failed'),
      this.flushBuffer('blocked'),
      this.flushBuffer('captcha'),
      this.flushBuffer('errors')
    ]);
  }

  writeSuccessFile(entry) {
    this.addToBuffer('successful', entry);
  }

  writeFailedFile(entry) {
    this.addToBuffer('failed', entry);
  }

  writeBlockedFile(entry) {
    this.addToBuffer('blocked', entry);
  }

  writeCaptchaFile(entry) {
    this.addToBuffer('captcha', entry);
  }

  writeErrorFile(entry) {
    this.addToBuffer('errors', entry);
  }

  // ============ CATEGORIZATION ============

  categorizeSuccess(method) {
    // ⭐ OAuth Code Redirect PRIORITY - Map methods to categories
    const highConfidenceMap = {
      'oauth_code_redirect': 'OAUTH_CODE_REDIRECT',
      'cas_ticket_redirect': 'CAS_TICKET_REDIRECT',
      'tgc_cookie': 'TGC_COOKIE',
      'oidc_authorize_redirect': 'REDIRECT_OIDC',
      'set_cookie': 'SET_COOKIE',
      'body_token': 'BODY_TOKEN'
    };

    return highConfidenceMap[method] || 'OTHER';
  }

  // ============ REPORTS ============

  generateSummaryReport() {
    const elapsed = (Date.now() - this.stats.startTime) / 1000;
    const minutes = (elapsed / 60).toFixed(2);
    const rate = (this.stats.totalProcessed / minutes).toFixed(2);
    const successRate = this.stats.totalProcessed > 0
      ? ((this.stats.successful / this.stats.totalProcessed) * 100).toFixed(2)
      : 0;
    const tgcRate = this.stats.successful > 0
      ? ((this.stats.tgcSuccess / this.stats.successful) * 100).toFixed(2)
      : 0;
    const redirect302Rate = this.stats.successful > 0
      ? ((this.stats.redirect302Success / this.stats.successful) * 100).toFixed(2)
      : 0;

    const report = `
${Colors.BrightCyan}╔════════════════════════════════════════════════════════════════╗${Colors.Reset}
${Colors.BrightCyan}║                   TESTING SUMMARY REPORT                        ║${Colors.Reset}
${Colors.BrightCyan}╠════════════════════════════════════════════════════════════════╣${Colors.Reset}
${Colors.BrightGreen}║ ✅ SUCCESSFUL LOGINS (>= 85% confidence): ${this.stats.successful.toString().padEnd(25)}║${Colors.Reset}
${Colors.BrightGreen}║    ├─ 🔑 TGC Cookie:  ${this.stats.tgcSuccess.toString().padEnd(43)}║${Colors.Reset}
${Colors.BrightGreen}║    ├─ 🔄 Redirect 302: ${this.stats.redirect302Success.toString().padEnd(40)}║${Colors.Reset}
${Colors.BrightGreen}║    └─ 📝 Other: ${(this.stats.successful - this.stats.tgcSuccess - this.stats.redirect302Success).toString().padEnd(46)}║${Colors.Reset}
${Colors.BrightRed}║ ❌ FAILED LOGINS:  ${(this.stats.totalProcessed - this.stats.successful - this.stats.blocked - this.stats.captcha).toString().padEnd(38)}║${Colors.Reset}
${Colors.BrightRed}║ 🚫 BLOCKED:  ${this.stats.blocked.toString().padEnd(49)}║${Colors.Reset}
${Colors.BrightYellow}║ ⚠️  CAPTCHA DETECTED: ${this.stats.captcha.toString().padEnd(40)}║${Colors.Reset}
${Colors.Cyan}║────────────────────────────────────────────────────────────────║${Colors.Reset}
${Colors.White}║ Total Processed: ${this.stats.totalProcessed.toString().padEnd(43)}║${Colors.Reset}
${Colors.White}║ Success Rate: ${successRate.padEnd(48)}%║${Colors.Reset}
${Colors.White}║ TGC Rate: ${tgcRate.padEnd(52)}%║${Colors.Reset}
${Colors.White}║ Processing Rate: ${rate.padEnd(47)}creds/min║${Colors.Reset}
${Colors.White}║ Elapsed Time: ${elapsed.toFixed(1).padEnd(48)}s║${Colors.Reset}
${Colors.BrightCyan}╚════════════════════════════════════════════════════════════════╝${Colors.Reset}
    `;

    return report;
  }

  generateDetailedReport() {
    const report = `
${Colors.BrightCyan}═══════════════════════════════════════════════════════════════${Colors.Reset}
${Colors.BrightGreen}SUCCESSFUL LOGINS BY METHOD${Colors.Reset}
${Colors.BrightCyan}═══════════════════════════════════════════════════════════════${Colors.Reset}

${Colors.BrightGreen}🔑 TGC COOKIE DETECTIONS (Highest Confidence - 99%):${Colors.Reset}
${this.formatSuccessList(this.results.successful.filter(r => r.method === 'tgc_cookie'))}

${Colors.BrightGreen}🔄 REDIRECT 302 DETECTIONS (99% Confidence):${Colors.Reset}
${this.formatSuccessList(this.results.successful.filter(r => r.method.includes('302') || r.method.includes('redirect')))}

${Colors.BrightGreen}📝 OTHER SUCCESSFUL METHODS (85-95% Confidence):${Colors.Reset}
${this.formatSuccessList(this.results.successful.filter(r => r.method !== 'tgc_cookie' && !r.method.includes('302')))}

${Colors.BrightRed}═══════════════════════════════════════════════════════════════${Colors.Reset}
${Colors.BrightRed}FAILED LOGINS${Colors.Reset}
${Colors.BrightCyan}═══════════════════════════════════════════════════════════════${Colors.Reset}

${this.formatFailureList()}

${Colors.BrightYellow}═══════════════════════════════════════════════════════════════${Colors.Reset}
${Colors.BrightYellow}BLOCKED / CAPTCHA DETECTIONS${Colors.Reset}
${Colors.BrightCyan}═══════════════════════════════════════════════════════════════${Colors.Reset}

${Colors.BrightRed}🚫 Blocked:    ${this.stats.blocked}${Colors.Reset}
${Colors.BrightYellow}⚠️  CAPTCHAs: ${this.stats.captcha}${Colors.Reset}
    `;

    return report;
  }

  formatSuccessList(entries) {
    if (entries.length === 0) {
      return `${Colors.Gray}  (None)${Colors.Reset}`;
    }

    return entries
      .slice(0, 10)
      .map((e, i) => {
        const conf = (e.confidence * 100).toFixed(0);
        return `  ${i + 1}. ${Colors.Green}${e.username}${Colors.Reset} - ${conf}% confidence - ${e.duration}ms`;
      })
      .join('\n') + (entries.length > 10 ?  `\n  ${Colors.Gray}...   and ${entries.length - 10} more${Colors.Reset}` : '');
  }

  formatFailureList() {
    if (this.results.failed.length === 0) {
      return `${Colors.Gray}  (None)${Colors.Reset}`;
    }

    const byReason = {};
    for (const entry of this.results.failed) {
      byReason[entry.reason] = (byReason[entry.reason] || 0) + 1;
    }

    return Object.entries(byReason)
      .map(([reason, count]) => {
        return `  ${Colors.Red}${reason}${Colors.Reset}:  ${count}`;
      })
      .join('\n');
  }

  // ============ EXPORT DATA ============

  exportResults(format = 'json') {
    const reportDir = path.join(this.logDir, 'reports');
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');

    if (format === 'json') {
      const filename = path.join(reportDir, `results_${timestamp}.json`);
      const data = {
        timestamp:  new Date().toISOString(),
        stats: this.stats,
        results: this.results
      };

      try {
        fs.writeFileSync(filename, JSON.stringify(data, null, 2), 'utf8');
        this.info('[EXPORT]', `Results exported to ${filename}`);
      } catch (e) {
        this.error('[EXPORT]', `Failed to export results: ${e.message}`);
      }
    }

    if (format === 'csv') {
      this.exportCSV();
    }
  }

  exportCSV() {
    const reportDir = path.join(this.logDir, 'reports');
    const timestamp = new Date().toISOString().split('T')[0];

    // Successful CSV
    const successFilename = path.join(reportDir, `successful_${timestamp}.csv`);
    const successCSV = [
      'Timestamp,Username,Password,Method,Confidence,Duration_ms,Category',
      ...this.results.successful.map(r =>
        `${r.timestamp},"${r.username}","${r.password}",${r.method},${r. confidence},${r.duration},${r. category}`
      )
    ].join('\n');

    try {
      fs.writeFileSync(successFilename, successCSV, 'utf8');
      this.info('[EXPORT]', `Successful credentials exported to ${successFilename}`);
    } catch (e) {
      this.error('[EXPORT]', `Failed to export CSV: ${e.message}`);
    }

    // Failed CSV
    const failedFilename = path.join(reportDir, `failed_${timestamp}.csv`);
    const failedCSV = [
      'Timestamp,Username,Password,Reason,Details',
      ...this.results.failed.map(r =>
        `${r.timestamp},"${r.username}","${r.password}",${r.reason},"${r.details}"`
      )
    ].join('\n');

    try {
      fs.writeFileSync(failedFilename, failedCSV, 'utf8');
      this.info('[EXPORT]', `Failed credentials exported to ${failedFilename}`);
    } catch (e) {
      this.error('[EXPORT]', `Failed to export CSV: ${e.message}`);
    }
  }

  printReport() {
    this.clearProgressBar();
    console.log(this.generateSummaryReport());
    console.log(this.generateDetailedReport());
    this.exportResults('json');
    this.exportResults('csv');
  }

  // ============ ENHANCED VISUAL METHODS (Phase 1) ============

  /**
   * Display a visual header
   */
  header(text, options = {}) {
    this.console.header(text, options);
  }

  /**
   * Display content in a box
   */
  section(title, content, options = {}) {
    this.console.section(title, content, options);
  }

  /**
   * Display separator line
   */
  separator(length, char, color) {
    this.console.separator(length, char, color);
  }

  /**
   * Display enhanced error with suggestions
   */
  enhancedError(errorInfo) {
    this.console.enhancedError(errorInfo);
  }

  /**
   * Display a table
   */
  table(headers, rows, options = {}) {
    this.console.table(headers, rows, options);
  }

  /**
   * Create a spinner for long operations
   */
  spinner(text, options = {}) {
    return this.console.spinner(text, options);
  }

  /**
   * Format duration
   */
  formatDuration(ms) {
    return this.console.formatDuration(ms);
  }

  /**
   * Display enhanced summary report using new visual elements
   */
  printEnhancedReport() {
    this.clearProgressBar();
    
    // Header
    this.header('TESTING SUMMARY REPORT', { color: 'cyan', char: '═' });
    this.console.spacing(1);

    // Statistics table
    const elapsed = (Date.now() - this.stats.startTime) / 1000;
    const minutes = (elapsed / 60).toFixed(2);
    const rate = (this.stats.totalProcessed / minutes).toFixed(2);
    const successRate = this.stats.totalProcessed > 0
      ? ((this.stats.successful / this.stats.totalProcessed) * 100).toFixed(2)
      : '0';

    const headers = ['Metric', 'Value'];
    const rows = [
      ['Total Processed', this.stats.totalProcessed],
      ['✓ Successful', `${this.stats.successful} (${successRate}%)`],
      ['✗ Failed', this.stats.totalProcessed - this.stats.successful - this.stats.blocked - this.stats.captcha],
      ['🚫 Blocked', this.stats.blocked],
      ['🔐 Captcha', this.stats.captcha],
      ['Processing Rate', `${rate} creds/min`],
      ['Elapsed Time', `${elapsed.toFixed(1)}s`]
    ];

    this.table(headers, rows, { headerColor: 'cyan' });
    this.console.spacing(1);

    // Success breakdown
    if (this.stats.successful > 0) {
      this.section('Success Breakdown', [
        `🔑 TGC Cookie: ${this.stats.tgcSuccess}`,
        `🎫 CAS Ticket Redirect: ${this.stats.casTicketRedirect}`,
        `🔄 Redirect 302: ${this.stats.redirect302Success}`,
        `📝 Other: ${this.stats.otherSuccess}`
      ].join('\n'), { borderColor: 'green' });
      this.console.spacing(1);
    }

    // Export results
    this.exportResults('json');
    this.exportResults('csv');

    this.console.success(`Report generated successfully - Check logs directory for details`);
  }
}


module.exports = AdvancedLogger;