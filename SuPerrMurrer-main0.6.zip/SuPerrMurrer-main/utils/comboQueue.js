/**
 * ============================================================================
 * COMBO QUEUE / BACKLOG SYSTEM
 * ============================================================================
 * 
 * Manages a persistent queue/backlog of combo .txt files with:
 * ✅ File management (add, remove, track metadata)
 * ✅ De-duplication (cross-file and against history)
 * ✅ Queue options (randomize, priority, listDelay)
 * ✅ Pause/Resume functionality
 * ✅ Persistence to combo_queue.json
 */

const fs = require('fs');
const path = require('path');
const { readTextFile, writeJSONFileAtomic, readJSONFile } = require('./fileHelper');

class ComboQueue {
  constructor(options = {}) {
    this.queueFile = options.queueFile || 'combo_queue.json';
    this.historyInstance = options.historyInstance || null;
    this.randomize = options.randomize !== undefined ? options.randomize : false;
    this.listDelay = options.listDelay || 0;
    this.listDelayJitter = options.listDelayJitter || 0;
    this.autoFeed = options.autoFeed !== undefined ? options.autoFeed : true;
    this.deduplication = options.deduplication || {
      enabled: true,
      crossFile: true,
      againstHistory: true,
      caseSensitive: false
    };
    this.defaultPriority = options.defaultPriority || 3;
    this.maxQueueSize = options.maxQueueSize || 0; // 0 = unlimited

    // Queue state
    this.files = []; // Array of file metadata objects
    this.combos = new Map(); // Map of "username\tpassword" -> { username, password, source, priority }
    this.paused = false;
    this.stats = {
      totalFilesAdded: 0,
      totalCombosAdded: 0,
      totalDuplicatesRemoved: 0,
      totalAlreadyProcessed: 0,
      totalProcessed: 0
    };

    // Ensure queue file path is absolute
    if (!path.isAbsolute(this.queueFile)) {
      this.queueFile = path.join(process.cwd(), this.queueFile);
    }

    // Load existing queue on instantiation
    this.load();
  }

  /**
   * Generate key for Map storage (tab-separated)
   */
  _key(username, password) {
    if (this.deduplication.caseSensitive) {
      return `${username}\t${password}`;
    } else {
      // Case-insensitive: lowercase both username and password for consistent deduplication
      return `${username.toLowerCase()}\t${password.toLowerCase()}`;
    }
  }

  /**
   * Check if a combo exists in queue
   */
  _hasCombo(username, password) {
    const key = this._key(username, password);
    return this.combos.has(key);
  }

  /**
   * Check if a combo was already processed (via history)
   */
  _wasProcessed(username, password) {
    if (!this.deduplication.enabled || !this.deduplication.againstHistory || !this.historyInstance) {
      return false;
    }
    const result = this.historyInstance.shouldSkip(username, password);
    return result.skip || false;
  }

  /**
   * Parse a combo line into username/password
   */
  _parseComboLine(line) {
    const trimmed = line.trim();
    if (!trimmed || !trimmed.includes(':')) {
      return null;
    }

    const colonIndex = trimmed.indexOf(':');
    const username = trimmed.substring(0, colonIndex).trim();
    const password = trimmed.substring(colonIndex + 1).trim();

    if (!username || !password) {
      return null;
    }

    return { username, password };
  }

  /**
   * Add a .txt file to the queue
   * @param {string} filepath - Path to combo file
   * @param {object} options - { priority: 1-5 }
   * @returns {object} { added, duplicatesRemoved, alreadyProcessed, queued }
   */
  addFile(filepath, options = {}) {
    const priority = options.priority || this.defaultPriority;

    // Validate priority
    if (priority < 1 || priority > 5) {
      throw new Error('Priority must be between 1 and 5');
    }

    // Check if file exists
    if (!fs.existsSync(filepath)) {
      throw new Error(`File not found: ${filepath}`);
    }

    // Read file
    const content = readTextFile(filepath);
    if (!content) {
      throw new Error(`Failed to read file: ${filepath}`);
    }
    const lines = content.split('\n').filter(line => line.trim());

    const filename = path.basename(filepath);
    return this._addCombosInternal(lines, filename, priority);
  }

  /**
   * Add raw combo lines (for GUI paste-in)
   * @param {array} lines - Array of combo lines
   * @param {string} sourceName - Name/identifier for this batch
   * @param {object} options - { priority: 1-5 }
   * @returns {object} { added, duplicatesRemoved, alreadyProcessed, queued }
   */
  addCombos(lines, sourceName, options = {}) {
    const priority = options.priority || this.defaultPriority;

    // Validate priority
    if (priority < 1 || priority > 5) {
      throw new Error('Priority must be between 1 and 5');
    }

    return this._addCombosInternal(lines, sourceName, priority);
  }

  /**
   * Internal method to add combos from lines
   */
  _addCombosInternal(lines, sourceName, priority) {
    const stats = {
      added: 0,
      duplicatesRemoved: 0,
      alreadyProcessed: 0,
      queued: 0
    };

    const newCombos = [];

    // Parse and deduplicate
    for (const line of lines) {
      const parsed = this._parseComboLine(line);
      if (!parsed) continue;

      stats.added++;

      const { username, password } = parsed;

      // Check against history first
      if (this._wasProcessed(username, password)) {
        stats.alreadyProcessed++;
        continue;
      }

      // Check for duplicates in queue
      if (this._hasCombo(username, password)) {
        stats.duplicatesRemoved++;
        continue;
      }

      newCombos.push({ username, password, source: sourceName, priority });
    }

    // Check max queue size
    if (this.maxQueueSize > 0 && (this.combos.size + newCombos.length) > this.maxQueueSize) {
      throw new Error(`Queue size limit exceeded. Max: ${this.maxQueueSize}, Current: ${this.combos.size}, Adding: ${newCombos.length}`);
    }

    // Add to queue
    for (const combo of newCombos) {
      const key = this._key(combo.username, combo.password);
      this.combos.set(key, combo);
      stats.queued++;
    }

    // Update or add file metadata
    const existingFileIndex = this.files.findIndex(f => f.filename === sourceName);
    if (existingFileIndex >= 0) {
      // Update existing file
      this.files[existingFileIndex].lineCount += stats.added;
      this.files[existingFileIndex].queuedCount += stats.queued;
      this.files[existingFileIndex].priority = priority;
    } else {
      // Add new file
      this.files.push({
        filename: sourceName,
        addedAt: new Date().toISOString(),
        lineCount: stats.added,
        queuedCount: stats.queued,
        processedCount: 0,
        status: 'pending',
        priority: priority
      });
      this.stats.totalFilesAdded++;
    }

    // Update global stats
    this.stats.totalCombosAdded += stats.added;
    this.stats.totalDuplicatesRemoved += stats.duplicatesRemoved;
    this.stats.totalAlreadyProcessed += stats.alreadyProcessed;

    // Save queue
    this.save();

    return stats;
  }

  /**
   * Get next batch of credentials to process
   * @param {number} batchSize - Number of credentials to return
   * @returns {array} Array of {username, password, source}
   */
  getNextBatch(batchSize) {
    if (this.paused) {
      return [];
    }

    const batch = [];
    const comboArray = Array.from(this.combos.values());

    // Sort by priority (1 = highest priority)
    comboArray.sort((a, b) => a.priority - b.priority);

    // Take batch
    for (let i = 0; i < Math.min(batchSize, comboArray.length); i++) {
      batch.push(comboArray[i]);
    }

    return batch;
  }

  /**
   * Mark a combo as processed and remove from queue
   * @param {string} username
   * @param {string} password
   */
  markProcessed(username, password) {
    const key = this._key(username, password);
    const combo = this.combos.get(key);
    
    if (combo) {
      // Update file metadata
      const fileIndex = this.files.findIndex(f => f.filename === combo.source);
      if (fileIndex >= 0) {
        this.files[fileIndex].processedCount++;
        this.files[fileIndex].queuedCount--;
        
        // Update status
        if (this.files[fileIndex].queuedCount === 0) {
          this.files[fileIndex].status = 'completed';
        } else if (this.files[fileIndex].processedCount > 0) {
          this.files[fileIndex].status = 'processing';
        }
      }

      // Remove from queue
      this.combos.delete(key);
      this.stats.totalProcessed++;

      // Save
      this.save();
    }
  }

  /**
   * Get queue status/stats
   * @returns {object} Stats object
   */
  getStats() {
    const pending = this.files.filter(f => f.status === 'pending').length;
    const processing = this.files.filter(f => f.status === 'processing').length;
    const completed = this.files.filter(f => f.status === 'completed').length;

    return {
      totalFiles: this.files.length,
      totalCombos: this.combos.size,
      pending,
      processing,
      completed,
      duplicatesRemoved: this.stats.totalDuplicatesRemoved,
      alreadyProcessed: this.stats.totalAlreadyProcessed,
      totalProcessed: this.stats.totalProcessed,
      paused: this.paused
    };
  }

  /**
   * Get all queued files with metadata
   * @returns {array} Array of file objects
   */
  getFiles() {
    // Sort by priority, then by addedAt
    return [...this.files].sort((a, b) => {
      if (a.priority !== b.priority) {
        return a.priority - b.priority;
      }
      return new Date(a.addedAt) - new Date(b.addedAt);
    });
  }

  /**
   * Remove a file from queue
   * @param {string} filename
   * @returns {boolean} True if removed, false if not found
   */
  removeFile(filename) {
    const fileIndex = this.files.findIndex(f => f.filename === filename);
    if (fileIndex < 0) {
      return false;
    }

    // Remove all combos from this file
    const file = this.files[fileIndex];
    const toRemove = [];
    
    for (const [key, combo] of this.combos.entries()) {
      if (combo.source === filename) {
        toRemove.push(key);
      }
    }

    for (const key of toRemove) {
      this.combos.delete(key);
    }

    // Remove file metadata
    this.files.splice(fileIndex, 1);

    // Save
    this.save();

    return true;
  }

  /**
   * Reorder / set priority
   * @param {string} filename
   * @param {number} priority - 1-5
   * @returns {boolean} True if updated, false if not found
   */
  setPriority(filename, priority) {
    if (priority < 1 || priority > 5) {
      throw new Error('Priority must be between 1 and 5');
    }

    const fileIndex = this.files.findIndex(f => f.filename === filename);
    if (fileIndex < 0) {
      return false;
    }

    // Update file priority
    this.files[fileIndex].priority = priority;

    // Update priority for all combos from this file
    for (const [key, combo] of this.combos.entries()) {
      if (combo.source === filename) {
        combo.priority = priority;
      }
    }

    // Save
    this.save();

    return true;
  }

  /**
   * Shuffle the current queue (Fisher-Yates)
   */
  shuffle() {
    const comboArray = Array.from(this.combos.entries());
    
    // Fisher-Yates shuffle
    for (let i = comboArray.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [comboArray[i], comboArray[j]] = [comboArray[j], comboArray[i]];
    }

    // Rebuild map
    this.combos.clear();
    for (const [key, value] of comboArray) {
      this.combos.set(key, value);
    }

    // Save
    this.save();
  }

  /**
   * Pause queue processing
   */
  pause() {
    this.paused = true;
    this.save();
  }

  /**
   * Resume queue processing
   */
  resume() {
    this.paused = false;
    this.save();
  }

  /**
   * Check if queue is paused
   * @returns {boolean}
   */
  isPaused() {
    return this.paused;
  }

  /**
   * Save queue to disk
   */
  save() {
    const data = {
      files: this.files,
      combos: Array.from(this.combos.entries()),
      paused: this.paused,
      stats: this.stats,
      savedAt: new Date().toISOString()
    };

    const success = writeJSONFileAtomic(this.queueFile, data);
    if (!success) {
      console.error('[QUEUE] Error saving queue');
    }
  }

  /**
   * Load queue from disk
   */
  load() {
    const defaultStats = {
      totalFilesAdded: 0,
      totalCombosAdded: 0,
      totalDuplicatesRemoved: 0,
      totalAlreadyProcessed: 0,
      totalProcessed: 0
    };

    const data = readJSONFile(this.queueFile);
    
    if (!data) {
      console.log('[QUEUE] No existing queue file, starting fresh');
      return;
    }

    this.files = data.files || [];
    this.paused = data.paused || false;
    this.stats = data.stats || defaultStats;

    // Rebuild combos map
    this.combos.clear();
    if (data.combos && Array.isArray(data.combos)) {
      for (const [key, value] of data.combos) {
        this.combos.set(key, value);
      }
    }

    console.log('[QUEUE] ✅ Loaded queue:');
    console.log(`  Files: ${this.files.length} | Combos: ${this.combos.size} | Paused: ${this.paused}`);
  }

  /**
   * Clear completed entries
   * @returns {number} Number of files cleared
   */
  clearCompleted() {
    const initialCount = this.files.length;
    this.files = this.files.filter(f => f.status !== 'completed');
    const cleared = initialCount - this.files.length;

    if (cleared > 0) {
      this.save();
    }

    return cleared;
  }

  /**
   * Get the delay to wait before processing the next file
   * @returns {number} Delay in milliseconds
   */
  getListDelay() {
    let delay = this.listDelay;
    
    if (this.listDelayJitter > 0) {
      const jitter = Math.floor(Math.random() * this.listDelayJitter);
      delay += jitter;
    }

    return delay;
  }
}

module.exports = ComboQueue;
