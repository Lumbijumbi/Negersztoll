#!/usr/bin/env node
/**
 * Workflow Manager - High-level workflow automation
 * 
 * This script provides automated workflows for common project management tasks,
 * building on top of the projectTracker utility.
 * 
 * Usage:
 *   node utils/workflowManager.js <workflow> [options]
 * 
 * Workflows:
 *   initiate-review       - Start the stakeholder review process
 *   approve-all           - Mark all stakeholders as approved
 *   setup-phase1          - Complete Phase 1 resource allocation and setup
 *   start-sprint          - Start a new sprint with proper initialization
 *   complete-sprint       - Mark sprint as complete and prepare next sprint
 *   weekly-update         - Generate weekly status update report
 */

const fs = require('fs');
const path = require('path');
const projectTracker = require('./projectTracker');

// Configuration
const PROJECT_STATUS_FILE = path.join(__dirname, '..', 'PROJECT_STATUS.md');

// Constants
const STAKEHOLDERS = [
  'Project Owner',
  'Technical Lead',
  'UX Lead',
  'Security Team',
  'QA Lead'
];

const PHASE1_TEAM = [
  { role: 'Lead Developer', name: 'Alex Chen' },
  { role: 'UX Developer', name: 'Jordan Miller' },
  { role: 'Frontend Developer', name: 'Sam Rivera' },
  { role: 'QA Engineer', name: 'Taylor Kim' },
  { role: 'Technical Writer', name: 'Morgan Lee' }
];

const PHASE1_START_DATE = '2026-02-03';
const PHASE1_END_DATE = '2026-03-14';

// Regex patterns for parsing PROJECT_STATUS.md
// Matches the current phase line: **Phase**: Pre-Phase 1 - Planning & Preparation
const PHASE_EXTRACTION_REGEX = /\*\*Phase\*\*: (.+)/;

// Matches assigned resources (non-TBD entries in resource tables)
// Format: | **Role Name** | Team Member Name |
const ASSIGNED_RESOURCES_REGEX = /\| \*\*.*?\*\* \| (?!TBD)[^|]+/g;

// Matches pending resources (TBD entries in resource tables)
// Format: | **Role Name** | TBD |
const PENDING_RESOURCES_REGEX = /\| \*\*.*?\*\* \| TBD/g;

/**
 * Initiate the stakeholder review process
 */
function initiateReview() {
  console.log('🔄 Initiating Stakeholder Review Process...\n');
  
  STAKEHOLDERS.forEach(stakeholder => {
    try {
      projectTracker.updateApproval(stakeholder, '🔄 In Review');
      console.log(`✓ ${stakeholder} marked as "In Review"`);
    } catch (error) {
      console.error(`✗ Failed to update ${stakeholder}: ${error.message}`);
    }
  });
  
  console.log('\n✅ All stakeholders have been marked for review.');
  console.log('💡 Next steps:');
  console.log('   - Schedule review meetings');
  console.log('   - Send plan documents to stakeholders');
  console.log('   - Use "approve-all" workflow when reviews complete\n');
}

/**
 * Approve all stakeholders (bulk approval)
 */
function approveAll() {
  console.log('✅ Approving All Stakeholders...\n');
  
  const date = new Date().toISOString().split('T')[0];
  
  STAKEHOLDERS.forEach(stakeholder => {
    try {
      projectTracker.updateApproval(stakeholder, '✅ Approved', date);
      console.log(`✓ ${stakeholder} approved`);
    } catch (error) {
      console.error(`✗ Failed to approve ${stakeholder}: ${error.message}`);
    }
  });
  
  console.log('\n✅ All stakeholders have approved the plan!');
  console.log('💡 Next steps:');
  console.log('   - Use "setup-phase1" workflow to prepare Phase 1');
  console.log('   - Complete environment setup');
  console.log('   - Schedule Phase 1 kickoff meeting\n');
}

/**
 * Set up Phase 1 with resources and environment
 */
function setupPhase1() {
  console.log('🚀 Setting Up Phase 1: Foundation & UX Enhancements...\n');
  
  console.log('📋 Step 1: Assigning team members...');
  
  PHASE1_TEAM.forEach(member => {
    try {
      projectTracker.assignResource('1', member.role, member.name, PHASE1_START_DATE, PHASE1_END_DATE);
      console.log(`✓ ${member.name} assigned as ${member.role}`);
    } catch (error) {
      console.error(`✗ Failed to assign ${member.name}: ${error.message}`);
    }
  });
  
  console.log('\n📋 Step 2: Marking environment setup items...');
  const setupItems = [
    'Node.js Environment',
    'Repository Setup',
    'IDE Configuration',
    'Dependencies Installation'
  ];
  
  setupItems.forEach(item => {
    try {
      projectTracker.updateSetupItem(item, true);
      console.log(`✓ ${item} complete`);
    } catch (error) {
      console.error(`✗ Failed to update ${item}: ${error.message}`);
    }
  });
  
  console.log('\n✅ Phase 1 setup complete!');
  console.log('💡 Next steps:');
  console.log('   - Schedule kickoff meeting');
  console.log('   - Use "start-sprint" workflow to begin Sprint 1');
  console.log('   - Review Phase 1 objectives with team\n');
}

/**
 * Start a new sprint
 */
function startSprint(sprintNumber, startDate, endDate) {
  if (!sprintNumber || !startDate || !endDate) {
    console.error('❌ Usage: start-sprint <number> <startDate> <endDate>');
    console.error('   Example: start-sprint 1 2026-02-03 2026-02-14');
    process.exit(1);
  }
  
  console.log(`🏃 Starting Sprint #${sprintNumber}...\n`);
  console.log(`📅 Sprint Period: ${startDate} to ${endDate}`);
  
  console.log('\n✅ Sprint initialized!');
  console.log('💡 Manual steps required:');
  console.log('   - Update Sprint Backlog in PROJECT_STATUS.md');
  console.log('   - Assign tasks to team members');
  console.log('   - Schedule daily standups');
  console.log('   - Set up sprint board (if using Jira/GitHub Projects)\n');
}

/**
 * Complete a sprint and prepare for next
 */
function completeSprint(sprintNumber, accomplishments) {
  if (!sprintNumber) {
    console.error('❌ Usage: complete-sprint <number> [accomplishments]');
    console.error('   Example: complete-sprint 1 "Menu system;Navigation;Icons"');
    process.exit(1);
  }
  
  console.log(`✅ Completing Sprint #${sprintNumber}...\n`);
  
  if (accomplishments) {
    console.log('📝 Sprint Accomplishments:');
    accomplishments.split(';').forEach(item => {
      console.log(`   ✓ ${item.trim()}`);
    });
  }
  
  console.log('\n💡 Sprint completion checklist:');
  console.log('   [ ] Hold sprint review/demo');
  console.log('   [ ] Conduct sprint retrospective');
  console.log('   [ ] Update Sprint Backlog with actual hours');
  console.log('   [ ] Document lessons learned in PROJECT_STATUS.md');
  console.log('   [ ] Update task statuses to "Complete"');
  console.log('   [ ] Plan next sprint tasks');
  console.log('   [ ] Use "start-sprint" for next sprint\n');
}

/**
 * Generate a weekly status update report
 */
function weeklyUpdate() {
  console.log('📊 Generating Weekly Status Update...\n');
  
  try {
    const content = projectTracker.readProjectStatus();
    
    // Extract key metrics
    const phaseMatch = content.match(PHASE_EXTRACTION_REGEX);
    const phase = phaseMatch ? phaseMatch[1] : 'Unknown';
    
    const pendingApprovals = (content.match(/⏳ Pending/g) || []).length;
    const inReview = (content.match(/🔄 In Review/g) || []).length;
    const approved = (content.match(/✅ Approved/g) || []).length;
    
    const resourcesAssigned = (content.match(ASSIGNED_RESOURCES_REGEX) || []).length;
    const resourcesPending = (content.match(PENDING_RESOURCES_REGEX) || []).length;
    
    const setupComplete = (content.match(/- \[x\]/g) || []).length;
    const setupPending = (content.match(/- \[ \]/g) || []).length;
    
    // Calculate progress percentages
    const totalApprovals = approved + inReview + pendingApprovals;
    const approvalProgress = totalApprovals > 0 ? Math.round((approved / totalApprovals) * 100) : 0;
    
    const totalResources = resourcesAssigned + resourcesPending;
    const resourceProgress = totalResources > 0 ? Math.round((resourcesAssigned / totalResources) * 100) : 0;
    
    const totalSetup = setupComplete + setupPending;
    const setupProgress = totalSetup > 0 ? Math.round((setupComplete / totalSetup) * 100) : 0;
    
    const reportDate = new Date().toISOString().split('T')[0];
    
    // Generate report content
    const reportContent = generateReportContent({
      reportDate,
      phase,
      approved,
      inReview,
      pendingApprovals,
      approvalProgress,
      resourcesAssigned,
      resourcesPending,
      resourceProgress,
      setupComplete,
      setupPending,
      setupProgress
    });
    
    // Display to console
    console.log('═══════════════════════════════════════════════════════');
    console.log('           WEEKLY PROJECT STATUS REPORT');
    console.log('═══════════════════════════════════════════════════════\n');
    console.log(`📅 Report Date: ${reportDate}`);
    console.log(`🎯 Current Phase: ${phase}\n`);
    console.log('📋 STAKEHOLDER APPROVALS');
    console.log(`   ✅ Approved: ${approved}`);
    console.log(`   🔄 In Review: ${inReview}`);
    console.log(`   ⏳ Pending: ${pendingApprovals}\n`);
    console.log('👥 RESOURCE ALLOCATION');
    console.log(`   ✅ Assigned: ${resourcesAssigned} roles`);
    console.log(`   ⏳ Pending: ${resourcesPending} roles\n`);
    console.log('🔧 ENVIRONMENT SETUP');
    console.log(`   ✅ Complete: ${setupComplete} items`);
    console.log(`   ⏳ Pending: ${setupPending} items\n`);
    console.log('📈 OVERALL PROGRESS');
    console.log(`   Approvals: ${approvalProgress}%`);
    console.log(`   Resources: ${resourceProgress}%`);
    console.log(`   Setup: ${setupProgress}%\n`);
    console.log('═══════════════════════════════════════════════════════\n');
    
    // Save report to file
    const reportDir = path.join(__dirname, '..', 'reports');
    if (!fs.existsSync(reportDir)) {
      fs.mkdirSync(reportDir, { recursive: true });
    }
    
    const reportFile = path.join(reportDir, `weekly-status-${reportDate}.txt`);
    fs.writeFileSync(reportFile, reportContent.trim());
    console.log(`📄 Report saved to: ${reportFile}`);
    console.log('💡 Use this report for stakeholder communications\n');
    
  } catch (error) {
    console.error('❌ Error generating report:', error.message);
    process.exit(1);
  }
}

/**
 * Generate report content from metrics
 */
function generateReportContent(metrics) {
  return `
WEEKLY PROJECT STATUS REPORT
Report Date: ${metrics.reportDate}
Current Phase: ${metrics.phase}

STAKEHOLDER APPROVALS
  Approved: ${metrics.approved}
  In Review: ${metrics.inReview}
  Pending: ${metrics.pendingApprovals}
  Progress: ${metrics.approvalProgress}%

RESOURCE ALLOCATION
  Assigned: ${metrics.resourcesAssigned} roles
  Pending: ${metrics.resourcesPending} roles
  Progress: ${metrics.resourceProgress}%

ENVIRONMENT SETUP
  Complete: ${metrics.setupComplete} items
  Pending: ${metrics.setupPending} items
  Progress: ${metrics.setupProgress}%

OVERALL PROGRESS
  Approvals: ${metrics.approvalProgress}%
  Resources: ${metrics.resourceProgress}%
  Setup: ${metrics.setupProgress}%
`;
}

/**
 * Display help information
 */
function displayHelp() {
  console.log(`
📋 Workflow Manager - Project Management Automation

USAGE:
  node utils/workflowManager.js <workflow> [options]

WORKFLOWS:
  initiate-review
      Start the stakeholder review process by marking all stakeholders as "In Review"
      Example: node utils/workflowManager.js initiate-review
      
  approve-all
      Bulk approve all stakeholders (after reviews are complete)
      Example: node utils/workflowManager.js approve-all
      
  setup-phase1
      Complete Phase 1 resource allocation and environment setup
      Example: node utils/workflowManager.js setup-phase1
      
  start-sprint <number> <startDate> <endDate>
      Initialize a new sprint with proper setup
      Example: node utils/workflowManager.js start-sprint 1 2026-02-03 2026-02-14
      
  complete-sprint <number> [accomplishments]
      Mark sprint as complete and provide completion checklist
      Example: node utils/workflowManager.js complete-sprint 1 "Menu;Navigation;Icons"
      
  weekly-update
      Generate a weekly status update report
      Example: node utils/workflowManager.js weekly-update

TYPICAL WORKFLOW SEQUENCE:
  1. initiate-review      # Start stakeholder reviews
  2. approve-all          # After all stakeholders approve
  3. setup-phase1         # Prepare Phase 1 resources and environment
  4. start-sprint 1 ...   # Begin first sprint
  5. weekly-update        # Generate weekly reports
  6. complete-sprint 1    # Finish sprint
  7. start-sprint 2 ...   # Continue with next sprint

For detailed project tracking commands, see:
  node utils/projectTracker.js --help

For more information:
  - See docs/PROJECT_TRACKING_QUICKSTART.md
  - See PROJECT_STATUS.md
`);
}

// Main CLI handler
function main() {
  const args = process.argv.slice(2);
  
  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') {
    displayHelp();
    return;
  }
  
  const workflow = args[0];
  
  try {
    switch (workflow) {
      case 'initiate-review':
        initiateReview();
        break;
        
      case 'approve-all':
        approveAll();
        break;
        
      case 'setup-phase1':
        setupPhase1();
        break;
        
      case 'start-sprint':
        startSprint(args[1], args[2], args[3]);
        break;
        
      case 'complete-sprint':
        completeSprint(args[1], args[2]);
        break;
        
      case 'weekly-update':
        weeklyUpdate();
        break;
        
      default:
        console.error(`❌ Unknown workflow: ${workflow}`);
        console.log('Run with --help to see available workflows');
        process.exit(1);
    }
  } catch (error) {
    console.error('❌ Error:', error.message);
    console.error(error.stack);
    process.exit(1);
  }
}

// Run if called directly
if (require.main === module) {
  main();
}

// Export functions for use as a module
module.exports = {
  initiateReview,
  approveAll,
  setupPhase1,
  startSprint,
  completeSprint,
  weeklyUpdate
};
