/**
 * File Helper Utility
 * Centralized file I/O operations to reduce code duplication
 */

const fs = require('fs');
const path = require('path');

/**
 * Safely read and parse a JSON file
 * @param {string} filepath - Path to JSON file
 * @param {*} defaultValue - Default value if file doesn't exist or parse fails
 * @returns {*} Parsed JSON data or defaultValue
 */
function readJSONFile(filepath, defaultValue = null) {
  try {
    if (!fs.existsSync(filepath)) {
      return defaultValue;
    }
    const content = fs.readFileSync(filepath, 'utf8');
    return JSON.parse(content);
  } catch (error) {
    console.warn(`[FileHelper] Failed to read/parse JSON file ${filepath}: ${error.message}`);
    return defaultValue;
  }
}

/**
 * Safely write data to a JSON file
 * @param {string} filepath - Path to JSON file
 * @param {*} data - Data to write
 * @param {object} options - Options for JSON.stringify (default: { pretty: true })
 * @returns {boolean} True if successful, false otherwise
 */
function writeJSONFile(filepath, data, options = { pretty: true }) {
  try {
    const jsonString = options.pretty 
      ? JSON.stringify(data, null, 2) 
      : JSON.stringify(data);
    fs.writeFileSync(filepath, jsonString, 'utf8');
    return true;
  } catch (error) {
    console.error(`[FileHelper] Failed to write JSON file ${filepath}: ${error.message}`);
    return false;
  }
}

/**
 * Atomically write data to a JSON file using temp file + rename
 * @param {string} filepath - Path to JSON file
 * @param {*} data - Data to write
 * @param {object} options - Options for JSON.stringify (default: { pretty: true })
 * @returns {boolean} True if successful, false otherwise
 */
function writeJSONFileAtomic(filepath, data, options = { pretty: true }) {
  try {
    const jsonString = options.pretty 
      ? JSON.stringify(data, null, 2) 
      : JSON.stringify(data);
    
    const tempFile = `${filepath}.tmp`;
    fs.writeFileSync(tempFile, jsonString, 'utf8');
    fs.renameSync(tempFile, filepath);
    return true;
  } catch (error) {
    console.error(`[FileHelper] Failed to write JSON file atomically ${filepath}: ${error.message}`);
    return false;
  }
}

/**
 * Read a text file and return its content
 * @param {string} filepath - Path to text file
 * @param {string} defaultValue - Default value if file doesn't exist
 * @returns {string} File content or defaultValue
 */
function readTextFile(filepath, defaultValue = '') {
  try {
    if (!fs.existsSync(filepath)) {
      return defaultValue;
    }
    return fs.readFileSync(filepath, 'utf8');
  } catch (error) {
    console.warn(`[FileHelper] Failed to read text file ${filepath}: ${error.message}`);
    return defaultValue;
  }
}

/**
 * Write text content to a file
 * @param {string} filepath - Path to text file
 * @param {string} content - Content to write
 * @returns {boolean} True if successful, false otherwise
 */
function writeTextFile(filepath, content) {
  try {
    fs.writeFileSync(filepath, content, 'utf8');
    return true;
  } catch (error) {
    console.error(`[FileHelper] Failed to write text file ${filepath}: ${error.message}`);
    return false;
  }
}

/**
 * Ensure a directory exists, creating it if necessary
 * @param {string} dirPath - Directory path
 * @param {boolean} recursive - Create parent directories if needed (default: true)
 * @returns {boolean} True if directory exists/created, false on error
 */
function ensureDirectory(dirPath, recursive = true) {
  try {
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive });
    }
    return true;
  } catch (error) {
    console.error(`[FileHelper] Failed to create directory ${dirPath}: ${error.message}`);
    return false;
  }
}

/**
 * Ensure multiple directories exist
 * @param {string[]} dirPaths - Array of directory paths
 * @param {boolean} recursive - Create parent directories if needed (default: true)
 * @returns {boolean} True if all directories exist/created, false if any failed
 */
function ensureDirectories(dirPaths, recursive = true) {
  let allSuccess = true;
  for (const dirPath of dirPaths) {
    if (!ensureDirectory(dirPath, recursive)) {
      allSuccess = false;
    }
  }
  return allSuccess;
}

module.exports = {
  readJSONFile,
  writeJSONFile,
  writeJSONFileAtomic,
  readTextFile,
  writeTextFile,
  ensureDirectory,
  ensureDirectories
};
