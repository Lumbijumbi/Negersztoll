/**
 * Form filling utilities with character-by-character priority
 */
const config = require('./config');

/**
 * Returns true when an error message indicates a fatal browser/context closed condition.
 * @param {string} errMsg - Error message string
 * @returns {boolean}
 */
function isBrowserClosedError(errMsg) {
  if (!errMsg) return false;
  return errMsg.includes('Target page') ||
    errMsg.includes('context or browser has been closed') ||
    errMsg.includes('browser has been closed') ||
    errMsg.includes('context was destroyed') ||
    errMsg.includes('session closed') ||
    errMsg.includes('page crashed');
}

/**
 * Fill form field with realistic typing (character-by-character FIRST)
 * Uses page.keyboard for typing to avoid per-character element refocusing.
 * No page.fill() or page.evaluate() fallbacks — these create synthetic events
 * that DataDome detects (isTrusted:false, missing keyboard event chain).
 * 
 * @param {Page} page - Playwright page object
 * @param {string} selector - CSS selector for input field
 * @param {string} text - Text to fill
 * @param {Object} options - Additional options
 * @returns {Promise<boolean>} - True if successful
 */
async function fastFill(page, selector, text, options = {}) {
  const {
    typeDelayMin = config.form.typeDelayMin,
    typeDelayMax = config.form.typeDelayMax,
    clearFirst = true,
    logPrefix = '[fastFill]'
  } = options;

  // Guard against a closed/crashed browser before attempting any interaction
  try {
    if (page.isClosed && page.isClosed()) {
      console.warn(`${logPrefix} Page is closed, aborting form fill for ${selector}`);
      return false;
    }
  } catch (_) {
    console.warn(`${logPrefix} Page state check failed, aborting form fill for ${selector}`);
    return false;
  }

  try {
    // Step 1: Click to focus (and optionally select all content for clearing)
    // Uses native Patchright click — produces trusted pointer/mouse events.
    if (clearFirst) {
      try {
        await page.locator(selector).click({ clickCount: 3 }).catch(() => {});
        await page.keyboard.press('Backspace').catch(() => {});
      } catch (e) {
        console.warn(`${logPrefix} Failed to clear field ${selector}`);
      }
    } else {
      try {
        await page.locator(selector).click().catch(() => {});
      } catch (e) {
        console.warn(`${logPrefix} Failed to focus on ${selector}`);
      }
    }

    // Step 2: TYPE CHARACTER-BY-CHARACTER via keyboard
    // page.keyboard.type() sends keys to the currently focused element without
    // re-focusing via selector lookup — matching how a real user types.
    console.log(`${logPrefix} Typing character-by-character into ${selector}`);
    let successfulChars = 0;
    let browserClosed = false;

    for (const char of text) {
      try {
        const delay = Math.floor(Math.random() * (typeDelayMax - typeDelayMin + 1)) + typeDelayMin;
        await new Promise(r => setTimeout(r, delay));
        await page.keyboard.type(char);
        if (browserClosed) break;
        successfulChars++;
      } catch (e) {
        const errMsg = (e && e.message) || '';
        if (isBrowserClosedError(errMsg)) {
          browserClosed = true;
          break;
        }
        console.warn(`${logPrefix} Failed to type char '${char}'`);
      }
    }

    if (browserClosed) {
      console.warn(`${logPrefix} Browser/context closed during character typing, aborting`);
      return false;
    }

    console.log(`${logPrefix} Typed ${successfulChars}/${text.length} characters successfully`);

    // Step 3: Verify the value was set
    const filledValue = await page.inputValue(selector).catch(() => '');
    if (filledValue === text) {
      console.log(`${logPrefix} ✓ Character-by-character fill successful for ${selector}`);
      return true;
    }

    // Do NOT fall back to page.fill() or page.evaluate() — they create detectable
    // synthetic events (missing keyboard chain, isTrusted:false).
    console.warn(`${logPrefix} ✗ Fill verification failed for ${selector} (${filledValue.length}/${text.length} chars)`);
    return false;

  } catch (error) {
    console.error(`${logPrefix} Unexpected error: `, error?.message);
    return false;
  }
}

/**
 * Fill multiple form fields in sequence
 * @param {Page} page - Playwright page object
 * @param {Object} fieldMap - { selector: value, ...  }
 * @param {Object} options - Additional options
 * @returns {Promise<Object>} - { success: boolean, filled: number, total: number }
 */
async function fillForm(page, fieldMap, options = {}) {
  let filledCount = 0;
  const totalCount = Object.keys(fieldMap).length;

  for (const [selector, value] of Object.entries(fieldMap)) {
    const success = await fastFill(page, selector, value, options);
    if (success) filledCount++;
  }

  return {
    success: filledCount === totalCount,
    filled: filledCount,
    total: totalCount
  };
}

module.exports = {
  fastFill,
  fillForm,
  isBrowserClosedError
};