# Security Policy

## Purpose and Scope

SuPerrMurrer is an educational tool designed for authorized security testing and research. This security policy covers:

- Responsible disclosure of vulnerabilities
- Supported versions
- Security best practices for users
- Reporting procedures

## Supported Versions

We actively maintain and provide security updates for the following versions:

| Version | Supported          |
| ------- | ------------------ |
| 2.x.x   | :white_check_mark: |
| < 2.0   | :x:                |

## Responsible Use

### Authorized Use Only

This tool must ONLY be used for:

- Systems you own
- Systems you have explicit written authorization to test
- Educational purposes in controlled environments
- Security research with proper authorization
- Penetration testing engagements with signed contracts

### Prohibited Use

DO NOT use this tool for:

- Unauthorized access to systems
- Illegal activities
- Testing systems without permission
- Causing harm or damage
- Violating terms of service
- Any malicious purposes

## Security Best Practices

### For Users

1. **Protect Credentials**
   - Store credential files (`test.txt`) with restricted permissions (600)
   - Never commit credentials to version control
   - Use `.env` files for sensitive configuration
   - Encrypt stored credentials when possible

2. **Secure Proxies**
   - Only use trusted proxy providers
   - Protect proxy authentication credentials
   - Verify proxy endpoints before use
   - Monitor proxy usage for anomalies

3. **Log Security**
   - Restrict access to log directories (logs/)
   - Logs contain sensitive credential information
   - Regularly purge old logs
   - Consider encrypting log archives

4. **Session Management**
   - Protect session files in `sessions/` directory
   - Set appropriate file permissions (600)
   - Regularly clean expired sessions
   - Never share session files

5. **Network Security**
   - Use HTTPS for webhook notifications
   - Validate webhook URLs before configuring
   - Use VPN or secure networks when testing
   - Monitor network traffic for anomalies

6. **Environment Variables**
   - Never commit `.env` files
   - Use strong values for sensitive settings
   - Rotate credentials regularly
   - Audit environment variable usage

### For Developers

1. **Code Security**
   - Validate all user inputs
   - Sanitize data before logging
   - Use parameterized queries (if using databases)
   - Avoid eval() and similar dangerous functions
   - Keep dependencies updated

2. **Dependency Management**
   - Regularly run `npm audit`
   - Update dependencies promptly
   - Review dependency changes
   - Use lock files (package-lock.json)

3. **Secrets Management**
   - Never hardcode secrets
   - Use environment variables
   - Implement secure secret storage
   - Rotate API keys and tokens

## Reporting a Vulnerability

### What to Report

Please report:

- Security vulnerabilities in the code
- Authentication bypass issues
- Data exposure risks
- Dependency vulnerabilities
- Configuration security issues
- Any security concerns

### How to Report

**DO NOT** create public GitHub issues for security vulnerabilities.

Instead:

1. **Email**: Send details to the repository maintainer via GitHub
2. **Include**:
   - Description of the vulnerability
   - Steps to reproduce
   - Potential impact
   - Suggested fix (if any)
   - Your contact information

### Response Timeline

- **Initial Response**: Within 48 hours
- **Assessment**: Within 1 week
- **Fix Timeline**: Depends on severity
  - Critical: 1-3 days
  - High: 1-2 weeks
  - Medium: 2-4 weeks
  - Low: Next release cycle

### Disclosure Policy

We follow **coordinated disclosure**:

1. Report received and acknowledged
2. Vulnerability confirmed and assessed
3. Fix developed and tested
4. Security advisory drafted
5. Fix released
6. Public disclosure (after fix is available)

Typical timeline: 30-90 days from report to disclosure.

## Security Advisories

Security advisories will be published:

- In GitHub Security Advisories
- In CHANGELOG.md
- Via repository notifications

## Security Features

### Current Protections

1. **Input Validation**: All user inputs are validated
2. **Error Handling**: Errors don't expose sensitive data
3. **Credential Storage**: Plain text with permission warnings
4. **Session Security**: Time-limited with expiration
5. **Proxy Security**: Authentication support
6. **Rate Limiting**: Built-in for webhooks
7. **Logging Controls**: Configurable log levels

### Planned Enhancements

- [ ] Credential encryption at rest
- [ ] Certificate pinning for webhooks
- [ ] Two-factor authentication support
- [ ] Audit logging
- [ ] Encrypted log storage
- [ ] API key management
- [ ] Role-based access control (for GUI)

## Legal Notice

**IMPORTANT**: Unauthorized access to computer systems is illegal and may violate:

- Computer Fraud and Abuse Act (CFAA) - United States
- Computer Misuse Act - United Kingdom
- Similar laws in other jurisdictions

Users are solely responsible for:

- Obtaining proper authorization
- Complying with applicable laws
- Using the tool ethically and legally

The authors and contributors:

- Provide this tool for educational purposes only
- Are not responsible for misuse
- Do not condone illegal activities
- Will cooperate with law enforcement if misuse is reported

## Compliance

### Data Protection

If processing personal data, users must comply with:

- GDPR (European Union)
- CCPA (California)
- Other applicable privacy laws

### Responsible Disclosure

We encourage:

- Responsible disclosure of vulnerabilities
- Ethical security research
- Collaboration to improve security
- Following this policy when reporting issues

## Questions?

For security questions or concerns:

- Review this document
- Check existing documentation
- Contact repository maintainers
- Create a security advisory (for verified vulnerabilities)

---

**Last Updated**: 2026-03-04

**This is a living document and may be updated as needed.**
