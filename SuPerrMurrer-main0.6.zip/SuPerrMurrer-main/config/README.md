# Configuration Management

This directory contains environment-specific configuration files for SuPerrMurrer.

## Structure

- `default.js` - Base configuration with all default values
- `development.js` - Development environment overrides
- `production.js` - Production environment overrides  
- `test.js` - Test environment overrides
- `index.js` - Configuration loader that merges configs based on NODE_ENV

## Usage

The configuration system automatically loads the appropriate config based on the `NODE_ENV` environment variable:

```bash
# Development (default)
NODE_ENV=development npm start

# Production
NODE_ENV=production npm start

# Test
NODE_ENV=test npm test
```

## Configuration Priority

Configurations are loaded and merged in this order:
1. `default.js` - Base configuration
2. Environment-specific file (e.g., `production.js`)
3. Environment variables (highest priority)

## Environment Variables

You can override any configuration value using environment variables:

```bash
# Override browser headless mode
BROWSER_HEADLESS=true npm start

# Override max workers
MAX_WORKERS=8 npm start

# Override GUI port
GUI_PORT=4000 npm run gui
```

## Creating Custom Configurations

To add a new environment (e.g., `staging`):

1. Create `config/staging.js`
2. Add environment-specific overrides
3. Run with `NODE_ENV=staging npm start`

## Security Notes

- Never commit sensitive values (passwords, API keys, secrets) to config files
- Use environment variables or a secrets manager for sensitive data
- In production, set `NODE_ENV=production` for optimized settings

## Example

```javascript
// config/production.js
module.exports = {
  browser: {
    headless: true,
    dumpio: false
  },
  batch: {
    maxParallelWorkers: 8
  },
  logging: {
    level: 'info'
  }
};
```

Then run: `NODE_ENV=production npm start`
